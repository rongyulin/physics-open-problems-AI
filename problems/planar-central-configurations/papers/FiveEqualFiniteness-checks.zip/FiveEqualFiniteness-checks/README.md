# Exact checks for generic finiteness on the five-equal-mass line

This is the computational supplement to the English manuscript by Chatgpt on planar Newtonian six-body central configurations with positive masses proportional to `(1,1,1,1,1,t)`. It supplies the inputs and executable checks for the proof along the mass-two specialization in residue characteristic 65521. The mathematical argument connecting these checks to finiteness up to similarity is in the accompanying article.

## Start here

Use Python 3.11 or later, SymPy 1.14.0, python-flint 0.8.0, Z3 and msolve 0.10.1. The runs supplied here used Z3 4.13.3 on Linux. Install the `msolve` binary on the executable search path. The valuation tests use `z3` on that path or the system Z3 shared library. The Python packages can be installed in a virtual environment. The commands below start in the extracted directory containing this README.

```sh
python3 -m pip install sympy==1.14.0 python-flint==0.8.0
sha256sum -c SHA256SUMS
python3 run.py arithmetic
```

The last command checks all the arithmetic groups listed below. It stops on the first failed check. Keep Python assertions enabled. A single group can be run as, for example, `python3 run.py diagram98`. The two commands under “Rebuilding the catalogue” audit the cell enumeration separately. No earlier manuscript, local project checkout or nested project archive is required.

## What each group checks

| Group | Calculation | Checkpoints |
| --- | --- | --- |
| `diagram98` | Factor the three-body shape equations, enclose every admissible projected root at mass 3 in certified complex disks, and test the leading signed torque and the two distinct cubic obstructions. | 26 and 30 roots, 199,680 leading combinations, 840 cubic tests. The JSON file stores starting centers; the program proves their enclosures. |
| `diagram94` | Check all fourteen shared-mass projections and the possible persistent seeds. Test their transverse Hessians and reduced cubic obstructions. Recompute the integer gcds for a marked binary. Exhaust the outer-mass valuations, initial ideals and lifts. | Fourteen complete test fibres over characteristic 673. The equilateral and collinear tests each cover 864 tuples, in characteristics 73 and 97 respectively. The outer lift tests all 144 choices to order eight at both primes 97 and 193. |
| `diagram88-boundary` | Encode translated subset force constraints and triangle minima in exact linear arithmetic. Test the four discarded boundary patterns in characteristic 65521 and the planar Gram determinant on the zero-stress chart. | Two unsatisfiable support queries, boundary counts 32/4/64/12 and 243 nonzero Gram determinants. |
| `diagram88-rank` | Exclude the zero-multiplier, four-collinear and three-collinear cases in the specialized quartet over the algebraic closure. The rational-field checks in some of these scripts are additional. | Every absolute noncollinear edge class, 32 line sign choices in the separate absolute check, six sign representatives for the four-collinear calculation, 64 three-collinear cases over each of two fields. |
| `diagram88-regular` | Build the three quartet ideals; derive their quotient dimensions by deterministic Gröbner bases; verify the squarefree parametrizations, all orderings, both projections and every torque sign by finite-algebra norms. | Chart dimensions 420, 4 and 102. The JSON records provide checked parametrizations; the independent dimension upper bound supplies completeness. |
| `physical` | Check the interval bounds for the four-equal-mass kite and supplementary binary-mass energy inequalities. | A rational contraction enclosure; both signs of the real inequalities and the nonreal-ratio resultant. |

The primary diagram-88 dimension calculation uses msolve. If Singular is available, `python3 run.py diagram88-regular --engine singular` asks it to compute the same dimensions. For a second implementation of just the dimension step, check out [OpenF4 at revision 7155c6e](https://github.com/nauotit/openf4/tree/7155c6ec4e5f776e0e12202716dc7da58469e77b) and run `python3 diagram88/OpenF4Dimension88.py /path/to/openf4` on x86 with SSE4.2, OpenMP and a C++14 compiler. Running `python3 diagram88/RegularQuartet88.py --points-only` skips the dimension upper bound.

## Rebuilding the catalogue

The initial data are the published cells and proof certificates for Tejasvi Tomar's generic-mass six-body theorem. The label of a cell in this supplement is a Tomar class number and its zero-based cell index, followed by a distinguished mass slot numbered from one. The diagram number in the result columns uses the Chang–Chen numbering.

1. Obtain the [Tomar source checkout](https://github.com/tejasvi/smale6-six-bodies-generic/tree/84bbcf276d029fdf31375c4a21c6a7e136955e51) at commit `84bbcf276d029fdf31375c4a21c6a7e136955e51`. It includes the 191 compressed cell inputs, diagram labels, core metadata and the 66 cell-to-core link files.
2. Obtain certificate parts `smale6-six-bodies-generic-lean-certs.tar.xz.part000` through `.part021` and `smale6-six-bodies-generic-hand-explanations-data.tar.xz` from [Zenodo record 23472605](https://doi.org/10.5281/zenodo.23472605). In the download directory join the parts in numerical order.

```sh
cat smale6-six-bodies-generic-lean-certs.tar.xz.part[0-9][0-9][0-9] > lean-certs.tar.xz
```

3. From the supplement run the complete census, substituting your input paths.

```sh
python3 run.py catalogue \
  --source /path/to/smale6-six-bodies-generic \
  --cores /path/to/lean-certs.tar.xz \
  --hand /path/to/smale6-six-bodies-generic-hand-explanations-data.tar.xz
```

The driver hashes the reassembled certificate archive (`f3db395afcdb965d932c609064811bcb857d0ad9e37538173b8d33ad14a2bd67`), the hand archive (`4fbe286ef6ef663b7d7b8b9ed74e5a1e100d65d714697ceaa97a0ae93f6de4bb`) and the upstream manifests and metadata. The census verifies each decompressed cell file and the individual certificates against the pinned manifests. It enumerates 232,788 marked placements of the 38,798 core-assigned cells. After specializing the core identities, 29,669 pairs survive. The triangle, clique and whole-diagram exclusions leave 738 core placements. Adding 114 placements from the 19 surviving unassigned cells gives 852, reduced to 187 placements in 55 orbits. Of these, 90 placements in 29 orbits pass the physical-origin condition. Energy and mass differentiation leave 74 in 22; the last two diagrams leave zero. The program compares the generated CSV files byte-for-byte against the included intermediate tables. The final ledger labels removals proved by the mathematical arguments and arithmetic tests in the paper; a table entry alone does not prove the indicated obstruction.

With only the pinned source checkout, `python3 run.py ledgers --source /path/to/smale6-six-bodies-generic` starts from the bundled 738-row table and checks all subsequent catalogue steps. Tomar's original Lean verification of the ambient diagram catalogue is a published external input. The upstream data retain their own terms.

## Lean checks

The `lean` subdirectory is an independent Lake project with 19 proof modules and one aggregate import. It pins Lean 4.28.0 and mathlib to commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365`. From this directory run

```sh
cd lean
lake exe cache get
lake build
```

The four diagram-98 modules check shape identities, disks, the leading sign calculation and the cubic tests. Other modules establish the stated field identities and inequalities for the cluster, energy, derivative, cubic-discriminant, torque and Gram arguments. They formalize parts of the proof. The final theorem on real six-body configurations also uses the analytic and algebraic arguments written in the paper and the separate computational checks above.

## Provenance and licensing

The scripts, seeds, chart data and intermediate tables were assembled from the [project at revision 1887f68](https://github.com/rongyulin/physics-open-problems-AI/tree/1887f6835afc2fc59fbdf328a0817d9953ccf524/problems/planar-central-configurations). The diagram-98 files are taken from the parameter-study verification archive distributed in that revision. Paths have been reorganized, and this release supplies a dedicated driver, Lake manifest, file manifest and fresh run transcripts. See `results/` for the checks run for this edition. The optional Singular and OpenF4 commands above are alternatives to the msolve check recorded there. Original code is distributed under the MIT License. Original accompanying prose is distributed under CC BY 4.0. The notices and full texts are in `LICENSE` and `LICENSES/`.
