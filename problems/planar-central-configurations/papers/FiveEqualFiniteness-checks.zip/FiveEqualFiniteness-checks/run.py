"""Replay the finite checks for the five-equal-mass finiteness manuscript."""
import argparse
import hashlib
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
CAT = ROOT / "catalogue"
GROUPS = {
    "diagram98": ["diagram98/SourceAlgebra.py", "diagram98/Diagram98.py", "diagram98/NextTorque.py"],
    "diagram94": ["diagram94/center_shapes.py", "diagram94/equilateral94.py",
                  "diagram94/collinear.py", "diagram94/verify_binary_cluster.py", "diagram94/outer94.py"],
    "diagram88-boundary": ["diagram88/BoundaryOrders88.py", "diagram88/Boundary88.py", "diagram88/ZeroStress88.py"],
    "diagram88-rank": ["diagram88/AbsoluteLine88.py","diagram88/AbsoluteQuartet88.py",
                       "diagram88/CollinearFibre88.py","diagram88/TripleFibre88.py"],
    "diagram88-regular": ["diagram88/RegularQuartet88.py"],
    "physical": ["physical/verify_equal_four.py", "diagram94/physical_windows.py"],
}
SOURCE_FILES = {
    "diagrams/cc_compare.json":"b5fdcb74c29ada7e104b74eda7b8a1f5de7431c2f2cc80011a50568579a15fa5",
    "diagrams/n6.json":"0f2ae5d0e1e8619eeb680c12b04fb168faaa856e43d61b16074df50a874e2ff4",
    "lean/sections3-5/data/f4/cores.jsonl":"d418c4e45eedbce5570089a13a33b8bed16cb423cc61d0ad90a4db2290d10934",
    "lean/sections3-5/data/f4/certs/SHA256SUMS":"f14be1079b0e7cbd8dd3766783aca8c0933889edb1468308f66b1a34680b3fff",
    "lean/sections3-5/data/cells/SHA256SUMS":"deb001fef4cf445f53af88d9c06d20be0ee86dd333a050e50bd9d65fe458b895",
}
def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()
def match(path, expected):
    if digest(path) != expected:
        raise ValueError(f"SHA-256 mismatch for {path}")
def run(script, *args):
    print(f"\n[{script}]", flush=True)
    subprocess.run([sys.executable, str(ROOT / script), *map(str, args)], check=True)
def compare_tables(destination, reference):
    expected = {path.name for path in reference.glob("*.csv")}
    generated = {path.name for path in destination.glob("*.csv")}
    if not expected or generated != expected:
        raise ValueError(f"Incomplete ledger {destination.name}: {sorted(generated)}")
    for path in sorted(destination.glob("*.csv")):
        match(path, digest(reference / path.name))
        print(f"{path.name}: matches the distributed table", flush=True)

def catalogue(args, full):
    source = args.source
    if source is None or (full and (not args.cores or not args.hand)):
        raise SystemExit("Supply --source and, for the complete census, --cores and --hand.")
    for name, sha in SOURCE_FILES.items():
        match(source / name, sha)
    links = sorted((source / "lean/sections3-5/data/f4/links").glob("c*.txt"))
    manifest = "".join(f"{digest(p)}  {p.name}\n" for p in links)
    if len(links) != 66 or hashlib.sha256(manifest.encode("ascii")).hexdigest() != "643d7180f66154ceccb085df135ccaed6d2fc311d27a80ea5f80fa2388f0c286":
        raise ValueError("The upstream manifest of 66 cell-to-certificate links differs.")
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp)
        if full:
            match(args.cores, "f3db395afcdb965d932c609064811bcb857d0ad9e37538173b8d33ad14a2bd67")
            match(args.hand, "4fbe286ef6ef663b7d7b8b9ed74e5a1e100d65d714697ceaa97a0ae93f6de4bb")
            run("catalogue/core_census.py", "--source", source, "--archive", args.cores, "--hand-archive", args.hand,
                "--cliques", "--final-remaining", out/"RemainingCorePlacements.csv")
            match(out/"RemainingCorePlacements.csv",digest(CAT/"RemainingCorePlacements.csv"))
            run("catalogue/diagram8_cover.py", source/"lean/sections3-5/data/cells/c29.jsonl.xz")
        for part in ("reduction","physical-ends","final"):
            run(f"catalogue/{part}/replay.py",source,out/part)
            compare_tables(out/part,CAT/part)
        run("physical/marked_binary.py","--previous",CAT/"reduction")
        run("physical/verify_equal_four.py","--cells",source/"lean/sections3-5/data/cells/c127.jsonl.xz")

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("suite", choices=(*GROUPS, "arithmetic", "ledgers", "catalogue"))
    parser.add_argument("--source", type=Path, help="pinned Tomar source directory")
    parser.add_argument("--cores", type=Path, help="reassembled Zenodo certificate archive")
    parser.add_argument("--hand", type=Path, help="Zenodo hand-explanations data archive")
    parser.add_argument("--engine", default="msolve", choices=["msolve", "singular"])
    args = parser.parse_args()
    if not __debug__:
        raise SystemExit("Run without -O or PYTHONOPTIMIZE. The verifiers use assertions.")
    if args.suite in ("catalogue","ledgers"):
        catalogue(args,args.suite == "catalogue")
        return
    for name in GROUPS if args.suite == "arithmetic" else (args.suite,):
        for script in GROUPS[name]:
            run(script, *(["--engine", args.engine] if name == "diagram88-regular" else []))
if __name__ == "__main__":
    main()
