# Verification record

All eight transcripts in this directory were generated for this edition on 27 November 2026. They record successful exits. The catalogue used the complete external certificate and hand archives. The arithmetic groups used SymPy 1.14.0, python-flint 0.8.0, Z3 4.13.3 and msolve 0.10.1. The Lean log comes from a fresh standalone build of the project's 19 mathematical modules and aggregate import with cached, pinned external mathlib dependencies. A Lake job count includes upstream targets.

The bundled programs and their chart inputs make the new runs reproducible. Reuse of the underlying seeds, integer and finite-field parametrizations, executable tests and starting tables from repository revision 1887f68 is documented in the main README. The OpenF4 and Singular alternatives have no transcript in this edition. The source programs and equations, not the logs, specify the checks.
