"""Check exact identities among the primary JSON, C++ seeds and Lean inputs."""
import json
import re
from fractions import Fraction
from pathlib import Path

directory = Path(__file__).resolve().parent
primary = json.loads((directory / "primaries/primary_centers.json").read_text())
source = (directory / "restricted/RestrictedReplay.lean").read_text()
seeds = iter((directory / "restricted/seeds.txt").read_text().splitlines())
names = set()
for header in seeds:
    name, total = header.split()
    if name in names or name not in primary:
        raise ValueError(f"Unexpected shape {name}")
    names.add(name)
    points = [tuple(map(int, next(seeds).split())) for _ in range(5 + int(total))]
    expected_centres = [tuple(Fraction(s) * 10**12 for s in point) for point in primary[name]]
    if points[:5] != expected_centres:
        raise ValueError(f"Different primary inputs for {name}")
    expression = re.search(r'def ' + re.escape(name) + r' : Shape := ⟨"' + re.escape(name) + r'",(.*?)⟩', source, re.S)
    if expression is None:
        raise ValueError(f"Missing Lean declaration {name}")
    lean_points = [tuple(map(int,pair)) for pair in re.findall(r'\((-?\d+),\s*(-?\d+)\)', expression[1])]
    if lean_points != points:
        raise ValueError(f"Different Lean and C++ inputs for {name}")
    print(f"{name}: five primary coordinates and {total} root coordinate pairs match.")
if names != set(primary) or len(names) != 5:
    raise ValueError("Incomplete set of primary inputs")

hampton_dir = directory / "hampton"
hampton = (hampton_dir / "Hampton.lean").read_text()
for size, prefix in [(6, "six"), (7, "seven")]:
    centers = json.loads((hampton_dir / f"{prefix}_centers.json").read_text())
    for i, (name, coords) in enumerate(centers.items(), start=1):
        search = rf'def s{size}_{i} : Configuration := ⟨"{re.escape(name)}",(.*?)⟩'
        block = re.search(search, hampton, re.S)
        if block is None:
            raise ValueError(f"Missing Hampton configuration {name}")
        actual = [tuple(map(int, pair)) for pair in re.findall(r"\((-?\d+),\s*(-?\d+)\)", block[1])]
        expected = [tuple(Fraction(t) * 10**15 for t in point) for point in coords]
        if actual != expected:
            raise ValueError(f"Different Hampton inputs for {size}/{name}")
    weights = re.search(rf'def weights{size} : List Nat := (\[.*?\])', hampton).group(1)
    symmetry = (hampton_dir / f"{prefix}_symmetries.log").read_text()
    if json.loads(weights) != [int(w) for w in re.findall(r'oriented-labelled=(\d+)', symmetry)]:
        raise ValueError(f"Different multiplicities for {size} bodies")
    print(f"All {len(centers)} equal-{size} coordinate lists and weights match the exact Python checks.")
