# Newtonian Morse polynomials at six and seven equal masses

Read the HamptonMorse paper in the papers directory for the two conjecture statements, the equivalence relation and the proof. Hampton predicted both coefficient lists. The published Moczurad–Zgliczyński catalogue supplies global exhaustiveness. The files here certify the inertia and symmetry data on each of its representatives. The six-body and seven-body coordinate files are part of the input. Run these commands from this directory with ordinary Python 3 and its standard library.

    python3 six_inertia.py .
    python3 orthogonal_stabilizers.py six_centers.json --wide 1e-12 --tight 1e-14 --anchor 4
    python3 verify_indices.py

The third command checks the 14 seven-body representatives, including their symmetries and the coefficient sum. The six-body checker uses the nine weights verified by the second command. Logs are provided for both cases. The scaling makes the total mass and force multiplier one. See Stabilizers.md for the handling of rotations and reflections, and MorseVerification.md for the connection between the normalized Hessian and the shape-space index.

Run `lean -j4 --run Hampton.lean` using Lean 4.28.0 for the independent Std implementation. It proves the two closed computational theorems `HamptonReplay.hampton6` and `HamptonReplay.hampton7`. The 23 interval Hessian and pivot computations and the resulting weighted sums reduce in the kernel. See LeanVerification.md for the input assumptions needed to interpret the checked integer calculations as physical Morse indices.
