"""Verify five normalized planar five-body central configurations (standard library).

Each input decimal is exact. Integer endpoints use outward rounding to the
lattice D^-1 Z for every arithmetic operation. All five masses are 1/5.
"""
if not __debug__:
    raise RuntimeError("Run this verifier with Python assertions enabled.")

import json
from fractions import Fraction
from math import isqrt
from pathlib import Path

D = 10**42
N = 9
ACTIVE = [k for k in range(10) if k != 7]
ZERO = None  # assigned after class definition


class Interval:
    __slots__ = ('lo', 'hi')

    def __init__(self, lo, hi):
        assert lo <= hi
        self.lo, self.hi = lo, hi

    @classmethod
    def of(cls, value):
        if isinstance(value, cls):
            return value
        x = Fraction(value) * D
        return cls(x.numerator // x.denominator, -((-x.numerator) // x.denominator))

    def __add__(self, other):
        t = self.of(other)
        return Interval(self.lo + t.lo, self.hi + t.hi)

    __radd__ = __add__

    def __neg__(self):
        return Interval(-self.hi, -self.lo)

    def __sub__(self, other):
        return self + (-self.of(other))

    def __rsub__(self, other):
        return self.of(other) + (-self)

    def __mul__(self, other):
        t = self.of(other)
        s = [a*b for a in (self.lo, self.hi) for b in (t.lo, t.hi)]
        return Interval(min(s)//D, -((-max(s))//D))

    __rmul__ = __mul__

    def inv_pos(self):
        assert self.lo > 0
        return Interval(D*D//self.hi, -((-D*D)//self.lo))

    def sqrt(self):
        assert self.lo >= 0
        x = isqrt(self.hi*D)
        return Interval(isqrt(self.lo*D), x + int(x*x != self.hi*D))

    def norm(self):
        return max(-self.lo, self.hi)


ZERO = Interval.of(0)
ONE = Interval.of(1)
MASS = Interval.of(Fraction(1, 5))
RAD = D // 10**11


def eval_primary(q):
    field = list(q)
    jac = [[Interval.of(int(i == j)) for j in range(10)] for i in range(10)]
    for i in range(5):
        for j in range(i):
            row = 2*i
            other = 2*j
            v = [q[row+k] - q[other+k] for k in range(2)]
            r2 = v[0]*v[0] + v[1]*v[1]
            inv2 = r2.inv_pos()
            inv3 = inv2 * inv2.sqrt()
            for a in range(2):
                gravity = MASS*v[a]*inv3
                field[row+a] -= gravity
                field[other+a] += gravity
                for b in range(2):
                    block = MASS*inv3*(int(a == b) - 3*v[a]*v[b]*inv2)
                    jac[row+a][row+b] -= block
                    jac[other+a][other+b] -= block
                    jac[row+a][other+b] += block
                    jac[other+a][row+b] += block
    return ([field[i] for i in ACTIVE],
            [[jac[i][j] for j in ACTIVE] for i in ACTIVE])


def precondition(jac):
    # Exact inversion of a rational approximation. Any fixed approximate inverse
    # would suffice, but computing it this way avoids external dependencies.
    a = [[Fraction(x.lo+x.hi, 2*D).limit_denominator(10**8) for x in row]
         + [Fraction(int(i == j)) for j in range(N)] for i, row in enumerate(jac)]
    for i in range(N):
        j = next(j for j in range(i, N) if a[j][i] != 0)
        a[i], a[j] = a[j], a[i]
        a[i] = [x/a[i][i] for x in a[i]]
        for j in range(N):
            if j != i:
                c = a[j][i]
                a[j] = [x-c*y for x, y in zip(a[j], a[i])]
    return [[Interval.of(x) for x in row[N:]] for row in a]


def dot(x, y):
    return sum((p*q for p, q in zip(x, y)), ZERO)


def check(centers):
    c = [Interval.of(x) for xy in centers for x in xy]
    assert all(p.lo == p.hi for p in c)
    assert c[7].lo == 0 and c[6].lo > RAD
    X = [Interval(p.lo-RAD, p.hi+RAD) if i in ACTIVE else p for i, p in enumerate(c)]
    field, jac_c = eval_primary(c)
    _, jac_x = eval_primary(X)
    R = precondition(jac_c)
    beta = max(dot(row, field).norm() for row in R)
    qt = 0
    for i, row in enumerate(R):
        norms = [(int(i == j)-dot(row, [s[j] for s in jac_x])).norm() for j in range(N)]
        qt = max(qt, sum(norms))
    # For T(z)=z-RF(z), ||T(c)-c||<= beta/D; Lip(T|X)<=qt/D.
    # Strict self-inclusion and strict contraction give a unique fixed point.
    # ||I-R DF||<1 also implies R is nonsingular, so the fixed point is a zero.
    assert qt < D and beta * D + qt * RAD < RAD * D
    radii = [X[2*i]*X[2*i] + X[2*i+1]*X[2*i+1] for i in range(5)]
    max_r2 = Interval(max(r.lo for r in radii), max(r.hi for r in radii))
    return beta, qt, max_r2


def ceil_scaled(n, places):
    return -((-n*10**places)//D)


def verify():
    shapes = json.loads(Path(__file__).with_name("primary_centers.json").read_text())
    assert len(shapes) == 5
    invariants = []
    for name, centers in shapes.items():
        beta, qt, r2 = check(centers)
        invariants.append(r2)
        print(f"{name:14} |T(c)-c| <= {ceil_scaled(beta,15)}e-15;"
              f" Lip(T) <= {ceil_scaled(qt,12)}e-12;"
              f" max |q_i|² in [{r2.lo*1000//D},{ceil_scaled(r2.hi,3)}]/1000")
    invariants.sort(key=lambda r:r.lo)
    assert all(a.hi < b.lo for a,b in zip(invariants,invariants[1:]))
    print("All five invariant ranges are pairwise disjoint.")


if __name__ == "__main__":
    verify()
