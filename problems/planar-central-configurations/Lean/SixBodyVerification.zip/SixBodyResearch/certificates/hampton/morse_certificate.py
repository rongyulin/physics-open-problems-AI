"""Exact interval Krawczyk and symmetric LDL for n equal masses.

Place certify_primaries.py on sys.path for its lattice interval arithmetic.
check(centers, denominator=10**12, axis=None) returns the displacement bound
and Lipschitz bound in integer units 1/D, the maximum squared radius interval,
and the full symmetry-gauge principal Jacobian interval. The target rotation
coordinate is (axis or n-2, y), where indexing starts at zero.
"""
from fractions import Fraction
from certify_primaries import Interval, D, ZERO


def eval_primary(q, omitted):
    n = len(q)//2
    active = [i for i in range(2*n) if i != omitted]
    mass = Interval.of(Fraction(1,n))
    field = list(q)
    jac = [[Interval.of(int(i == j)) for j in range(2*n)] for i in range(2*n)]
    for i in range(n):
        for j in range(i):
            row = 2*i
            other = 2*j
            v = [q[row+k] - q[other+k] for k in range(2)]
            r2 = v[0]*v[0] + v[1]*v[1]
            inv2 = r2.inv_pos()
            inv3 = inv2 * inv2.sqrt()
            for a in range(2):
                gravity = mass*v[a]*inv3
                field[row+a] -= gravity
                field[other+a] += gravity
                for b in range(2):
                    block = mass*inv3*(int(a == b) - 3*v[a]*v[b]*inv2)
                    jac[row+a][row+b] -= block
                    jac[other+a][other+b] -= block
                    jac[row+a][other+b] += block
                    jac[other+a][row+b] += block
    return ([field[i] for i in active],
            [[jac[i][j] for j in active] for i in active])


def precondition(jac):
    N = len(jac)
    # Exact inversion of a rational approximation. Any fixed approximate inverse
    # would suffice, but computing it this way avoids external dependencies.
    a = [[Fraction(x.lo+x.hi, 2*D).limit_denominator(10**8) for x in row]
         + [Fraction(int(i == j)) for j in range(N)] for i, row in enumerate(jac)]
    for i in range(N):
        j = next(j for j in range(i, N) if a[j][i] != 0)
        a[i], a[j] = a[j], a[i]
        a[i] = [x/a[i][i] for x in a[i]]
        for j in range(N):
            if j != i:
                c = a[j][i]
                a[j] = [x-c*y for x, y in zip(a[j], a[i])]
    return [[Interval.of(x) for x in row[N:]] for row in a]


def dot(x, y):
    return sum((p*q for p, q in zip(x, y)), ZERO)


def check(centers, denominator=10**12, axis=None):
    n = len(centers)
    body = n-2 if axis is None else axis
    omitted = 2*body+1
    active = [i for i in range(2*n) if i != omitted]
    assert D % denominator == 0
    rad = D//denominator
    dim = len(active)
    c = [Interval.of(x) for xy in centers for x in xy]
    assert all(p.lo == p.hi for p in c)
    assert c[omitted].lo == 0 and c[omitted-1].lo > rad
    X = [Interval(p.lo-rad, p.hi+rad) if i in active else p for i, p in enumerate(c)]
    field, jac_c = eval_primary(c, omitted)
    _, jac_x = eval_primary(X, omitted)
    R = precondition(jac_c)
    beta = max(dot(row, field).norm() for row in R)
    qt = 0
    for i, row in enumerate(R):
        norms = [(int(i == j)-dot(row, [s[j] for s in jac_x])).norm() for j in range(dim)]
        qt = max(qt, sum(norms))
    # For T(z)=z-RF(z), ||T(c)-c||<= beta/D; Lip(T|X)<=qt/D.
    # Strict self-inclusion and strict contraction give a unique fixed point.
    # ||I-R DF||<1 also implies R is nonsingular, so the fixed point is a zero.
    assert qt < D and beta * D + qt * rad < rad * D
    radii = [X[2*i]*X[2*i] + X[2*i+1]*X[2*i+1] for i in range(n)]
    max_r2 = Interval(max(r.lo for r in radii), max(r.hi for r in radii))
    return beta, qt, max_r2, jac_x



def inverse(a):
    if a.lo > 0:
        return a.inv_pos()
    if a.hi < 0:
        return -(-a).inv_pos()
    raise ArithmeticError("Pivot interval meets zero")


def diagonalize(a):
    pivots = []
    while a:
        p = a[0][0]
        pinv = inverse(p)
        pivots.append(p)
        a = [[a[i][j] - a[i][0]*pinv*a[0][j] for j in range(1, len(a))]
             for i in range(1, len(a))]
    return pivots


