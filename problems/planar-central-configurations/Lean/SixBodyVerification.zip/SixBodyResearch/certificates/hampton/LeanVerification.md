# Newtonian Hessian inertia on the equal-mass six- and seven-body sets

`Hampton.lean` is a pure Lean 4.28/Std calculation. Its 23 embedded real-plane input box centers are exact multiples of $10^{-15}$, matching the independent Python certificate files `six_centers.json` and `seven_centers.json`. The six-body coordinate half-width is $10^{-12}$, the seven-body half-width $10^{-11}$. The y coordinate of zero-indexed body $n-2$ alone is fixed at zero; the checker verifies that its x coordinate is positive throughout the box. Each mass equals $1/n$, with central multiplier one.

For a relative vector $v=q_i-q_j$ of length $r$, the checker computes

$$K_{ij}=\frac1n\left(3vv^T/r^5-I_2/r^3\right).$$

It starts the full Jacobian at the identity, adds $K_{ij}$ to the two diagonal blocks, and subtracts it from the corresponding off-diagonal blocks. The Cartesian Hessian of the augmented potential equals a positive multiple of this symmetric matrix. Deleting the rotation slice's fixed coordinate and its row gives an $(2n-1)$-dimensional principal matrix. Schur elimination accepts a pivot only when its entire enclosure has one strict sign. Since each symmetric Schur step is a congruence separating the pivot, the number of negative pivots equals the negative inertia (Morse index) of the slice Hessian. The translation and scaling directions omitted in alternative normalizations have positive sign, as explained in the paper.

Every operation uses signed integer endpoints with fixed denominator $2^{72}$ and outward rounding. Root finding supplies trial coordinates only; the separately supplied primary existence/isolation certificates are the justification that these boxes contain true central configurations. The fixed input geometry order is that of Moczurad and Zgliczyński's Appendix A.2.4 (six) and A.2.5 (seven). Label multiplicities are separately certified via rotation orbit sizes. Their values are explicit input constants for the Lean weighted sums.

Run `lean --run Hampton.lean`. The executable reports the computed index for every input, and the closed kernel-computation theorems check exactly those index and coefficient calculations. Analytic correctness of the Hessian identification, interval method, Sylvester inertia, and geometry classification is supplied by the accompanying mathematical argument. No `native_decide` is used.
