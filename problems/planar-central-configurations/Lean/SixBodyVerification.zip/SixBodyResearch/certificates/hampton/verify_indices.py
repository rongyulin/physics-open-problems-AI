"""Isolate all fourteen seven-body representatives and certify Hessian inertia."""
from pathlib import Path
import json
from fractions import Fraction
from math import factorial
from orthogonal_stabilizers import I, symmetries
from morse_certificate import check, diagonalize, D

def main():
    if not __debug__:
        raise SystemExit("Do not run the certificate with Python -O.")
    data = json.loads(Path(__file__).with_name('seven_centers.json').read_text())
    assert len(data) == 14
    bounds = []
    polynomial = [0]*6
    for k, centers in data.items():
        assert len(centers) == 7
        displacement, lip, radius, jac = check(centers, denominator=10**11)
        pivots = diagonalize(jac)
        assert len(pivots) == 13
        signs = ''.join('-' if p.hi < 0 else '+' for p in pivots)
        pivot_lower = min(p.lo if p.lo > 0 else -p.hi for p in pivots)
        assert pivot_lower > 0
        bounds.append(radius)
        err = Fraction(displacement, D-lip)
        assert err < Fraction(1,10**13)
        def box(radius):
            return [tuple(I(Fraction(t)-radius,Fraction(t)+radius) for t in point)
                    for point in centers]
        rotations, reflections = symmetries(box(Fraction(1,10**13)),
                                            box(Fraction(1,10**11)), 5)
        assert rotations > 0 and reflections in (0, rotations)
        assert factorial(7) % rotations == 0
        weight = (1 if reflections else 2)*factorial(7)//rotations
        polynomial[signs.count('-')] += weight
        print(k, 'rotations', rotations, 'reflections', reflections, 'weight',weight, 'index', signs.count('-'), 'pivots', signs,
              'min |pivot| >=', pivot_lower*10**5//D, '/10^5',
              'max position error <', 1+err.numerator*10**16//err.denominator, '/10^16')
    bounds.sort(key=lambda a:a.lo)
    assert all(a.hi < b.lo for a,b in zip(bounds,bounds[1:]))
    assert polynomial == [120*x for x in [7,84,132,105,84,35]]
    print('Newtonian seven-body Morse polynomial coefficients:', polynomial)
    print('Total:', sum(polynomial))
    print('Fourteen mutually disjoint maximum squared-radius intervals.')

if __name__=='__main__':
    main()
