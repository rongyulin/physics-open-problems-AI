"""Certify nine equal-six-body shapes using only standard-library arithmetic."""
import json
from pathlib import Path
import sys

if len(sys.argv) != 2:
    raise SystemExit("Usage: python3 six_inertia.py PATH/TO/primaries")
sys.path.insert(0, str(Path(sys.argv[1]).resolve()))
from morse_certificate import check, diagonalize, D

groups = [360, 360, 240, 720, 120, 240, 720, 720, 144]
data = json.loads(Path(__file__).with_name('six_centers.json').read_text())
assert set(data) == {str(k) for k in range(1,10)}
radii = []
coefficients = [0]*6
for k, weight in enumerate(groups, 1):
    beta, lip, max_r2, jac = check(data[str(k)])
    assert beta*D < (D//10**14)*(D-lip)
    pivots = diagonalize(jac)
    signs = ''.join('+' if p.lo > 0 else '-' for p in pivots)
    index = signs.count('-')
    low = min(p.lo if p.lo > 0 else -p.hi for p in pivots)
    radii.append(max_r2)
    coefficients[index] += weight
    print(f"A.2.4.{k}  index={index}  pivots={signs}  min |pivot| >= {low*10**6//D}e-6"
          f"  max |q|² in [{max_r2.lo*10**5//D},{-((-max_r2.hi*10**5)//D)}]e-5"
          f"  oriented multiplicity={weight}")
radii.sort(key=lambda x:x.lo)
assert all(a.hi < b.lo for a,b in zip(radii,radii[1:]))
assert coefficients == [384,840,1080,960,360,0]
print("All nine certified radii pairwise disjoint. All center errors <1e-14.")
print("Morse coefficients by increasing index:", coefficients)
