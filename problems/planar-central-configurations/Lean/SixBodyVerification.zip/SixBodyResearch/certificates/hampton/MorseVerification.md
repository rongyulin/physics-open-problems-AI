# Morse index certificates for the Newtonian central configurations

Use the Morse index convention that counts negative eigenvalues. For rectangular-coordinate positions, use the augmented potential

$$
 F(q)=\tfrac12\sum_i m_i |q_i|^2+\sum_{i<j}m_i m_j/|q_i-q_j|.
$$

For total mass one and Newtonian exponent $A=3$, this is Hampton's own function $MI/2+U/(A-2)$. For any common mass scaling, a common coordinate rescaling and a positive scalar multiple identify the corresponding critical-point equations and preserve Hessian inertia. The formulas below use multiplier one.

## Exact inertia on a rotation slice

The equal-mass normalized force field is the gradient of $F$ divided by the common mass. Fix one named primary with positive $x$ coordinate and set its $y$ coordinate equal to zero. Delete that variable and its corresponding equation. The removed residual vanishes at any zero of the reduced system by the Newtonian torque identity. The Jacobian of the reduced system is a positive scalar multiple of the corresponding principal Hessian submatrix. The tangent plane to this gauge is complementary to the infinitesimal rotation. Since the rotational tangent is in the kernel, restriction to this plane has precisely the nonzero inertia of the full Hessian.

The two translations give a positive two-dimensional subspace that is orthogonal for the mass inner product to all centered motions. The radial vector has positive generalized Hessian eigenvalue 3. Indeed, along $sq$ the gravitational gradient is homogeneous of degree $-2$; differentiating at a unit-multiplier critical point gives $D^2F(q)\,q=3\,{\rm diag}(m_i I_2)\,q$. Consequently, passage to the centered, unit-inertia, rotation-reduced shape space gives the same negative index. The Hessian of the constrained potential there is the restriction of the augmented Hessian to the tangent of the inertia sphere. On the transverse rotation slice the translation and radial directions need not coincide with coordinate axes; inertia is invariant under change of complement to the rotational kernel.

Each certificate uses rational Cartesian boxes with an integer interval-arithmetic mesh of $10^{-42}$. It encloses every matrix entry on the entire certified box. For a symmetric block matrix with first diagonal entry $d\ne0$, symmetric Gaussian elimination is an exact congruence to $\operatorname{diag}(d,C-bb^T/d)$. All linear solves for the preconditioner use rational arithmetic, all interval divisions and square roots round outwards, and every pivot interval excludes zero. The counted negative pivots thus determine the exact index.

## Nine equal-six shapes and Hampton's Newtonian clause

Run `python3 six_inertia.py ../primaries`. For each of nine inputs, `six_centers.json` specifies an exact rational seed. The checker finds a unique root within sup-norm distance $10^{-12}$ and bounds its displacement from the seed by $10^{-14}$. The mass of each body is $1/6$. In zero-based notation the gauge is $q_{4,y}=0$. The nine verified ranges of the maximum squared radius are pairwise disjoint, proving inequivalence of the shapes. Moczurad and Zgliczyński's classification supplies global exhaustiveness. The data are in their Appendix A.2.4 order. [Moczurad and Zgliczyński (2019)](https://arxiv.org/abs/1812.07279)

| Shape in A.2.4 | Morse index | Labelled multiplicity modulo rotations |
|---|---:|---:|
| 1. Line | 4 | 360 |
| 2. Cross | 2 | 360 |
| 3. Two equilateral triangles I | 3 | 240 |
| 4. Trapezium | 2 | 720 |
| 5. Regular hexagon | 1 | 120 |
| 6. Two equilateral triangles II | 0 | 240 |
| 7. Two isosceles triangles I | 3 | 720 |
| 8. Two isosceles triangles II | 1 | 720 |
| 9. Regular pentagon with center | 0 | 144 |

The rotational stabilizer orders are $2,2,3,1,6,3,1,1,5$, respectively, and each underlying shape admits a reflection. The rotational multiplicity is $6!$ divided by the rotational stabilizer order. The independent group checker also determines these groups directly within the same certified position boxes. The sum of $t^{\mathrm{index}}$ over all 3,624 labelled oriented shapes is therefore

$$
384+840t+1080t^2+960t^3+360t^4.
$$

This is the $A=3$ clause of Marshall Hampton's Conjecture 4 in §3.4. The other clause concerns sufficiently large exponents. [Hampton](https://arxiv.org/abs/1810.13011)

## Five equal primaries and a light sixth mass

Run `python3 primary_inertia.py ../primaries`. The primary indices in catalogue order are $3,0,2,1,0$. For masses $1/5,\ldots,1/5,\varepsilon$, write $q$ for the five primaries on the chosen rotation slice, $u$ for the sixth position, and $F_\varepsilon(q,u)=F_0(q)+\varepsilon W(q,u)$, where $W(q,u)=|u|^2/2+\sum_i (1/5)/|q_i-u|$. Along each analytic continuation with distinct limiting positions, the Hessian has blocks

$$
 A_\varepsilon=A_0+O(\varepsilon),\qquad
 B_\varepsilon=O(\varepsilon),\qquad
 C_\varepsilon=\varepsilon H_{\rm test}+O(\varepsilon^2).
$$

Here $A_0$ is the ordinary primary Hessian on the slice. Its inverse stays bounded because it is nonsingular. The symmetric Schur complement satisfies $C_\varepsilon-B_\varepsilon^TA_\varepsilon^{-1}B_\varepsilon=\varepsilon H_{\rm test}+O(\varepsilon^2)$. For positive $\varepsilon$ sufficiently small, its inertia agrees with that of the nonsingular restricted Hessian. Congruence adds the two indices. Finiteness of the list makes one neighborhood valid for every branch. This argument also works for nearby positive primary masses by continuity.

The certified pairs of restricted minima and saddles for line, centered square, two triangles, trapezium, and pentagon are $(2,6),(4,8),(3,7),(5,9),(6,10)$, respectively. Their labelled oriented primary multiplicities are $60,30,120,120,24$. Weighting by these multiplicities gives

$$
264+1080t+1440t^2+960t^3+360t^4 .
$$

The coefficient sum is 4,104 and the alternating sum is 24. These are indices of critical points of the normalized potential; linear stability of the rotating Newtonian orbit uses a different operator.
