"""Certify all orthogonal automorphisms of isolated central configurations.

Use the same exact centers as their primary contraction certificate. The wide
radius is the uniqueness cube. The tight radius is the rigorous a posteriori
coordinate error from that certificate. A single fixed coordinate (the gauge)
is exact. Orthogonal images are tested by actual inclusion, not proximity.
"""
import argparse
import json
from math import factorial
from fractions import Fraction as Q
from pathlib import Path
from math import isqrt


class I:
    def __init__(self,lo,hi=None):
        self.lo=Q(lo); self.hi=Q(lo if hi is None else hi)
        if self.lo>self.hi: raise ValueError('inverted interval')

    def __add__(x,y):
        return I(x.lo+y.lo,x.hi+y.hi)

    def __neg__(x):
        return I(-x.hi,-x.lo)

    def __sub__(x,y):
        return x + (-y)

    def __mul__(x,y):
        products=[a*b for a in (x.lo,x.hi) for b in (y.lo,y.hi)]
        return I(min(products),max(products))

    def __truediv__(x,y):
        if y.lo*y.hi<=0: raise ValueError('division through zero')
        return x * I(1/y.hi,1/y.lo)

    def sqrt(x):
        assert x.lo>0
        S=10**30
        def down(q): return isqrt(q.numerator*S*S//q.denominator)
        return I(Q(down(x.lo),S),Q(down(x.hi)+1,S))

    def inside(x,y): return y.lo<=x.lo and x.hi<=y.hi

    def overlaps(x,y):
        return max(x.lo,y.lo)<=min(x.hi,y.hi)


def image(matrix,p):
    return tuple(row[0]*p[0]+row[1]*p[1] for row in matrix)




def symmetries(q, original, anchor):
    assert q[anchor][0].lo>0
    q[anchor]=(q[anchor][0],I(0)); original[anchor]=(original[anchor][0],I(0))
    actions=[]
    for sign in (1,-1):
        for j,(h,k) in enumerate(q):
            if h.overlaps(I(0)) and k.overlaps(I(0)):
                assert (h*h+k*k).hi < (q[anchor][0]*q[anchor][0]).lo
                continue
            radius=(h*h+k*k).sqrt()
            if not radius.overlaps(q[anchor][0]): continue
            c,s=h/radius,k/radius
            matrix=((c,s),(-s if sign==1 else s,c if sign==1 else -c))
            images=[image(matrix,p) for p in q]; images[j]=(radius,I(0))
            perm=[]
            impossible=False
            for (x,y) in images:
                opts=[i for i,(a,b) in enumerate(original) if x.overlaps(a) and y.overlaps(b)]
                if not opts: impossible=True;break
                assert len(opts)==1
                i=opts[0];a,b=original[i]
                assert x.inside(a) and y.inside(b)
                perm.append(i)
            if impossible: continue
            assert sorted(perm)==list(range(len(q))) and perm[j]==anchor
            actions.append((sign,tuple(perm)))
    # Count physical orthogonal transformations: a collinear configuration can
    # have transformations with identical induced permutations but opposite signs.
    assert len(set(actions))==len(actions)
    for sa,aa in actions:
        for sb,bb in actions: assert (sa*sb,tuple(aa[i] for i in bb)) in actions
    return [sum(k==s for k,p in actions) for s in (1,-1)]


def main():
    if not __debug__: raise RuntimeError('run without -O')
    p=argparse.ArgumentParser()
    p.add_argument('input',type=Path)
    p.add_argument('--wide',type=Q,required=True)
    p.add_argument('--tight',type=Q,required=True)
    p.add_argument('--anchor',type=int,required=True,help='zero-based index')
    args=p.parse_args(); data=json.loads(args.input.read_text());tot=0
    assert args.wide>args.tight>0
    for name, positions in data.items():
        def boxes(r): return [tuple(I(Q(x)-r,Q(x)+r) for x in pos) for pos in positions]
        assert Q(positions[args.anchor][1])==0
        rot,ref=symmetries(boxes(args.tight),boxes(args.wide),args.anchor)
        n=len(positions);assert factorial(n)%rot==0 and ref in (0,rot)
        # Source class enumerates O(2)- and label-quotient orbits. If chirality
        # occurs, two distinct unlabelled SO(2) classes contribute here.
        labelled=(1 if ref else 2)*factorial(n)//rot
        tot+=labelled
        print(f'{name}: rotations={rot} reflections={ref} oriented-labelled={labelled}')
    print('total labelled oriented:',tot)


if __name__=='__main__': main()
