import Physical

namespace SixTriangles

def totalMass (m : Fin 6 → ℝ) : ℝ := ∑ i, m i
noncomputable def center (p : Fin 6 → Point) (m : Fin 6 → ℝ) (coord : Point → ℝ) : ℝ :=
  (∑ i, m i * coord (p i)) / totalMass m
noncomputable def acceleration (p : Fin 6 → Point) (m : Fin 6 → ℝ) (coord : Point → ℝ) (i : Fin 6) : ℝ :=
  ∑ j : Fin 6, (m j) * (coord (p j)-coord (p i)) * grav (sqDist (p i) (p j))

def NewtonianCentral (p : Fin 6 → Point) (m : Fin 6 → ℝ) : Prop :=
  Function.Injective p ∧ (∀ i, 0 < m i) ∧ ∃ L : ℝ, 0 < L ∧ ∀ i : Fin 6,
    newtonX p m i = -L*((p i).1-center p m Prod.fst) ∧
    newtonY p m i = -L*((p i).2-center p m Prod.snd)

theorem internal_force_cancels (p : Fin 6 → Point) (m : Fin 6 → ℝ) (coord : Point → ℝ) :
    ∑ i, m i * acceleration p m coord i = 0 := by
  let H (i j : Fin 6) := m i * (m j * (coord (p j)-coord (p i)) * grav (sqDist (p i) (p j)))
  have skew (i j : Fin 6) : H i j = -H j i := by
    have dist : sqDist (p i) (p j) = sqDist (p j) (p i) := by unfold sqDist; ring
    dsimp only [H]; rw [dist]; ring
  have z : (∑ i, ∑ j, H i j) = -(∑ i, ∑ j, H i j) := calc
    _ = ∑ i, ∑ j, -(H j i) := by
      apply Finset.sum_congr rfl
      intro i _
      apply Finset.sum_congr rfl
      intro j _
      exact skew i j
    _ = _ := by simp only [Finset.sum_neg_distrib]; rw [Finset.sum_comm]
  have z' : (∑ i, ∑ j, H i j) = 0 := by linarith only [z]
  simpa only [acceleration,Finset.mul_sum,H] using z'

theorem centered (p : Fin 6 → Point) (m : Fin 6 → ℝ) (coord : Point → ℝ)
    (k c : ℝ) (hm : totalMass m ≠ 0) (h : ∀ i, acceleration p m coord i = k*coord (p i)+c) :
    ∀ i, acceleration p m coord i = k*(coord (p i)-center p m coord) := by
  have z := internal_force_cancels p m coord
  have rel : k * (∑ i, m i * coord (p i)) + (totalMass m)*c = 0 := by
    calc
      _ = ∑ i, (k*(m i*coord (p i))+m i*c) := by
        simp only [totalMass,Finset.sum_add_distrib, ← Finset.mul_sum, ← Finset.sum_mul]
      _ = ∑ i, m i * acceleration p m coord i := by
        apply Finset.sum_congr rfl
        intro i _
        rw [h]
        ring
      _ = 0 := z
  intro i
  rw [h,center]
  field_simp [hm]
  linear_combination rel


theorem geometry (a b : ℝ) (ha : ARange a) (hb : b ∈ strip) :
    Function.Injective (pos a b) ∧ (∀ i, ((pos a b i).1) ≤ 1) := by
  have al := ha.1; have au := ha.2; have bl := hb.1; have bu := hb.2
  norm_num [bLow,bHigh] at al au bl bu
  constructor
  · intro i j hij
    fin_cases i <;> fin_cases j
    · rfl
    · exfalso
      have h : (a-b:ℝ) = (b-a:ℝ) := congrArg Prod.fst hij
      linarith only [al,au,bl,bu,h]
    · exfalso
      have h : (a-b:ℝ) = (0:ℝ) := congrArg Prod.fst hij
      linarith only [al,au,bl,bu,h]
    · exfalso
      have h : (a-b:ℝ) = (0:ℝ) := congrArg Prod.fst hij
      linarith only [al,au,bl,bu,h]
    · exfalso
      have h : (a-b:ℝ) = (1:ℝ) := congrArg Prod.fst hij
      linarith only [al,au,bl,bu,h]
    · exfalso
      have h : (a-b:ℝ) = (-1:ℝ) := congrArg Prod.fst hij
      linarith only [al,au,bl,bu,h]
    · exfalso
      have h : (b-a:ℝ) = (a-b:ℝ) := congrArg Prod.fst hij
      linarith only [al,au,bl,bu,h]
    · rfl
    · exfalso
      have h : (b-a:ℝ) = (0:ℝ) := congrArg Prod.fst hij
      linarith only [al,au,bl,bu,h]
    · exfalso
      have h : (b-a:ℝ) = (0:ℝ) := congrArg Prod.fst hij
      linarith only [al,au,bl,bu,h]
    · exfalso
      have h : (b-a:ℝ) = (1:ℝ) := congrArg Prod.fst hij
      linarith only [al,au,bl,bu,h]
    · exfalso
      have h : (b-a:ℝ) = (-1:ℝ) := congrArg Prod.fst hij
      linarith only [al,au,bl,bu,h]
    · exfalso
      have h : (0:ℝ) = (a-b:ℝ) := congrArg Prod.fst hij
      linarith only [al,au,bl,bu,h]
    · exfalso
      have h : (0:ℝ) = (b-a:ℝ) := congrArg Prod.fst hij
      linarith only [al,au,bl,bu,h]
    · rfl
    · exfalso
      have h : (a:ℝ) = (0:ℝ) := congrArg Prod.snd hij
      linarith only [al,au,bl,bu,h]
    · exfalso
      have h : (0:ℝ) = (1:ℝ) := congrArg Prod.fst hij
      linarith only [al,au,bl,bu,h]
    · exfalso
      have h : (0:ℝ) = (-1:ℝ) := congrArg Prod.fst hij
      linarith only [al,au,bl,bu,h]
    · exfalso
      have h : (0:ℝ) = (a-b:ℝ) := congrArg Prod.fst hij
      linarith only [al,au,bl,bu,h]
    · exfalso
      have h : (0:ℝ) = (b-a:ℝ) := congrArg Prod.fst hij
      linarith only [al,au,bl,bu,h]
    · exfalso
      have h : (0:ℝ) = (a:ℝ) := congrArg Prod.snd hij
      linarith only [al,au,bl,bu,h]
    · rfl
    · exfalso
      have h : (0:ℝ) = (1:ℝ) := congrArg Prod.fst hij
      linarith only [al,au,bl,bu,h]
    · exfalso
      have h : (0:ℝ) = (-1:ℝ) := congrArg Prod.fst hij
      linarith only [al,au,bl,bu,h]
    · exfalso
      have h : (1:ℝ) = (a-b:ℝ) := congrArg Prod.fst hij
      linarith only [al,au,bl,bu,h]
    · exfalso
      have h : (1:ℝ) = (b-a:ℝ) := congrArg Prod.fst hij
      linarith only [al,au,bl,bu,h]
    · exfalso
      have h : (1:ℝ) = (0:ℝ) := congrArg Prod.fst hij
      linarith only [al,au,bl,bu,h]
    · exfalso
      have h : (1:ℝ) = (0:ℝ) := congrArg Prod.fst hij
      linarith only [al,au,bl,bu,h]
    · rfl
    · exfalso
      have h : (1:ℝ) = (-1:ℝ) := congrArg Prod.fst hij
      linarith only [al,au,bl,bu,h]
    · exfalso
      have h : (-1:ℝ) = (a-b:ℝ) := congrArg Prod.fst hij
      linarith only [al,au,bl,bu,h]
    · exfalso
      have h : (-1:ℝ) = (b-a:ℝ) := congrArg Prod.fst hij
      linarith only [al,au,bl,bu,h]
    · exfalso
      have h : (-1:ℝ) = (0:ℝ) := congrArg Prod.fst hij
      linarith only [al,au,bl,bu,h]
    · exfalso
      have h : (-1:ℝ) = (0:ℝ) := congrArg Prod.fst hij
      linarith only [al,au,bl,bu,h]
    · exfalso
      have h : (-1:ℝ) = (1:ℝ) := congrArg Prod.fst hij
      linarith only [al,au,bl,bu,h]
    · rfl
  · intro i
    fin_cases i
    · change (a-b:ℝ) ≤ 1; linarith only [al,au,bl,bu]
    · change (b-a:ℝ) ≤ 1; linarith only [al,au,bl,bu]
    · change (0:ℝ) ≤ 1; linarith only [al,au,bl,bu]
    · change (0:ℝ) ≤ 1; linarith only [al,au,bl,bu]
    · change (1:ℝ) ≤ 1; linarith only [al,au,bl,bu]
    · change (-1:ℝ) ≤ 1; linarith only [al,au,bl,bu]

theorem slope_negative (a b u v w k j : ℝ)
    (hx : ∀ i, (pos a b i).1 ≤ 1) (hm : ∀ i, 0 < mass u v w i)
    (hf : ∀ i, newtonX (pos a b) (mass u v w) i = k*(pos a b i).1 ∧
       newtonY (pos a b) (mass u v w) i = k*(pos a b i).2+j) : k < 0 := by
  have p4 : pos a b 4 = (1,1) := rfl
  have p5 : pos a b 5 = (-1,1) := rfl
  have m5 : mass u v w 5 = 1 := rfl
  have sq : Real.sqrt 4 = 2 := by rw [Real.sqrt_eq_iff_eq_sq] <;> norm_num
  have g45 : grav (sqDist (pos a b 4) (pos a b 5)) = (1/8:ℝ) := by
    rw [p4,p5]; norm_num [sqDist,grav,sq]
  have hs : newtonX (pos a b) (mass u v w) 4 < 0 := by
    unfold newtonX
    apply Finset.sum_neg'
    · intro i _
      have g : 0 ≤ grav (sqDist (pos a b 4) (pos a b i)) := by
        unfold grav sqDist
        positivity
      apply mul_nonpos_of_nonpos_of_nonneg _ g
      apply mul_nonpos_of_nonneg_of_nonpos (hm i).le
      rw [p4]
      exact sub_nonpos.mpr (hx i)
    · refine ⟨5,Finset.mem_univ _,?_⟩
      rw [g45,p4,p5,m5]; norm_num
  have hk := (hf 4).1
  rw [p4] at hk
  simpa [hk] using hs

def equilateral (p : Fin 6 → Point) (i j k : Fin 6) : Prop :=
   sqDist (p i) (p j) = sqDist (p j) (p k) ∧ sqDist (p j) (p k) = sqDist (p k) (p i)

theorem triangles_equilateral (a b : ℝ) :
    equilateral (pos a b) 0 1 2 ∧ equilateral (pos a b) 3 4 5 := by
  change (((b-a)-(a-b))^2+3*(b-b)^2 = (0-(b-a))^2+3*(a-b)^2 ∧
          (0-(b-a))^2+3*(a-b)^2 = ((a-b)-0)^2+3*(b-a)^2) ∧
     (((1:ℝ)-0)^2+3*(1-0:ℝ)^2 = ((-1:ℝ)-1)^2+3*(1-1:ℝ)^2 ∧
       ((-1:ℝ)-1)^2+3*(1-1:ℝ)^2 = (0-(-1):ℝ)^2+3*(0-1:ℝ)^2)
  constructor <;> constructor <;> ring

noncomputable def triangleYCentroid (p : Fin 6 → Point) (i j k : Fin 6) : ℝ :=
  ((p i).2 + (p j).2 + (p k).2) / 3

theorem physical_six_body_standard (a : ℝ) (ha : ARange a) : ∃ b ∈ strip,
    triangleYCentroid (pos a b) 0 1 2 ≠ triangleYCentroid (pos a b) 3 4 5 ∧
    (0 < outerApexMass a b ∧ outerApexMass a b < innerPairMass a b ∧
      innerPairMass a b < 1 ∧ 1 < innerApexMass a b) ∧
    (equilateral (pos a b) 0 1 2 ∧ equilateral (pos a b) 3 4 5) ∧
    NewtonianCentral (pos a b) (mass (innerPairMass a b) (innerApexMass a b) (outerApexMass a b)) := by
  obtain ⟨b,hb,hc,hm,k,j,hf⟩ := six_body_equations a ha
  let m := mass (innerPairMass a b) (innerApexMass a b) (outerApexMass a b)
  have hu := hm.1.trans hm.2.1; have hv := hm.2.2.2; have hw := hm.1
  have qm : ∀ i, 0 < m i := by
    intro i
    fin_cases i
    · exact hu
    · exact hu
    · exact zero_lt_one.trans hv
    · exact hw
    · exact zero_lt_one
    · exact zero_lt_one
  obtain ⟨hI,hX⟩ := geometry a b ha hb
  have neg := slope_negative a b _ _ _ k j hX qm hf
  have masspos : 0 < totalMass m := by
    exact Finset.sum_pos (fun i _ => qm i) Finset.univ_nonempty
  have fx := centered (pos a b) m Prod.fst k 0 (ne_of_gt masspos)
    (fun i => by simpa using (hf i).1)
  have fy := centered (pos a b) m Prod.snd k j (ne_of_gt masspos) (fun i => (hf i).2)
  have hc' : triangleYCentroid (pos a b) 0 1 2 ≠ triangleYCentroid (pos a b) 3 4 5 := by
    change (b+b+a)/3 ≠ (0+1+1:ℝ)/3
    intro he; apply hc; linarith only [he]
  refine ⟨b,hb,hc',hm,triangles_equilateral a b,hI,qm,-k,neg_pos.mpr neg,?_⟩
  intro i
  simpa using And.intro (fx i) (fy i)

#print axioms physical_six_body_standard
end SixTriangles
