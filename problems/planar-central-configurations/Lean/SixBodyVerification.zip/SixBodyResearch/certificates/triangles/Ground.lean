import Force
import Mathlib.Data.Fin.VecNotation
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Tactic.FinCases

namespace SixTriangles
abbrev Point := ℝ × ℝ

/-- The height coordinate is physical height divided by sqrt 3. -/
def pos (a b : ℝ) : Fin 6 → Point :=
  ![(a-b,b),(b-a,b),(0,a),(0,0),(1,1),(-1,1)]
def mass (u v w : ℝ) : Fin 6 → ℝ := ![u,u,v,w,1,1]
noncomputable def grav (squareDistance : ℝ) := 1/(squareDistance * Real.sqrt squareDistance)
def sqDist (x y : Point) := (y.1-x.1)^2+3*(y.2-x.2)^2
noncomputable def newtonX (p : Fin 6 → Point) (m : Fin 6 → ℝ) (i : Fin 6) : ℝ :=
  ∑ j : Fin 6, (m j) * ((p j).1-(p i).1) * grav (sqDist (p i) (p j))
noncomputable def newtonY (p : Fin 6 → Point) (m : Fin 6 → ℝ) (i : Fin 6) : ℝ :=
  ∑ j : Fin 6, (m j) * ((p j).2-(p i).2) * grav (sqDist (p i) (p j))

/-- Affine central-configuration equations at all six positions. The term with
j=i contributes zero, which lets the sum run over all six indices. -/
def Central (p : Fin 6 → Point) (m : Fin 6 → ℝ) : Prop :=
  ∃ k j : ℝ, ∀ i, newtonX p m i = k*(p i).1 ∧ newtonY p m i = k*(p i).2+j

end SixTriangles
