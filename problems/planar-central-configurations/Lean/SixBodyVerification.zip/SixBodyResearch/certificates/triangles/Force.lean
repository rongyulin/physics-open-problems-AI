import Bounds

namespace SixTriangles

/-- Coordinate equations for the four orbits of the reflection symmetry.
The x-coordinate is physical.  The vertical coordinate is divided by sqrt 3.
u = mass at each inner base, v = inner apex, w = outer apex, outer pair mass = 1.
h,t,s,r,c,l are the six distinct inverse-cube distances, apart from 1/8. -/
def ForceEquations (a b d h t s r c l u v w : ℝ) : Prop :=
  let x₁ := -2*d*h*u - d*h*v - d*t*w + (1-d)*s - (1+d)*r
  let y₁ := d*h*v - b*t*w + (1-b)*(s+r)
  let y₃ := -2*d*h*u - a*c*w + 2*(1-a)*l
  let y₄ := 2*b*t*u + a*c*v + 2/8
  let x₅ := ((d-1)*s-(d+1)*r)*u-l*v-(1/8)*w-2/8
  let y₅ := (b-1)*(s+r)*u + (a-1)*l*v -(1/8)*w
  ∃ slope intercept : ℝ,
    x₁ = slope*d ∧ y₁ = slope*b+intercept ∧ y₃ = slope*a+intercept ∧
    y₄ = intercept ∧ x₅ = slope ∧ y₅ = slope+intercept

theorem force_from_reduction
    (a b d h t s r c l u v w R S : ℝ)
    (hd : d = a-b)
    (hv : v = u*R)
    (hS : S = (d-1)*s-(d+1)*r-R*l)
    (hw : a*(t-c)*w = (2-a)*s-a*r-2*(1-a)*l)
    (hR : a*(l-c)*R = 2*b*t-(b-d)*s-(b+d)*r)
    (hu : d*(h*(2+R)+S)*u = -d*t*w+(1-d)*s-(1+d)*r+d*(1/8)*(w+2))
    (hres : u*(-2*d*h-2*b*t-a*c*R-a*S) +
      (-a*c*w+2*(1-a)*l-2/8+a*(1/8)*(w+2)) = 0) :
    ForceEquations a b d h t s r c l u v w := by
  subst d
  subst v
  subst S
  refine ⟨((a-b-1)*s-(a-b+1)*r)*u-l*(u*R)-(1/8)*w-2/8,
    2*b*t*u+a*c*(u*R)+2/8, ?_, ?_, ?_, rfl, rfl, ?_⟩
  · linear_combination -hu
  · linear_combination hres - hw + hu
  · linear_combination hres
  · linear_combination u * hR

end SixTriangles
