import Theorem
import Newton
namespace SixTriangles
set_option maxRecDepth 4096
set_option maxHeartbeats 3000000
theorem six_body_equations (a : ℝ) (ha : ARange a) : ∃ b ∈ strip, a+2*b ≠ 2 ∧
  (0 < outerApexMass a b ∧ outerApexMass a b < innerPairMass a b ∧ innerPairMass a b < 1 ∧ 1 < innerApexMass a b) ∧
  Central (pos a b) (mass (innerPairMass a b) (innerApexMass a b) (outerApexMass a b)) := by
  obtain ⟨b,hb,hc,hm,hf⟩ := nonconcentric_six_body a ha
  refine ⟨b,hb,hc,hm,?_⟩
  have wd : 0 ≤ 2 * width a b := by
    have hx := ha.1; have hy := hb.2; norm_num [bHigh] at hx hy
    simp only [width,term2]; linarith
  apply newton_from_components a b (width a b) (innerForce a b) (innerToOrigin a b) (nearSide a b) (farSide a b) (apexToOrigin a b) (apexToPair a b) _ _ _ _ _ _ _ _ _ _ hf
  · simp [width,term2,sub_eq_add_neg]
  · rw [grav,Real.sqrt_sq wd]; simp only [innerForce,term10,term8,term7,term6]; push_cast; ring
  · have he : (width a b)^2+3*b^2 = term16 a b := by
      simp only [term19,term18,term16,term12,term15,term14,term17] <;> push_cast <;> ring
    rw [he]; simp [innerToOrigin,term19,term18,term17,grav]
  · have he : (1-width a b)^2+3*(1-b)^2 = term32 a b := by
      simp only [term35,term34,term32,term25,term22,term21,term24,term23,term31,term28,term27,term26,term30,term29,term33] <;> push_cast <;> ring
    rw [he]; simp [nearSide,term35,term34,term33,grav]
  · have he : (1+width a b)^2+3*(1-b)^2 = term46 a b := by
      simp only [term49,term48,term46,term39,term37,term38,term45,term42,term41,term40,term44,term43,term47] <;> push_cast <;> ring
    rw [he]; simp [farSide,term49,term48,term47,grav]
  · have he : 3*a^2 = term52 a b := by
      simp only [term55,term54,term52,term51,term53] <;> push_cast <;> ring
    rw [he]; simp [apexToOrigin,term55,term54,term53,grav]
  · have he : 1+3*(1-a)^2 = term63 a b := by
      simp only [term66,term65,term63,term62,term59,term58,term57,term61,term60,term64] <;> push_cast <;> ring
    rw [he]; simp [apexToPair,term66,term65,term64,grav]
#print axioms six_body_equations
end SixTriangles
