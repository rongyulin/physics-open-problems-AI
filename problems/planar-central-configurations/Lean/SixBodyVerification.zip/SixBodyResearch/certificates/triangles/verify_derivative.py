"""Enclose partial derivatives of the scalar residual by rational interval AD."""
from fractions import Fraction as F
from make_certificate import A, B, NODES, evaluate, lower, upper, res, w

def plus(x, y):
    return lower(x[0]+y[0]), upper(x[1]+y[1])
def neg(x):
    return -x[1], -x[0]
def mult(x, y):
    products=[a*b for a in x for b in y]
    return lower(min(products)), upper(max(products))
def inv(x):
    assert x[0]>0
    return lower(1/x[1]), upper(1/x[0])

def derivative(A,B,variable):
    vals=evaluate(A,B); ders=[]
    for n in NODES:
        if n.op in ('a','b','const'):
            z=F(n.op==variable)
            ders.append((z,z)); continue
        j=n.args[0].i; x,dx=vals[j],ders[j]
        if n.op in ('plus','mul'):
            k=n.args[1].i; y,dy=vals[k],ders[k]
            out=plus(dx,dy) if n.op=='plus' else plus(mult(x,dy),mult(dx,y))
        elif n.op=='neg': out=neg(dx)
        elif n.op=='inverse':
            # d(1/x)=-x' (1/x)^2.
            f=vals[n.i]; out=neg(mult(dx,mult(f,f)))
        elif n.op=='sqrt':
            out=mult(dx,inv(mult((F(2),F(2)),vals[n.i])))
        else:raise ValueError(n.op)
        ders.append(out)
    return ders

if __name__=='__main__':
    for var in ('a','b'):
        for n in [res]:
            q=derivative(A,B,var)[n.i]
            print(var,n.nm,q,tuple(map(float,q)))
            if var=='b': assert q[0] > 0
    da,db=derivative(A,B,'a'),derivative(A,B,'b')
    slope=mult(neg(da[res.i]),inv(db[res.i]))
    mass_slope=plus(da[w.i],mult(db[w.i],slope))
    assert slope[0]>0 and mass_slope[0]>0
    print('db/da',*map(str,slope))
    print('dw/da',*map(str,mass_slope))
