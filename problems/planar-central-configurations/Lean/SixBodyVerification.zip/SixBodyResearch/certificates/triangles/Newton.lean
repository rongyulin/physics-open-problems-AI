import Ground
namespace SixTriangles
set_option maxRecDepth 4096
set_option maxHeartbeats 4500000
theorem newton_from_components (a b d h t s r c l u v w : ℝ) (hd : d = a-b)
    (hh : grav ((2*d)^2) = h) (ht : grav (d^2+3*b^2) = t)
    (hs : grav ((1-d)^2+3*(1-b)^2) = s) (hr : grav ((1+d)^2+3*(1-b)^2) = r)
    (hc : grav (3*a^2) = c) (hl : grav (1+3*(1-a)^2) = l)
    (eq : ForceEquations a b d h t s r c l u v w) : Central (pos a b) (mass u v w) := by
  obtain ⟨k,j,hx₁,hy₁,hy₃,hy₄,hx₅,hy₅⟩ := eq
  have sq : Real.sqrt 4 = 2 := by rw [Real.sqrt_eq_iff_eq_sq] <;> norm_num
  have he : grav 4 = (1/8 : ℝ) := by norm_num [grav,sq]
  have bSub : b-a = -d := by linarith
  have aSub : a-b = d := hd.symm
  have p0 : pos a b 0 = (a-b,b) := rfl
  have m0 : mass u v w 0 = u := rfl
  have p1 : pos a b 1 = (b-a,b) := rfl
  have m1 : mass u v w 1 = u := rfl
  have p2 : pos a b 2 = (0,a) := rfl
  have m2 : mass u v w 2 = v := rfl
  have p3 : pos a b 3 = (0,0) := rfl
  have m3 : mass u v w 3 = w := rfl
  have p4 : pos a b 4 = (1,1) := rfl
  have m4 : mass u v w 4 = 1 := rfl
  have p5 : pos a b 5 = (-1,1) := rfl
  have m5 : mass u v w 5 = 1 := rfl
  have g01 : grav (sqDist (pos a b 0) (pos a b 1)) = h := by
    rw [show sqDist (pos a b 0) (pos a b 1) = (2*d)^2 by
      simp only [sqDist,p0,p1,hd] <;> ring]
    exact hh
  have g02 : grav (sqDist (pos a b 0) (pos a b 2)) = h := by
    rw [show sqDist (pos a b 0) (pos a b 2) = (2*d)^2 by
      simp only [sqDist,p0,p2,hd] <;> ring]
    exact hh
  have g03 : grav (sqDist (pos a b 0) (pos a b 3)) = t := by
    rw [show sqDist (pos a b 0) (pos a b 3) = d^2+3*b^2 by
      simp only [sqDist,p0,p3,hd] <;> ring]
    exact ht
  have g04 : grav (sqDist (pos a b 0) (pos a b 4)) = s := by
    rw [show sqDist (pos a b 0) (pos a b 4) = (1-d)^2+3*(1-b)^2 by
      simp only [sqDist,p0,p4,hd] <;> ring]
    exact hs
  have g05 : grav (sqDist (pos a b 0) (pos a b 5)) = r := by
    rw [show sqDist (pos a b 0) (pos a b 5) = (1+d)^2+3*(1-b)^2 by
      simp only [sqDist,p0,p5,hd] <;> ring]
    exact hr
  have g10 : grav (sqDist (pos a b 1) (pos a b 0)) = h := by
    rw [show sqDist (pos a b 1) (pos a b 0) = (2*d)^2 by
      simp only [sqDist,p1,p0,hd] <;> ring]
    exact hh
  have g12 : grav (sqDist (pos a b 1) (pos a b 2)) = h := by
    rw [show sqDist (pos a b 1) (pos a b 2) = (2*d)^2 by
      simp only [sqDist,p1,p2,hd] <;> ring]
    exact hh
  have g13 : grav (sqDist (pos a b 1) (pos a b 3)) = t := by
    rw [show sqDist (pos a b 1) (pos a b 3) = d^2+3*b^2 by
      simp only [sqDist,p1,p3,hd] <;> ring]
    exact ht
  have g14 : grav (sqDist (pos a b 1) (pos a b 4)) = r := by
    rw [show sqDist (pos a b 1) (pos a b 4) = (1+d)^2+3*(1-b)^2 by
      simp only [sqDist,p1,p4,hd] <;> ring]
    exact hr
  have g15 : grav (sqDist (pos a b 1) (pos a b 5)) = s := by
    rw [show sqDist (pos a b 1) (pos a b 5) = (1-d)^2+3*(1-b)^2 by
      simp only [sqDist,p1,p5,hd] <;> ring]
    exact hs
  have g20 : grav (sqDist (pos a b 2) (pos a b 0)) = h := by
    rw [show sqDist (pos a b 2) (pos a b 0) = (2*d)^2 by
      simp only [sqDist,p2,p0,hd] <;> ring]
    exact hh
  have g21 : grav (sqDist (pos a b 2) (pos a b 1)) = h := by
    rw [show sqDist (pos a b 2) (pos a b 1) = (2*d)^2 by
      simp only [sqDist,p2,p1,hd] <;> ring]
    exact hh
  have g23 : grav (sqDist (pos a b 2) (pos a b 3)) = c := by
    rw [show sqDist (pos a b 2) (pos a b 3) = 3*a^2 by
      simp only [sqDist,p2,p3,hd] <;> ring]
    exact hc
  have g24 : grav (sqDist (pos a b 2) (pos a b 4)) = l := by
    rw [show sqDist (pos a b 2) (pos a b 4) = 1+3*(1-a)^2 by
      simp only [sqDist,p2,p4,hd] <;> ring]
    exact hl
  have g25 : grav (sqDist (pos a b 2) (pos a b 5)) = l := by
    rw [show sqDist (pos a b 2) (pos a b 5) = 1+3*(1-a)^2 by
      simp only [sqDist,p2,p5,hd] <;> ring]
    exact hl
  have g30 : grav (sqDist (pos a b 3) (pos a b 0)) = t := by
    rw [show sqDist (pos a b 3) (pos a b 0) = d^2+3*b^2 by
      simp only [sqDist,p3,p0,hd] <;> ring]
    exact ht
  have g31 : grav (sqDist (pos a b 3) (pos a b 1)) = t := by
    rw [show sqDist (pos a b 3) (pos a b 1) = d^2+3*b^2 by
      simp only [sqDist,p3,p1,hd] <;> ring]
    exact ht
  have g32 : grav (sqDist (pos a b 3) (pos a b 2)) = c := by
    rw [show sqDist (pos a b 3) (pos a b 2) = 3*a^2 by
      simp only [sqDist,p3,p2,hd] <;> ring]
    exact hc
  have g34 : grav (sqDist (pos a b 3) (pos a b 4)) = (1/8:ℝ) := by
    rw [show sqDist (pos a b 3) (pos a b 4) = 4 by
      simp only [sqDist,p3,p4,hd] <;> ring]
    exact he
  have g35 : grav (sqDist (pos a b 3) (pos a b 5)) = (1/8:ℝ) := by
    rw [show sqDist (pos a b 3) (pos a b 5) = 4 by
      simp only [sqDist,p3,p5,hd] <;> ring]
    exact he
  have g40 : grav (sqDist (pos a b 4) (pos a b 0)) = s := by
    rw [show sqDist (pos a b 4) (pos a b 0) = (1-d)^2+3*(1-b)^2 by
      simp only [sqDist,p4,p0,hd] <;> ring]
    exact hs
  have g41 : grav (sqDist (pos a b 4) (pos a b 1)) = r := by
    rw [show sqDist (pos a b 4) (pos a b 1) = (1+d)^2+3*(1-b)^2 by
      simp only [sqDist,p4,p1,hd] <;> ring]
    exact hr
  have g42 : grav (sqDist (pos a b 4) (pos a b 2)) = l := by
    rw [show sqDist (pos a b 4) (pos a b 2) = 1+3*(1-a)^2 by
      simp only [sqDist,p4,p2,hd] <;> ring]
    exact hl
  have g43 : grav (sqDist (pos a b 4) (pos a b 3)) = (1/8:ℝ) := by
    rw [show sqDist (pos a b 4) (pos a b 3) = 4 by
      simp only [sqDist,p4,p3,hd] <;> ring]
    exact he
  have g45 : grav (sqDist (pos a b 4) (pos a b 5)) = (1/8:ℝ) := by
    rw [show sqDist (pos a b 4) (pos a b 5) = 4 by
      simp only [sqDist,p4,p5,hd] <;> ring]
    exact he
  have g50 : grav (sqDist (pos a b 5) (pos a b 0)) = r := by
    rw [show sqDist (pos a b 5) (pos a b 0) = (1+d)^2+3*(1-b)^2 by
      simp only [sqDist,p5,p0,hd] <;> ring]
    exact hr
  have g51 : grav (sqDist (pos a b 5) (pos a b 1)) = s := by
    rw [show sqDist (pos a b 5) (pos a b 1) = (1-d)^2+3*(1-b)^2 by
      simp only [sqDist,p5,p1,hd] <;> ring]
    exact hs
  have g52 : grav (sqDist (pos a b 5) (pos a b 2)) = l := by
    rw [show sqDist (pos a b 5) (pos a b 2) = 1+3*(1-a)^2 by
      simp only [sqDist,p5,p2,hd] <;> ring]
    exact hl
  have g53 : grav (sqDist (pos a b 5) (pos a b 3)) = (1/8:ℝ) := by
    rw [show sqDist (pos a b 5) (pos a b 3) = 4 by
      simp only [sqDist,p5,p3,hd] <;> ring]
    exact he
  have g54 : grav (sqDist (pos a b 5) (pos a b 4)) = (1/8:ℝ) := by
    rw [show sqDist (pos a b 5) (pos a b 4) = 4 by
      simp only [sqDist,p5,p4,hd] <;> ring]
    exact he
  refine ⟨k,j,?_⟩
  intro i
  fin_cases i
  · change newtonX (pos a b) (mass u v w) 0 = _ ∧ newtonY (pos a b) (mass u v w) 0 = _
    unfold newtonX newtonY
    simp only [Fin.sum_univ_succ,Fin.isValue,Fin.reduceFinMk,Fin.reduceSucc,Fin.sum_univ_zero]
    simp only [g01,g02,g03,g04,g05]
    simp only [p0,p1,p2,p3,p4,p5,m0,m1,m2,m3,m4,m5,aSub,bSub]
    constructor
    · linear_combination hx₁
    · linear_combination hy₁
  · change newtonX (pos a b) (mass u v w) 1 = _ ∧ newtonY (pos a b) (mass u v w) 1 = _
    unfold newtonX newtonY
    simp only [Fin.sum_univ_succ,Fin.isValue,Fin.reduceFinMk,Fin.reduceSucc,Fin.sum_univ_zero]
    simp only [g10,g12,g13,g14,g15]
    simp only [p0,p1,p2,p3,p4,p5,m0,m1,m2,m3,m4,m5,aSub,bSub]
    constructor
    · linear_combination -hx₁
    · linear_combination hy₁
  · change newtonX (pos a b) (mass u v w) 2 = _ ∧ newtonY (pos a b) (mass u v w) 2 = _
    unfold newtonX newtonY
    simp only [Fin.sum_univ_succ,Fin.isValue,Fin.reduceFinMk,Fin.reduceSucc,Fin.sum_univ_zero]
    simp only [g20,g21,g23,g24,g25]
    simp only [p0,p1,p2,p3,p4,p5,m0,m1,m2,m3,m4,m5,aSub,bSub]
    constructor
    · ring
    · linear_combination hy₃
  · change newtonX (pos a b) (mass u v w) 3 = _ ∧ newtonY (pos a b) (mass u v w) 3 = _
    unfold newtonX newtonY
    simp only [Fin.sum_univ_succ,Fin.isValue,Fin.reduceFinMk,Fin.reduceSucc,Fin.sum_univ_zero]
    simp only [g30,g31,g32,g34,g35]
    simp only [p0,p1,p2,p3,p4,p5,m0,m1,m2,m3,m4,m5,aSub,bSub]
    constructor
    · ring
    · linear_combination hy₄
  · change newtonX (pos a b) (mass u v w) 4 = _ ∧ newtonY (pos a b) (mass u v w) 4 = _
    unfold newtonX newtonY
    simp only [Fin.sum_univ_succ,Fin.isValue,Fin.reduceFinMk,Fin.reduceSucc,Fin.sum_univ_zero]
    simp only [g40,g41,g42,g43,g45]
    simp only [p0,p1,p2,p3,p4,p5,m0,m1,m2,m3,m4,m5,aSub,bSub]
    constructor
    · linear_combination hx₅
    · linear_combination hy₅
  · change newtonX (pos a b) (mass u v w) 5 = _ ∧ newtonY (pos a b) (mass u v w) 5 = _
    unfold newtonX newtonY
    simp only [Fin.sum_univ_succ,Fin.isValue,Fin.reduceFinMk,Fin.reduceSucc,Fin.sum_univ_zero]
    simp only [g50,g51,g52,g53,g54]
    simp only [p0,p1,p2,p3,p4,p5,m0,m1,m2,m3,m4,m5,aSub,bSub]
    constructor
    · linear_combination -hx₅
    · linear_combination hy₅
end SixTriangles
