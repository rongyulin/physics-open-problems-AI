import Certificate
import Force
namespace SixTriangles
set_option maxRecDepth 4096
set_option maxHeartbeats 4500000
abbrev bLow : ℝ := (((5611/20000:ℚ)) : ℝ)
abbrev bHigh : ℝ := (((1403/5000:ℚ)) : ℝ)
abbrev strip := Set.Icc bLow bHigh
abbrev ARange (a : ℝ) := Box a (874999999/1000000000:ℚ) (875000001/1000000000:ℚ)
theorem denominators (a b : ℝ) (ha : ARange a) (hb : b ∈ strip) : term8 a b ≠ 0 ∧ term18 a b ≠ 0 ∧ term34 a b ≠ 0 ∧ term48 a b ≠ 0 ∧ term54 a b ≠ 0 ∧ term65 a b ≠ 0 ∧ term82 a b ≠ 0 ∧ term98 a b ≠ 0 ∧ term129 a b ≠ 0 := by
  obtain ⟨_, _, _, h8, h18, h34, h48, h54, h65, h82, h98, h129⟩ := rangeFull a b ha hb
  refine ⟨?_ , ?_ , ?_ , ?_ , ?_ , ?_ , ?_ , ?_ , ?_ ⟩
  · exact ne_of_gt (lt_of_lt_of_le (by norm_num) h8.1)
  · exact ne_of_gt (lt_of_lt_of_le (by norm_num) h18.1)
  · exact ne_of_gt (lt_of_lt_of_le (by norm_num) h34.1)
  · exact ne_of_gt (lt_of_lt_of_le (by norm_num) h48.1)
  · exact ne_of_gt (lt_of_lt_of_le (by norm_num) h54.1)
  · exact ne_of_gt (lt_of_lt_of_le (by norm_num) h65.1)
  · exact ne_of_gt (lt_of_lt_of_le (by norm_num) h82.1)
  · exact ne_of_gt (lt_of_lt_of_le (by norm_num) h98.1)
  · exact ne_of_gt (lt_of_lt_of_le (by norm_num) h129.1)
theorem continuousResidual (a : ℝ) (ha : ARange a) : ContinuousOn (residual a) strip := by
  have p8 : ∀ b ∈ strip, term8 a b ≠ 0 := fun b hb => (denominators a b ha hb).1
  have p18 : ∀ b ∈ strip, term18 a b ≠ 0 := fun b hb => (denominators a b ha hb).2.1
  have p34 : ∀ b ∈ strip, term34 a b ≠ 0 := fun b hb => (denominators a b ha hb).2.2.1
  have p48 : ∀ b ∈ strip, term48 a b ≠ 0 := fun b hb => (denominators a b ha hb).2.2.2.1
  have p54 : ∀ b ∈ strip, term54 a b ≠ 0 := fun b hb => (denominators a b ha hb).2.2.2.2.1
  have p65 : ∀ b ∈ strip, term65 a b ≠ 0 := fun b hb => (denominators a b ha hb).2.2.2.2.2.1
  have p82 : ∀ b ∈ strip, term82 a b ≠ 0 := fun b hb => (denominators a b ha hb).2.2.2.2.2.2.1
  have p98 : ∀ b ∈ strip, term98 a b ≠ 0 := fun b hb => (denominators a b ha hb).2.2.2.2.2.2.2.1
  have p129 : ∀ b ∈ strip, term129 a b ≠ 0 := fun b hb => (denominators a b ha hb).2.2.2.2.2.2.2.2
  have z2 : ContinuousOn (term2 a) strip := ContinuousOn.neg continuousOn_id
  have z3 : ContinuousOn (width a) strip := ContinuousOn.add continuousOn_const z2
  have z6 : ContinuousOn (term6 a) strip := ContinuousOn.mul continuousOn_const z3
  have z7 : ContinuousOn (term7 a) strip := ContinuousOn.mul z6 z6
  have z8 : ContinuousOn (term8 a) strip := ContinuousOn.mul z7 z6
  have z10 : ContinuousOn (term10 a) strip := ContinuousOn.div continuousOn_const z8 p8
  have z11 : ContinuousOn (innerForce a) strip := ContinuousOn.mul continuousOn_const z10
  have z12 : ContinuousOn (term12 a) strip := ContinuousOn.mul z3 z3
  have z14 : ContinuousOn (term14 a) strip := ContinuousOn.mul continuousOn_const continuousOn_id
  have z15 : ContinuousOn (term15 a) strip := ContinuousOn.mul z14 continuousOn_id
  have z16 : ContinuousOn (term16 a) strip := ContinuousOn.add z12 z15
  have z17 : ContinuousOn (term17 a) strip := Real.continuous_sqrt.comp_continuousOn z16
  have z18 : ContinuousOn (term18 a) strip := ContinuousOn.mul z16 z17
  have z19 : ContinuousOn (term19 a) strip := ContinuousOn.div continuousOn_const z18 p18
  have z20 : ContinuousOn (innerToOrigin a) strip := ContinuousOn.mul continuousOn_const z19
  have z21 : ContinuousOn (term21 a) strip := ContinuousOn.neg z3
  have z22 : ContinuousOn (term22 a) strip := ContinuousOn.add continuousOn_const z21
  have z23 : ContinuousOn (term23 a) strip := ContinuousOn.neg z3
  have z24 : ContinuousOn (term24 a) strip := ContinuousOn.add continuousOn_const z23
  have z25 : ContinuousOn (term25 a) strip := ContinuousOn.mul z22 z24
  have z26 : ContinuousOn (term26 a) strip := ContinuousOn.neg continuousOn_id
  have z27 : ContinuousOn (term27 a) strip := ContinuousOn.add continuousOn_const z26
  have z28 : ContinuousOn (term28 a) strip := ContinuousOn.mul continuousOn_const z27
  have z29 : ContinuousOn (term29 a) strip := ContinuousOn.neg continuousOn_id
  have z30 : ContinuousOn (term30 a) strip := ContinuousOn.add continuousOn_const z29
  have z31 : ContinuousOn (term31 a) strip := ContinuousOn.mul z28 z30
  have z32 : ContinuousOn (term32 a) strip := ContinuousOn.add z25 z31
  have z33 : ContinuousOn (term33 a) strip := Real.continuous_sqrt.comp_continuousOn z32
  have z34 : ContinuousOn (term34 a) strip := ContinuousOn.mul z32 z33
  have z35 : ContinuousOn (term35 a) strip := ContinuousOn.div continuousOn_const z34 p34
  have z36 : ContinuousOn (nearSide a) strip := ContinuousOn.mul continuousOn_const z35
  have z37 : ContinuousOn (term37 a) strip := ContinuousOn.add continuousOn_const z3
  have z38 : ContinuousOn (term38 a) strip := ContinuousOn.add continuousOn_const z3
  have z39 : ContinuousOn (term39 a) strip := ContinuousOn.mul z37 z38
  have z40 : ContinuousOn (term40 a) strip := ContinuousOn.neg continuousOn_id
  have z41 : ContinuousOn (term41 a) strip := ContinuousOn.add continuousOn_const z40
  have z42 : ContinuousOn (term42 a) strip := ContinuousOn.mul continuousOn_const z41
  have z43 : ContinuousOn (term43 a) strip := ContinuousOn.neg continuousOn_id
  have z44 : ContinuousOn (term44 a) strip := ContinuousOn.add continuousOn_const z43
  have z45 : ContinuousOn (term45 a) strip := ContinuousOn.mul z42 z44
  have z46 : ContinuousOn (term46 a) strip := ContinuousOn.add z39 z45
  have z47 : ContinuousOn (term47 a) strip := Real.continuous_sqrt.comp_continuousOn z46
  have z48 : ContinuousOn (term48 a) strip := ContinuousOn.mul z46 z47
  have z49 : ContinuousOn (term49 a) strip := ContinuousOn.div continuousOn_const z48 p48
  have z50 : ContinuousOn (farSide a) strip := ContinuousOn.mul continuousOn_const z49
  have z51 : ContinuousOn (term51 a) strip := ContinuousOn.mul continuousOn_const continuousOn_const
  have z52 : ContinuousOn (term52 a) strip := ContinuousOn.mul z51 continuousOn_const
  have z53 : ContinuousOn (term53 a) strip := Real.continuous_sqrt.comp_continuousOn z52
  have z54 : ContinuousOn (term54 a) strip := ContinuousOn.mul z52 z53
  have z55 : ContinuousOn (term55 a) strip := ContinuousOn.div continuousOn_const z54 p54
  have z56 : ContinuousOn (apexToOrigin a) strip := ContinuousOn.mul continuousOn_const z55
  have z57 : ContinuousOn (term57 a) strip := ContinuousOn.neg continuousOn_const
  have z58 : ContinuousOn (term58 a) strip := ContinuousOn.add continuousOn_const z57
  have z59 : ContinuousOn (term59 a) strip := ContinuousOn.mul continuousOn_const z58
  have z60 : ContinuousOn (term60 a) strip := ContinuousOn.neg continuousOn_const
  have z61 : ContinuousOn (term61 a) strip := ContinuousOn.add continuousOn_const z60
  have z62 : ContinuousOn (term62 a) strip := ContinuousOn.mul z59 z61
  have z63 : ContinuousOn (term63 a) strip := ContinuousOn.add continuousOn_const z62
  have z64 : ContinuousOn (term64 a) strip := Real.continuous_sqrt.comp_continuousOn z63
  have z65 : ContinuousOn (term65 a) strip := ContinuousOn.mul z63 z64
  have z66 : ContinuousOn (term66 a) strip := ContinuousOn.div continuousOn_const z65 p65
  have z67 : ContinuousOn (apexToPair a) strip := ContinuousOn.mul continuousOn_const z66
  have z68 : ContinuousOn (term68 a) strip := ContinuousOn.neg continuousOn_const
  have z69 : ContinuousOn (term69 a) strip := ContinuousOn.add continuousOn_const z68
  have z70 : ContinuousOn (term70 a) strip := ContinuousOn.mul z69 z36
  have z71 : ContinuousOn (term71 a) strip := ContinuousOn.mul continuousOn_const z50
  have z72 : ContinuousOn (term72 a) strip := ContinuousOn.neg z71
  have z73 : ContinuousOn (term73 a) strip := ContinuousOn.add z70 z72
  have z74 : ContinuousOn (term74 a) strip := ContinuousOn.neg continuousOn_const
  have z75 : ContinuousOn (term75 a) strip := ContinuousOn.add continuousOn_const z74
  have z76 : ContinuousOn (term76 a) strip := ContinuousOn.mul continuousOn_const z75
  have z77 : ContinuousOn (term77 a) strip := ContinuousOn.mul z76 z67
  have z78 : ContinuousOn (term78 a) strip := ContinuousOn.neg z77
  have z79 : ContinuousOn (term79 a) strip := ContinuousOn.add z73 z78
  have z80 : ContinuousOn (term80 a) strip := ContinuousOn.neg z56
  have z81 : ContinuousOn (term81 a) strip := ContinuousOn.add z20 z80
  have z82 : ContinuousOn (term82 a) strip := ContinuousOn.mul continuousOn_const z81
  have z83 : ContinuousOn (term83 a) strip := ContinuousOn.div continuousOn_const z82 p82
  have z84 : ContinuousOn (outerApexMass a) strip := ContinuousOn.mul z79 z83
  have z85 : ContinuousOn (term85 a) strip := ContinuousOn.mul continuousOn_const continuousOn_id
  have z86 : ContinuousOn (term86 a) strip := ContinuousOn.mul z85 z20
  have z87 : ContinuousOn (term87 a) strip := ContinuousOn.neg z3
  have z88 : ContinuousOn (term88 a) strip := ContinuousOn.add continuousOn_id z87
  have z89 : ContinuousOn (term89 a) strip := ContinuousOn.mul z88 z36
  have z90 : ContinuousOn (term90 a) strip := ContinuousOn.neg z89
  have z91 : ContinuousOn (term91 a) strip := ContinuousOn.add z86 z90
  have z92 : ContinuousOn (term92 a) strip := ContinuousOn.add continuousOn_id z3
  have z93 : ContinuousOn (term93 a) strip := ContinuousOn.mul z92 z50
  have z94 : ContinuousOn (term94 a) strip := ContinuousOn.neg z93
  have z95 : ContinuousOn (term95 a) strip := ContinuousOn.add z91 z94
  have z96 : ContinuousOn (term96 a) strip := ContinuousOn.neg z56
  have z97 : ContinuousOn (term97 a) strip := ContinuousOn.add z67 z96
  have z98 : ContinuousOn (term98 a) strip := ContinuousOn.mul continuousOn_const z97
  have z99 : ContinuousOn (term99 a) strip := ContinuousOn.div continuousOn_const z98 p98
  have z100 : ContinuousOn (innerRatio a) strip := ContinuousOn.mul z95 z99
  have z101 : ContinuousOn (term101 a) strip := ContinuousOn.neg continuousOn_const
  have z102 : ContinuousOn (term102 a) strip := ContinuousOn.add z3 z101
  have z103 : ContinuousOn (term103 a) strip := ContinuousOn.mul z102 z36
  have z104 : ContinuousOn (term104 a) strip := ContinuousOn.add z3 continuousOn_const
  have z105 : ContinuousOn (term105 a) strip := ContinuousOn.mul z104 z50
  have z106 : ContinuousOn (term106 a) strip := ContinuousOn.neg z105
  have z107 : ContinuousOn (term107 a) strip := ContinuousOn.add z103 z106
  have z108 : ContinuousOn (term108 a) strip := ContinuousOn.mul z100 z67
  have z109 : ContinuousOn (term109 a) strip := ContinuousOn.neg z108
  have z110 : ContinuousOn (horizontalUnit a) strip := ContinuousOn.add z107 z109
  have z111 : ContinuousOn (term111 a) strip := ContinuousOn.neg z3
  have z112 : ContinuousOn (term112 a) strip := ContinuousOn.mul z111 z20
  have z113 : ContinuousOn (term113 a) strip := ContinuousOn.mul z112 z84
  have z114 : ContinuousOn (term114 a) strip := ContinuousOn.neg z3
  have z115 : ContinuousOn (term115 a) strip := ContinuousOn.add continuousOn_const z114
  have z116 : ContinuousOn (term116 a) strip := ContinuousOn.mul z115 z36
  have z117 : ContinuousOn (term117 a) strip := ContinuousOn.add z113 z116
  have z118 : ContinuousOn (term118 a) strip := ContinuousOn.add continuousOn_const z3
  have z119 : ContinuousOn (term119 a) strip := ContinuousOn.mul z118 z50
  have z120 : ContinuousOn (term120 a) strip := ContinuousOn.neg z119
  have z121 : ContinuousOn (term121 a) strip := ContinuousOn.add z117 z120
  have z122 : ContinuousOn (term122 a) strip := ContinuousOn.mul z3 continuousOn_const
  have z123 : ContinuousOn (term123 a) strip := ContinuousOn.add z84 continuousOn_const
  have z124 : ContinuousOn (term124 a) strip := ContinuousOn.mul z122 z123
  have z125 : ContinuousOn (term125 a) strip := ContinuousOn.add z121 z124
  have z126 : ContinuousOn (term126 a) strip := ContinuousOn.add continuousOn_const z100
  have z127 : ContinuousOn (term127 a) strip := ContinuousOn.mul z11 z126
  have z128 : ContinuousOn (term128 a) strip := ContinuousOn.add z127 z110
  have z129 : ContinuousOn (term129 a) strip := ContinuousOn.mul z3 z128
  have z130 : ContinuousOn (term130 a) strip := ContinuousOn.div continuousOn_const z129 p129
  have z131 : ContinuousOn (innerPairMass a) strip := ContinuousOn.mul z125 z130
  have z132 : ContinuousOn (innerApexMass a) strip := ContinuousOn.mul z131 z100
  have z134 : ContinuousOn (term134 a) strip := ContinuousOn.mul continuousOn_const z3
  have z135 : ContinuousOn (term135 a) strip := ContinuousOn.mul z134 z11
  have z136 : ContinuousOn (term136 a) strip := ContinuousOn.mul continuousOn_const continuousOn_id
  have z137 : ContinuousOn (term137 a) strip := ContinuousOn.mul z136 z20
  have z138 : ContinuousOn (term138 a) strip := ContinuousOn.neg z137
  have z139 : ContinuousOn (term139 a) strip := ContinuousOn.add z135 z138
  have z140 : ContinuousOn (term140 a) strip := ContinuousOn.mul continuousOn_const z56
  have z141 : ContinuousOn (term141 a) strip := ContinuousOn.mul z140 z100
  have z142 : ContinuousOn (term142 a) strip := ContinuousOn.neg z141
  have z143 : ContinuousOn (term143 a) strip := ContinuousOn.add z139 z142
  have z144 : ContinuousOn (term144 a) strip := ContinuousOn.mul continuousOn_const z110
  have z145 : ContinuousOn (term145 a) strip := ContinuousOn.neg z144
  have z146 : ContinuousOn (term146 a) strip := ContinuousOn.add z143 z145
  have z147 : ContinuousOn (term147 a) strip := ContinuousOn.mul z131 z146
  have z148 : ContinuousOn (term148 a) strip := ContinuousOn.neg continuousOn_const
  have z149 : ContinuousOn (term149 a) strip := ContinuousOn.mul z148 z56
  have z150 : ContinuousOn (term150 a) strip := ContinuousOn.mul z149 z84
  have z151 : ContinuousOn (term151 a) strip := ContinuousOn.neg continuousOn_const
  have z152 : ContinuousOn (term152 a) strip := ContinuousOn.add continuousOn_const z151
  have z153 : ContinuousOn (term153 a) strip := ContinuousOn.mul continuousOn_const z152
  have z154 : ContinuousOn (term154 a) strip := ContinuousOn.mul z153 z67
  have z155 : ContinuousOn (term155 a) strip := ContinuousOn.add z150 z154
  have z156 : ContinuousOn (term156 a) strip := ContinuousOn.mul continuousOn_const continuousOn_const
  have z157 : ContinuousOn (term157 a) strip := ContinuousOn.neg z156
  have z158 : ContinuousOn (term158 a) strip := ContinuousOn.add z155 z157
  have z159 : ContinuousOn (term159 a) strip := ContinuousOn.mul continuousOn_const continuousOn_const
  have z160 : ContinuousOn (term160 a) strip := ContinuousOn.add z84 continuousOn_const
  have z161 : ContinuousOn (term161 a) strip := ContinuousOn.mul z159 z160
  have z162 : ContinuousOn (term162 a) strip := ContinuousOn.add z158 z161
  have z163 : ContinuousOn (residual a) strip := ContinuousOn.add z147 z162
  exact z163
theorem root_on_strip (a : ℝ) (ha : ARange a) : ∃ b ∈ strip, residual a b = 0 := by
  have hL := (rangeLeft a bLow ha ⟨le_rfl,le_rfl⟩).2
  have hR := (rangeRight a bHigh ha ⟨le_rfl,le_rfl⟩).1
  apply intermediate_value_Icc (a:=bLow) (b:=bHigh) (f:=residual a) (by norm_num [bLow,bHigh]) (continuousResidual a ha)
  exact ⟨le_trans hL (by norm_num), le_trans (by norm_num) hR⟩
theorem physical_root (a b : ℝ) (ha : ARange a) (hb : b ∈ strip) (hz : residual a b = 0) : ForceEquations a b (width a b) (innerForce a b) (innerToOrigin a b) (nearSide a b) (farSide a b) (apexToOrigin a b) (apexToPair a b) (innerPairMass a b) (innerApexMass a b) (outerApexMass a b) := by
  obtain ⟨_,_,_,_,_,_,h82,h98,h129⟩ := denominators a b ha hb
  apply force_from_reduction (R:=innerRatio a b) (S:=horizontalUnit a b)
  · simp [width,term2,sub_eq_add_neg]
  · rfl
  · simp only [horizontalUnit,term107,term103,term102,term101,term106,term105,term104,term109,term108]; push_cast; ring
  · have he : term82 a b * outerApexMass a b = term79 a b := by
      rw [outerApexMass,term83]; field_simp [h82]
    convert he using 1 <;> simp only [term82,term81,term80,term79,term73,term70,term69,term68,term72,term71,term78,term77,term76,term75,term74] <;> push_cast <;> ring
  · have he : term98 a b * innerRatio a b = term95 a b := by
      rw [innerRatio,term99]; field_simp [h98]
    convert he using 1 <;> simp only [term98,term97,term96,term95,term91,term86,term85,term90,term89,term88,term87,term94,term93,term92] <;> push_cast <;> ring
  · have he : term129 a b * innerPairMass a b = term125 a b := by
      rw [innerPairMass,term130]; field_simp [h129]
    convert he using 1 <;> simp only [term129,term128,term127,term126,term125,term121,term117,term113,term112,term111,term116,term115,term114,term120,term119,term118,term124,term122,term123] <;> push_cast <;> ring
  · convert hz using 1 <;> simp only [residual,term147,term146,term143,term139,term135,term134,term138,term137,term136,term142,term141,term140,term145,term144,term162,term158,term155,term150,term149,term148,term154,term153,term152,term151,term157,term156,term161,term159,term160] <;> push_cast <;> ring
theorem nonconcentric_six_body (a : ℝ) (ha : ARange a) : ∃ b ∈ strip,
    a+2*b ≠ 2 ∧ (0 < outerApexMass a b ∧ outerApexMass a b < innerPairMass a b ∧ innerPairMass a b < 1 ∧ 1 < innerApexMass a b) ∧
    ForceEquations a b (width a b) (innerForce a b) (innerToOrigin a b) (nearSide a b) (farSide a b) (apexToOrigin a b) (apexToPair a b) (innerPairMass a b) (innerApexMass a b) (outerApexMass a b) := by
  obtain ⟨b,hb,hz⟩ := root_on_strip a ha
  obtain ⟨hw,hu,hv,_⟩ := rangeFull a b ha hb
  refine ⟨b,hb,?_,?_,physical_root a b ha hb hz⟩
  · have hab := ha.2; have hbb := hb.2; norm_num [bHigh] at hab hbb; linarith
  · exact ⟨lt_of_lt_of_le (by norm_num) hw.1, lt_of_le_of_lt hw.2 (lt_of_lt_of_le (by norm_num) hu.1), lt_of_le_of_lt hu.2 (by norm_num), lt_of_lt_of_le (by norm_num) hv.1⟩
#print axioms nonconcentric_six_body
end SixTriangles
