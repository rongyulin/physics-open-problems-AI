from make_certificate import *
def synth():
    ls=['import Certificate','import Force','namespace SixTriangles','set_option maxRecDepth 4096','set_option maxHeartbeats 4500000']
    lo,hi=map(rat,B)
    ls += [f'abbrev bLow : ℝ := (({lo}) : ℝ)', f'abbrev bHigh : ℝ := (({hi}) : ℝ)', 'abbrev strip := Set.Icc bLow bHigh',
           f'abbrev ARange (a : ℝ) := Box a {rat(A[0])} {rat(A[1])}']
    av=evaluate(A,B)
    denoms=' ∧ '.join(f'{n.nm} a b ≠ 0' for n in allinv)
    ls += [f'theorem denominators (a b : ℝ) (ha : ARange a) (hb : b ∈ strip) : {denoms} := by',
           '  obtain ⟨' + ', '.join(['_','_','_']+[f'h{n.i}' for n in allinv]) + '⟩ := rangeFull a b ha hb',
           '  refine ⟨' + ', '.join('?_ ' for n in allinv) + '⟩']
    for n in allinv:
        ls += [f'  · exact ne_of_gt (lt_of_lt_of_le (by norm_num) h{n.i}.1)']
    ls+=['theorem continuousResidual (a : ℝ) (ha : ARange a) : ContinuousOn (residual a) strip := by']
    for n in allinv:
        i=allinv.index(n)
        idx=('.2' * i)+('.1' if i<len(allinv)-1 else '')
        ls.append(f'  have p{n.i} : ∀ b ∈ strip, {n.nm} a b ≠ 0 := fun b hb => (denominators a b ha hb){idx}')
    decided={}
    for n in NODES:
        op=n.op
        if op=='a' or op=='const':
            decided[n.i]='continuousOn_const';continue
        if op=='b':
            decided[n.i]='continuousOn_id';continue
        cc=decided[n.args[0].i];q=decided[n.args[1].i] if len(n.args)>1 else None
        zz={'plus':f'ContinuousOn.add {cc} {q}','mul':f'ContinuousOn.mul {cc} {q}','neg':f'ContinuousOn.neg {cc}',
            'inverse':f'ContinuousOn.div continuousOn_const {cc} p{n.args[0].i}', 'sqrt':f'Real.continuous_sqrt.comp_continuousOn {cc}'}[op]
        ls.append(f'  have z{n.i} : ContinuousOn ({n.nm} a) strip := {zz}')
        decided[n.i]=f'z{n.i}'
    ls.append(f'  exact z{res.i}')
    ls += ['theorem root_on_strip (a : ℝ) (ha : ARange a) : ∃ b ∈ strip, residual a b = 0 := by',
           '  have hL := (rangeLeft a bLow ha ⟨le_rfl,le_rfl⟩).2',
           '  have hR := (rangeRight a bHigh ha ⟨le_rfl,le_rfl⟩).1',
           '  apply intermediate_value_Icc (a:=bLow) (b:=bHigh) (f:=residual a) (by norm_num [bLow,bHigh]) (continuousResidual a ha)',
           '  exact ⟨le_trans hL (by norm_num), le_trans (by norm_num) hR⟩']
    reduced_names=['a','b',d.nm,h.nm,t.nm,s.nm,r.nm,c.nm,l.nm,u.nm,v.nm,w.nm]
    args=' '.join(x if x in ('a','b') else '('+x+' a b)' for x in reduced_names)
    ls += [f'theorem physical_root (a b : ℝ) (ha : ARange a) (hb : b ∈ strip) (hz : residual a b = 0) : ForceEquations {args} := by',
           '  obtain ⟨_,_,_,_,_,_,h82,h98,h129⟩ := denominators a b ha hb',
           f'  apply force_from_reduction (R:=innerRatio a b) (S:=horizontalUnit a b)',
           '  · simp [width,term2,sub_eq_add_neg]',
           '  · rfl']
    def expand(roots):
        libs=[]
        def walk(m,force=False):
            if m.op in ('a','b','const') or (not force and m.name is not None):return
            if m.nm in libs:return
            libs.append(m.nm)
            for p in m.args:walk(p)
        for m in roots:walk(m,True)
        return ','.join(libs)
    ls+=['  · simp only ['+expand([S])+']; push_cast; ring']
    for den,num,quot in [(82,79,w),(98,95,ratio),(129,125,u)]:
        l1=f'  · have he : {NODES[den].nm} a b * {quot.nm} a b = {NODES[num].nm} a b := by'
        z=quot.args[1].nm
        ls += [l1,f'      rw [{quot.nm},{z}]; field_simp [h{den}]',
               '    convert he using 1 <;> simp only ['+expand([NODES[den],NODES[num]])+'] <;> push_cast <;> ring']
    ls+=['  · convert hz using 1 <;> simp only ['+expand([res])+'] <;> push_cast <;> ring']
    ls += [f'theorem nonconcentric_six_body (a : ℝ) (ha : ARange a) : ∃ b ∈ strip,',
           f'    a+2*b ≠ 2 ∧ (0 < outerApexMass a b ∧ outerApexMass a b < innerPairMass a b ∧ innerPairMass a b < 1 ∧ 1 < innerApexMass a b) ∧',
           f'    ForceEquations {args} := by',
           '  obtain ⟨b,hb,hz⟩ := root_on_strip a ha',
           '  obtain ⟨hw,hu,hv,_⟩ := rangeFull a b ha hb',
           '  refine ⟨b,hb,?_,?_,physical_root a b ha hb hz⟩',
           '  · have hab := ha.2; have hbb := hb.2; norm_num [bHigh] at hab hbb; linarith',
           '  · exact ⟨lt_of_lt_of_le (by norm_num) hw.1, lt_of_le_of_lt hw.2 (lt_of_lt_of_le (by norm_num) hu.1), lt_of_le_of_lt hu.2 (by norm_num), lt_of_lt_of_le (by norm_num) hv.1⟩',
           '#print axioms nonconcentric_six_body','end SixTriangles']
    return '\n'.join(ls)+'\n'
if __name__=='__main__':
    Path(__file__).with_name('Theorem.lean').write_text(synth())
