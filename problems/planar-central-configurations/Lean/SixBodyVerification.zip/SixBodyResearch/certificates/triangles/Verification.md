# Verification of the two-triangle result

## Wide analytic family

Use Python 3.8 or newer. Run `python continuation.py 4000` in this folder. It uses exact rational arithmetic, integer square roots, and ordinary interval differentiation for 4,000 complete slabs. It checks both edge signs of the scalar force residual, strict monotonicity in the free height, strict monotonicity of one mass along the solution curve, positivity of every denominator, and separation of the four mass classes. `continuation.log` gives the rational extrema. The mean value theorem and analytic implicit function theorem are applied in the paper. The wide result is verified through the Python calculation and the mathematical proof.

## Smaller rectangle in Lean

The checked project uses Lean 4.28.0 and mathlib commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365`. Run

```bash
lake update
lake exe cache get
lake build
lake env lean Standard.lean
```

The specialized theorem is `SixTriangles.nonconcentric_six_body`. It quantifies over every permitted inner-apex height and proves existence of an inner-base height in the smaller rectangle with distinct triangle centroids, ordered positive masses, and a common affine acceleration law in all independent coordinate components of the symmetric configuration. The inverse-cube factors and forces used by this statement are the explicitly expanded six-body expressions in the paper. `Bounds.lean` proves the interval operations over the reals, `Certificate.lean` checks the mass bounds, denominator signs and opposite signs at the two edges, `Force.lean` verifies the elimination identities, and `Theorem.lean` proves continuity, applies the intermediate value theorem and recovers the force equations. The theorem `SixTriangles.six_body_equations` in `Physical.lean` uses `Ground.lean` and `Newton.lean` to verify both acceleration components for each of the six particles directly against finite sums over the six positions, with the physical metric and inverse-cube inverse distances. It also verifies all distance factors against the coordinate proposals. The final theorem `SixTriangles.physical_six_body_standard` in `Standard.lean` takes the extra steps of proving that the internal forces cancel pairwise, identifying the true mass-weighted center from the six masses, and certifying that the common multiplier is strictly positive. It verifies injectivity of the six positions, positivity of every mass, equilateral squared-distance identities for both triangles and different centroid heights. The conclusion uses the standard Newtonian equation at every particle. The final axiom report is

```
'SixTriangles.physical_six_body_standard' depends on axioms: [propext, Classical.choice, Quot.sound]
```

No new axiom or proof placeholder is used. The core proof checks all inequalities in the kernel. The computable certificate uses exact rational arithmetic and `decide +kernel`. The numerical enclosure in the small rectangle can also be replayed independently with `python verify_intervals.py`. The derivative bounds for that same rectangle are reproduced by `python verify_derivative.py`. The generators produce the human-auditable Lean proof declarations and are optional for verification.
