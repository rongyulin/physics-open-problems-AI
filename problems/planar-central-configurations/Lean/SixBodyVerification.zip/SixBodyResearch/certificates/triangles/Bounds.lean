import Mathlib.Data.Real.Sqrt
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.FieldSimp
import Mathlib.Topology.Order.IntermediateValue

namespace SixTriangles
def Box (x : ℝ) (lo hi : ℚ) : Prop := (lo : ℝ) ≤ x ∧ x ≤ (hi : ℝ)

theorem boxConst (q : ℚ) : Box (q : ℝ) q q := ⟨le_rfl, le_rfl⟩

theorem boxNeg {x : ℝ} {a b l u : ℚ} (hx : Box x a b)
    (hl : l ≤ -b) (hu : -a ≤ u) : Box (-x) l u := by
  obtain ⟨h1,h2⟩ := hx
  have hl' : (l : ℝ) ≤ -(b : ℝ) := by exact_mod_cast hl
  have hu' : -(a : ℝ) ≤ (u : ℝ) := by exact_mod_cast hu
  exact ⟨by linarith, by linarith⟩

theorem boxAdd {x y : ℝ} {a b c d l u : ℚ} (hx : Box x a b) (hy : Box y c d)
    (hl : l ≤ a+c) (hu : b+d ≤ u) : Box (x+y) l u := by
  have hl' : (l:ℝ) ≤ (a:ℝ)+(c:ℝ) := by exact_mod_cast hl
  have hu' : (b:ℝ)+(d:ℝ) ≤ (u:ℝ) := by exact_mod_cast hu
  exact ⟨hl'.trans (add_le_add hx.1 hy.1),(add_le_add hx.2 hy.2).trans hu'⟩

theorem cornerLo {x y a b c d l : ℝ} (hx : a ≤ x ∧ x ≤ b) (hy : c ≤ y ∧ y ≤ d)
    (h1 : l ≤ a*c) (h2 : l ≤ a*d) (h3 : l ≤ b*c) (h4 : l ≤ b*d) : l ≤ x*y := by
  rcases le_total 0 y with h | h
  · apply le_trans _ (mul_le_mul_of_nonneg_right hx.1 h)
    rcases le_total 0 a with ha|ha
    · exact h1.trans (mul_le_mul_of_nonneg_left hy.1 ha)
    · exact h2.trans (mul_le_mul_of_nonpos_left hy.2 ha)
  · apply le_trans _ (mul_le_mul_of_nonpos_right hx.2 h)
    rcases le_total 0 b with hb|hb
    · exact h3.trans (mul_le_mul_of_nonneg_left hy.1 hb)
    · exact h4.trans (mul_le_mul_of_nonpos_left hy.2 hb)

theorem boxMul {x y : ℝ} {a b c d l u : ℚ} (hx : Box x a b) (hy : Box y c d)
   (h : l ≤ a*c ∧ l ≤ a*d ∧ l ≤ b*c ∧ l ≤ b*d ∧ a*c ≤ u ∧ a*d ≤ u ∧ b*c ≤ u ∧ b*d ≤ u) :
    Box (x*y) l u := by
  obtain ⟨h1,h2,h3,h4,h5,h6,h7,h8⟩ := h
  constructor
  · apply cornerLo hx hy <;> exact_mod_cast ‹_›
  · have h : -(u:ℝ) ≤ (-x)*y := by
      apply cornerLo (a := -(b:ℝ)) (b := -(a:ℝ)) ⟨neg_le_neg hx.2, neg_le_neg hx.1⟩ hy
      all_goals simp only [neg_mul, neg_le_neg_iff]
      all_goals exact_mod_cast ‹_›
    linarith

theorem boxInv {x : ℝ} {a b l u : ℚ} (hx : Box x a b) (hpos : 0<a)
    (hl : l≤ 1/b) (hu : 1/a ≤ u) : Box (1/x) l u := by
  have ha : (0:ℝ)<(a:ℝ) := by exact_mod_cast hpos
  have h1 : (l:ℝ) ≤ 1/(b:ℝ) := by exact_mod_cast hl
  have h2 : 1/(a:ℝ) ≤ (u:ℝ) := by exact_mod_cast hu
  exact ⟨h1.trans (one_div_le_one_div_of_le (ha.trans_le hx.1) hx.2),
    (one_div_le_one_div_of_le ha hx.1).trans h2⟩

theorem boxSqrt {x : ℝ} {a b l u : ℚ} (hx : Box x a b)
    (hp : 0 ≤ a ∧ 0 ≤ l ∧ 0 ≤ u ∧ l*l ≤ a ∧ b ≤ u*u) :
    Box (Real.sqrt x) l u := by
  obtain ⟨p1,p2,p3,p4,p5⟩ := hp
  have A : 0 ≤ (a:ℝ) := by exact_mod_cast p1
  have L : 0 ≤ (l:ℝ) := by exact_mod_cast p2
  have U : 0 ≤ (u:ℝ) := by exact_mod_cast p3
  have hl : (l:ℝ)*(l:ℝ)≤(a:ℝ) := by exact_mod_cast p4
  have hu : (b:ℝ)≤(u:ℝ)*(u:ℝ) := by exact_mod_cast p5
  have sq := Real.sq_sqrt (A.trans hx.1)
  have s := Real.sqrt_nonneg x
  constructor
  · nlinarith only [sq,s,L,hl,hx.1,sq_nonneg (Real.sqrt x-(l:ℝ))]
  · nlinarith only [sq,s,U,hu,hx.2,sq_nonneg (Real.sqrt x-(u:ℝ))]
end SixTriangles
