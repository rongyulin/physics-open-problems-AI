from pathlib import Path
def build():
    force0=[
      '-2*d*h*u - d*h*v - d*t*w + (1-d)*s - (1+d)*r',
      'd*h*v - b*t*w + (1-b)*(s+r)', '-2*d*h*u - a*c*w + 2*(1-a)*l',
      '2*b*t*u + a*c*v + 2/8', '((d-1)*s-(d+1)*r)*u-l*v-(1/8)*w-2/8',
      '(b-1)*(s+r)*u + (a-1)*l*v -(1/8)*w']
    square=['(2*d)^2', 'd^2+3*b^2','(1-d)^2+3*(1-b)^2','(1+d)^2+3*(1-b)^2','3*a^2','1+3*(1-a)^2','4']
    weights={'h':square[0],'t':square[1],'s':square[2],'r':square[3],'c':square[4],'l':square[5],'e':square[6]}
    tab=[['_','h','h','t','s','r'],['h','_','h','t','r','s'],['h','h','_','c','l','l'],['t','t','c','_','e','e'],['s','r','l','e','_','e'],['r','s','l','e','e','_']]
    ls=['import Ground','namespace SixTriangles','set_option maxRecDepth 4096','set_option maxHeartbeats 4500000',
        'theorem newton_from_components (a b d h t s r c l u v w : ℝ) (hd : d = a-b)',
        '    (hh : grav ((2*d)^2) = h) (ht : grav (d^2+3*b^2) = t)',
        '    (hs : grav ((1-d)^2+3*(1-b)^2) = s) (hr : grav ((1+d)^2+3*(1-b)^2) = r)',
        '    (hc : grav (3*a^2) = c) (hl : grav (1+3*(1-a)^2) = l)',
        '    (eq : ForceEquations a b d h t s r c l u v w) : Central (pos a b) (mass u v w) := by',
        '  obtain ⟨k,j,hx₁,hy₁,hy₃,hy₄,hx₅,hy₅⟩ := eq',
        '  have sq : Real.sqrt 4 = 2 := by rw [Real.sqrt_eq_iff_eq_sq] <;> norm_num',
        '  have he : grav 4 = (1/8 : ℝ) := by norm_num [grav,sq]',
        '  have bSub : b-a = -d := by linarith',
        '  have aSub : a-b = d := hd.symm']
    for i,(p,m) in enumerate(zip(['(a-b,b)','(b-a,b)','(0,a)','(0,0)','(1,1)','(-1,1)'],['u','u','v','w','1','1'])):
        ls.append(f'  have p{i} : pos a b {i} = {p} := rfl')
        ls.append(f'  have m{i} : mass u v w {i} = {m} := rfl')
    for i in range(6):
        for j in range(6):
            if i==j:continue
            n=tab[i][j]
            var='(1/8:ℝ)' if n=='e' else n
            squareEq=weights[n]
            ls.extend([f'  have g{i}{j} : grav (sqDist (pos a b {i}) (pos a b {j})) = {var} := by',
                       f'    rw [show sqDist (pos a b {i}) (pos a b {j}) = {squareEq} by',
                       f'      simp only [sqDist,p{i},p{j},hd] <;> ring]',
                       f'    exact h{n}'])
    ls+=['  refine ⟨k,j,?_⟩', '  intro i', '  fin_cases i']
    simp='p0,p1,p2,p3,p4,p5,m0,m1,m2,m3,m4,m5'
    for i in range(6):
        gs=','.join(f'g{i}{j}' for j in range(6) if j!=i)
        xr,yr=[('hx₁','hy₁'),('-hx₁','hy₁'),('0','hy₃'),('0','hy₄'),('hx₅','hy₅'),('-hx₅','hy₅')][i]
        ls+=['  · change newtonX (pos a b) (mass u v w) '+str(i)+' = _ ∧ newtonY (pos a b) (mass u v w) '+str(i)+' = _',
            '    unfold newtonX newtonY','    simp only [Fin.sum_univ_succ,Fin.isValue,Fin.reduceFinMk,Fin.reduceSucc,Fin.sum_univ_zero]','    simp only ['+gs+']',
            '    simp only ['+simp+',aSub,bSub]','    constructor',
            ('    · ring' if xr=='0' else '    · linear_combination '+xr), '    · linear_combination '+yr]
    ls+=['end SixTriangles']
    return '\n'.join(ls)+'\n'
if __name__=='__main__':
 Path(__file__).with_name('Newton.lean').write_text(build())
