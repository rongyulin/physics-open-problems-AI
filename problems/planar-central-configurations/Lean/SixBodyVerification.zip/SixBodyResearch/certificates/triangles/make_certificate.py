"""Derive interval certificates in exact rational arithmetic, emit Lean proof terms.

The normalized coordinates are (x, y/sqrt(3)).  A and B are apex and base
heights of the moving triangle; its half side is D=A-B. The other triangle
has vertices (0,0), (1,1), (-1,1) in these coordinates.
"""
from fractions import Fraction as F
from math import isqrt
from pathlib import Path

NODES=[]
PREC=10**9

def rat(x):
    return f"({x.numerator}/{x.denominator}:ℚ)" if x.denominator!=1 else f"({x.numerator}:ℚ)"

def floor(x):
    return x.numerator//x.denominator
def ceil(x):
    return -floor(-x)
def lower(x):
    return F(floor(x*PREC),PREC)
def upper(x):
    return F(ceil(x*PREC),PREC)
def boundroot(x):
    k=isqrt(floor(x*PREC*PREC))
    return F(k,PREC), F(k+1,PREC)
class E:
    def __init__(self,op,*args,name=None):
        self.op,self.args,self.i,self.name=op,args,len(NODES),name
        NODES.append(self)
    def __add__(self,x): return E('plus',self,co(x))
    def __radd__(self,x): return co(x)+self
    def __neg__(self): return E('neg',self)
    def __sub__(self,x): return self+-co(x)
    def __rsub__(self,x): return co(x)+-self
    def __mul__(self,x): return E('mul',self,co(x))
    def __rmul__(self,x): return co(x)*self
    def __truediv__(self,x): return self*E('inverse',co(x))
    def __rtruediv__(self,x): return co(x)*E('inverse',self)
    def label(self,name): self.name=name; return self
    @property
    def nm(self): return self.name or f"term{self.i}"
    @property
    def term(self):
        return ('a' if self.op=='a' else 'b' if self.op=='b' else
               f"({rat(self.args[0])} : ℝ)" if self.op=='const' else f'({self.nm} a b)')
C={}
def co(x):
    if isinstance(x,E): return x
    x=F(x)
    if x not in C: C[x]=E('const',x)
    return C[x]
def invcube(x):
    return 1/(x*E('sqrt',x))
a=E('a'); b=E('b')
d=(a-b).label('width')
e=co(F(1,8))
k=2*d
h=(1/(k*k*k)).label('innerForce')
t=invcube(d*d+3*b*b).label('innerToOrigin')
s=invcube((1-d)*(1-d)+3*(1-b)*(1-b)).label('nearSide')
r=invcube((1+d)*(1+d)+3*(1-b)*(1-b)).label('farSide')
c=invcube(3*a*a).label('apexToOrigin')
l=invcube(1+3*(1-a)*(1-a)).label('apexToPair')
w=(((2-a)*s-a*r-2*(1-a)*l)/(a*(t-c))).label('outerApexMass')
ratio=((2*b*t-(b-d)*s-(b+d)*r)/(a*(l-c))).label('innerRatio')
S=((d-1)*s-(d+1)*r-ratio*l).label('horizontalUnit')
u=((-d*t*w+(1-d)*s-(1+d)*r+d*e*(w+2))/(d*(h*(2+ratio)+S))).label('innerPairMass')
v=(u*ratio).label('innerApexMass')
res=(u*(-2*d*h-2*b*t-a*c*ratio-a*S)+(-a*c*w+2*(1-a)*l-2*e+a*e*(w+2))).label('residual')
A=(F(874999999,10**9),F(875000001,10**9))
B=(F(28055,100000),F(28060,100000))
allinv=[x.args[0] for x in NODES if x.op=='inverse']

def evaluate(A,B):
    result=[]
    for n in NODES:
        op=n.op
        if op in ('a','b'):
            result.append(A if op=='a' else B); continue
        if op=='const':
            result.append((n.args[0],)*2);continue
        L,H=result[n.args[0].i]
        if op in ('plus','mul'):
            J,K=result[n.args[1].i]
            if op=='plus': lo,hi=L+J,H+K
            else:
                vs=[L*J,L*K,H*J,H*K]
                lo,hi=min(vs),max(vs)
        elif op=='neg': lo,hi=-H,-L
        elif op=='sqrt': lo,hi=boundroot(L)[0],boundroot(H)[1]
        elif op=='inverse':
            assert L>0,(n.nm,L,H)
            lo,hi=1/H,1/L
        result.append((lower(lo),upper(hi)))
    return result

def defs():
    lns=['import Bounds','namespace SixTriangles','set_option linter.unusedVariables false']
    for n in NODES:
        if n.op in ('const','a','b'):continue
        x=n.args[0].term; y=n.args[1].term if len(n.args)>1 else None
        term={'plus':f'{x} + {y}','mul':f'{x} * {y}','neg':f'-{x}','sqrt':f'Real.sqrt {x}','inverse':f'1 / {x}'}[n.op]
        lns.append(f'noncomputable def {n.nm} (a b : ℝ) : ℝ := {term}')
    return lns

def as_box(n,vals):
    lo,hi=vals[n.i]
    return f'Box {n.term} {rat(lo)} {rat(hi)}'
def range_proof(name,BR,fields):
    vals=evaluate(A,BR)
    st=' ∧ '.join(as_box(n,vals) for n in fields)
    ls=[f'theorem {name} (a b : ℝ) (ha : {as_box(a,vals)}) (hb : {as_box(b,vals)}) :\n    {st} := by']
    memo={}
    for n in NODES:
        op=n.op;var=f'h{n.i}'
        if op=='a' or op=='b': memo[n.i]='h'+op;continue
        if op=='const':
            memo[n.i]=f'(boxConst {rat(n.args[0])})'; continue
        inputs=' '.join(memo[m.i] for m in n.args)
        uses={'plus':'boxAdd','mul':'boxMul','sqrt':'boxSqrt','inverse':'boxInv','neg':'boxNeg'}
        count={'plus':2,'neg':2,'inverse':3,'sqrt':1,'mul':1}
        facts=' '.join(['(by decide +kernel)']*count[op])
        ls.append(f'  have {var} : {as_box(n,vals)} := {uses[op]} {inputs} {facts}')
        memo[n.i]=var
    ls.append('  exact '+('⟨'+', '.join(memo[n.i] for n in fields)+'⟩' if len(fields)>1 else memo[fields[0].i]))
    return ls

if __name__=='__main__':
    for name,BR in [('full',B),('left',(B[0],B[0])),('right',(B[1],B[1]))]:
        vals=evaluate(A,BR)
        print(name,[(n.nm,tuple(float(q) for q in vals[n.i])) for n in [res,w,u,v]])
    fields=[w,u,v]+allinv
    ls=defs()+range_proof('rangeFull',B,fields)+range_proof('rangeLeft',(B[0],)*2,[res])+range_proof('rangeRight',(B[1],)*2,[res])
    ls.append('end SixTriangles')
    Path(__file__).with_name('Certificate.lean').write_text('\n'.join(ls)+'\n')
