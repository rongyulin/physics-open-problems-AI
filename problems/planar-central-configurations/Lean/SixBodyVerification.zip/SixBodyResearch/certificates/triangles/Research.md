# A certified interval of nonconcentric equilateral-triangle central configurations

## Claim and relation to previous work

For every real number $a$ between $0.874999999$ and $0.875000001$, there exists $b$ between $0.28055$ and $0.28060$ such that six positive Newtonian point masses in the plane form a central configuration on two equilateral triangles with distinct centroids. Four different mass values occur. The masses are determined after choosing the shape. The result gives no count for any fixed mass vector.

Xie, Bhusal and Tahir, *Central configurations in the planar 6-body problem forming two equilateral triangles*, Journal of Geometry and Physics 153 (2020), article 103645, Theorem 1.1(E), investigated this same physical phenomenon using Maple and reported numerical examples in Table 2. They explicitly described the proof of part (E) as numerical and plotted possible curves. Our independent derivation replaces a numerical common-zero test by a sign change for one continuous real function and certifies existence throughout the specified parameter interval. The interval sign proof establishes existence over a parameter interval. A further derivative certificate below gives uniqueness and an analytic branch within the specified rectangle. The coordinate convention below divides the paper's vertical coordinates by $\sqrt{3}$. The chosen $a$ corresponds to a physical apex height close to $1.51554$, between two of their tabulated examples. Searches for the title, authors, nonconcentric triangles, stacked six-body configurations, distinct centroids, and matching GitHub code did not identify another rigorous proof of this particular existence conclusion. This establishes neither bibliographic priority nor a new solution of Smale's problem.

Sources: [paper](https://doi.org/10.1016/j.geomphys.2020.103645), [university record](https://aquila.usm.edu/fac_pubs/17850/), [text and Table 2](https://www.academia.edu/119310870/Central_configurations_in_the_planar_6_body_problem_forming_two_equilateral_triangles). For concentric twisted triangles the number was already studied analytically in [Barrabés and Cors (2019)](https://doi.org/10.1016/j.jmaa.2019.04.010).

## Six positions and the force equations

Write coordinates $(x,y)$ for the physical point $(x,\sqrt3 y)$. Squared distance is $(\Delta x)^2+3(\Delta y)^2$. Set $d=a-b$. Choose positions and masses in the following order:

| Index | Coordinates | Mass |
|---|---|---|
| 1,2 | $(d,b),(-d,b)$ | $u,u$ |
| 3 | $(0,a)$ | $v$ |
| 4 | $(0,0)$ | $w$ |
| 5,6 | $(1,1),(-1,1)$ | $1,1$ |

The inner and outer side lengths are $2d$ and $2$. In the allowed ranges $0<b<a<1$, $0<d<1$ and all six points are distinct. The centroid heights are $(2b+a)/3$ and $2/3$, which are unequal. Distinct $a$ give inequivalent marked shapes because fixing the labeled outer triangle fixes the similarity scale and frame.

Let $g(z)=1/(z\sqrt z)$ and define

$$
h=(2d)^{-3},\quad t=g(d^2+3b^2),\quad
s=g((1-d)^2+3(1-b)^2),\quad
r=g((1+d)^2+3(1-b)^2),\quad c=g(3a^2),\quad l=g(1+3(1-a)^2),\quad e=1/8.
$$

For each pair the acceleration contribution is the mass of the other body multiplied by its coordinate displacement and inverse cubed physical distance. Adding those terms gives the following components, where vertical acceleration is also divided by $\sqrt3$:

$$
\begin{aligned}
X_1&=-2dhu-dhv-dtw+(1-d)s-(1+d)r,\\
Y_1&=dhv-btw+(1-b)(s+r),\\
Y_3&=-2dhu-acw+2(1-a)l,\\
Y_4&=2btu+acv+2e,\\
X_5&=((d-1)s-(d+1)r)u-lv-ew-2e,\\
Y_5&=(b-1)(s+r)u+(a-1)lv-ew .
\end{aligned}
$$

The axial particles have zero horizontal acceleration and the other pair members follow by reflection. Write the common affine acceleration law as $X_i=k x_i$, $Y_i=k y_i+j$. Necessarily $k=X_5<0$ by positivity and $d<1$, and $j=Y_4$. Newton's third law gives $j=-k\bar y$ after summing the equations with mass weights. Thus the affine law is precisely the central-configuration condition about the physical center of mass.

## Reduction to one residual

Impose $Y_3-Y_1-X_1=0$ (equal axial and horizontal slopes on the inner triangle), $Y_5-Y_4-X_5=0$ (the same for the outer triangle), and $X_1-dX_5=0$ (common slope). The first equation determines $w$, the second determines $R=v/u$, and the third determines $u$:

$$
\begin{aligned}
w &= \frac{(2-a)s-ar-2(1-a)l}{a(t-c)},\\
R &= \frac{2bt-(b-d)s-(b+d)r}{a(l-c)},\\
S &=(d-1)s-(d+1)r-Rl,\\
u &= \frac{-dtw+(1-d)s-(1+d)r+de(w+2)}
                {d[h(2+R)+S]},\qquad v=uR.
\end{aligned}
$$

The remaining equation $Y_3-Y_4-aX_5=0$ has residual

$$
F=u[-2dh-2bt-acR-aS]+[-acw+2(1-a)l-2e+ae(w+2)].
$$

This reduction directly explains why a root of only one numerical equation could appear to satisfy the additional equations in the earlier work. We have not identified these particular formulas with each named Maple residual in that paper.

## Exact certificate

All interval endpoints below are outward-rounded rationals. For each square root the checker verifies inequalities by squaring nonnegative endpoints. Each reciprocal has a strictly positive denominator on the entire rectangle. At each fixed $a$ this makes $F$ continuous on the closed $b$ interval.

| Quantity | Lower bound | Upper bound |
|---|---:|---:|
| $F(a,0.28055)$ | $-0.000898888$ | $-0.000897720$ |
| $F(a,0.28060)$ | $0.000953445$ | $0.000954513$ |
| $w$ throughout the rectangle | $0.095640519$ | $0.095755931$ |
| $u$ throughout the rectangle | $0.524036384$ | $0.561709605$ |
| $v$ throughout the rectangle | $1.179845724$ | $1.265436432$ |

The intermediate value theorem gives at least one exact root for each $a$. At every such root the inequalities imply $0<w<u<1<v$. The endpoint opposite signs hold uniformly in $a$. They do not assert uniqueness of the root or connectedness of a particular continuous branch.


## Derivative check and a fixed-mass consequence on this branch

For each elementary arithmetic operation in the preceding formulas, the separate exact verifier `verify_derivative.py` propagates both its range and the ranges of its partial derivatives by the product and chain rules. Every square-root argument and reciprocal denominator is strictly positive. Thus all quantities are real analytic on a neighborhood of the closed rectangle. On this rectangle,
$$
-22.477368738\le F_a\le-17.555636655,\qquad 34.719610963\le F_b\le39.562801361.
$$
The strict sign of $F_b$ gives exactly one root in the strip for each $a$. The implicit function theorem makes it a real-analytic graph locally at every point of the interval, with derivative $b'(a)=-F_a/F_b$ in $[0.443740977,0.647396929]$. Differentiating the explicit outer apex mass gives $1.471168231\le dw/da\le1.651674387$ along the graph. In particular this family contains at most one marked configuration for each **fixed outer-apex to outer-base mass ratio**. This is a local fixed-mass finiteness statement restricted to the specified shapes and box. This extension is checked with exact rational interval arithmetic in Python and derived by ordinary calculus. The Lean endpoint-and-equations theorem checks the existence part through the standard per-particle Newton equation, the true mass center, strictly positive multiplier, collision-free positions, and the equilateral and different-centroid properties.

## A wider certified analytic family

The separate verifier `python continuation.py 4000` subdivides $0.87\le a\le0.88$ into 4,000 closed intervals. Put $z=a-7/8$ and
$$P(a)=0.28057414+0.5382z-3.12z^2.$$
For each $a$ in this whole interval, **exactly one** $b$ with $|b-P(a)|\le1/40000$ gives a zero of $F$. The positive mass assignment above then produces a nonconcentric central configuration. Conversely, throughout this corridor the three algebraic eliminations have positive denominators, so any positive reflection-invariant mass assignment for such a central configuration with outer base masses normalized to $1$ must be this one. Indeed the first and second equations give $w$ and $R=v/u$, and the third gives $u$.

For a slab $[a_0,a_1]$ the quadratic $P$ is strictly increasing. The outward rectangular enclosure of the full curvilinear slab therefore uses $b\in[P(a_0)-1/40000,P(a_1)+1/40000]$. The lower and upper edges use their own narrower rectangular enclosures obtained with the corresponding single sign. Different slabs use the same two edge functions. Every lower-edge residual is at most $-0.000376509$ and every upper-edge residual is at least $0.000289681$. The derivative bound $F_b\ge27.439643169$ gives one root per section. Each section's root is strictly interior, so the analytic implicit function theorem gives an analytic graph across the joins as well as within each slab.

Exact differentiation and interval arithmetic give $1.45315412\le dw/da\le1.743050985$. Consequently **each fixed normalized outer-apex mass occurs at most once on the entire graph**. The verified mass bounds over the full corridor are
$$
0.087941992\le w\le0.103607943,\quad
0.505498846\le u\le0.567175769,\quad
1.105569924\le v\le1.310848936.
$$
Only the image of the graph is claimed; these intervals are outer enclosures, not claimed exact images.

All computational checks here use exact fractions and integer square roots. The Python derivative and 4,000-slab continuation are separate from the single-rectangle Lean certificate. The 2020 paper supplied numerical evidence and suggested curves; the certified local uniqueness, analyticity and strictly monotone mass ratio give stronger conclusions in this specific corridor. No statement for unrestricted shapes or for all configurations at one fixed six-tuple of masses follows.
