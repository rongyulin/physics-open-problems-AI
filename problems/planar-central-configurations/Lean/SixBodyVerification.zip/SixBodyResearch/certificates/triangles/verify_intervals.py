"""Run with Python 3.8+; no third-party packages are required."""
from make_certificate import A, B, allinv, evaluate, res, u, v, w

full = evaluate(A, B)
left = evaluate(A, (B[0], B[0]))
right = evaluate(A, (B[1], B[1]))
assert all(full[n.i][0] > 0 for n in allinv)
assert left[res.i][1] < 0 < right[res.i][0]
assert 0 < full[w.i][0] and full[w.i][1] < full[u.i][0]
assert full[u.i][1] < 1 < full[v.i][0]
assert A[1]+2*B[1] < 2 and 0 < B[0] < B[1] < A[0] < A[1] < 1
for key,value in [('left residual',left[res.i]),('right residual',right[res.i]),
                  ('outer apex mass',full[w.i]),('inner pair mass',full[u.i]),
                  ('inner apex mass',full[v.i])]:
    print(key, *map(str,value))
