"""Certified analytic continuation along a rational parabolic corridor.

Every slab shares its two curved b boundaries with adjacent slabs. Widths are
checked over the whole slab for derivatives, and on each entire boundary for
the residual signs. No numerical root finder is used.
"""
from fractions import Fraction as F
from make_certificate import evaluate,res,w,u,v
from verify_derivative import derivative,mult,inv,neg,plus
from functools import partial

def predictor(a):
    z=a-F(7,8)
    return F(28057414,10**8)+F(5382,10000)*z-F(312,100)*z*z
width=F(25,10**6)
def check_slab(lo,hi):
    # The quadratic predictor is increasing on [0.87,0.88].
    low,high=predictor(lo),predictor(hi)
    bounds=lo,hi
    wide=low-width,high+width
    vals=evaluate(bounds,wide)
    left=evaluate(bounds,(low-width,high-width))[res.i]
    right=evaluate(bounds,(low+width,high+width))[res.i]
    da,db=derivative(bounds,wide,'a'),derivative(bounds,wide,'b')
    assert db[res.i][0]>0 and left[1]<0<right[0]
    slope=mult(neg(da[res.i]),inv(db[res.i]))
    dw=plus(da[w.i],mult(db[w.i],slope))
    assert dw[0]>0
    assert 0 < vals[w.i][0] and vals[w.i][1] < vals[u.i][0] and vals[u.i][1] < 1 < vals[v.i][0]
    return [left,right,db[res.i],dw,vals[w.i],vals[u.i],vals[v.i]]
if __name__=='__main__':
    import sys
    n=int(sys.argv[1]) if len(sys.argv)>1 else 4000
    samples = bool(len(sys.argv)>2)
    merged=None
    for i in ([0,n//4,n//2,3*n//4,n-1] if samples else range(n)):
        lo,hi=F(87,100)+F(i,100*n), F(87,100)+F(i+1,100*n)
        a=check_slab(lo,hi)
        if merged is None:merged=a
        else:merged=[(min(x[0],y[0]),max(x[1],y[1])) for x,y in zip(merged,a)]
    for label,interval in zip(['lower F','upper F','F_b','dw/da','w','u','v'],merged):
        print(label,*map(str,interval))
