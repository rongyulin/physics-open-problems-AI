from make_certificate import *
from pathlib import Path
out=['import Theorem','import Newton','namespace SixTriangles','set_option maxRecDepth 4096','set_option maxHeartbeats 3000000',
     'theorem six_body_equations (a : ℝ) (ha : ARange a) : ∃ b ∈ strip, a+2*b ≠ 2 ∧',
     '  (0 < outerApexMass a b ∧ outerApexMass a b < innerPairMass a b ∧ innerPairMass a b < 1 ∧ 1 < innerApexMass a b) ∧',
     '  Central (pos a b) (mass (innerPairMass a b) (innerApexMass a b) (outerApexMass a b)) := by',
     '  obtain ⟨b,hb,hc,hm,hf⟩ := nonconcentric_six_body a ha','  refine ⟨b,hb,hc,hm,?_⟩',
     '  have wd : 0 ≤ 2 * width a b := by',
     '    have hx := ha.1; have hy := hb.2; norm_num [bHigh] at hx hy',
     '    simp only [width,term2]; linarith',
     '  apply newton_from_components a b (width a b) (innerForce a b) (innerToOrigin a b) (nearSide a b) (farSide a b) (apexToOrigin a b) (apexToPair a b) _ _ _ _ _ _ _ _ _ _ hf',
     '  · simp [width,term2,sub_eq_add_neg]',
     '  · rw [grav,Real.sqrt_sq wd]; simp only [innerForce,term10,term8,term7,term6]; push_cast; ring']
for m in [t,s,r,c,l]:
    sub=m.args[1].args[0].args[0]
    names=[]
    def visit(n,first=False):
        if n.op in ('a','b','const') or (n.name and not first):return
        if n.nm in names:return
        names.append(n.nm)
        for v in n.args:visit(v)
    visit(m,True)
    left={t:'(width a b)^2+3*b^2',s:'(1-width a b)^2+3*(1-b)^2',r:'(1+width a b)^2+3*(1-b)^2',c:'3*a^2',l:'1+3*(1-a)^2'}[m]
    names2=[n for n in names if n!=m.nm]
    out.extend([f'  · have he : {left} = {sub.nm} a b := by',
                '      simp only ['+','.join(names2)+'] <;> push_cast <;> ring',
                '    rw [he]; simp ['+','.join(names[:names.index(sub.nm)]+[m.args[1].args[0].args[1].nm])+',grav]'])
out+=['#print axioms six_body_equations','end SixTriangles']
Path(__file__).with_name('Physical.lean').write_text('\n'.join(out)+'\n')
