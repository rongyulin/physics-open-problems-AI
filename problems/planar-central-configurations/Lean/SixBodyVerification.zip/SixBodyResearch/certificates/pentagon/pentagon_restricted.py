"""Exact rational interval Hessian certificates for the known 16 restricted equilibria.

Five unit primaries on a regular unit pentagon with a vertex at (1,0).
Reproduces radial brackets and Hessian signs using only Python's standard library.
"""
from fractions import Fraction as Q
from math import isqrt


class Interval:
    def __init__(self, lo, hi=None):
        self.lo, self.hi = Q(lo), Q(lo if hi is None else hi)
        assert self.lo <= self.hi

    def __add__(u, v):
        v = as_interval(v)
        return Interval(u.lo + v.lo, u.hi + v.hi)

    __radd__ = __add__

    def __neg__(u):
        return Interval(-u.hi, -u.lo)

    def __sub__(u, v):
        return u + (-as_interval(v))

    def __rsub__(u, v):
        return as_interval(v) + (-u)

    def __mul__(u, v):
        v = as_interval(v)
        products = [x*y for x in (u.lo,u.hi) for y in (v.lo,v.hi)]
        return Interval(min(products), max(products))

    __rmul__ = __mul__

    def __truediv__(u, v):
        v = as_interval(v)
        assert v.lo*v.hi > 0
        return u * Interval(1/v.hi, 1/v.lo)

    def __rtruediv__(u, v):
        return as_interval(v)/u

    def sqrt(u):
        assert u.lo >= 0
        den = 10**25
        def floor_grid_sqrt(q):
            return isqrt((q.numerator * den**2)//q.denominator)
        l, h = floor_grid_sqrt(u.lo), floor_grid_sqrt(u.hi)+1
        return Interval(Q(l,den), Q(h,den))

    def square(u):
        lo = 0 if u.lo <= 0 <= u.hi else min(u.lo**2,u.hi**2)
        return Interval(lo,max(u.lo**2,u.hi**2))


def as_interval(x):
    return x if isinstance(x, Interval) else Interval(x)


# Vertex cosine values and their multiplicities. Sine is needed only through sin².
h = Interval(5).sqrt()
ring = [(Interval(1),1), ((h-1)/4,2), ((-h-1)/4,2)]
# Angular speed squared follows from radial force balance on (1,0).
omega2 = sum(m*(1-c)/((2-2*c)*(2-2*c).sqrt()) for c,m in ring[1:])


def grad_hessian(x):
    g, radial, transverse = omega2*x, omega2, omega2
    for c,m in ring:
        t = x-c
        sine2 = 1-c.square()
        rho = t.square() + sine2
        k3 = 1/(rho*rho.sqrt())
        k5 = k3/rho
        g -= m*t*k3
        radial += m*(3*t.square()*k5-k3)
        transverse += m*(3*sine2*k5-k3)
    return g, radial, transverse


# Noncentral root x intervals (unit circumradius). The integers supplied with each
# row bound the actual two Hessian diagonal entries on the entire root interval.
rows = [(-159793,-159791, (3,4),(1,2)),
        (-82219,-82217, (-8,-7),(20,22)),
        (178287,178289, (6,7),(-1,0))]
if not __debug__:
    raise RuntimeError('run without python -O')
for left,right,hx,hy in rows:
    x = Interval(Q(left,100000),Q(right,100000))
    val_l = grad_hessian(Interval(x.lo))[0]
    val_r = grad_hessian(Interval(x.hi))[0]
    assert (val_l*val_r).hi < 0
    _, xx, yy = grad_hessian(x)
    assert hx[0] < xx.lo <= xx.hi < hx[1]
    assert hy[0] < yy.lo <= yy.hi < hy[1]
    print(f'{float(x.lo):+.5f} to {float(x.hi):+.5f}: Hxx in {hx}, Hyy in {hy}')
# The origin is a root by 5-fold symmetry; both diagonal entries there equal omega²+5/2.
assert (omega2+Q(5,2)).lo>3 and (omega2+Q(5,2)).hi<4
print('PASS: three noncentral orbit representatives plus origin, all nondegenerate.')
