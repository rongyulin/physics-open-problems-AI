# Five certified primary configurations

Run `python3 certify_primaries.py` with `primary_centers.json` in the same directory. Only the Python 3 standard library is required. Decimal strings in the JSON represent exact rational numbers. The fixed-point arithmetic uses integers with denominator $10^{42}$ and rounds outward on every operation. Square roots are enclosed using the integer square-root algorithm.

Each primary has mass $1/5$, the rotation multiplier is 1, and the origin is the center of mass. In each of the five boxes, the fourth body's $y$ coordinate equals 0 exactly. Each of the remaining nine coordinates differs from its JSON value by at most $10^{-11}$. The numerical guesses for the five shapes were obtained from the configurations in Appendix A.2.3 of [Moczurad and Zgliczyński, arXiv:1812.07279](https://arxiv.org/abs/1812.07279).

Write $F_i=q_i-(1/5)\sum_{j\ne i}(q_i-q_j)/|q_i-q_j|^3$. Set $q_{4,y}=0$ and drop $F_{4,y}$, using one-based body numbering. The checker evaluates the resulting nine-dimensional function $f$ and its interval Jacobian $Df(X)$ on each cube $X$. For $d=q_i-q_j$, the derivative of $d/|d|^3$ is $|d|^{-3}I-3dd^T|d|^{-5}$.

The checker inverts a rational approximation to the center Jacobian by exact Gaussian elimination, giving a fixed rational matrix $R$. It verifies both

$$
 L=\sup_{x\in X}\|I-RDf(x)\|_{\infty}<1, \qquad
 \|Rf(c)\|_\infty+L\,10^{-11}<10^{-11}.
$$

Here $c$ is the box center and the matrix norm is the maximum absolute row sum. Thus $x\mapsto x-Rf(x)$ strictly maps the box to itself and is a contraction. The first inequality also implies the product $R Df(x)$ is invertible everywhere in the box. The fixed point is a zero of $f$, and the reduced Jacobian is invertible there. The pairwise forces satisfy $\sum_i q_i\wedge F_i=0$. Only the fourth $y$ residual can remain, and $q_{4,x}>0$ throughout the box, so it too vanishes. Summing $F_i=0$ gives $\sum_i q_i=0$.

The maximum squared distance of a primary from the origin is unchanged by orthogonal transformations and permutation of labels at this normalization. The five disjoint ranges of this invariant in `primary-check.txt` prove that the five certified configurations are inequivalent. The five-class classification of Moczurad and Zgliczyński then gives exhaustiveness up to reflection, rotation and relabeling.
