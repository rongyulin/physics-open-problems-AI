# Congruence classes when the five heavy masses agree

The scripts `certify_primaries.py` and `isolate.cpp` first certify the five limiting primary configurations and all their restricted roots. `check_orbits.py` computes the exact symmetry actions on these roots using Python's standard library. Run it against the same `seeds.txt`, for example `python3 check_orbits.py /path/to/seeds.txt`. Identify the primary inputs by their exact decimal coordinates. The functions use rational interval bounds. In this count the five equally massive bodies may be relabelled, and the sixth, lighter body remains intrinsically distinguished.

For each primary representative the fixed-point bound gives a sharper enclosure of its coordinates. If the original box has center c, the contraction constant is at most 14924 × 10⁻¹² and the sup-norm of the displacement of c is at most 488 × 10⁻¹⁵. The true center therefore lies within distance 5 × 10⁻¹³ of c. The fourth primary lies exactly on the positive horizontal axis, as fixed in the nine-dimensional primary certificate.

To enumerate the whole orthogonal group of a primary shape, choose which primary j should go to the fourth one. For each determinant sign e = ±1 there is a unique orthogonal transformation sending the position (h,k) of primary j to (r,0), r = √(h²+k²). Its matrix has rows (h/r,k/r) and (−ek/r,eh/r). Any genuine symmetry occurs among these candidates. Necessary radius and position tests exclude candidates. To certify a symmetry positively, the code encloses all five transformed positions within a permutation of the original primary boxes. It uses the identity that the image of primary j is exactly (r,0). The true transformed configuration, after relabelling, is a solution of exactly the same gauge-fixed, equal-mass primary equations in the same nine-dimensional box. Uniqueness in that box proves equality of the configurations. This also verifies each reflection exactly even when its axis is not a coordinate axis.

A proven orthogonal symmetry sends a root of the restricted field to another root. The global coverage certificate ensures its image lies in some previously certified root box. Each transformed enclosure intersects exactly one of those boxes, identifying its image. Root enclosures here include an extra 2⁻⁷² to account for the C++ checker's outward rounding of decimal centers. The code checks closure and counts orbits of the resulting permutations.

| Primary shape | Restricted roots | Orbits under rotations | Orbits under all orthogonal maps | Sizes of the latter orbits |
| --- | ---: | ---: | ---: | --- |
| Collinear | 8 | 4 | 4 | 2,2,2,2 |
| Square with center | 12 | 3 | 3 | 4,4,4 |
| Two isosceles triangles | 10 | 10 | 7 | 1,1,1,1,2,2,2 |
| Trapezium | 14 | 14 | 9 | 1,1,1,1,2,2,2,2,2 |
| Regular pentagon | 16 | 4 | 4 | 1,5,5,5 |
| **Total** | | **35** | **27** | |

For sufficiently small positive sixth mass, unique continuation provides a bijection between labelled oriented boundary roots and labelled oriented positive-mass configurations. This bijection commutes with permutations of the heavy labels and with reflection: applying either operation to a continued branch yields a solution near the transformed limiting root and uniqueness identifies the branch. Consequently the same orbit counts hold at positive mass. Positive uniform scaling may also be divided out, since the multiplier-one normalization fixes that scale. These geometric counts apply when the five primary masses are exactly equal.
