import TriangleData
namespace SixBody.Diagram93
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem positive6 (m : ℝ) (hm : 0 < m) : 0 < q6 m := by
  unfold q6
  positivity
end SixBody.Diagram93
