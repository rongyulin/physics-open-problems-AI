import TriangleData
namespace SixBody.Diagram93
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem positive16 (m : ℝ) (hm : 0 < m) : 0 < q16 m := by
  by_cases hu1_1 : m < 1
  ·
    let x : ℝ := 1*m - 0
    let y : ℝ := 1 - 1*m
    have hx : 0 ≤ x := by dsimp [x]; linarith
    have hy : 0 < y := by dsimp [y]; linarith
    have hpoly : 1 * q16 m = 68*y^16 + x*(1204*y^15 + x*(9965*y^14 + x*(51114*y^13 + x*(181613*y^12 + x*(473240*y^11 + x*(933850*y^10 + x*(1420450*y^9 + x*(1678360*y^8 + x*(1539428*y^7 + x*(1085925*y^6 + x*(577472*y^5 + x*(223480*y^4 + x*(59268*y^3 + x*(9708*y^2 + x*(828*y^1 + x*(36)))))))))))))))) := by
      dsimp [x, y, q16]
      ring
    have hpos : 0 < 68*y^16 + x*(1204*y^15 + x*(9965*y^14 + x*(51114*y^13 + x*(181613*y^12 + x*(473240*y^11 + x*(933850*y^10 + x*(1420450*y^9 + x*(1678360*y^8 + x*(1539428*y^7 + x*(1085925*y^6 + x*(577472*y^5 + x*(223480*y^4 + x*(59268*y^3 + x*(9708*y^2 + x*(828*y^1 + x*(36)))))))))))))))) := by positivity
    rw [← hpoly] at hpos
    exact pos_of_mul_pos_right hpos (by norm_num)
  by_cases hu2_1 : m < 2
  ·
    let x : ℝ := 1*m - 1
    let y : ℝ := 2 - 1*m
    have hx : 0 ≤ x := by dsimp [x]; linarith
    have hy : 0 < y := by dsimp [y]; linarith
    have hpoly : 1 * q16 m = 36*y^16 + x*(324*y^15 + x*(2148*y^14 + x*(26076*y^13 + x*(250624*y^12 + x*(1512544*y^11 + x*(6141349*y^10 + x*(17857984*y^9 + x*(38643220*y^8 + x*(63553374*y^7 + x*(80112798*y^6 + x*(77219960*y^5 + x*(56126949*y^4 + x*(29872606*y^3 + x*(11018185*y^2 + x*(2523432*y^1 + x*(270992)))))))))))))))) := by
      dsimp [x, y, q16]
      ring
    have hpos : 0 < 36*y^16 + x*(324*y^15 + x*(2148*y^14 + x*(26076*y^13 + x*(250624*y^12 + x*(1512544*y^11 + x*(6141349*y^10 + x*(17857984*y^9 + x*(38643220*y^8 + x*(63553374*y^7 + x*(80112798*y^6 + x*(77219960*y^5 + x*(56126949*y^4 + x*(29872606*y^3 + x*(11018185*y^2 + x*(2523432*y^1 + x*(270992)))))))))))))))) := by positivity
    rw [← hpoly] at hpos
    exact pos_of_mul_pos_right hpos (by norm_num)
  have hx : 0 ≤ m - 2 := by linarith
  have hpoly : q16 m = (m-2)^16 + 32*(m-2)^15 + 482*(m-2)^14 + 4548*(m-2)^13 + 30165*(m-2)^12 + 149474*(m-2)^11 + 573576*(m-2)^10 + 1741464*(m-2)^9 + 4232872*(m-2)^8 + 8269986*(m-2)^7 + 12947381*(m-2)^6 + 16067876*(m-2)^5 + 15481786*(m-2)^4 + 11177144*(m-2)^3 + 5685745*(m-2)^2 + 1812440*(m-2) + 270992 := by unfold q16; ring
  rw [hpoly]
  positivity
end SixBody.Diagram93
