#!/usr/bin/env bash
# Run from a Lean 4.28.0 Lake project with mathlib at the revision in README.md,
# or supply the Lake project path as the first argument.
set -euo pipefail
source_dir=$(cd -- "$(dirname -- "$0")" && pwd)
project_dir=$(cd -- "${1:-.}" && pwd)
build_dir=$(mktemp -d)
trap 'rm -rf -- "$build_dir"' EXIT
dependency_path=$(cd -- "$project_dir" && lake env printenv LEAN_PATH)
lean_binary=$(cd -- "$project_dir" && lake env which lean)
export LEAN_PATH="$build_dir:$dependency_path"
cd -- "$source_dir"
while read -r module; do
    echo "Checking $module"
    "$lean_binary" -j1 -o "$build_dir/$module.olean" "$module.lean"
done < module_order.txt
