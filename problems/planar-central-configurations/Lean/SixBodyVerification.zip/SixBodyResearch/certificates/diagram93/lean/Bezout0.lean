import TriangleData
namespace SixBody.Diagram93
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem bezout0 {R : Type*} [CommRing R] (m t : R)
    (hs : (t^2-t+1) = 0) (hp : torque m t = 0) :
    (m - 1)*(m + 2)*(q6 m) = 0 := by
  let a : R := - t^2*m^8 - 8*t^2*m^5 + t*m^8 + 8*t*m^5 + m^8 + 2*m^7 + 2*m^6 + 6*m^5 + 8*m^4 + 8*m^3 - 4*m^2 - 16*m - 16
  let b : R := 1
  have hid : (m - 1)*(m + 2)*(q6 m) = a*(t^2-t+1) + b*torque m t := by
    dsimp [a, b, torque, q6]
    ring
  rw [hid, hs, hp, mul_zero, mul_zero, add_zero]
end SixBody.Diagram93
