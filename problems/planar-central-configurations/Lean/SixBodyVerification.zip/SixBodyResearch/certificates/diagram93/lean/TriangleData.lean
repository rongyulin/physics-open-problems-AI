import Mathlib.Analysis.Complex.Polynomial.Basic
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity

/-!
# The diagram-93 torque condition at two equal triangle masses

The shape factors and torque polynomial below are Tejasvi Singh Tomar,
*Smale's sixth problem for six bodies in the plane* (2026), §§6.4 and 6.6,
at triangle masses (1,1,m). The relevant shape may be complex.
-/
namespace SixBody.Diagram93

set_option maxRecDepth 100000
set_option maxHeartbeats 0

def torque {R : Type*} [CommRing R] (m t : R) : R :=
  let a := 1 + m*t
  let b := a - (2+m)
  let c := a - (2+m)*t
  let u := b*c
  let v := a*c
  let w := m^2*a*b
  u^2 + v^2 + w^2 - 2*(u*v+v*w+w*u)

def euler {R : Type*} [CommRing R] (b c m t : R) : R :=
  let x := t-1
  2*x^3*t^2+x^2*t^2 + m*b*x^3-m*c*t^3-b*x^2-c*t^2

def shape {R : Type*} [CommRing R] (m t : R) : R :=
  (t^2 - t + 1) * (t^4-5*t^3+9*t^2-5*t+1) *
  (t^4+t^3-2*t+1) * (t^4-2*t^3+t+1) *
  euler 1 1 m t * euler 1 (-1) m t * euler (-1) (-1) m t * euler (-1) 1 m t

def q6 {R : Type*} [CommRing R] (m : R) : R :=
  m^6 + m^5 + 4*m^4 + 6*m^3 + 9*m^2 + 9*m + 6
def q9 {R : Type*} [CommRing R] (m : R) : R :=
  m^9 - m^7 + 6*m^6 + 5*m^5 - 6*m^4 - 5*m^3 + 4*m^2 + 13*m + 10
def q14 {R : Type*} [CommRing R] (m : R) : R :=
  m^14 - 6*m^13 + 21*m^12 - 38*m^11 + 36*m^10 + 6*m^9 - 29*m^8 + 9*m^6 + 54*m^5 - 78*m^4 - 84*m^3 + 21*m^2 + 84*m + 84
def q16 {R : Type*} [CommRing R] (m : R) : R :=
  m^16 + 2*m^14 + 12*m^13 + 5*m^12 + 10*m^11 + 36*m^10 + 16*m^9 - 8*m^8 - 30*m^7 - 39*m^6 - 48*m^5 - 114*m^4 - 56*m^3 + 65*m^2 + 116*m + 68
def q28 {R : Type*} [CommRing R] (m : R) : R :=
  m^28 + 6*m^27 + 15*m^26 + 32*m^25 + 105*m^24 + 252*m^23 + 351*m^22 + 510*m^21 + 1071*m^20 + 1322*m^19 + 546*m^18 + 6*m^17 + 136*m^16 - 114*m^15 - 738*m^14 - 1002*m^13 + 39*m^12 + 1116*m^11 + 2076*m^10 + 1248*m^9 + 654*m^8 + 180*m^7 - 324*m^6 - 648*m^5 - 711*m^4 - 216*m^3 + 216*m^2 + 288*m + 144
def q36 {R : Type*} [CommRing R] (m : R) : R :=
  m^36 + 4*m^34 + 20*m^33 + 14*m^32 + 68*m^31 + 152*m^30 + 204*m^29 + 373*m^28 + 516*m^27 + 790*m^26 + 608*m^25 + 428*m^24 + 332*m^23 - 424*m^22 - 508*m^21 - 708*m^20 + 604*m^19 + 1178*m^18 + 868*m^17 - 1143*m^16 - 5320*m^15 - 8960*m^14 - 11968*m^13 - 8470*m^12 + 3184*m^11 + 17796*m^10 + 24456*m^9 + 19793*m^8 + 9064*m^7 - 8168*m^6 - 21472*m^5 - 22256*m^4 - 8192*m^3 + 6144*m^2 + 8192*m + 4096

end SixBody.Diagram93
