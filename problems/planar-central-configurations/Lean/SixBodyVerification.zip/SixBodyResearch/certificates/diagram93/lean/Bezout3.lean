import TriangleData
namespace SixBody.Diagram93
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem bezout3 {R : Type*} [CommRing R] (m t : R)
    (hs : (t^4-2*t^3+t+1) = 0) (hp : torque m t = 0) :
    (m + 2)*(q14 m) = 0 := by
  let a : R := t^2*m^15 - 4*t^2*m^14 + 6*t^2*m^13 + 6*t^2*m^12 - 36*t^2*m^11 + 48*t^2*m^10 - 12*t^2*m^9 - 24*t^2*m^8 + 32*t^2*m^6 + 64*t^2*m^5 - t*m^15 + 4*t*m^14 - 6*t*m^13 - 6*t*m^12 + 36*t*m^11 - 48*t*m^10 + 12*t*m^9 + 24*t*m^8 - 32*t*m^6 - 64*t*m^5 + m^15 - 4*m^14 + 9*m^13 + 6*m^12 - 39*m^11 + 72*m^10 - 9*m^9 - 42*m^8 + 40*m^6 + 16*m^5 - 192*m^4 - 112*m^3 + 96*m^2 + 192*m + 128
  let b : R := - t^2*m^7 + 4*t^2*m^6 - 6*t^2*m^5 + 2*t^2*m^4 + 4*t^2*m^3 - 4*t^2*m - 8*t^2 + t*m^7 - 4*t*m^6 + 6*t*m^5 - 2*t*m^4 - 4*t*m^3 + 4*t*m + 8*t - 2*m^6 + 3*m^5 - 2*m^4 - 5*m^3 + 5*m + 10
  have hid : (m + 2)*(q14 m) = a*(t^4-2*t^3+t+1) + b*torque m t := by
    dsimp [a, b, torque, q14]
    ring
  rw [hid, hs, hp, mul_zero, mul_zero, add_zero]
end SixBody.Diagram93
