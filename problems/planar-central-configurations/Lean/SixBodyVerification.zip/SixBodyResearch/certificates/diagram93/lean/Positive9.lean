import TriangleData
namespace SixBody.Diagram93
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem positive9 (m : ℝ) (hm : 0 < m) : 0 < q9 m := by
  by_cases hu1_1 : m < 1
  ·
    let x : ℝ := 1*m - 0
    let y : ℝ := 1 - 1*m
    have hx : 0 ≤ x := by dsimp [x]; linarith
    have hy : 0 < y := by dsimp [y]; linarith
    have hpoly : 1 * q9 m = 10*y^9 + x*(103*y^8 + x*(468*y^7 + x*(1227*y^6 + x*(2036*y^5 + x*(2210*y^4 + x*(1574*y^3 + x*(720*y^2 + x*(198*y^1 + x*(27))))))))) := by
      dsimp [x, y, q9]
      ring
    have hpos : 0 < 10*y^9 + x*(103*y^8 + x*(468*y^7 + x*(1227*y^6 + x*(2036*y^5 + x*(2210*y^4 + x*(1574*y^3 + x*(720*y^2 + x*(198*y^1 + x*(27))))))))) := by positivity
    rw [← hpoly] at hpos
    exact pos_of_mul_pos_right hpos (by norm_num)
  have hx : 0 ≤ m - 1 := by linarith
  have hpoly : q9 m = (m-1)^9 + 9*(m-1)^8 + 35*(m-1)^7 + 83*(m-1)^6 + 146*(m-1)^5 + 200*(m-1)^4 + 190*(m-1)^3 + 108*(m-1)^2 + 45*(m-1) + 27 := by unfold q9; ring
  rw [hpoly]
  positivity
end SixBody.Diagram93
