import TriangleData
namespace SixBody.Diagram93
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem positive14 (m : ℝ) (hm : 0 < m) : 0 < q14 m := by
  by_cases hu1_1 : m < 1
  ·
    let x : ℝ := 1*m - 0
    let y : ℝ := 1 - 1*m
    have hx : 0 ≤ x := by dsimp [x]; linarith
    have hy : 0 < y := by dsimp [y]; linarith
    have hpoly : 1 * q14 m = 84*y^14 + x*(1260*y^13 + x*(8757*y^12 + x*(37296*y^11 + x*(108492*y^10 + x*(227502*y^9 + x*(353880*y^8 + x*(414000*y^7 + x*(365371*y^6 + x*(241584*y^5 + x*(117504*y^4 + x*(40626*y^3 + x*(9396*y^2 + x*(1296*y^1 + x*(81)))))))))))))) := by
      dsimp [x, y, q14]
      ring
    have hpos : 0 < 84*y^14 + x*(1260*y^13 + x*(8757*y^12 + x*(37296*y^11 + x*(108492*y^10 + x*(227502*y^9 + x*(353880*y^8 + x*(414000*y^7 + x*(365371*y^6 + x*(241584*y^5 + x*(117504*y^4 + x*(40626*y^3 + x*(9396*y^2 + x*(1296*y^1 + x*(81)))))))))))))) := by positivity
    rw [← hpoly] at hpos
    exact pos_of_mul_pos_right hpos (by norm_num)
  by_cases hu2_1 : m < 2
  ·
    let x : ℝ := 1*m - 1
    let y : ℝ := 2 - 1*m
    have hx : 0 ≤ x := by dsimp [x]; linarith
    have hy : 0 < y := by dsimp [y]; linarith
    have hpoly : 1 * q14 m = 81*y^14 + x*(972*y^13 + x*(5184*y^12 + x*(16398*y^11 + x*(36324*y^10 + x*(70680*y^9 + x*(150667*y^8 + x*(325696*y^7 + x*(581896*y^6 + x*(778738*y^5 + x*(755008*y^4 + x*(516736*y^3 + x*(238165*y^2 + x*(66760*y^1 + x*(8656)))))))))))))) := by
      dsimp [x, y, q14]
      ring
    have hpos : 0 < 81*y^14 + x*(972*y^13 + x*(5184*y^12 + x*(16398*y^11 + x*(36324*y^10 + x*(70680*y^9 + x*(150667*y^8 + x*(325696*y^7 + x*(581896*y^6 + x*(778738*y^5 + x*(755008*y^4 + x*(516736*y^3 + x*(238165*y^2 + x*(66760*y^1 + x*(8656)))))))))))))) := by positivity
    rw [← hpoly] at hpos
    exact pos_of_mul_pos_right hpos (by norm_num)
  have hx : 0 ≤ m - 2 := by linarith
  have hpoly : q14 m = (m-2)^14 + 22*(m-2)^13 + 229*(m-2)^12 + 1506*(m-2)^11 + 7032*(m-2)^10 + 24750*(m-2)^9 + 67807*(m-2)^8 + 146896*(m-2)^7 + 252697*(m-2)^6 + 343074*(m-2)^5 + 361098*(m-2)^4 + 284748*(m-2)^3 + 157981*(m-2)^2 + 54424*(m-2) + 8656 := by unfold q14; ring
  rw [hpoly]
  positivity
end SixBody.Diagram93
