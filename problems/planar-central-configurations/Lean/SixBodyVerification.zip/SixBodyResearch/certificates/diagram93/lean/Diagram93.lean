import Positive6
import Positive9
import Positive14
import Positive16
import Positive28
import Positive36
import Bezout0
import Bezout1
import Bezout2
import Bezout3
import Bezout4
import Bezout5
import Bezout6
import Bezout7
namespace SixBody.Diagram93
set_option maxRecDepth 100000
set_option maxHeartbeats 0

/-- A common complex root of the shape and torque equations for positive masses
(1,1,m) forces m = 1. This analytic obstruction is conditional on the published
implication from a diagram-93 degeneration to the two polynomial equations. -/
theorem mass_eq_one (m : ℝ) (hm : 0 < m) (t : ℂ)
    (hs : shape (m : ℂ) t = 0) (hp : torque (m : ℂ) t = 0) : m = 1 := by
  by_contra hn
  have hm0 : (m : ℂ) ≠ 0 := by exact_mod_cast hm.ne'
  have hm1 : (m : ℂ) - 1 ≠ 0 := by exact_mod_cast sub_ne_zero.mpr hn
  have hm2 : (m : ℂ) + 2 ≠ 0 := by exact_mod_cast (show m+2 ≠ 0 by linarith)
  have h6 : q6 (m : ℂ) ≠ 0 := by
    have h := (positive6 m hm).ne'
    unfold q6 at h ⊢
    exact_mod_cast h
  have h9 : q9 (m : ℂ) ≠ 0 := by
    have h := (positive9 m hm).ne'
    unfold q9 at h ⊢
    exact_mod_cast h
  have h14 : q14 (m : ℂ) ≠ 0 := by
    have h := (positive14 m hm).ne'
    unfold q14 at h ⊢
    exact_mod_cast h
  have h16 : q16 (m : ℂ) ≠ 0 := by
    have h := (positive16 m hm).ne'
    unfold q16 at h ⊢
    exact_mod_cast h
  have h28 : q28 (m : ℂ) ≠ 0 := by
    have h := (positive28 m hm).ne'
    unfold q28 at h ⊢
    exact_mod_cast h
  have h36 : q36 (m : ℂ) ≠ 0 := by
    have h := (positive36 m hm).ne'
    unfold q36 at h ⊢
    exact_mod_cast h
  simp only [shape, mul_eq_zero, or_assoc] at hs
  rcases hs with h_0 | h_1 | h_2 | h_3 | h_4 | h_5 | h_6 | h_7
  · exact (mul_ne_zero (mul_ne_zero hm1 hm2) h6) (bezout0 (m : ℂ) t h_0 hp)
  · exact (mul_ne_zero hm2 h28) (bezout1 (m : ℂ) t h_1 hp)
  · exact (mul_ne_zero hm2 h28) (bezout2 (m : ℂ) t h_2 hp)
  · exact (mul_ne_zero hm2 h14) (bezout3 (m : ℂ) t h_3 hp)
  · exact (mul_ne_zero (pow_ne_zero 4 hm2) h36) (bezout4 (m : ℂ) t h_4 hp)
  · exact (mul_ne_zero (mul_ne_zero (pow_ne_zero 4 hm0) (pow_ne_zero 4 hm2)) h16) (bezout5 (m : ℂ) t h_5 hp)
  · exact (mul_ne_zero (pow_ne_zero 4 hm2) h36) (bezout6 (m : ℂ) t h_6 hp)
  · exact (mul_ne_zero (mul_ne_zero (mul_ne_zero (mul_ne_zero hm1 (pow_ne_zero 4 hm0)) (pow_ne_zero 4 hm2)) h6) h9) (bezout7 (m : ℂ) t h_7 hp)
/-- Simultaneous zeros in the positive two-equal-mass slice are exactly the
equal-mass, equilateral shape roots. This is the complete positive slice. -/
theorem zero_locus (m : ℝ) (hm : 0 < m) (t : ℂ) :
    (shape (m : ℂ) t = 0 ∧ torque (m : ℂ) t = 0) ↔
      (m = 1 ∧ t^2-t+1=0) := by
  have h1 : torque (1:ℂ) t = 9*(t^2-t+1)^2 := by unfold torque; ring
  constructor
  · rintro ⟨hs, hp⟩
    obtain rfl := mass_eq_one m hm t hs hp
    refine ⟨rfl, ?_⟩
    rw [Complex.ofReal_one, h1] at hp
    simpa using hp
  · rintro ⟨rfl, ht⟩
    exact ⟨by simp [shape, ht], by simp [h1, ht]⟩

/-- At m=1 the shared roots include both roots of the equilateral shape factor. -/
theorem root_iff (m : ℝ) (hm : 0 < m) :
    (∃ t : ℂ, shape (m : ℂ) t = 0 ∧ torque (m : ℂ) t = 0) ↔ m = 1 := by
  constructor
  · rintro ⟨t, hs, hp⟩
    exact mass_eq_one m hm t hs hp
  · rintro rfl
    obtain ⟨u, hu⟩ := IsAlgClosed.exists_pow_nat_eq (-3 : ℂ) (show 0 < (2:ℕ) by decide)
    let t : ℂ := (1+u)/2
    have ht : t^2-t+1=0 := by dsimp [t]; linear_combination hu / 4
    refine ⟨t, ?_, ?_⟩
    · simp [shape, ht]
    · have hh : torque (1:ℂ) t = 9*(t^2-t+1)^2 := by unfold torque; ring
      rw [Complex.ofReal_one, hh, ht]
      norm_num

end SixBody.Diagram93
#print axioms SixBody.Diagram93.zero_locus
#print axioms SixBody.Diagram93.root_iff
