# The positive mass locus of the diagram-93 torque condition

The calculation uses the complex three-body shape polynomial and the leading torque equation in Sections 6.4 and 6.6 of [Tomar's 2026 six-body preprint](https://hexagonmath.org/pdf/2611.00377v1). The three masses belong to the fully circled triangle of diagram 93. The other three six-body masses are unrestricted.

For ordered positive masses, scale the lightest to one and write the triple as `(1,u,v)`. Exactly three mass triples admit a common complex root of the two necessary equations. The first is `(1,1,1)`; its possible shapes satisfy `t²−t+1=0`. Approximate ordered coordinates of the other two triples and one choice of shape in each are given below. The exact specifications are the unique zeros in the rational boxes used by the checker. Complex conjugation gives the other shape in each case.

| Shape branch | Middle mass | Heaviest mass | Re t | Im t |
| --- | ---: | ---: | ---: | ---: |
| Lagrange quartic N11 | 1.211156057904405 | 1.470853017662610 | −0.473561483353507 | 0.444771808762066 |
| Euler signs (+,+,−) | 1.104244723429672 | 1.128840671501523 | −0.227312842305231 | 0.896449611254474 |

Each number in the table is a rational box centre with coordinate error less than `10⁻¹⁰`. Passing this condition does not prove that the associated six-body degeneration occurs. In particular it does not establish either finiteness or infinitude of physical central configurations for any six-body mass tuple.

## Reproduction

Use Python 3 with SymPy and NumPy. Run `python diagram93_global.py` with assertions enabled. It reconstructs the input, resultants, factors, dyadic covers, quadratic subresultants and fixed-point bounds from the source equations. Decisions use exact integers or fractions. NumPy arrays have dtype `object` and hold unbounded Python integers. No precomputed data files are required.

For a low-memory Lean build, run `lean/check.sh /path/to/your/lake/project` with Lean 4.28.0 and mathlib commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365`. The checker compiles the modules in order and prints the axioms of the final theorems. At masses `(1,1,m)` the accompanying Lean development encodes the eight shape branches and the torque polynomial directly, and characterizes their simultaneous zeros. A separate optional Lean arithmetic certificate covers the two unequal local tests; consult its stated theorems for its scope.

## Why the global checker proves exhaustiveness

1. Form the resultant of each of the eight shape factors with the torque polynomial in the complex shape variable. A simultaneous root makes at least one of the eight resultants vanish. Conversely, the shape factors have leading coefficient one or `1+u>0`, so their degree stays fixed and a zero of a specialized resultant yields a finite common root. On each of the two ordered equal-pair boundaries, exact univariate root counts discard all ratios greater than one. At the all-equal point the torque becomes nine times the square of the equilateral quadratic.
2. On the strict-order region use `X=1/u, Y=u/v`. The two variables independently range over the open unit square. For each factor, multiply by positive powers of X and Y to get a bivariate polynomial. The sign is chosen at masses (1,2,4). Convert to the Bernstein basis and bisect alternately in X and Y using the integer-scaled midpoint de Casteljau construction. A nonnegative coefficient net with some positive coefficient implies positivity in the interior of a cell. A positive coefficient on each interior split edge proves positivity along its relative interior. Each interior vertex is also checked. Across the eight branches, exactly one depth-100 cell survives for the quartic N11, and one for the Euler sign pattern (+,+,−). The other factors have no surviving cells.
3. In each surviving cell, form the second subresultant in t. Its coefficients have only a positive power of the total mass as common content. After division the quadratic is `A t²+B t+C`. The polynomial belongs to the ideal of the two inputs up to the nonzero content, so it vanishes at any simultaneous root. Compute exact Taylor bounds over the surviving mass box on A, B and C. They give `A≠0` and `C/A−(B/2A)²>0`, enclosing the two conjugate shape roots. Every simultaneous root in the cell lies within the local four-variable box or its conjugate.
4. In that box set `F=(Re(shape),Im(shape),Re(torque),Im(torque))`, using real coordinates (Re t, Im t,u,v). The displayed rational matrix entries in the checker define an invertible matrix M for each branch. At the centre z the code bounds `‖MF(z)‖∞ < 10⁻¹⁵`. For `T(w)=w−MF(w)` it bounds `sup ‖DT(w)‖∞ < 0.00111` on the closed radius-`10⁻¹⁰` box, by summing absolute bounds for the Hessians on the larger cube [−2,2]⁴. These inequalities make T a strict contraction of the box into itself. The Banach fixed-point theorem yields a unique zero there. The disjoint mass boxes and the global exclusion complete the classification.

## Prior work

The ambient elimination factors were derived by [Albouy and Kaloshin in 2012, Section 8.2.1](https://doi.org/10.4007/annals.2012.176.1.10). Tomar's Theorem 6.15 connects these factors to six-body diagram 93. The result above classifies the positive real locus of that necessary test as normalized by ascending mass order.
