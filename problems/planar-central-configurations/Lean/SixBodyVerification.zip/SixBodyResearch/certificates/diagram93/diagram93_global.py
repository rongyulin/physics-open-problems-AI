"""Classify the real positive triangle-mass locus of the diagram-93 torque condition.

Python 3, NumPy, and SymPy. Run without -O so that certificates are checked.
Every exclusion and enclosure is decided by integer or rational arithmetic.
The polynomial input is Tomar (2026), Sections 6.4 and 6.6.
"""

from fractions import Fraction
from itertools import product
from math import comb, lcm

import numpy as np
import sympy as sp

t, u, v = sp.symbols("t u v")
x, y, a, b = sp.symbols("x y a b", real=True)
variables = (x, y, a, b)
RADIUS = Fraction(1, 10**10)
BRANCHES = {
    3: (
        [-473561483353507, 444771808762066, 1211156057904405, 1470853017662610],
        [[112072, 245314, 0, 0], [-245314, 112072, 0, 0],
         [-106576, -269116, 1937, 3785], [157988, -312575, -1870, 4793]],
    ),
    5: (
        [-227312842305231, 896449611254474, 1104244723429672, 1128840671501523],
        [[-63590, 13427, 314, 274], [-13263, -61162, -488, 728],
         [20323, -11584, 4480, 123], [21501, 9757, 2551, 3735]],
    ),
}


def polynomials():
    # Ordered mass triple (1,u,v). Multiplying every mass by the same positive
    # constant leaves the zero tests invariant.
    ell1 = u + v*t
    ell2 = ell1 - (1+u+v)
    ell3 = ell1 - (1+u+v)*t
    Y1, Y2, Y3 = ell2*ell3, u**2*ell1*ell3, v**2*ell1*ell2
    phi = sp.expand(Y1**2+Y2**2+Y3**2 - 2*(Y1*Y2+Y2*Y3+Y3*Y1))
    shapes = [t*t-t+1, t**4-5*t**3+9*t*t-5*t+1,
              t**4+t**3-2*t+1, t**4-2*t**3+t+1]
    z = t-1
    for sign13, sign23 in [(1, 1), (1, -1), (-1, -1), (-1, 1)]:
        shapes.append(sp.expand((1+u)*z**3*t**2 + z**2*t**2
                                + v*sign13*z**3 - v*sign23*t**3
                                - sign13*z**2 - u*sign23*t**2))
    return shapes, phi


def bernstein_net(factor):
    # Let X=1/u, Y=u/v. Clear the denominator by positive powers of X,Y.
    poly = sp.Poly(factor, u, v)
    degree = poly.total_degree()
    coefficients = {(degree-i-j, degree-j): int(c) for (i, j), c in poly.terms()}
    xmin = min(i for i, j in coefficients)
    ymin = min(j for i, j in coefficients)
    coefficients = {(i-xmin, j-ymin): c for (i, j), c in coefficients.items()}
    nx = max(i for i, j in coefficients)
    ny = max(j for i, j in coefficients)
    power = np.zeros((nx+1, ny+1), dtype=object)
    for (i, j), coefficient in coefficients.items():
        power[i, j] = coefficient

    def change_of_basis(n):
        denominator = lcm(*(comb(n, k) for k in range(n+1)))
        return np.array([[comb(i, k) * (denominator // comb(n, k)) if i >= k else 0
                          for k in range(n+1)] for i in range(n+1)], dtype=object)

    return change_of_basis(nx) @ power @ change_of_basis(ny).T


def halves(net, axis):
    # Midpoint de Casteljau coefficients, scaled by 2^n to remain integers.
    row = net if axis == 0 else net.T
    n = len(row)-1
    left, right = row.copy(), row.copy()
    for k in range(n+1):
        left[k] = row[0] * 2**(n-k)
        right[n-k] = row[-1] * 2**(n-k)
        if k < n:
            row = row[:-1] + row[1:]
    return (left, right) if axis == 0 else (left.T, right.T)


def positive_on_cell(net, sides):
    # The physical open square excludes its outer boundary only. All interior
    # split edges and vertices receive an explicit additional positivity test.
    if np.any(net < 0) or not np.any(net > 0):
        return False
    for i, coord in zip((0, -1), sides[0]):
        if coord not in (0, 1) and max(net[i]) == 0:
            return False
    for j, coord in zip((0, -1), sides[1]):
        if coord not in (0, 1) and max(net[:, j]) == 0:
            return False
    for i, X in zip((0, -1), sides[0]):
        for j, Y in zip((0, -1), sides[1]):
            if X not in (0, 1) and Y not in (0, 1) and net[i, j] == 0:
                return False
    return True


def cover(factor, depth=100):
    survivors = []
    count = 0

    def visit(net, sides, level):
        nonlocal count
        if positive_on_cell(net, sides):
            count += 1
            return
        if level == depth:
            survivors.append(sides)
            return
        axis = level % 2
        low, high = sides[axis]
        mid = (low+high)/2
        for new_net, interval in zip(halves(net, axis), ((low, mid), (mid, high))):
            child = list(sides)
            child[axis] = interval
            visit(new_net, child, level+1)

    visit(bernstein_net(factor), [(Fraction(0), Fraction(1))]*2, 0)
    return count, survivors


def times(A, B):
    values = [x*y for x, y in product(A, B)]
    return min(values), max(values)


def divide(A, B):
    assert B[0]*B[1] > 0
    return times(A, (1/B[1], 1/B[0]))


def polynomial_interval(expression, U, V, center):
    # Taylor enclosure, with all second derivatives bounded on [-2,2]^2.
    assert all(abs(z) <= 2 for z in (*U, *V, *center))
    p = sp.Poly(expression, u, v)
    u0, v0 = center
    d = max(*(abs(z-u0) for z in U), *(abs(z-v0) for z in V))

    def value(poly):
        return Fraction(sum(c*u0**i*v0**j for (i, j), c in poly.terms()))

    def absolute_bound(poly):
        return sum(abs(int(c))*2**(i+j) for (i, j), c in poly.terms())

    first = sum(abs(value(p.diff(k))) for k in (u,v))
    second = sum(absolute_bound(p.diff(k).diff(l)) for k,l in product((u,v),repeat=2))
    error = d*first + d*d*second/2
    central_value = value(p)
    return central_value-error, central_value+error


def lift_box(f, phi, mass_box, center):
    # Subresultants belong to the ideal (f,Phi), including after evaluation.
    second, = [p for p in sp.subresultants(f, phi, t) if sp.degree(p, t) == 2]
    coefficients = sp.Poly(second, t).all_coeffs()
    content = sp.gcd_list(coefficients)
    assert sp.factor(content) in ((1+u+v)**2,(1+u+v)**3)
    coefficients = [sp.cancel(c/content) for c in coefficients]
    mass_u = divide((Fraction(1),Fraction(1)), mass_box[0])
    mass_v = divide(mass_u, mass_box[1])
    for interval, z in zip((mass_u,mass_v), center[2:]):
        assert z-RADIUS < interval[0] <= interval[1] < z+RADIUS
    A, B, C = [polynomial_interval(q, mass_u, mass_v, center[2:]) for q in coefficients]
    real = divide((-B[1], -B[0]), times((2,2), A))
    ratio = divide(C, A)
    square = times(real, real)
    imag2 = (ratio[0]-square[1], ratio[1]-square[0])
    assert center[0]-RADIUS < real[0] <= real[1] < center[0]+RADIUS
    assert 0 < (center[1]-RADIUS)**2 < imag2[0] <= imag2[1] < (center[1]+RADIUS)**2


def contraction(f, phi, center, inverse):
    def real_imag(p):
        subst = {u: a, v: b, t: x + sp.I*y}
        expansion = sp.expand(p.subs(subst))
        return sp.re(expansion), sp.im(expansion)

    def norm(matrix):
        return max(sum(abs(z) for z in matrix.row(i)) for i in range(matrix.rows))

    def bound(p):
        return sum(abs(c)*2**sum(k) for k,c in sp.Poly(p,*variables).terms())

    system = sp.Matrix((*real_imag(f), *real_imag(phi)))
    jacobian = system.jacobian(variables)
    point = dict(zip(variables,center))
    matrix = sp.Matrix(inverse)/10**6
    assert matrix.det() != 0
    assert max(map(abs,center))+RADIUS < 2
    assert 1 < center[2]-RADIUS < center[2]+RADIUS < center[3]-RADIUS
    assert 0 < center[1]-RADIUS
    hessian = max(sum(bound(sp.diff(z,i,j)) for i,j in product(variables,repeat=2))
                  for z in system)
    error = norm(matrix*system.subs(point))
    defect = norm(sp.eye(4)-matrix*jacobian.subs(point))
    kappa = defect + norm(matrix)*hessian*RADIUS
    assert hessian == 14549050
    assert error < Fraction(1,10**15) and kappa < Fraction(111,100000)
    assert error + kappa*RADIUS < RADIUS


def check_equal_pair(resultant):
    # The two boundaries of ordered positive masses: (1,1,v) or (1,u,u).
    # Rescale the free positive mass if desired. Handle the whole x>1 ray.
    for f, z in ((resultant.subs(u,1), v),(resultant.subs(v,u),u)):
        assert f != 0
        p = sp.Poly(f,z)
        _, primitive = p.terms_gcd()
        p = primitive
        while p.eval(1) == 0:
            p = p.exquo(sp.Poly(z-1,z))
        assert p.count_roots(1,sp.oo) == 0


def main():
    if not __debug__:
        raise RuntimeError("Run without Python's -O option")
    shapes, phi = polynomials()
    total = 0
    for index, shape in enumerate(shapes):
        resultant = sp.resultant(shape, phi, t)
        assert resultant != 0
        constant, factors = sp.factor_list(resultant)
        assert constant != 0
        found = []
        for factor, multiplicity in factors:
            check_equal_pair(factor)
            sign = sp.sign(factor.subs({u: 2,v: 4}))
            assert sign != 0
            count, survivors = cover(sign*factor)
            total += count
            if survivors:
                assert index in BRANCHES
                found.extend(survivors)
        if index in BRANCHES:
            assert len(found) == 1
            numerators, inverse = BRANCHES[index]
            center = [Fraction(z,10**15) for z in numerators]
            print("  closed box in (1/u,u/v):", found[0], flush=True)
            lift_box(shape, phi, found[0], center)
            contraction(shape, phi, center, inverse)
        else:
            assert not found
        print(f"branch {index}: {len(found)} surviving ordered mass box(es)", flush=True)
    assert sp.expand(phi.subs({u: 1,v: 1}) - 9*(t**2-t+1)**2) == 0
    assert sp.rem(sp.prod(shapes).subs({u: 1,v: 1}), t**2-t+1,t) == 0
    print(f"PASS: {total} excluded leaves across factorizations, two unequal mass rays"
          " and one equal ray admitted by the published leading condition.", flush=True)


if __name__ == "__main__":
    main()
