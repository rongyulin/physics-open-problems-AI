"""Exact interval symmetric elimination for the five heavy-body Hessians.

Usage: python3 primary_inertia.py PATH/TO/primaries
The supplied directory must contain certify_primaries.py and primary_centers.json.
"""
import json
from pathlib import Path
import sys

if len(sys.argv) != 2:
    raise SystemExit("Usage: python3 primary_inertia.py PATH/TO/primaries")
primary_dir = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(primary_dir))
from certify_primaries import ACTIVE, D, RAD, Interval, check, eval_primary


def inverse(a):
    if a.lo > 0:
        return a.inv_pos()
    if a.hi < 0:
        return -(-a).inv_pos()
    raise ArithmeticError("Pivot interval meets zero")


def diagonalize(a):
    pivots = []
    while a:
        p = a[0][0]
        pinv = inverse(p)
        pivots.append(p)
        a = [[a[i][j] - a[i][0]*pinv*a[0][j] for j in range(1, len(a))]
             for i in range(1, len(a))]
    return pivots


for name, centers in json.loads((primary_dir / 'primary_centers.json').read_text()).items():
    check(centers)
    center = [Interval.of(x) for pair in centers for x in pair]
    q = [Interval(x.lo-RAD, x.hi+RAD) if i in ACTIVE else x for i, x in enumerate(center)]
    _, h = eval_primary(q)
    pivots = diagonalize(h)
    signs = ''.join('+' if p.lo > 0 else '-' for p in pivots)
    low = min(p.lo if p.lo > 0 else -p.hi for p in pivots)
    print(f"{name:14} diagonal signs {signs}, negative index {signs.count('-')},"
          f" |pivot| >= {low*1000//D}/1000")
