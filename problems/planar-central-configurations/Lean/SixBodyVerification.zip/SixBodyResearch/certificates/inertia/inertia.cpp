// Compile with -I pointing to the directory containing the main isolate.cpp.
#define main restricted_global_checker_main
#include "isolate.cpp"
#undef main

int main() {
    try {
        std::string name;
        int n, shapes=0;
        while (std::cin >> name >> n) {
            if (n<0 || n>1000) throw std::runtime_error("invalid root count");
            Primaries primaries;
            for (auto &p : primaries) p=around(readPoint(),rational(1,1000000000));
            int positive=0, negative=0;
            std::string bySeed;
            for (int k=0;k<n;k++) {
                auto X=around(readPoint(),rational(1,16384));
                checkRoot(primaries,X);
                auto J=evaluate(primaries,X,true).j;
                auto det=J[0][0]*J[1][1]-J[0][1]*J[1][0];
                if ((J[0][0]+J[1][1]).lo<=0) throw std::runtime_error("trace not certified positive");
                if (det.lo>0) { positive++; bySeed.push_back('+'); }
                else if (det.hi<0) { negative++; bySeed.push_back('-'); }
                else throw std::runtime_error("determinant interval contains zero");
            }
            if (positive-negative != -4) throw std::runtime_error("signed-degree mismatch");
            std::cout << name << " minima=" << positive << " saddles=" << negative << " det-signs=" << bySeed << '\n';
            shapes++;
        }
        if (shapes!=5 || !std::cin.eof()) throw std::runtime_error("malformed transcript");
    } catch (const std::exception &e) { std::cerr << e.what() << '\n';return 1; }
}
