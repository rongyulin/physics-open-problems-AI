# Restricted Hessian inertia

Compile against the same `isolate.cpp` used for global coverage. `-I` names the directory with that file.

```sh
c++ -std=c++17 -O2 -I/path/to/restricted inertia.cpp -lgmpxx -lgmp -o inertia
./inertia < /path/to/restricted/seeds.txt
```

For each seed the program first repeats the original contraction check. It then calculates rigorous interval enclosures of the trace and determinant of the real symmetric two-dimensional Jacobian over the entire original root box and the entire $10^{-9}$ primary coordinate uncertainty. Positive trace and positive determinant imply a strict minimum of the restricted effective potential. Negative determinant identifies a saddle. The signs in `restricted-inertia.txt` follow the original seed order. This computation determines restricted potential signatures and does not test dynamical stability of the rotating orbit.
