# Morse indices in the one-light six-body regime

Run these commands from this directory with Python 3, a C++17 compiler and GMP.

    python3 primary_inertia.py ../primaries
    c++ -std=c++17 -O2 -I../restricted inertia.cpp -lgmpxx -lgmp -o inertia
    ./inertia < ../restricted/seeds.txt

The heavy, gauge-fixed, nine-dimensional symmetric elimination gives indices 3, 0, 2, 1, 0. On the full 60 root boxes the five restricted minimum/saddle pairs are (2,6), (4,8), (3,7), (5,9), (6,10). The heavy block of the full Hessian stays invertible along each branch, the off-diagonal block is O(t), and the light block divided by t tends to the restricted Hessian. Sylvester inertia additivity in the Schur complement yields 264, 1080, 1440, 960, 360 as the full index counts. See SmallMass.pdf and the MorseVerification note for the removal of gauge, translation and scaling modes.
