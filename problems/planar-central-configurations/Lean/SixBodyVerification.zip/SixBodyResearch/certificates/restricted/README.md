# Certification of every restricted equilibrium at the five primary shapes

`isolate.cpp` uses GNU MP integer arithmetic. It solves the two test-body force equations for each shape in `seeds.txt`. All five primary masses are $1/5$ and the multiplier is one. Each point in the input is stored as two decimal integers divided by $10^{12}$. The first five points in a record are the primary centers; they agree exactly with the separately certified primary input. The remaining points are proposed root centers. The proof holds simultaneously for every choice of primary positions in their respective coordinate boxes of radius $10^{-9}$, wider than the primary certificate's $10^{-11}$. All intervals actually used are rounded outwards.

Build and run from this directory with a C++17 compiler, the GMP development headers, and the GMP and GMP C++ libraries.

```sh
c++ -std=c++17 -O2 -Wall -Wextra isolate.cpp -lgmpxx -lgmp -o isolate
./isolate < seeds.txt
```

The resulting lines are saved in `verification.txt`. Every test operates on dyadic endpoints of denominator $2^{72}$. Multiplication, reciprocals and square roots round toward the outside using integer floor, ceiling or integer square root. The root suggestions and matrix preconditioner can be arbitrary guesses. Success requires strict containment and contraction inequalities followed by a global exclusion test.

## Certification inside and away from root boxes

Writing $v_i=u-q_i$, the force is $F=u-\sum_i v_i/(5|v_i|^3)$ and its Jacobian is $I-\sum_i I/(5|v_i|^3)+\sum_i3v_iv_i^T/(5|v_i|^5)$. For each proposed root construct a box $X$ of coordinate half-width $2^{-14}$, midpoint $c$, and a dyadic approximation $B$ to the inverse midpoint Jacobian. The verifier checks $B$ is invertible, verifies the interval row-sum bound $\|I-BDF(X)\|_\infty<1$, and verifies

$$c-BF(c)+(I-BDF(X))(X-c)\subset\operatorname{int} X.$$

The contraction mapping theorem applied to $u\mapsto u-BF(u)$ now gives exactly one root in $X$. The row norm also proves nonsingularity throughout $X$. Root boxes are pairwise disjoint.

All primary boxes satisfy $|q_i|<2$ and $|q_i-q_j|>1/4$. If $|u|\ge4$, then $\sum_i 1/(5|u-q_i|^2)\le1/(|u|-2)^2\le1/4<|u|$. Hence all roots occur in $[-4,4]^2$. Whenever $0<|u-q_i|\le1/32$, the acceleration due to $i$ has norm at least $1024/5$. The sum of the norms of the other accelerations is less than $(4/5)(32/7)^2$ and $|u|<2+1/32$. The reverse triangle inequality excludes a zero. The centers themselves lie outside the equation domain.

The verifier bisects the square in its longer direction until every leaf either lies within a certified root box, lies in a collision-exclusion disk, or has a force component whose interval excludes zero. All leaves include their shared boundaries. No root can be lost on a division boundary. Successful runs visited between 3,183 and 25,159 tree nodes per shape.

## Boundary roots and six-body continuation

The restricted counts, in file order, are 8 (line), 12 (square with center), 10 (two isosceles triangles), 14 (trapezium), and 16 (regular pentagon). There are respectively 60, 30, 120, 120, and 24 representatives with labelled primaries modulo positive scaling, translation, and rotation. The heavy Jacobian on a rotation slice and every restricted Jacobian are nonsingular. At zero light mass the combined Jacobian is block triangular. Each labelled boundary point has one nearby continuation, and compactness in the one-light limit excludes additional solutions for small light mass. Thus the small-mass count is $60(8)+30(12)+120(10)+120(14)+24(16)=4104$. These calculations do not yield a numerical cutoff for the sixth mass. The interval verifier is a separate exact-arithmetic program; its source and its input are supplied for independent replay.

## Independent Lean replay

`RestrictedReplay.lean` implements the arithmetic, root contraction checks, and full coverage traversal independently, with the decimal inputs embedded. Run `lean --run RestrictedReplay.lean` with Lean 4.28.0. It uses only `Std` and Lean integers. Every square root returned by its Newton iteration is checked against the two defining integer-square inequalities. The Lean executable returns the restricted-root count and coverage node count for each shape, matching both columns of the C++ transcript. It uses no `native_decide` or foreign function bindings. An executed Lean checker does not by itself formalize the analytic correctness of the interval method; that reasoning is given above.

The five closed theorems `line_local`, `square_local`, `two_triangles_local`, `trapezium_local`, and `pentagon_local` use `decide +kernel` to verify the actual integer local-root tests for **all 60 restricted root boxes**. `#print axioms` reports their dependencies in `lean-replay.txt`. The separate 54,489-node global exclusion is evaluated by the executable in both independent implementations. The kernel does not currently establish the entire global traversal, the correctness of the verifier with respect to real Newtonian equations, or the continuation theorem.
