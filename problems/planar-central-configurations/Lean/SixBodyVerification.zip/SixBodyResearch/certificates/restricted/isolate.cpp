// Exact interval verification of all test-body equilibria (five masses 1/5).
// c++ -std=c++17 -O2 isolate.cpp -lgmpxx -lgmp -o isolate && ./isolate < seeds.txt
#include <gmpxx.h>
#include <algorithm>
#include <array>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
using Integer = mpz_class;
const Integer scale = Integer(1) << 72;
Integer floorQ(const Integer &a, const Integer &b) { Integer v; mpz_fdiv_q(v.get_mpz_t(),a.get_mpz_t(),b.get_mpz_t()); return v; }
Integer ceilQ(const Integer &a, const Integer &b) { Integer v; mpz_cdiv_q(v.get_mpz_t(),a.get_mpz_t(),b.get_mpz_t()); return v; }
Integer isqrt(const Integer &x) { if (x<0) throw std::runtime_error("negative sqrt"); Integer v; mpz_sqrt(v.get_mpz_t(),x.get_mpz_t()); return v; }
struct Interval { Integer lo,hi; };
Interval rational(const Integer &a, const Integer &b=1) { return {floorQ(a*scale,b),ceilQ(a*scale,b)}; }
Interval exact(long v) { return rational(v); }
Interval operator+(const Interval &a,const Interval &b) { return {a.lo+b.lo,a.hi+b.hi}; }
Interval operator-(const Interval &a,const Interval &b) { return {a.lo-b.hi,a.hi-b.lo}; }
Interval operator*(const Interval &a,const Interval &b) {
    std::array<Integer,4> c={a.lo*b.lo,a.lo*b.hi,a.hi*b.lo,a.hi*b.hi};
    auto ext=std::minmax_element(c.begin(),c.end()); return {floorQ(*ext.first,scale),ceilQ(*ext.second,scale)};
}
Interval square(const Interval &a) { Integer l=a.lo*a.lo,h=a.hi*a.hi; return {a.lo<=0 && 0<=a.hi ? Integer(0) : floorQ(std::min(l,h),scale),ceilQ(std::max(l,h),scale)}; }
Interval sqrtI(const Interval &a) { Integer upper=a.hi*scale,r=isqrt(upper); return {isqrt(a.lo*scale),r*r==upper ? r : r+1}; }
Interval inverse(const Interval &a) { if(a.lo<=0 && 0<=a.hi) throw std::runtime_error("division through zero"); return {floorQ(scale*scale,a.hi),ceilQ(scale*scale,a.lo)}; }
Interval midpoint(const Interval &a) { Integer m=floorQ(a.lo+a.hi,2); return {m,m}; }
Integer absBound(const Interval &a) { Integer l=abs(a.lo),h=abs(a.hi); return std::max(l,h); }
bool zeroExcluded(const Interval &a) { return a.lo>0 || a.hi<0; }
bool subset(const Interval&a,const Interval&b) { return b.lo<=a.lo && a.hi<=b.hi; }
using Point=std::array<Interval,2>;
using Matrix=std::array<Point,2>;
using Primaries=std::array<Point,5>;
const Interval mass=rational(1,5), one=exact(1),zero=exact(0),three=exact(3);
struct Field { Point f; Matrix j; };
Field evaluate(const Primaries &q,const Point &x,bool withJacobian) {
    Field result{x,{Point{one,zero},Point{zero,one}}};
    for(const auto &c:q) {
        Point d{x[0]-c[0],x[1]-c[1]}; Interval r2=square(d[0])+square(d[1]);
        Interval m3=mass*inverse(r2*sqrtI(r2));
        for(int i=0;i<2;i++) result.f[i]=result.f[i]-m3*d[i];
        if(withJacobian) {
            Interval m5=three*m3*inverse(r2);
            for(int i=0;i<2;i++) for(int j=0;j<2;j++) {
                Interval product=(i==j ? square(d[i]) : d[i]*d[j]);
                result.j[i][j]=result.j[i][j] + m5*product - (i==j ? m3 : zero);
            }
        }
    }
    return result;
}
Interval around(const Interval &a,const Interval &radius) { return {a.lo-radius.hi,a.hi+radius.hi}; }
Point around(const Point &p,const Interval &radius) { return {around(p[0],radius),around(p[1],radius)}; }
Point readPoint() { Point out; for(auto &c:out){Integer v; if(!(std::cin>>v)) throw std::runtime_error("bad seed"); c=rational(v,Integer("1000000000000"));} return out; }
void checkRoot(const Primaries &q,const Point &x) {
    Point c{midpoint(x[0]),midpoint(x[1])};
    Field aroundCenter=evaluate(q,c,true), whole=evaluate(q,x,true);
    Matrix a=aroundCenter.j;
    for(auto &row:a) for(auto &v:row) v=midpoint(v);
    Interval det=a[0][0]*a[1][1]-a[1][0]*a[0][1];
    Interval di=inverse(det);
    Matrix B={Point{midpoint(a[1][1]*di),midpoint((zero-a[0][1])*di)},Point{midpoint((zero-a[1][0])*di),midpoint(a[0][0]*di)}};
    if(!zeroExcluded(B[0][0]*B[1][1]-B[1][0]*B[0][1])) throw std::runtime_error("inverse uncertified");
    for(int i=0;i<2;i++) {
        Interval K=c[i]; Integer rowNorm(0);
        for(int k=0;k<2;k++) K=K-B[i][k]*aroundCenter.f[k];
        for(int j=0;j<2;j++) {
            Interval e=(i==j?one:zero);
            for(int k=0;k<2;k++) e=e-B[i][k]*whole.j[k][j];
            rowNorm+=absBound(e); K=K+e*(x[j]-c[j]);
        }
        if(rowNorm>=scale || !(x[i].lo<K.lo && K.hi<x[i].hi)) throw std::runtime_error("Krawczyk containment/contraction failed");
    }
}
struct Counters { long nodes=0,excluded=0,holes=0,captured=0; int depth=0; };
void cover(const Primaries &q,const std::vector<Point>& roots,const Point &box,int depth,Counters &c) {
    c.nodes++; c.depth=std::max(depth,c.depth); if(depth>120 || c.nodes>2000000) throw std::runtime_error("coverage budget exceeded");
    for(const auto &r:roots) if(subset(box[0],r[0]) && subset(box[1],r[1])) { c.captured++;return; }
    bool singular=false;
    for(const auto &s:q) {
        Interval r2=square(box[0]-s[0])+square(box[1]-s[1]);
        if(r2.hi<=rational(1,1024).lo) { c.holes++;return; }
        if(r2.lo<=0) singular=true;
    }
    if(!singular) { auto F=evaluate(q,box,false).f; if(zeroExcluded(F[0]) || zeroExcluded(F[1])) {c.excluded++;return;} }
    int i=(box[0].hi-box[0].lo >= box[1].hi-box[1].lo ? 0 : 1);
    auto mid=midpoint(box[i]); Point left=box,right=box; left[i].hi=mid.hi; right[i].lo=mid.lo;
    cover(q,roots,left,depth+1,c); cover(q,roots,right,depth+1,c);
}
int main() {
 try {
    std::string name; int N,records=0;
    while(std::cin>>name>>N) {
        if(N<0 || N>1000) throw std::runtime_error("invalid number of root candidates");
        Primaries q; for(auto &s:q) s=around(readPoint(),rational(1,1000000000));
        for(int i=0;i<5;i++) {
            if((square(q[i][0])+square(q[i][1])).hi>=exact(4).lo) throw std::runtime_error("primary too far");
            for(int j=0;j<i;j++) if((square(q[i][0]-q[j][0])+square(q[i][1]-q[j][1])).lo<=rational(1,16).hi) throw std::runtime_error("primary separation failed");
        }
        std::vector<Point> roots; for(int k=0;k<N;k++) {
            Point r=around(readPoint(),rational(1,16384)); checkRoot(q,r);
            for(const auto &other:roots) if(!zeroExcluded(r[0]-other[0]) && !zeroExcluded(r[1]-other[1])) throw std::runtime_error("root boxes overlap");
            roots.push_back(r);
        }
        const Interval axis{exact(-4).lo,exact(4).hi}; Counters counts;
        cover(q,roots,Point{axis,axis},0,counts);
        std::cout<<name<<" count="<<N<<" coverage_nodes="<<counts.nodes<<" range_exclusions="<<counts.excluded<<" singularity_exclusions="<<counts.holes<<" enclosed_leaves="<<counts.captured<<" max_depth="<<counts.depth<<std::endl;
        records++;
    }
    if(records!=5 || !std::cin.eof()) throw std::runtime_error("expected exactly five input records");
    return 0;
 } catch(const std::exception &e) {std::cerr<<e.what()<<std::endl;return 1;}
}
