import FiniteTransfer
import TorqueSlice

/-! Conditional assembly for the actual six-body acceleration equations. The
compactness and coordinate-chart hypotheses below have mathematical proofs in
the manuscript. They are explicit parameters of this Lean theorem. -/
open Set Filter Topology
namespace SmallMass
open SmallMassTorque
abbrev Positions := (Fin 6 → ℝ) × (Fin 6 → ℝ)

/-- Five unit masses followed by a light body of mass t. -/
def masses (t : ℝ) (i : Fin 6) : ℝ := if i = 5 then t else 1

/-- Labelled Newtonian configurations in the multiplier-one, oriented slice.
The divided acceleration equation of body 5 is retained at t = 0. -/
def configurations (t : ℝ) : Set Positions :=
  {q | q.2 0 = q.2 1 ∧ q.1 0 > q.1 1 ∧
    (∀ i j : Fin 6, i ≠ j → (q.1 i, q.2 i) ≠ (q.1 j, q.2 j)) ∧
    ∀ i : Fin 6, residual (masses t) q.1 (inverseCube q.1 q.2) i = 0 ∧
                residual (masses t) q.2 (inverseCube q.1 q.2) i = 0}

/-- Once normalized compactness and the two implicit eliminations have been
supplied, the whole physical fiber is finite for every sufficiently small t. -/
theorem finite_six_body_of_implicit_charts {ι : Type*} [Finite ι]
    (C : ι → ScalarChart ℝ Positions 0) (O : ι → Set Positions)
    (hopen : ∀ i, IsOpen (O i))
    (hboundary : configurations 0 ⊆ ⋃ i, O i)
    (hcompact : ∀ (p : ℕ → ℝ) (q : ℕ → Positions),
      Tendsto p atTop (𝓝 0) → (∀ n, 0 < p n) → (∀ n, q n ∈ configurations (p n)) →
      ∃ (v : ℕ → ℕ) (z : Positions), StrictMono v ∧ z ∈ configurations 0 ∧
        Tendsto (q ∘ v) atTop (𝓝 z))
    (hchart : ∀ i, ∀ᶠ t in 𝓝 (0 : ℝ), ∀ q ∈ O i, q ∈ configurations t →
      q ∈ (C i).candidates t) :
    ∃ ε : ℝ, 0 < ε ∧ ∀ t : ℝ, 0 < t → t < ε → (configurations t).Finite := by
  have hO : ∀ᶠ p in 𝓝 (0 : ℝ), p ∈ Set.Ioi (0 : ℝ) →
      configurations p ⊆ ⋃ i, O i := by
    apply eventually_covered (isOpen_iUnion hopen)
    intro p q hp hpos hq
    obtain ⟨v, z, hv, hz, hlim⟩ := hcompact p q hp hpos hq
    exact ⟨v, z, hv, hboundary hz, hlim⟩
  have hc : ∀ᶠ p in 𝓝 (0 : ℝ), p ∈ Set.Ioi (0 : ℝ) →
      configurations p ⊆ ⋃ i, (C i).candidates p := by
    filter_upwards [hO, Filter.eventually_all.mpr hchart] with p hOp hp
    intro hpos q hq
    obtain ⟨i, hi⟩ := Set.mem_iUnion.mp (hOp hpos hq)
    exact Set.mem_iUnion.mpr ⟨i, hp i q hi hq⟩
  obtain ⟨ε, he, hb⟩ := Metric.mem_nhds_iff.mp (finite_fibers_of_scalar_charts C hc)
  refine ⟨ε, he, fun t ht htε => ?_⟩
  have hball : t ∈ Metric.ball (0 : ℝ) ε := by
    simpa [Metric.mem_ball, Real.dist_eq, abs_of_pos ht] using htε
  exact hb hball ht

#print axioms finite_six_body_of_implicit_charts
end SmallMass
