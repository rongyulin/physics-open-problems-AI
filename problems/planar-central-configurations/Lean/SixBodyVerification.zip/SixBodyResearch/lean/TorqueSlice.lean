import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

/-! Torque cancellation for the planar Newtonian central equations, followed by
recovery of one deleted coordinate equation on a rotation slice. -/

noncomputable section
namespace SmallMassTorque
open scoped BigOperators

variable {n : ℕ}

/-- Inverse cubed mutual distance. At a diagonal term the force factor
will be multiplied by zero displacement. The intended application is
collision-free off the diagonal. -/
def inverseCube (x y : Fin n → ℝ) (i j : Fin n) : ℝ :=
  ((x i - x j)^2 + (y i - y j)^2)^(-(3 : ℝ) / 2)

theorem inverseCube_symm (x y : Fin n → ℝ) (i j : Fin n) :
    inverseCube x y i j = inverseCube x y j i := by
  unfold inverseCube
  congr 1
  ring

/-- One coordinate of the mass-divided, multiplier-one residual. -/
def residual (mass q : Fin n → ℝ) (weight : Fin n → Fin n → ℝ)
    (i : Fin n) : ℝ :=
  q i - ∑ j, mass j * (q i - q j) * weight i j

private def crossTerm (mass x y : Fin n → ℝ) (w : Fin n → Fin n → ℝ)
    (i j : Fin n) : ℝ :=
  mass i * mass j * w i j * (x i * y j - y i * x j)

private theorem torque_expand (mass x y : Fin n → ℝ) (w : Fin n → Fin n → ℝ)
    (i : Fin n) :
    mass i * (x i * residual mass y w i - y i * residual mass x w i) =
      ∑ j, crossTerm mass x y w i j := by
  simp only [residual, mul_sub, Finset.mul_sum, mul_comm (y i) (x i), sub_sub_sub_cancel_left]
  rw [← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro j _
  unfold crossTerm
  ring

/-- The total Newtonian torque of the mass-weighted residual vanishes
identically. No equations of motion, positive masses, or gauge are assumed. -/
theorem torque_zero (mass x y : Fin n → ℝ) :
    ∑ i, mass i * (x i * residual mass y (inverseCube x y) i -
      y i * residual mass x (inverseCube x y) i) = 0 := by
  let T := crossTerm mass x y (inverseCube x y)
  have negSwap (i j : Fin n) : T j i = - T i j := by
    dsimp [T, crossTerm]
    rw [inverseCube_symm x y j i]
    ring
  simp_rw [torque_expand]
  change (∑ i, ∑ j, T i j) = 0
  have h : (∑ i, ∑ j, T i j) = -(∑ i, ∑ j, T i j) := calc
    (∑ i, ∑ j, T i j) = ∑ j, ∑ i, T i j := Finset.sum_comm
    _ = ∑ j, ∑ i, -T j i := by
      apply Finset.sum_congr rfl
      intro j _
      apply Finset.sum_congr rfl
      intro i _
      exact negSwap j i
    _ = _ := by simp
  linarith

/-- Where the distinguished heavy body's first coordinate is nonzero, its
second residual follows from all other coordinate equations and torque.
This remains valid when another mass vanishes. -/
theorem recover_deleted (mass x y : Fin n → ℝ) (h : Fin n)
    (hm : mass h ≠ 0) (hx : x h ≠ 0)
    (hallX : ∀ i, residual mass x (inverseCube x y) i = 0)
    (hallY : ∀ i, i ≠ h → residual mass y (inverseCube x y) i = 0) :
    residual mass y (inverseCube x y) h = 0 := by
  have ht := torque_zero mass x y
  simp only [hallX, mul_zero, sub_zero] at ht
  rw [Finset.sum_eq_single h] at ht
  · exact (mul_eq_zero.mp ((mul_eq_zero.mp ht).resolve_left hm)).resolve_left hx
  · intro i _ hi
    simp [hallY i hi]
  · simp

#print axioms torque_zero
#print axioms recover_deleted

/-- A bordered rotational gauge introduces a scalar multiplier `t` and a
fixed reference tangent `(-b_i,a_i)`. Put `a_i=b_i=0` for the light body.
Its equation is then kept in full. Where the moment pairing stays nonzero,
the augmented equations force the introduced multiplier to vanish. -/
theorem bordered_multiplier_zero (mass x y a b : Fin n → ℝ) (t : ℝ)
    (hpair : (∑ i, mass i * (x i * a i + y i * b i)) ≠ 0)
    (hX : ∀ i, residual mass x (inverseCube x y) i = -(t * b i))
    (hY : ∀ i, residual mass y (inverseCube x y) i = t * a i) :
    t = 0 := by
  have ht := torque_zero mass x y
  have h : t * (∑ i, mass i * (x i * a i + y i * b i)) = 0 := by
    rw [Finset.mul_sum]
    calc
      _ = ∑ i, mass i * (x i * residual mass y (inverseCube x y) i -
          y i * residual mass x (inverseCube x y) i) := by
        apply Finset.sum_congr rfl
        intro i _
        rw [hX, hY]
        ring
      _ = 0 := ht
  exact (mul_eq_zero.mp h).resolve_right hpair

#print axioms bordered_multiplier_zero
end SmallMassTorque
