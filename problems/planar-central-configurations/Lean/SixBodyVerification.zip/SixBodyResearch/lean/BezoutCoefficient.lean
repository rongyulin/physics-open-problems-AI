import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-! In the multihomogeneous Bézout product, only terms at most linear in
each of the two position hyperplanes can contribute to the point class.
This polynomial identity computes all surviving terms before truncating
the inverse-distance hyperplane degree. -/
namespace SmallMassDegree

private theorem five_distance_factors {R : Type*} [CommRing R] (z w p : R)
    (ht : (z+w)^2 = 2*(z*w)) (htt : (z+w)^3 = 0) :
    (z+w+2*p)^5 = 32*p^5 + 80*p^4*(z+w) + 160*p^3*(z*w) := by
  linear_combination 80*p^3*ht + (40*p^2+10*p*(z+w)+(z+w)^2)*htt

theorem degree_five_primary {R : Type*} [CommRing R] (z w p : R)
    (hz : z^2 = 0) (hw : w^2 = 0) :
    (z+w+2*p)^5 * (z+3*p) * (w+3*p) =
      288*p^7 + 816*p^6*(z+w) + 1952*p^5*(z*w) := by
  have ht : (z+w)^2 = 2*(z*w) := by linear_combination hz + hw
  have htu : (z+w)*(z*w) = 0 := by linear_combination w*hz + z*hw
  have htt : (z+w)^3 = 0 := by linear_combination (z+w)*ht + 2*htu
  have huu : (z*w)^2 = 0 := by linear_combination w^2*hz
  rw [five_distance_factors z w p ht htt]
  linear_combination 240*p^5*ht + 560*p^4*htu + 160*p^3*huu

/-- With 354 labelled, oriented primary shapes the resulting upper bound. -/
theorem upper_bound_arithmetic : (354 : ℕ) * 1952 = 691008 := by norm_num

/-- The nonphysical real sign sheets each spend at least n−1 roots. -/
theorem refined_arithmetic : (1952 : ℕ) - (2^5-1)*(5-1) = 1828 ∧
    (354 : ℕ)*1828 = 647112 := by norm_num

/-- In the nonrotating coplanar Coulomb case, cancel one linear
distance factor in each force before clearing the other denominators. -/
theorem degree_five_coplanar_coulomb {R : Type*} [CommRing R] (z w p : R)
    (hz : z^2 = 0) (hw : w^2 = 0) :
    (z+w+2*p)^5 * (4*z+p) * (4*w+p) =
      32*p^7 + 208*p^6*(z+w) + 1312*p^5*(z*w) := by
  have ht : (z+w)^2 = 2*(z*w) := by linear_combination hz + hw
  have htu : (z+w)*(z*w) = 0 := by linear_combination w*hz + z*hw
  have htt : (z+w)^3 = 0 := by linear_combination (z+w)*ht + 2*htu
  have huu : (z*w)^2 = 0 := by linear_combination w^2*hz
  rw [five_distance_factors z w p ht htt]
  linear_combination 320*p^5*ht + 1920*p^4*htu + 2560*p^3*huu

#print axioms degree_five_primary
#print axioms upper_bound_arithmetic
#print axioms refined_arithmetic
#print axioms degree_five_coplanar_coulomb
end SmallMassDegree
