import FiniteTransfer
import Mathlib.Analysis.Calculus.InverseFunctionTheorem.FDeriv
import Mathlib.Topology.OpenPartialHomeomorph.IsImage
import Mathlib.SetTheory.Cardinal.Finite

/-!
# From one local branch at each boundary shape to the exact physical count

The branch index can be the dependent type of labelled primaries paired with
their restricted equilibria. Local existence and uniqueness on each chart
come from the implicit function theorem in the application. The final theorem
uses sequential compactness to produce a single neighborhood working for all
branches and all physical solutions.
-/

open Set Filter Topology

namespace SmallMass

/-- Disjoint neighborhoods, one solution in each, and complete coverage give
a bijection between the chart labels and the entire physical solution fiber. -/
theorem branchEquiv_of_disjoint_cover {I X : Type*} {S : Set X} (U : I → Set X)
    (separated : ∀ i j x, x ∈ U i → x ∈ U j → i = j)
    (cover : S ⊆ ⋃ i, U i)
    (single : ∀ i, ∃! x, x ∈ S ∧ x ∈ U i) :
    Nonempty (I ≃ S) := by
  classical
  choose point mem uniq using single
  let f : I → S := fun i => ⟨point i, (mem i).1⟩
  refine ⟨Equiv.ofBijective f ⟨?_, ?_⟩⟩
  · intro i j h
    have h' : point i = point j := congrArg Subtype.val h
    apply separated i j (point i) (mem i).2
    exact h' ▸ (mem j).2
  · intro x
    obtain ⟨i, hi⟩ := Set.mem_iUnion.mp (cover x.property)
    refine ⟨i, Subtype.ext ?_⟩
    exact (uniq i x.val ⟨x.property, hi⟩).symm

/-- Finitely many locally unique solution charts work simultaneously on one
parameter neighborhood, restricted to the requested physical parameter set. -/
theorem eventually_branchEquiv {I P X : Type*} [Finite I] [TopologicalSpace P]
    {p₀ : P} {D : Set P} {S : P → Set X} (U : I → Set X)
    (separated : ∀ i j x, x ∈ U i → x ∈ U j → i = j)
    (cover : ∀ᶠ p in 𝓝 p₀, p ∈ D → S p ⊆ ⋃ i, U i)
    (single : ∀ i, ∀ᶠ p in 𝓝 p₀, p ∈ D → ∃! x, x ∈ S p ∧ x ∈ U i) :
    ∀ᶠ p in 𝓝 p₀, p ∈ D → Nonempty (I ≃ S p) := by
  filter_upwards [cover, Filter.eventually_all.mpr single] with p hp hall
  exact fun hd => branchEquiv_of_disjoint_cover U separated (hp hd) (fun i => hall i hd)

/-- Sequential compactness at the mass boundary and local IFT uniqueness imply
a bijection and exact cardinality in every sufficiently nearby physical fiber.
The sequence hypothesis asks that all limits can be caught by the open union
of charts. In particular, the indicated neighborhood is uniform in the masses. -/
theorem eventually_exact_count_of_branch_charts {I P X : Type*} [Finite I]
    [TopologicalSpace P] [FirstCountableTopology P] [TopologicalSpace X]
    {p₀ : P} {D : Set P} {S : P → Set X} (U : I → Set X)
    (openCharts : ∀ i, IsOpen (U i))
    (separated : ∀ i j x, x ∈ U i → x ∈ U j → i = j)
    (compact : ∀ (p : ℕ → P) (x : ℕ → X),
      Tendsto p atTop (𝓝 p₀) → (∀ n, p n ∈ D) → (∀ n, x n ∈ S (p n)) →
      ∃ (v : ℕ → ℕ) (z : X), StrictMono v ∧ z ∈ ⋃ i, U i ∧ Tendsto (x ∘ v) atTop (𝓝 z))
    (single : ∀ i, ∀ᶠ p in 𝓝 p₀, p ∈ D → ∃! x, x ∈ S p ∧ x ∈ U i) :
    ∀ᶠ p in 𝓝 p₀, p ∈ D → (Nonempty (I ≃ S p) ∧ Nat.card (S p) = Nat.card I) := by
  have uniformCover := eventually_covered (isOpen_iUnion openCharts) compact
  filter_upwards [eventually_branchEquiv U separated uniformCover single] with p hp
  intro hd
  obtain ⟨e⟩ := hp hd
  exact ⟨⟨e⟩, Nat.card_congr e.symm⟩

/-- Mathlib's inverse function theorem constructs the unique branch on a
possibly smaller open set within any prescribed neighborhood. In a parameterized
system one takes the augmented map (parameters, residuals). -/
theorem exists_unique_local_branch_of_invertible_derivative
    {E F : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] {f : E → F} {a : E} {A : E ≃L[ℝ] F}
    (deriv : HasStrictFDerivAt f (A : E →L[ℝ] F) a)
    {V : Set E} (openV : IsOpen V) (aV : a ∈ V) :
    ∃ U : Set E, IsOpen U ∧ a ∈ U ∧ U ⊆ V ∧
      ∀ᶠ y in 𝓝 (f a), ∃! x, f x = y ∧ x ∈ U := by
  let e := (deriv.toOpenPartialHomeomorph f).restrOpen V openV
  have aSource : a ∈ e.source := ⟨deriv.mem_toOpenPartialHomeomorph_source, aV⟩
  refine ⟨e.source, e.open_source, aSource, fun _ h => h.2, ?_⟩
  filter_upwards [e.open_target.mem_nhds (e.map_source aSource)] with y hy
  refine ⟨e.symm y, ⟨e.right_inv hy, e.map_target hy⟩, ?_⟩
  intro x hx
  apply e.injOn hx.2 (e.map_target hy)
  exact hx.1.trans (e.right_inv hy).symm

/-- Full gluing in a Banach chart using an invertible strict derivative at
each limiting solution, with no local root or branch existence hypothesis.
The physical part is W. The inputs on disjoint seed neighborhoods and sequential
compactness describe how the analytic setting models the application. -/
theorem exact_fibers_of_invertible_derivatives {I P E F : Type*} [Finite I]
    [TopologicalSpace P] [FirstCountableTopology P]
    [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    {f : E → F} {g : P → F} {p₀ : P} {D : Set P} {W : Set E}
    (a : I → E) (A : I → E ≃L[ℝ] F)
    (deriv : ∀ i, HasStrictFDerivAt f ((A i) : E →L[ℝ] F) (a i))
    (boundary : ∀ i, f (a i) = g p₀) (continuity : ContinuousAt g p₀)
    (V : I → Set E) (openV : ∀ i, IsOpen (V i)) (atV : ∀ i, a i ∈ V i)
    (physicalV : ∀ i, V i ⊆ W) (separated : ∀ i j x, x ∈ V i → x ∈ V j → i = j)
    (compact : ∀ (p : ℕ → P) (x : ℕ → E), Tendsto p atTop (𝓝 p₀) →
      (∀ n, p n ∈ D) → (∀ n, x n ∈ W ∧ f (x n) = g (p n)) →
      ∃ (v : ℕ → ℕ) (i : I), StrictMono v ∧ Tendsto (x ∘ v) atTop (𝓝 (a i))) :
    ∀ᶠ p in 𝓝 p₀, p ∈ D → (Nonempty (I ≃ {x ∈ W | f x = g p}) ∧
      Nat.card {x ∈ W | f x = g p} = Nat.card I) := by
  classical
  choose U uOpen aU uSub localBranch using fun i =>
    exists_unique_local_branch_of_invertible_derivative (deriv i) (openV i) (atV i)
  apply eventually_exact_count_of_branch_charts U uOpen
  · exact fun i j x hx hy => separated i j x (uSub i hx) (uSub j hy)
  · intro p x hp hD hS
    obtain ⟨v,i,hv,hi⟩ := compact p x hp hD hS
    exact ⟨v, a i, hv, Set.mem_iUnion.mpr ⟨i, aU i⟩, hi⟩
  · intro i
    have h := localBranch i
    rw [boundary i] at h
    filter_upwards [continuity.tendsto.eventually h] with p hp
    intro _
    obtain ⟨x, hx, unique⟩ := hp
    refine ⟨x, ⟨⟨physicalV i (uSub i hx.2), hx.1⟩, hx.2⟩, ?_⟩
    exact fun y hy => unique y ⟨hy.1.2, hy.2⟩

#print axioms exists_unique_local_branch_of_invertible_derivative
#print axioms exact_fibers_of_invertible_derivatives

#print axioms branchEquiv_of_disjoint_cover
#print axioms eventually_branchEquiv
#print axioms eventually_exact_count_of_branch_charts

end SmallMass
