import Mathlib.Analysis.Calculus.IteratedDeriv.Defs
import Mathlib.Analysis.Calculus.LocalExtr.Rolle
import Mathlib.Analysis.Analytic.Order
import Mathlib.Data.Finset.Sort
import Mathlib.Data.Set.Card
import Mathlib.Tactic

/-! A one-variable finite order certificate for a uniform bound on distinct zeros. -/
noncomputable section
namespace RestrictedNewton
open Set Filter
open scoped ENNReal Topology

/-- If the kth derivative never vanishes, no k+1 distinct increasingly ordered
zeros can occur in the interval. The needed regularity is localized to that interval. -/
theorem no_extra_roots (k : ℕ) (f : ℝ → ℝ) (a b : ℝ)
    (hc : ∀ j < k, ContinuousOn (iteratedDeriv j f) (Icc a b))
    (hn : ∀ x ∈ Icc a b, iteratedDeriv k f x ≠ 0)
    (r : Fin (k+1) → ℝ) (hs : StrictMono r)
    (hr : ∀ i, r i ∈ Icc a b) (hz : ∀ i, f (r i) = 0) : False := by
  induction k generalizing f with
  | zero => exact hn (r 0) (hr 0) (by simpa using hz 0)
  | succ k ih =>
    have allRolle (i : Fin (k+1)) :
        ∃ c ∈ Ioo (r i.castSucc) (r i.succ), deriv f c = 0 := by
      apply exists_deriv_eq_zero (hs Fin.castSucc_lt_succ)
      · have hcont : ContinuousOn f (Icc a b) := by simpa using hc 0 (by omega)
        exact hcont.mono (Icc_subset_Icc (hr _).1 (hr _).2)
      · rw [hz, hz]
    choose t ht ht0 using allRolle
    refine ih (deriv f) ?_ ?_ t ?_ ?_ ht0
    · intro j hj
      rw [← iteratedDeriv_succ']
      exact hc (j+1) (by omega)
    · intro x hx
      rw [← iteratedDeriv_succ']
      exact hn x hx
    · apply Fin.strictMono_iff_lt_succ.mpr
      intro i
      exact (ht i.castSucc).2.trans (ht i.succ).1
    · intro i
      exact ⟨(hr i.castSucc).1.trans (ht i).1.le, (ht i).2.le.trans (hr i.succ).2⟩

/-- Cardinal form of the iterated Rolle bound. -/
theorem finite_roots (k : ℕ) (f : ℝ → ℝ) (a b : ℝ)
    (hc : ∀ j < k, ContinuousOn (iteratedDeriv j f) (Icc a b))
    (hn : ∀ x ∈ Icc a b, iteratedDeriv k f x ≠ 0) :
    {x ∈ Icc a b | f x = 0}.Finite ∧ {x ∈ Icc a b | f x = 0}.ncard ≤ k := by
  classical
  let S := {x ∈ Icc a b | f x = 0}
  have impossible (s : Finset ℝ) (hb : (s : Set ℝ) ⊆ S) (hs : s.card = k+1) : False := by
    let hmem := fun i => hb (s.orderEmbOfFin_mem hs i)
    exact no_extra_roots k f a b hc hn (s.orderEmbOfFin hs) (s.orderEmbOfFin hs).strictMono
      (fun i => (hmem i).1) (fun i => (hmem i).2)
  have hf : S.Finite := by
    by_contra hi
    obtain ⟨s, hb, hs⟩ := Set.Infinite.exists_subset_card_eq (s := S) hi (k+1)
    exact impossible s hb hs
  refine ⟨hf, ?_⟩
  change S.ncard ≤ k
  rw [Set.ncard_eq_toFinset_card S hf]
  by_contra! hk
  obtain ⟨s, hsub, hs⟩ := Finset.exists_subset_card_eq (show k+1 ≤ hf.toFinset.card by omega)
  exact impossible s (fun _ h => hf.mem_toFinset.mp (hsub h)) hs

/-- An analytic scalar germ which is not identically zero has a nonzero finite jet. -/
theorem nonzero_jet (f : ℝ → ℝ) (x : ℝ) (ha : AnalyticAt ℝ f x)
    (hg : ¬ ∀ᶠ s in nhds x, f s = 0) : ∃ k : ℕ, iteratedDeriv k f x ≠ 0 := by
  by_contra! h0
  have hfin : analyticOrderAt f x ≠ ⊤ := fun ht => hg (analyticOrderAt_eq_top.mp ht)
  have hh := (natCast_le_analyticOrderAt_iff_iteratedDeriv_eq_zero
    (n := analyticOrderNatAt f x + 1) ha).mpr (fun i _ => h0 i)
  rw [← Nat.cast_analyticOrderNatAt hfin] at hh
  exact (by exact_mod_cast (Nat.not_succ_le_self (analyticOrderNatAt f x)) :
    ¬ (((analyticOrderNatAt f x + 1 : ℕ) : ℕ∞) ≤ (analyticOrderNatAt f x : ℕ∞))) hh

/-- Uniform nearby finiteness for a real-analytic reduced equation. The continuity
assumptions state precisely which sliced derivatives must vary continuously. -/
theorem nearby_scalar_finiteness (F : ℝ → ℝ → ℝ) (p₀ x₀ : ℝ)
    (ha : AnalyticAt ℝ (F p₀) x₀) (hg : ¬ ∀ᶠ x in nhds x₀, F p₀ x = 0)
    (hc : ∀ k : ℕ, ContinuousAt (fun q : ℝ × ℝ => iteratedDeriv k (F q.1) q.2) (p₀,x₀))
    (hs : ∀ᶠ q : ℝ × ℝ in nhds (p₀,x₀), ∀ j : ℕ, ContinuousAt (iteratedDeriv j (F q.1)) q.2) :
    ∃ k : ℕ, ∃ a b : ℝ, a < x₀ ∧ x₀ < b ∧ ∀ᶠ p in nhds p₀,
      {x ∈ Icc a b | F p x = 0}.Finite ∧ {x ∈ Icc a b | F p x = 0}.ncard ≤ k := by
  obtain ⟨k, hk⟩ := nonzero_jet (F p₀) x₀ ha hg
  have hne : ∀ᶠ q : ℝ × ℝ in nhds (p₀,x₀), iteratedDeriv k (F q.1) q.2 ≠ 0 :=
    (hc k) (isOpen_ne.mem_nhds hk)
  obtain ⟨U, hu, V, hv, huv⟩ := mem_nhds_prod_iff.mp (hne.and hs)
  obtain ⟨c,d,hxcd,hcd⟩ := mem_nhds_iff_exists_Ioo_subset.mp hv
  let a := (c+x₀)/2
  let b := (d+x₀)/2
  have hx1 := hxcd.1
  have hx2 := hxcd.2
  have hV : Icc a b ⊆ V := fun z hz => hcd ⟨by dsimp [a] at hz; linarith [hz.1],
                                                 by dsimp [b] at hz; linarith [hz.2]⟩
  refine ⟨k,a,b,by dsimp [a]; linarith,by dsimp [b]; linarith,?_⟩
  filter_upwards [hu] with p hp
  apply finite_roots k (F p) a b
  · intro j _ z hz
    exact ((huv (show (p,z) ∈ U ×ˢ V from ⟨hp,hV hz⟩)).2 j).continuousWithinAt
  · intro z hz
    exact (huv (show (p,z) ∈ U ×ˢ V from ⟨hp,hV hz⟩)).1

#print axioms nearby_scalar_finiteness

#print axioms no_extra_roots
end RestrictedNewton
