import Mathlib.Analysis.Convex.Slope
import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-! Five equiangular rays. The chosen basis consists of the third and fourth
unit rays in counterclockwise order. Their labels in the file are 2 and 3. -/

namespace PentagonalRigidity

/-- Coordinates of the zero weighted vector sum in the oblique ray basis.
The five direction vectors in that basis are respectively
(-c,-c), (c,-1), (1,0), (0,1), (-1,c). -/
def Balanced (c a b d e g : ℝ) : Prop :=
  d = g + c * (a - b) ∧ e = b + c * (a - g)

private theorem rotate {c a b d e g : ℝ} (hc : c^2 + c = 1)
    (h : Balanced c a b d e g) : Balanced c b d e g a := by
  obtain ⟨hd, he⟩ := h
  constructor
  · rw [he, hd]
    linear_combination (a - b) * hc
  · rw [hd]
    ring

/-- At the largest radius, compare two secants of the radial law. -/
private theorem aligned {s : Set ℝ} {f : ℝ → ℝ}
    (hf : StrictConvexOn ℝ s f) {c a b d e g : ℝ}
    (hc : 0 < c) (hc1 : c < 1) (ha : a ∈ s) (hb : b ∈ s)
    (hbd : b ≤ g) (hg : g ≤ a) (hdmax : d ≤ a)
    (h : Balanced c a b d e g) (hw : Balanced c (f a) (f b) (f d) (f e) (f g)) :
    b = a ∧ d = a ∧ e = a ∧ g = a := by
  obtain ⟨hd, he⟩ := h
  have hga : g = a := by
    by_contra hne
    have hga : g < a := lt_of_le_of_ne hg hne
    have hba : b < a := lt_of_le_of_lt hbd hga
    have hbe : b < e := by linarith [mul_pos hc (sub_pos.mpr hga)]
    have hea : e < a := by nlinarith [mul_pos (sub_pos.mpr hc1) (sub_pos.mpr hga)]
    have hs1 := hf.secant_strict_mono_aux2 hb ha hbe hea
    have hs2 : (f a - f b) / (a - b) ≤ (f a - f g) / (a - g) := by
      rcases hbd.eq_or_lt with eq | lt
      · rw [eq]
      · exact (hf.secant_strict_mono_aux3 hb ha lt hga).le
    have hs := hs1.trans_le hs2
    have he' : e - b = c * (a - g) := by linarith
    have hw' : f e - f b = c * (f a - f g) := by linarith [hw.2]
    rw [he', hw', mul_div_mul_left _ _ hc.ne'] at hs
    exact lt_irrefl _ hs
  have hba : b = a := by
    apply le_antisymm (hbd.trans hg)
    by_contra! hlt
    have := mul_pos hc (sub_pos.mpr hlt)
    linarith
  exact ⟨hba, by simpa [hga, hba] using hd, by simpa [hga, hba] using he, hga⟩

private theorem largest {s : Set ℝ} {f : ℝ → ℝ}
    (hf : StrictConvexOn ℝ s f) {c a b d e g : ℝ} (hc : 0 < c) (hc1 : c < 1)
    (ha : a ∈ s) (hb : b ∈ s) (hg : g ∈ s)
    (hbmax : b ≤ a) (hdmax : d ≤ a) (hemax : e ≤ a) (hgmax : g ≤ a)
    (h : Balanced c a b d e g) (hw : Balanced c (f a) (f b) (f d) (f e) (f g)) :
    b = a ∧ d = a ∧ e = a ∧ g = a := by
  rcases le_total b g with hbg | hgb
  · exact aligned hf hc hc1 ha hb hbg hgmax hdmax h hw
  · obtain ⟨e1,e2,e3,e4⟩ := aligned hf hc hc1 ha hg hgb hbmax hemax
      (show Balanced c a g e d b from ⟨h.2, h.1⟩)
      (show Balanced c (f a) (f g) (f e) (f d) (f b) from ⟨hw.2, hw.1⟩)
    exact ⟨e4,e3,e2,e1⟩

private theorem around {c : ℝ} {r : Fin 5 → ℝ} (hc : c^2 + c = 1)
    (h : Balanced c (r 0) (r 1) (r 2) (r 3) (r 4)) (i : Fin 5) :
    Balanced c (r i) (r (i+1)) (r (i+2)) (r (i+3)) (r (i+4)) := by
  have h1 := rotate hc h
  have h2 := rotate hc h1
  have h3 := rotate hc h2
  have h4 := rotate hc h3
  fin_cases i
  · exact h
  · exact h1
  · exact h2
  · exact h3
  · exact h4

/-- A strictly convex function and its arguments cannot both have balanced
pentagonal ray sums unless the arguments are constant. -/
theorem convex_rigidity {s : Set ℝ} {f : ℝ → ℝ} (hf : StrictConvexOn ℝ s f)
    {c : ℝ} (hc : c^2 + c = 1) (hc0 : 0 < c) (hc1 : c < 1)
    (r : Fin 5 → ℝ) (hs : ∀ i, r i ∈ s)
    (h : Balanced c (r 0) (r 1) (r 2) (r 3) (r 4))
    (hw : Balanced c (f (r 0)) (f (r 1)) (f (r 2)) (f (r 3)) (f (r 4))) :
    ∀ i j, r i = r j := by
  obtain ⟨i, -, hmax⟩ := Finset.exists_max_image Finset.univ r Finset.univ_nonempty
  have hm (j : Fin 5) : r j ≤ r i := hmax j (Finset.mem_univ _)
  obtain ⟨h1,h2,h3,h4⟩ := largest hf hc0 hc1 (hs i) (hs (i+1)) (hs (i+4))
    (hm (i+1)) (hm (i+2)) (hm (i+3)) (hm (i+4)) (around hc h i)
    (around (r := fun k => f (r k)) hc hw i)
  have shift (k : Fin 5) : r (i+k) = r i := by
    fin_cases k
    · simp
    · exact h1
    · exact h2
    · exact h3
    · exact h4
  have allEq (k : Fin 5) : r k = r i := by simpa using shift (k-i)
  intro j k
  exact (allEq j).trans (allEq k).symm

/-- Newtonian specialization. Masses of the five outer bodies are equal.
The common outer mass and the mass at the origin cancel from both balances. -/
theorem inverse_square_rigidity {c : ℝ} (hc : c^2 + c = 1) (hc0 : 0 < c) (hc1 : c < 1)
    (r : Fin 5 → ℝ) (hr : ∀ i, 0 < r i)
    (h : Balanced c (r 0) (r 1) (r 2) (r 3) (r 4))
    (hw : Balanced c (1/(r 0)^2) (1/(r 1)^2) (1/(r 2)^2) (1/(r 3)^2) (1/(r 4)^2)) :
    ∀ i j, r i = r j := by
  apply convex_rigidity (f := fun x : ℝ => x ^ (-2 : ℤ))
    (strictConvexOn_zpow (by decide) (by decide)) hc hc0 hc1 r hr h
  simpa [zpow_neg, one_div] using hw

#print axioms convex_rigidity
#print axioms inverse_square_rigidity


/-- The five unit directions, represented by powers of the counterclockwise
rotation through 72 degrees. -/
noncomputable def rayRotation : ℂ :=
  ⟨Real.cos (2 * (Real.pi / 5)), Real.sin (2 * (Real.pi / 5))⟩

noncomputable def rayCoefficient : ℝ := 2 * Real.cos (2 * (Real.pi / 5))

private theorem golden : rayCoefficient ^ 2 + rayCoefficient = 1 ∧
    0 < rayCoefficient ∧ rayCoefficient < 1 := by
  have hs : 0 ≤ Real.sqrt 5 := Real.sqrt_nonneg _
  have hs2 : (Real.sqrt 5)^2 = 5 := Real.sq_sqrt (by norm_num)
  have hh : rayCoefficient = (Real.sqrt 5 - 1) / 2 := by
    unfold rayCoefficient
    rw [Real.cos_two_mul, Real.cos_pi_div_five]
    nlinarith
  rw [hh]
  refine ⟨by nlinarith, by nlinarith, by nlinarith⟩

private theorem rotationQuadratic :
    rayRotation ^ 2 = (rayCoefficient : ℂ) * rayRotation - 1 := by
  apply Complex.ext
  · simp only [pow_two, Complex.mul_re, Complex.sub_re, Complex.ofReal_re,
      Complex.ofReal_im, zero_mul, sub_zero, Complex.one_re]
    unfold rayRotation rayCoefficient
    nlinarith [Real.sin_sq_add_cos_sq (2 * (Real.pi / 5))]
  · simp only [pow_two, Complex.mul_im, Complex.sub_im, Complex.ofReal_re,
      Complex.ofReal_im, zero_mul, add_zero, Complex.one_im, sub_zero]
    unfold rayRotation rayCoefficient
    ring

private theorem rotationImaginary : rayRotation.im ≠ 0 := by
  apply ne_of_gt
  apply Real.sin_pos_of_pos_of_lt_pi <;> linarith [Real.pi_pos]

/-- The oblique-coordinate balances follow from the ordinary vector equation
for the physical pentagonal rays. -/
private theorem from_ray_sum {u : Fin 5 → ℝ}
    (h : ∑ j : Fin 5, (u j : ℂ) * rayRotation ^ (j : ℕ) = 0) :
    Balanced rayCoefficient (u 0) (u 1) (u 2) (u 3) (u 4) := by
  let c := rayCoefficient
  let z := rayRotation
  have hc : c^2 + c = 1 := golden.1
  have hc' : (c : ℂ)^2 + c = 1 := by exact_mod_cast hc
  have h2 : z^2 = (c : ℂ)*z - 1 := rotationQuadratic
  have h3 : z^3 = -(c : ℂ)*(z+1) := by
    calc z^3 = z*z^2 := by ring
         _ = (c : ℂ)*z^2-z := by rw [h2]; linear_combination c * h2
         _ = -(c : ℂ)*(z+1) := by rw [h2]; linear_combination z * hc'
  have h4 : z^4 = (c : ℂ)-z := by
    calc z^4 = z*z^3 := by ring
         _ = -(c : ℂ)*z^2-c*z := by rw [h3]; ring
         _ = (c : ℂ)-z := by rw [h2]; linear_combination -z * hc'
  let A := u 0 - u 2 - c*u 3 + c*u 4
  let B := u 1 + c*u 2 - c*u 3 - u 4
  have hsum : (A : ℂ) + B*z = 0 := by
    change ∑ j : Fin 5, (u j : ℂ) * z ^ (j : ℕ) = 0 at h
    norm_num [Fin.sum_univ_succ] at h
    change (u 0 : ℂ) + ((u 1 : ℂ)*z + ((u 2 : ℂ)*z^2 +
      ((u 3 : ℂ)*z^3 + (u 4 : ℂ)*z^4))) = 0 at h
    rw [h2,h3,h4] at h
    dsimp [A, B]
    push_cast
    linear_combination h
  have hBi : B * z.im = 0 := by
    simpa [Complex.mul_im] using congrArg Complex.im hsum
  have hB : B = 0 := (mul_eq_zero.mp hBi).resolve_right rotationImaginary
  have hA : A = 0 := by
    rw [hB] at hsum
    simpa using hsum
  dsimp [A] at hA
  dsimp [B] at hB
  change Balanced c _ _ _ _ _
  constructor
  · linear_combination -c * hA + c * hB - (u 2-u 4)*hc
  · linear_combination -c * hA - hB - (u 3-u 4)*hc

/-- Coordinate-free vector form in the complex plane. -/
theorem pentagonal_convex_ray_rigidity {s : Set ℝ} {f : ℝ → ℝ}
    (hf : StrictConvexOn ℝ s f) (r : Fin 5 → ℝ) (hr : ∀ k, r k ∈ s)
    (center : ∑ j : Fin 5, (r j : ℂ) * rayRotation ^ (j : ℕ) = 0)
    (field : ∑ j : Fin 5, (f (r j) : ℂ) * rayRotation ^ (j : ℕ) = 0) :
    ∀ i j, r i = r j :=
  convex_rigidity hf golden.1 golden.2.1 golden.2.2 r hr
    (from_ray_sum center) (from_ray_sum (u := fun j => f (r j)) field)

/-- A zero Newtonian gravitational field at the barycenter of five equal
positive masses on these five rays forces a single radius. -/
theorem newtonian_pentagonal_ray_rigidity (r : Fin 5 → ℝ) (hr : ∀ k, 0 < r k)
    (center : ∑ j : Fin 5, (r j : ℂ) * rayRotation ^ (j : ℕ) = 0)
    (field : ∑ j : Fin 5, ((1/(r j)^2 : ℝ) : ℂ) * rayRotation ^ (j : ℕ) = 0) :
    ∀ i j, r i = r j :=
  inverse_square_rigidity golden.1 golden.2.1 golden.2.2 r hr (from_ray_sum center)
    (from_ray_sum (u := fun j => 1/(r j)^2) field)

#print axioms pentagonal_convex_ray_rigidity
#print axioms newtonian_pentagonal_ray_rigidity

end PentagonalRigidity
