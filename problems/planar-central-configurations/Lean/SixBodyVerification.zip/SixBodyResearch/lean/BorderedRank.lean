import Mathlib.LinearAlgebra.FiniteDimensional.Basic
import Mathlib.LinearAlgebra.Prod
import Mathlib.Data.Real.Basic

/-! Nonsingularity of the square bordered primary block after adjoining the
rotation gauge to a primary Jacobian with a one-dimensional rotational kernel. -/
namespace SmallMassRank

variable {E : Type*} [AddCommGroup E] [Module ℝ E]

def bordered (A : E →ₗ[ℝ] E) (ℓ : E →ₗ[ℝ] ℝ) (k : E) :
    (E × ℝ) →ₗ[ℝ] (E × ℝ) :=
  ((A.comp (LinearMap.fst ℝ E ℝ)) +
      ((LinearMap.toSpanSingleton ℝ E k).comp (LinearMap.snd ℝ E ℝ))).prod
    (ℓ.comp (LinearMap.fst ℝ E ℝ))

/-- In the application `k` is the primary rotation tangent and `ℓ` its
mass-metric dual. Infinitesimal torque supplies `horth`, and nondegeneracy
modulo rotation supplies `hkernel`. -/
theorem bordered_bijective [FiniteDimensional ℝ E]
    (A : E →ₗ[ℝ] E) (ℓ : E →ₗ[ℝ] ℝ) (k : E)
    (horth : ∀ v, ℓ (A v) = 0)
    (hkernel : ∀ v, A v = 0 → ∃ a : ℝ, v = a • k)
    (hpair : ℓ k ≠ 0) : Function.Bijective (bordered A ℓ k) := by
  have ker : ∀ v : E × ℝ, bordered A ℓ k v = 0 → v = 0 := by
    rintro ⟨v, t⟩ hv
    change (A v + t • k, ℓ v) = (0, 0) at hv
    have hz := congrArg Prod.fst hv
    have hg := congrArg Prod.snd hv
    change A v + t • k = 0 at hz
    change ℓ v = 0 at hg
    have ht := congrArg ℓ hz
    rw [map_add, map_smul, horth, zero_add, map_zero, smul_eq_mul] at ht
    have htz := (mul_eq_zero.mp ht).resolve_right hpair
    subst t
    simp only [zero_smul, add_zero] at hz
    obtain ⟨s, rfl⟩ := hkernel v hz
    rw [map_smul, smul_eq_mul] at hg
    simp [(mul_eq_zero.mp hg).resolve_right hpair]
  have hi : Function.Injective (bordered A ℓ k) :=
    (injective_iff_map_eq_zero _).2 ker
  exact ⟨hi, LinearMap.injective_iff_surjective.1 hi⟩

#print axioms bordered_bijective
end SmallMassRank
