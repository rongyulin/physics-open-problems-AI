import Mathlib.Analysis.SpecialFunctions.Pow.Deriv
import Mathlib.Analysis.Calculus.Deriv.Add
import Mathlib.Tactic

/-! Planar Newtonian restricted potential in co-rotating units, with arbitrary
finite primary masses. Real powers below are powers of **squared** distance. -/
noncomputable section
namespace RestrictedNewton
open scoped BigOperators Topology
open Filter Set

variable {n : ℕ}

def squared (x a v : ℝ) : ℝ := (x-a)^2 + v^2

def potential (mass a v : Fin n → ℝ) (x transverse : ℝ) : ℝ :=
  (x^2 + transverse^2) / 2 + ∑ i, mass i * (squared x (a i) (v i)) ^ (-(1:ℝ)/2)

def field (mass a v : Fin n → ℝ) (x : ℝ) : ℝ :=
  x - ∑ i, mass i * (x - a i) * (squared x (a i) (v i)) ^ (-(3:ℝ)/2)

def curvature (mass a v : Fin n → ℝ) (x : ℝ) : ℝ :=
  1 + ∑ i, mass i * (3*(x-a i)^2*(squared x (a i) (v i))^(-(5:ℝ)/2)
                       - (squared x (a i) (v i)) ^ (-(3:ℝ)/2))

private theorem hdSquared (x a v : ℝ) :
    HasDerivAt (fun s => squared s a v) (2*(x-a)) x := by
  have h := ((((hasDerivAt_id x).sub_const a).pow 2).add_const (v^2))
  simpa [squared] using h

private theorem potTerm (x a v m : ℝ) (h : 0 < squared x a v) :
    HasDerivAt (fun s => m * (squared s a v)^(-(1:ℝ)/2))
      (-(m * (x-a) * (squared x a v)^(-(3:ℝ)/2))) x := by
  have hh := ((hdSquared x a v).rpow_const (p := -(1:ℝ)/2) (Or.inl h.ne')).const_mul m
  convert hh using 1
  norm_num
  ring

private theorem fieldTerm (x a v m : ℝ) (h : 0 < squared x a v) :
    HasDerivAt (fun s => m * (s-a) * (squared s a v)^(-(3:ℝ)/2))
      (-(m * (3*(x-a)^2*(squared x a v)^(-(5:ℝ)/2) - (squared x a v)^(-(3:ℝ)/2)))) x := by
  have hh := (((hasDerivAt_id x).sub_const a).const_mul m).mul
    ((hdSquared x a v).rpow_const (p := -(3:ℝ)/2) (Or.inl h.ne'))
  convert hh using 1
  norm_num
  ring

/-- True first derivative of the restricted potential on a noncollision slice. -/
theorem first_deriv (mass a v : Fin n → ℝ) (x t : ℝ)
    (h : ∀ i, 0 < squared x (a i) (v i)) :
    HasDerivAt (fun s => potential mass a v s t) (field mass a v x) x := by
  have h0 := (((hasDerivAt_id x).pow 2).add_const (t^2)).div_const 2
  have hs := HasDerivAt.fun_sum (u := Finset.univ)
    (fun i _ => potTerm x (a i) (v i) (mass i) (h i))
  convert h0.add hs using 1
  simp [field]
  ring

/-- Derivative of the first-derivative formula on that slice. -/
theorem field_deriv (mass a v : Fin n → ℝ) (x : ℝ)
    (h : ∀ i, 0 < squared x (a i) (v i)) :
    HasDerivAt (field mass a v) (curvature mass a v x) x := by
  have hs := HasDerivAt.fun_sum (u := Finset.univ)
    (fun i _ => fieldTerm x (a i) (v i) (mass i) (h i))
  convert (hasDerivAt_id x).sub hs using 1
  simp [curvature]

/-- The curvature formula is the actual second derivative at the point. -/
theorem second_deriv (mass a v : Fin n → ℝ) (x t : ℝ)
    (h : ∀ i, 0 < squared x (a i) (v i)) :
    deriv (deriv (fun s => potential mass a v s t)) x = curvature mass a v x := by
  have he : (deriv (fun s => potential mass a v s t)) =ᶠ[nhds x] field mass a v := by
    have hp : ∀ᶠ s in nhds x, ∀ i, 0 < squared s (a i) (v i) := by
      rw [Filter.eventually_all]; intro i
      exact (hdSquared x (a i) (v i)).continuousAt (Ioi_mem_nhds (h i))
    filter_upwards [hp] with s hs using (first_deriv mass a v s t hs).deriv
  rw [he.deriv_eq]; exact (field_deriv mass a v x h).deriv

/-- The restricted potential at (x,y) for primary positions (a_i,b_i). -/
def W (mass a b : Fin n → ℝ) (x y : ℝ) : ℝ :=
  potential mass a (fun i => y-b i) x y

private theorem singleTrace (u v : ℝ) (h : 0 < u^2+v^2) :
    3*u^2*(u^2+v^2)^(-(5:ℝ)/2) - (u^2+v^2)^(-(3:ℝ)/2)
    + (3*v^2*(u^2+v^2)^(-(5:ℝ)/2) - (u^2+v^2)^(-(3:ℝ)/2))
    = (u^2+v^2)^(-(3:ℝ)/2) := by
  have hh := Real.rpow_add_one h.ne' (-(5:ℝ)/2)
  norm_num at hh ⊢
  linear_combination -3*hh

/-- The sum of actual second partials of W is the physical Laplacian. -/
theorem laplacian (mass a b : Fin n → ℝ) (x y : ℝ)
    (h : ∀ i, 0 < squared x (a i) (y-b i)) :
    deriv (deriv (fun z => W mass a b z y)) x + deriv (deriv (W mass a b x)) y =
      2 + ∑ i, mass i * (squared x (a i) (y-b i)) ^ (-(3:ℝ)/2) := by
  have hsw (z : ℝ) : W mass a b x z = potential mass b (fun i => x-a i) z x := by
    simp only [W, potential, squared, add_comm]
  have h' : ∀ i, 0 < squared y (b i) (x-a i) := by simpa only [squared, add_comm] using h
  change deriv (deriv (fun z => potential _ _ _ z y)) x + _ = _
  rw [show W mass a b x = _ from funext hsw, second_deriv _ _ _ _ _ h, second_deriv _ _ _ _ _ h']
  unfold curvature
  rw [show ∀ A B : ℝ, 1+A+(1+B)=2+(A+B) by intro A B; ring]
  rw [← Finset.sum_add_distrib]
  congr 1
  apply Finset.sum_congr rfl
  intro i _
  rw [← mul_add]
  congr 1
  simpa only [squared, add_comm ((y-b i)^2) ((x-a i)^2)] using singleTrace (x-a i) (y-b i) (h i)

/-- A strictly positive planar trace guarantees that one elimination derivative is nonzero. -/
theorem some_positive_pure_partial (mass a b : Fin n → ℝ) (x y : ℝ)
    (hm : ∀ i, 0 ≤ mass i) (h : ∀ i, 0 < squared x (a i) (y-b i)) :
    0 < deriv (deriv (fun z => W mass a b z y)) x ∨ 0 < deriv (deriv (W mass a b x)) y := by
  have hh := laplacian mass a b x y h
  have hn : 0 ≤ ∑ i, mass i * (squared x (a i) (y-b i)) ^ (-(3:ℝ)/2) :=
    Finset.sum_nonneg fun i _ => mul_nonneg (hm i) (Real.rpow_nonneg (h i).le _)
  by_contra! hnone
  linarith [hnone.1, hnone.2]

#print axioms laplacian
#print axioms some_positive_pure_partial

end RestrictedNewton
