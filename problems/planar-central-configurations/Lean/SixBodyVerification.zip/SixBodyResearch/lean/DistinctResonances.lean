import Std

/-! Exact integer arithmetic for a local contraction test. The rows are the
real and imaginary parts of f(t) and Φ(t,1,A,B), at t=x+iy, for the
quartic f=t⁴-2t³+t+1. Coordinates are ordered x,y,A,B. A physical six-body
solution is not asserted by this polynomial certificate. -/
namespace DistinctTripleCertificate
set_option maxRecDepth 100000
set_option maxHeartbeats 0

structure Monomial where
  c : Int
  e : Array Nat
  deriving DecidableEq

def P0 : Array Monomial := #[
  ⟨1, #[4,0,0,0]⟩,
  ⟨-2, #[3,0,0,0]⟩,
  ⟨-6, #[2,2,0,0]⟩,
  ⟨6, #[1,2,0,0]⟩,
  ⟨1, #[1,0,0,0]⟩,
  ⟨1, #[0,4,0,0]⟩,
  ⟨1, #[0,0,0,0]⟩
]

def P1 : Array Monomial := #[
  ⟨4, #[3,1,0,0]⟩,
  ⟨-6, #[2,1,0,0]⟩,
  ⟨-4, #[1,3,0,0]⟩,
  ⟨2, #[0,3,0,0]⟩,
  ⟨1, #[0,1,0,0]⟩
]

def P2 : Array Monomial := #[
  ⟨1, #[4,0,6,2]⟩,
  ⟨2, #[4,0,5,2]⟩,
  ⟨-1, #[4,0,4,2]⟩,
  ⟨2, #[4,0,3,5]⟩,
  ⟨-4, #[4,0,3,2]⟩,
  ⟨2, #[4,0,2,5]⟩,
  ⟨-1, #[4,0,2,2]⟩,
  ⟨2, #[4,0,1,5]⟩,
  ⟨2, #[4,0,1,2]⟩,
  ⟨1, #[4,0,0,8]⟩,
  ⟨2, #[4,0,0,5]⟩,
  ⟨1, #[4,0,0,2]⟩,
  ⟨2, #[3,0,7,1]⟩,
  ⟨-2, #[3,0,6,2]⟩,
  ⟨4, #[3,0,6,1]⟩,
  ⟨-2, #[3,0,5,2]⟩,
  ⟨4, #[3,0,4,4]⟩,
  ⟨6, #[3,0,4,2]⟩,
  ⟨-2, #[3,0,4,1]⟩,
  ⟨-4, #[3,0,3,5]⟩,
  ⟨2, #[3,0,3,4]⟩,
  ⟨8, #[3,0,3,2]⟩,
  ⟨2, #[3,0,3,1]⟩,
  ⟨-2, #[3,0,2,5]⟩,
  ⟨-2, #[3,0,2,2]⟩,
  ⟨2, #[3,0,1,7]⟩,
  ⟨-6, #[3,0,1,5]⟩,
  ⟨-2, #[3,0,1,4]⟩,
  ⟨-6, #[3,0,1,2]⟩,
  ⟨-4, #[3,0,1,1]⟩,
  ⟨-2, #[3,0,0,8]⟩,
  ⟨-2, #[3,0,0,7]⟩,
  ⟨-4, #[3,0,0,5]⟩,
  ⟨-4, #[3,0,0,4]⟩,
  ⟨-2, #[3,0,0,2]⟩,
  ⟨-2, #[3,0,0,1]⟩,
  ⟨-6, #[2,2,6,2]⟩,
  ⟨-12, #[2,2,5,2]⟩,
  ⟨6, #[2,2,4,2]⟩,
  ⟨-12, #[2,2,3,5]⟩,
  ⟨24, #[2,2,3,2]⟩,
  ⟨-12, #[2,2,2,5]⟩,
  ⟨6, #[2,2,2,2]⟩,
  ⟨-12, #[2,2,1,5]⟩,
  ⟨-12, #[2,2,1,2]⟩,
  ⟨-6, #[2,2,0,8]⟩,
  ⟨-12, #[2,2,0,5]⟩,
  ⟨-6, #[2,2,0,2]⟩,
  ⟨1, #[2,0,8,0]⟩,
  ⟨-4, #[2,0,7,1]⟩,
  ⟨2, #[2,0,7,0]⟩,
  ⟨1, #[2,0,6,2]⟩,
  ⟨-4, #[2,0,6,1]⟩,
  ⟨1, #[2,0,6,0]⟩,
  ⟨2, #[2,0,5,3]⟩,
  ⟨6, #[2,0,5,1]⟩,
  ⟨2, #[2,0,5,0]⟩,
  ⟨-8, #[2,0,4,4]⟩,
  ⟨-2, #[2,0,4,3]⟩,
  ⟨-6, #[2,0,4,2]⟩,
  ⟨4, #[2,0,4,1]⟩,
  ⟨4, #[2,0,4,0]⟩,
  ⟨2, #[2,0,3,5]⟩,
  ⟨-2, #[2,0,3,4]⟩,
  ⟨-4, #[2,0,3,3]⟩,
  ⟨-4, #[2,0,3,2]⟩,
  ⟨-2, #[2,0,3,1]⟩,
  ⟨2, #[2,0,3,0]⟩,
  ⟨1, #[2,0,2,6]⟩,
  ⟨-6, #[2,0,2,4]⟩,
  ⟨-4, #[2,0,2,3]⟩,
  ⟨6, #[2,0,2,2]⟩,
  ⟨6, #[2,0,2,1]⟩,
  ⟨1, #[2,0,2,0]⟩,
  ⟨-4, #[2,0,1,7]⟩,
  ⟨-4, #[2,0,1,6]⟩,
  ⟨6, #[2,0,1,5]⟩,
  ⟨4, #[2,0,1,4]⟩,
  ⟨-2, #[2,0,1,3]⟩,
  ⟨6, #[2,0,1,2]⟩,
  ⟨8, #[2,0,1,1]⟩,
  ⟨2, #[2,0,1,0]⟩,
  ⟨1, #[2,0,0,8]⟩,
  ⟨2, #[2,0,0,7]⟩,
  ⟨1, #[2,0,0,6]⟩,
  ⟨2, #[2,0,0,5]⟩,
  ⟨4, #[2,0,0,4]⟩,
  ⟨2, #[2,0,0,3]⟩,
  ⟨1, #[2,0,0,2]⟩,
  ⟨2, #[2,0,0,1]⟩,
  ⟨1, #[2,0,0,0]⟩,
  ⟨-6, #[1,2,7,1]⟩,
  ⟨6, #[1,2,6,2]⟩,
  ⟨-12, #[1,2,6,1]⟩,
  ⟨6, #[1,2,5,2]⟩,
  ⟨-12, #[1,2,4,4]⟩,
  ⟨-18, #[1,2,4,2]⟩,
  ⟨6, #[1,2,4,1]⟩,
  ⟨12, #[1,2,3,5]⟩,
  ⟨-6, #[1,2,3,4]⟩,
  ⟨-24, #[1,2,3,2]⟩,
  ⟨-6, #[1,2,3,1]⟩,
  ⟨6, #[1,2,2,5]⟩,
  ⟨6, #[1,2,2,2]⟩,
  ⟨-6, #[1,2,1,7]⟩,
  ⟨18, #[1,2,1,5]⟩,
  ⟨6, #[1,2,1,4]⟩,
  ⟨18, #[1,2,1,2]⟩,
  ⟨12, #[1,2,1,1]⟩,
  ⟨6, #[1,2,0,8]⟩,
  ⟨6, #[1,2,0,7]⟩,
  ⟨12, #[1,2,0,5]⟩,
  ⟨12, #[1,2,0,4]⟩,
  ⟨6, #[1,2,0,2]⟩,
  ⟨6, #[1,2,0,1]⟩,
  ⟨-2, #[1,0,8,0]⟩,
  ⟨2, #[1,0,7,1]⟩,
  ⟨-2, #[1,0,7,0]⟩,
  ⟨-4, #[1,0,5,3]⟩,
  ⟨-2, #[1,0,5,2]⟩,
  ⟨-6, #[1,0,5,1]⟩,
  ⟨-4, #[1,0,5,0]⟩,
  ⟨4, #[1,0,4,4]⟩,
  ⟨2, #[1,0,4,3]⟩,
  ⟨-2, #[1,0,4,1]⟩,
  ⟨-4, #[1,0,4,0]⟩,
  ⟨-2, #[1,0,2,6]⟩,
  ⟨-2, #[1,0,2,5]⟩,
  ⟨6, #[1,0,2,4]⟩,
  ⟨8, #[1,0,2,3]⟩,
  ⟨-2, #[1,0,2,2]⟩,
  ⟨-6, #[1,0,2,1]⟩,
  ⟨-2, #[1,0,2,0]⟩,
  ⟨2, #[1,0,1,7]⟩,
  ⟨4, #[1,0,1,6]⟩,
  ⟨-2, #[1,0,1,4]⟩,
  ⟨2, #[1,0,1,3]⟩,
  ⟨-4, #[1,0,1,1]⟩,
  ⟨-2, #[1,0,1,0]⟩,
  ⟨1, #[0,4,6,2]⟩,
  ⟨2, #[0,4,5,2]⟩,
  ⟨-1, #[0,4,4,2]⟩,
  ⟨2, #[0,4,3,5]⟩,
  ⟨-4, #[0,4,3,2]⟩,
  ⟨2, #[0,4,2,5]⟩,
  ⟨-1, #[0,4,2,2]⟩,
  ⟨2, #[0,4,1,5]⟩,
  ⟨2, #[0,4,1,2]⟩,
  ⟨1, #[0,4,0,8]⟩,
  ⟨2, #[0,4,0,5]⟩,
  ⟨1, #[0,4,0,2]⟩,
  ⟨-1, #[0,2,8,0]⟩,
  ⟨4, #[0,2,7,1]⟩,
  ⟨-2, #[0,2,7,0]⟩,
  ⟨-1, #[0,2,6,2]⟩,
  ⟨4, #[0,2,6,1]⟩,
  ⟨-1, #[0,2,6,0]⟩,
  ⟨-2, #[0,2,5,3]⟩,
  ⟨-6, #[0,2,5,1]⟩,
  ⟨-2, #[0,2,5,0]⟩,
  ⟨8, #[0,2,4,4]⟩,
  ⟨2, #[0,2,4,3]⟩,
  ⟨6, #[0,2,4,2]⟩,
  ⟨-4, #[0,2,4,1]⟩,
  ⟨-4, #[0,2,4,0]⟩,
  ⟨-2, #[0,2,3,5]⟩,
  ⟨2, #[0,2,3,4]⟩,
  ⟨4, #[0,2,3,3]⟩,
  ⟨4, #[0,2,3,2]⟩,
  ⟨2, #[0,2,3,1]⟩,
  ⟨-2, #[0,2,3,0]⟩,
  ⟨-1, #[0,2,2,6]⟩,
  ⟨6, #[0,2,2,4]⟩,
  ⟨4, #[0,2,2,3]⟩,
  ⟨-6, #[0,2,2,2]⟩,
  ⟨-6, #[0,2,2,1]⟩,
  ⟨-1, #[0,2,2,0]⟩,
  ⟨4, #[0,2,1,7]⟩,
  ⟨4, #[0,2,1,6]⟩,
  ⟨-6, #[0,2,1,5]⟩,
  ⟨-4, #[0,2,1,4]⟩,
  ⟨2, #[0,2,1,3]⟩,
  ⟨-6, #[0,2,1,2]⟩,
  ⟨-8, #[0,2,1,1]⟩,
  ⟨-2, #[0,2,1,0]⟩,
  ⟨-1, #[0,2,0,8]⟩,
  ⟨-2, #[0,2,0,7]⟩,
  ⟨-1, #[0,2,0,6]⟩,
  ⟨-2, #[0,2,0,5]⟩,
  ⟨-4, #[0,2,0,4]⟩,
  ⟨-2, #[0,2,0,3]⟩,
  ⟨-1, #[0,2,0,2]⟩,
  ⟨-2, #[0,2,0,1]⟩,
  ⟨-1, #[0,2,0,0]⟩,
  ⟨1, #[0,0,8,0]⟩,
  ⟨2, #[0,0,5,3]⟩,
  ⟨2, #[0,0,5,2]⟩,
  ⟨2, #[0,0,5,1]⟩,
  ⟨2, #[0,0,5,0]⟩,
  ⟨1, #[0,0,2,6]⟩,
  ⟨2, #[0,0,2,5]⟩,
  ⟨-1, #[0,0,2,4]⟩,
  ⟨-4, #[0,0,2,3]⟩,
  ⟨-1, #[0,0,2,2]⟩,
  ⟨2, #[0,0,2,1]⟩,
  ⟨1, #[0,0,2,0]⟩
]

def P3 : Array Monomial := #[
  ⟨4, #[3,1,6,2]⟩,
  ⟨8, #[3,1,5,2]⟩,
  ⟨-4, #[3,1,4,2]⟩,
  ⟨8, #[3,1,3,5]⟩,
  ⟨-16, #[3,1,3,2]⟩,
  ⟨8, #[3,1,2,5]⟩,
  ⟨-4, #[3,1,2,2]⟩,
  ⟨8, #[3,1,1,5]⟩,
  ⟨8, #[3,1,1,2]⟩,
  ⟨4, #[3,1,0,8]⟩,
  ⟨8, #[3,1,0,5]⟩,
  ⟨4, #[3,1,0,2]⟩,
  ⟨6, #[2,1,7,1]⟩,
  ⟨-6, #[2,1,6,2]⟩,
  ⟨12, #[2,1,6,1]⟩,
  ⟨-6, #[2,1,5,2]⟩,
  ⟨12, #[2,1,4,4]⟩,
  ⟨18, #[2,1,4,2]⟩,
  ⟨-6, #[2,1,4,1]⟩,
  ⟨-12, #[2,1,3,5]⟩,
  ⟨6, #[2,1,3,4]⟩,
  ⟨24, #[2,1,3,2]⟩,
  ⟨6, #[2,1,3,1]⟩,
  ⟨-6, #[2,1,2,5]⟩,
  ⟨-6, #[2,1,2,2]⟩,
  ⟨6, #[2,1,1,7]⟩,
  ⟨-18, #[2,1,1,5]⟩,
  ⟨-6, #[2,1,1,4]⟩,
  ⟨-18, #[2,1,1,2]⟩,
  ⟨-12, #[2,1,1,1]⟩,
  ⟨-6, #[2,1,0,8]⟩,
  ⟨-6, #[2,1,0,7]⟩,
  ⟨-12, #[2,1,0,5]⟩,
  ⟨-12, #[2,1,0,4]⟩,
  ⟨-6, #[2,1,0,2]⟩,
  ⟨-6, #[2,1,0,1]⟩,
  ⟨-4, #[1,3,6,2]⟩,
  ⟨-8, #[1,3,5,2]⟩,
  ⟨4, #[1,3,4,2]⟩,
  ⟨-8, #[1,3,3,5]⟩,
  ⟨16, #[1,3,3,2]⟩,
  ⟨-8, #[1,3,2,5]⟩,
  ⟨4, #[1,3,2,2]⟩,
  ⟨-8, #[1,3,1,5]⟩,
  ⟨-8, #[1,3,1,2]⟩,
  ⟨-4, #[1,3,0,8]⟩,
  ⟨-8, #[1,3,0,5]⟩,
  ⟨-4, #[1,3,0,2]⟩,
  ⟨2, #[1,1,8,0]⟩,
  ⟨-8, #[1,1,7,1]⟩,
  ⟨4, #[1,1,7,0]⟩,
  ⟨2, #[1,1,6,2]⟩,
  ⟨-8, #[1,1,6,1]⟩,
  ⟨2, #[1,1,6,0]⟩,
  ⟨4, #[1,1,5,3]⟩,
  ⟨12, #[1,1,5,1]⟩,
  ⟨4, #[1,1,5,0]⟩,
  ⟨-16, #[1,1,4,4]⟩,
  ⟨-4, #[1,1,4,3]⟩,
  ⟨-12, #[1,1,4,2]⟩,
  ⟨8, #[1,1,4,1]⟩,
  ⟨8, #[1,1,4,0]⟩,
  ⟨4, #[1,1,3,5]⟩,
  ⟨-4, #[1,1,3,4]⟩,
  ⟨-8, #[1,1,3,3]⟩,
  ⟨-8, #[1,1,3,2]⟩,
  ⟨-4, #[1,1,3,1]⟩,
  ⟨4, #[1,1,3,0]⟩,
  ⟨2, #[1,1,2,6]⟩,
  ⟨-12, #[1,1,2,4]⟩,
  ⟨-8, #[1,1,2,3]⟩,
  ⟨12, #[1,1,2,2]⟩,
  ⟨12, #[1,1,2,1]⟩,
  ⟨2, #[1,1,2,0]⟩,
  ⟨-8, #[1,1,1,7]⟩,
  ⟨-8, #[1,1,1,6]⟩,
  ⟨12, #[1,1,1,5]⟩,
  ⟨8, #[1,1,1,4]⟩,
  ⟨-4, #[1,1,1,3]⟩,
  ⟨12, #[1,1,1,2]⟩,
  ⟨16, #[1,1,1,1]⟩,
  ⟨4, #[1,1,1,0]⟩,
  ⟨2, #[1,1,0,8]⟩,
  ⟨4, #[1,1,0,7]⟩,
  ⟨2, #[1,1,0,6]⟩,
  ⟨4, #[1,1,0,5]⟩,
  ⟨8, #[1,1,0,4]⟩,
  ⟨4, #[1,1,0,3]⟩,
  ⟨2, #[1,1,0,2]⟩,
  ⟨4, #[1,1,0,1]⟩,
  ⟨2, #[1,1,0,0]⟩,
  ⟨-2, #[0,3,7,1]⟩,
  ⟨2, #[0,3,6,2]⟩,
  ⟨-4, #[0,3,6,1]⟩,
  ⟨2, #[0,3,5,2]⟩,
  ⟨-4, #[0,3,4,4]⟩,
  ⟨-6, #[0,3,4,2]⟩,
  ⟨2, #[0,3,4,1]⟩,
  ⟨4, #[0,3,3,5]⟩,
  ⟨-2, #[0,3,3,4]⟩,
  ⟨-8, #[0,3,3,2]⟩,
  ⟨-2, #[0,3,3,1]⟩,
  ⟨2, #[0,3,2,5]⟩,
  ⟨2, #[0,3,2,2]⟩,
  ⟨-2, #[0,3,1,7]⟩,
  ⟨6, #[0,3,1,5]⟩,
  ⟨2, #[0,3,1,4]⟩,
  ⟨6, #[0,3,1,2]⟩,
  ⟨4, #[0,3,1,1]⟩,
  ⟨2, #[0,3,0,8]⟩,
  ⟨2, #[0,3,0,7]⟩,
  ⟨4, #[0,3,0,5]⟩,
  ⟨4, #[0,3,0,4]⟩,
  ⟨2, #[0,3,0,2]⟩,
  ⟨2, #[0,3,0,1]⟩,
  ⟨-2, #[0,1,8,0]⟩,
  ⟨2, #[0,1,7,1]⟩,
  ⟨-2, #[0,1,7,0]⟩,
  ⟨-4, #[0,1,5,3]⟩,
  ⟨-2, #[0,1,5,2]⟩,
  ⟨-6, #[0,1,5,1]⟩,
  ⟨-4, #[0,1,5,0]⟩,
  ⟨4, #[0,1,4,4]⟩,
  ⟨2, #[0,1,4,3]⟩,
  ⟨-2, #[0,1,4,1]⟩,
  ⟨-4, #[0,1,4,0]⟩,
  ⟨-2, #[0,1,2,6]⟩,
  ⟨-2, #[0,1,2,5]⟩,
  ⟨6, #[0,1,2,4]⟩,
  ⟨8, #[0,1,2,3]⟩,
  ⟨-2, #[0,1,2,2]⟩,
  ⟨-6, #[0,1,2,1]⟩,
  ⟨-2, #[0,1,2,0]⟩,
  ⟨2, #[0,1,1,7]⟩,
  ⟨4, #[0,1,1,6]⟩,
  ⟨-2, #[0,1,1,4]⟩,
  ⟨2, #[0,1,1,3]⟩,
  ⟨-4, #[0,1,1,1]⟩,
  ⟨-2, #[0,1,1,0]⟩
]

/-- A sparse symbolic polynomial ring over ℤ. Exponent tuples have the order x,y,A,B. -/
private abbrev E := Nat × Nat × Nat × Nat
private def eCompare (a b : E) : Ordering :=
  match compare a.1 b.1 with
  | .eq => match compare a.2.1 b.2.1 with
    | .eq => match compare a.2.2.1 b.2.2.1 with
      | .eq => compare a.2.2.2 b.2.2.2
      | u => u
    | u => u
  | u => u
private abbrev P := Std.TreeMap E Int eCompare
private def term (e : E) (v : Int) : P := (∅ : P).insert e v
private def esum (a b : E) : E := (a.1+b.1,a.2.1+b.2.1,a.2.2.1+b.2.2.1,a.2.2.2+b.2.2.2)
private def addTerm (p : P) (e : E) (v : Int) : P :=
  let c := p.getD e 0 + v
  if c=0 then p.erase e else p.insert e c
private def pAdd (p q : P) := q.foldl addTerm p
private def pNeg (p : P) : P := p.foldl (fun m e v => m.insert e (-v)) ∅
private def pMul (p q : P) : P := p.foldl (fun m e v =>
  q.foldl (fun out j c => addTerm out (esum e j) (v*c)) m) ∅
private abbrev Z := P × P
private def plus (p q : Z) : Z := (pAdd p.1 q.1,pAdd p.2 q.2)
private def minus (p q : Z) : Z := (pAdd p.1 (pNeg q.1),pAdd p.2 (pNeg q.2))
private def times (p q : Z) : Z :=
  (pAdd (pMul p.1 q.1) (pNeg (pMul p.2 q.2)),pAdd (pMul p.1 q.2) (pMul p.2 q.1))
private def one : Z := (term (0,0,0,0) 1,∅)
private def T : Z := (term (1,0,0,0) 1,term (0,1,0,0) 1)
private def A1 : Z := (term (0,0,1,0) 1,∅)
private def A2 : Z := (term (0,0,0,1) 1,∅)
private def sq (p : Z) := times p p
private def twiceP (p : Z) := plus p p
private def phi : Z :=
  let a := plus A1 (times A2 T)
  let M := plus one (plus A1 A2)
  let b := minus a M
  let c := minus a (times M T)
  let a1 := times b c
  let b1 := times (sq A1) (times a c)
  let c1 := times (sq A2) (times a b)
  minus (plus (sq a1) (plus (sq b1) (sq c1)))
    (twiceP (plus (times a1 b1) (plus (times b1 c1) (times c1 a1))))
private def quartic : Z := plus (minus (sq (sq T)) (twiceP (times T (sq T)))) (plus T one)
private def euler : Z :=
  let X := minus T one
  let X2 := sq X
  let X3 := times X X2
  let T2 := sq T
  -- sigma13=+1, sigma23=-1; terms with -sigma23 acquire a plus.
  plus (minus (plus (times (plus one A1) (times X3 T2))
      (plus (times X2 T2) (plus (times A2 X3) (times A2 (times T T2))))) X2) (times A1 T2)
private def monomials (p : P) : Array Monomial := (p.toList.reverse.map fun (e,v) =>
    ⟨v,#[e.1,e.2.1,e.2.2.1,e.2.2.2]⟩).toArray

/-- The expanded coefficient tables used by the bounds are derived again here
from the defining formulas by exact symbolic addition and multiplication. -/
theorem coefficient_expansion :
    P0 = monomials quartic.1 ∧ P1 = monomials quartic.2 ∧
    P2 = monomials phi.1 ∧ P3 = monomials phi.2 := by decide +kernel

#print axioms coefficient_expansion

private def Q0 : Array Monomial := #[
  ⟨1, #[5,0,1,0]⟩,
  ⟨1, #[5,0,0,0]⟩,
  ⟨-3, #[4,0,1,0]⟩,
  ⟨-2, #[4,0,0,0]⟩,
  ⟨-10, #[3,2,1,0]⟩,
  ⟨-10, #[3,2,0,0]⟩,
  ⟨3, #[3,0,1,0]⟩,
  ⟨2, #[3,0,0,1]⟩,
  ⟨1, #[3,0,0,0]⟩,
  ⟨18, #[2,2,1,0]⟩,
  ⟨12, #[2,2,0,0]⟩,
  ⟨-3, #[2,0,0,1]⟩,
  ⟨-1, #[2,0,0,0]⟩,
  ⟨5, #[1,4,1,0]⟩,
  ⟨5, #[1,4,0,0]⟩,
  ⟨-9, #[1,2,1,0]⟩,
  ⟨-6, #[1,2,0,1]⟩,
  ⟨-3, #[1,2,0,0]⟩,
  ⟨3, #[1,0,0,1]⟩,
  ⟨2, #[1,0,0,0]⟩,
  ⟨-3, #[0,4,1,0]⟩,
  ⟨-2, #[0,4,0,0]⟩,
  ⟨3, #[0,2,0,1]⟩,
  ⟨1, #[0,2,0,0]⟩,
  ⟨-1, #[0,0,0,1]⟩,
  ⟨-1, #[0,0,0,0]⟩
]

private def Q1 : Array Monomial := #[
  ⟨5, #[4,1,1,0]⟩,
  ⟨5, #[4,1,0,0]⟩,
  ⟨-12, #[3,1,1,0]⟩,
  ⟨-8, #[3,1,0,0]⟩,
  ⟨-10, #[2,3,1,0]⟩,
  ⟨-10, #[2,3,0,0]⟩,
  ⟨9, #[2,1,1,0]⟩,
  ⟨6, #[2,1,0,1]⟩,
  ⟨3, #[2,1,0,0]⟩,
  ⟨12, #[1,3,1,0]⟩,
  ⟨8, #[1,3,0,0]⟩,
  ⟨-6, #[1,1,0,1]⟩,
  ⟨-2, #[1,1,0,0]⟩,
  ⟨1, #[0,5,1,0]⟩,
  ⟨1, #[0,5,0,0]⟩,
  ⟨-3, #[0,3,1,0]⟩,
  ⟨-2, #[0,3,0,1]⟩,
  ⟨-1, #[0,3,0,0]⟩,
  ⟨3, #[0,1,0,1]⟩,
  ⟨2, #[0,1,0,0]⟩
]

theorem euler_expansion : Q0 = monomials euler.1 ∧ Q1 = monomials euler.2 := by decide +kernel
#print axioms euler_expansion

/-- Four-by-four signed determinant, expanded along row 0. -/
private def det4 (m : Array (Array Int)) : Int :=
  let minor := fun (i j k : Nat) => m[1]![i]!*(m[2]![j]!*m[3]![k]! - m[2]![k]!*m[3]![j]!)
    - m[1]![j]!*(m[2]![i]!*m[3]![k]! - m[2]![k]!*m[3]![i]!)
    + m[1]![k]!*(m[2]![i]!*m[3]![j]! - m[2]![j]!*m[3]![i]!)
  m[0]![0]! * minor 1 2 3 - m[0]![1]! * minor 0 2 3 + m[0]![2]! * minor 0 1 3 - m[0]![3]! * minor 0 1 2

namespace QuarticWitness
def rows := #[P0,P1,P2,P3]
def ix : List Nat := [0,1,2,3]
def D : Int := 10^15
def B : Int := 10^6
def N : Array Int := #[-473561483353507,444771808762066,1211156057904405,1470853017662610]
def V : Array (Array Int) := #[#[112072,245314,0,0],#[-245314,112072,0,0],
  #[-106576,-269116,1937,3785],#[157988,-312575,-1870,4793]]

def deg (g : Monomial) := g.e.foldl (·+·) 0

/-- D^12 times the monomial evaluated at the rational point N/D. -/
def val12 (g : Monomial) : Int :=
  g.c * D^(12-deg g) * (ix.map (fun j => N[j]!^g.e[j]!)).foldl (·*·) 1

/-- D^11 times the j-th partial, by the integer power rule. -/
def partial11 (g : Monomial) (j : Nat) : Int :=
  g.c * (g.e[j]! : Int) * D^(12-deg g) *
    (ix.map (fun k => N[k]!^(g.e[k]! - (if k=j then 1 else 0)))).foldl (·*·) 1

/-- Bound for the sum of absolute ordered second partials when all |x_j|≤2. -/
def hessianTerm (g : Monomial) : Nat :=
  let d := deg g
  g.c.natAbs * d * (d-1) * 2^(d-2)

def FF := rows.map fun row => (row.map val12).toList.sum
def JJ := rows.map fun row => ix.toArray.map fun j => (row.map fun g => partial11 g j).toList.sum
def Hess := rows.map fun row => (row.map hessianTerm).toList.sum

def defectRow (i : Nat) : Nat :=
  (ix.map fun j => ((if i=j then B*D^11 else 0) -
    (ix.map fun h => V[i]![h]! * JJ[h]![j]!).sum).natAbs).sum

def residualRow (i : Nat) : Nat :=
  ((ix.map fun h => V[i]![h]! * FF[h]!).sum).natAbs

/-- All coordinate Jacobian residuals at the center satisfy
‖I−(V/B)JF‖∞ < 377/10⁶. -/
theorem jacobian_defect : ix.all (fun i => 10^6 * defectRow i < 377 * (B*D^11).natAbs) := by decide +kernel

/-- The Picard displacement of the center has sup norm < 10⁻¹⁵. -/
theorem residual : ix.all (fun i => 10^15 * residualRow i < (B*D^12).natAbs) := by decide +kernel

/-- Radius 10⁻¹⁰ keeps the box coordinates in [−2,2]; the two masses
are respectively >1 and strictly smaller than the third throughout the box. -/
theorem box_coordinates :
    ix.all (fun i => (N[i]!.natAbs + 10^5) < 2*D.natAbs) ∧
    D+10^5 < N[2]! ∧ N[2]!+2*10^5 < N[3]! := by decide +kernel

/-- Hessian row sum upper bound is exact for this coefficient-norm test.
The matrix bounds are written with integer denominators cleared. -/
theorem remaining_data : Hess.toList.max? = some 14549050 ∧
    ix.all (fun i => 2 * (ix.map fun j => V[i]![j]!.natAbs).sum < B.natAbs) ∧
    det4 V ≠ 0 ∧
    (2*377*(10^10)/10^6 + 14549050 < (10^10 : Nat)) ∧ 4*10^10 < (10^15 : Nat) := by decide +kernel

#print axioms jacobian_defect
#print axioms residual
#print axioms box_coordinates
#print axioms remaining_data
end QuarticWitness

namespace EulerWitness
def rows := #[Q0,Q1,P2,P3]
def ix : List Nat := [0,1,2,3]
def D : Int := 10^15
def B : Int := 10^6
def N : Array Int := #[-227312842305231,896449611254474,1104244723429672,1128840671501523]
def V : Array (Array Int) := #[#[-63590,13427,314,274],#[-13263,-61162,-488,728],#[20323,-11584,4480,123],#[21501,9757,2551,3735]]

def deg (g : Monomial) := g.e.foldl (·+·) 0

/-- D^12 times the monomial evaluated at the rational point N/D. -/
def val12 (g : Monomial) : Int :=
  g.c * D^(12-deg g) * (ix.map (fun j => N[j]!^g.e[j]!)).foldl (·*·) 1

/-- D^11 times the j-th partial, by the integer power rule. -/
def partial11 (g : Monomial) (j : Nat) : Int :=
  g.c * (g.e[j]! : Int) * D^(12-deg g) *
    (ix.map (fun k => N[k]!^(g.e[k]! - (if k=j then 1 else 0)))).foldl (·*·) 1

/-- Bound for the sum of absolute ordered second partials when all |x_j|≤2. -/
def hessianTerm (g : Monomial) : Nat :=
  let d := deg g
  g.c.natAbs * d * (d-1) * 2^(d-2)

def FF := rows.map fun row => (row.map val12).toList.sum
def JJ := rows.map fun row => ix.toArray.map fun j => (row.map fun g => partial11 g j).toList.sum
def Hess := rows.map fun row => (row.map hessianTerm).toList.sum

def defectRow (i : Nat) : Nat :=
  (ix.map fun j => ((if i=j then B*D^11 else 0) -
    (ix.map fun h => V[i]![h]! * JJ[h]![j]!).sum).natAbs).sum

def residualRow (i : Nat) : Nat :=
  ((ix.map fun h => V[i]![h]! * FF[h]!).sum).natAbs

/-- All coordinate Jacobian residuals at the center satisfy
‖I−(V/B)JF‖∞ < 251/10⁶. -/
theorem jacobian_defect : ix.all (fun i => 10^6 * defectRow i < 251 * (B*D^11).natAbs) := by decide +kernel

/-- The Picard displacement of the center has sup norm < 10⁻¹⁵. -/
theorem residual : ix.all (fun i => 10^15 * residualRow i < (B*D^12).natAbs) := by decide +kernel

/-- Radius 10⁻¹⁰ keeps the box coordinates in [−2,2]; the two masses
are respectively >1 and strictly smaller than the third throughout the box. -/
theorem box_coordinates :
    ix.all (fun i => (N[i]!.natAbs + 10^5) < 2*D.natAbs) ∧
    D+10^5 < N[2]! ∧ N[2]!+2*10^5 < N[3]! := by decide +kernel

/-- Hessian row sum upper bound is exact for this coefficient-norm test.
The matrix bounds are written with integer denominators cleared. -/
theorem remaining_data : Hess.toList.max? = some 14549050 ∧
    ix.all (fun i => 2 * (ix.map fun j => V[i]![j]!.natAbs).sum < B.natAbs) ∧
    det4 V ≠ 0 ∧
    (2*251*(10^10)/10^6 + 14549050 < (10^10 : Nat)) ∧ 4*10^10 < (10^15 : Nat) := by decide +kernel

#print axioms jacobian_defect
#print axioms residual
#print axioms box_coordinates
#print axioms remaining_data
end EulerWitness
end DistinctTripleCertificate
