import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Data.Fintype.BigOperators
import Mathlib.GroupTheory.GroupAction.Quotient
import Mathlib.Topology.LocallyConstant.Basic
import Mathlib.Topology.Instances.Real.Lemmas
import Mathlib.Topology.Order.IntermediateValue
import Mathlib.Tactic

/-!
# Weighted counts and their transition on a connected mass path

The five primary multiplicities and five test-equilibrium counts are inputs
from celestial mechanics and the finite interval certificates. The statements
here formalize their consequences for a given continuation bijection, a
reflection action, and a regularity criterion on a parameter path.
-/

open scoped BigOperators Topology
open Filter

namespace SmallMass.Count

/-- Order: line, centered square, two triangles, trapezium, regular pentagon. -/
def primaryMultiplicity : Fin 5 → ℕ := ![60, 30, 120, 120, 24]

/-- Number of physical massless equilibria in each of the five shapes. -/
def restrictedCount : Fin 5 → ℕ := ![8, 12, 10, 14, 16]

/-- Count the actual oriented fiber from a continuation equivalence, labelled
primary counts by shape, and the restricted count over each labelled primary. -/
theorem oriented_count
    {C : Type*} [Fintype C] (P : Fin 5 → Type*) [∀ i, Fintype (P i)]
    (T : (i : Fin 5) → P i → Type*) [∀ i p, Fintype (T i p)]
    (continuation : C ≃ Σ i, Σ p : P i, T i p)
    (primary : ∀ i, Fintype.card (P i) = primaryMultiplicity i)
    (restricted : ∀ i p, Fintype.card (T i p) = restrictedCount i) :
    Fintype.card C = 4104 := by
  classical
  rw [Fintype.card_congr continuation, Fintype.card_sigma]
  simp_rw [Fintype.card_sigma, restricted]
  simp only [Finset.sum_const, Finset.card_univ, primary, smul_eq_mul]
  simp [Fin.sum_univ_succ, primaryMultiplicity, restrictedCount]

/-- Burnside's lemma applied to the order-two group of reflections, with 360
collinear fixed shapes. The result counts the actual orbit quotient. -/
theorem reflection_orbit_count (C : Type*) [Fintype C] [AddAction (Fin 2) C]
    (all : Fintype.card C = 4104)
    (fixed : Nat.card (AddAction.fixedBy C (1 : Fin 2)) = 360) :
    Nat.card (Quotient (AddAction.orbitRel (Fin 2) C)) = 2232 := by
  classical
  letI : Fintype (Quotient (AddAction.orbitRel (Fin 2) C)) := Fintype.ofFinite _
  let h := AddAction.sum_card_fixedBy_eq_card_orbits_mul_card_addGroup (Fin 2) C
  have h0 : Fintype.card (AddAction.fixedBy C (0 : Fin 2)) = Fintype.card C := by
    simp [AddAction.fixedBy_zero_eq_univ]
  simp only [Fin.sum_univ_two, Fintype.card_fin] at h
  rw [← Nat.card_eq_fintype_card (α := AddAction.fixedBy C (1 : Fin 2)), fixed,
    h0, all] at h
  rw [Nat.card_eq_fintype_card]
  omega

/-- On a connected path different endpoint counts force at least one parameter
where the proposed regularity property fails, provided regularity makes the
count locally constant. The property may include nonsingularity of all solutions. -/
theorem exists_nonregular_of_different_counts {P : Type*} [TopologicalSpace P]
    [PreconnectedSpace P] (n : P → ℕ) (Regular : P → Prop)
    (localCount : ∀ p, Regular p → ∀ᶠ q in 𝓝 p, n q = n p)
    {a b : P} (different : n a ≠ n b) : ∃ p, ¬ Regular p := by
  by_contra! allRegular
  have hlocal : IsLocallyConstant n :=
    (IsLocallyConstant.iff_eventually_eq n).2 (fun p => localCount p (allRegular p))
  exact different (hlocal.apply_eq_of_preconnectedSpace a b)

/-- Exact numbers on a connected positive mass segment force an interior
irregular ratio if all regular fibers have locally constant cardinality.
The endpoints have the small-mass and all-equal counts respectively. -/
theorem interior_transition {a b : ℝ} (hab : a ≤ b)
    (n : Set.Icc a b → ℕ) (Regular : Set.Icc a b → Prop)
    (localCount : ∀ p, Regular p → ∀ᶠ q in 𝓝 p, n q = n p)
    (leftCount : n ⟨a, le_rfl, hab⟩ = 4104)
    (rightCount : n ⟨b, hab, le_rfl⟩ = 3624)
    (leftReg : Regular ⟨a, le_rfl, hab⟩) (rightReg : Regular ⟨b, hab, le_rfl⟩) :
    ∃ t : Set.Icc a b, a < t.val ∧ t.val < b ∧ ¬ Regular t := by
  letI : PreconnectedSpace (Set.Icc a b) := Subtype.preconnectedSpace isPreconnected_Icc
  obtain ⟨t, ht⟩ := exists_nonregular_of_different_counts n Regular localCount
    (a := ⟨a, le_rfl, hab⟩) (b := ⟨b, hab, le_rfl⟩) (by omega)
  refine ⟨t, lt_of_le_of_ne t.property.1 ?_, lt_of_le_of_ne t.property.2 ?_, ht⟩
  · intro h
    apply ht
    have eq : t = ⟨a, le_rfl, hab⟩ := Subtype.ext h.symm
    simpa only [eq] using leftReg
  · intro h
    apply ht
    have eq : t = ⟨b, hab, le_rfl⟩ := Subtype.ext h
    simpa only [eq] using rightReg

/-- Apply an orbit decomposition over the five known primary shapes, with an
input equivalence for the geometric quotient and each shape's orbit count. -/
theorem count_geometric_quotient {C : Type*} [Fintype C]
    (O : Fin 5 → Type*) [∀ i, Fintype (O i)]
    (orbits : C ≃ Σ i, O i) (sizes : Fin 5 → ℕ)
    (verified : ∀ i, Fintype.card (O i) = sizes i) :
    Fintype.card C = ∑ i, sizes i := by
  rw [Fintype.card_congr orbits, Fintype.card_sigma]
  simp_rw [verified]

theorem geometric_orbit_totals :
    (∑ i : Fin 5, (![4,3,10,14,4] : Fin 5 → ℕ) i) = 35 ∧
    (∑ i : Fin 5, (![4,3,7,9,4] : Fin 5 → ℕ) i) = 27 := by
  simp [Fin.sum_univ_succ]

#print axioms interior_transition
#print axioms count_geometric_quotient
#print axioms geometric_orbit_totals

#print axioms oriented_count
#print axioms reflection_orbit_count
#print axioms exists_nonregular_of_different_counts

end SmallMass.Count
