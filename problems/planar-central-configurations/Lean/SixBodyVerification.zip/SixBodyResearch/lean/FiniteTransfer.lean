import Mathlib.Analysis.Analytic.IsolatedZeros
import Mathlib.Topology.Instances.Real.Lemmas

/-!
# Finiteness in one-dimensional real analytic charts

This file proves the analytic and compactness steps of the small-mass transfer.
The Newtonian implicit charts and the compactness theorem providing their
limiting points are inputs in the application, not axioms of this file.
-/
open Set Filter Topology

namespace SmallMass

/-- Zeros in a compact subset of a connected one-dimensional analytic domain
are finite if the function is nonzero somewhere in the domain. -/
theorem finite_compact_zeros {U K : Set ℝ} {f : ℝ → ℝ}
    (hU : IsPreconnected U) (hK : IsCompact K) (hKU : K ⊆ U)
    (hf : AnalyticOnNhd ℝ f U) {b : ℝ} (hb : b ∈ U) (hfb : f b ≠ 0) :
    {x ∈ K | f x = 0}.Finite := by
  by_contra h
  obtain ⟨a, ha, hacc⟩ := Set.Infinite.exists_accPt_of_subset_isCompact
    h hK (show {x ∈ K | f x = 0} ⊆ K from fun _ hx => hx.1)
  have hz : ∃ᶠ x in 𝓝[≠] a, f x = 0 :=
    (accPt_iff_frequently_nhdsNE.mp hacc).mono fun _ hx => hx.2
  exact hfb (hf.eqOn_zero_of_preconnected_of_frequently_eq_zero hU (hKU ha) hz hb)

/-- One test value at the limiting parameter keeps the reduced residual
nontrivial throughout a neighbourhood of parameters. -/
theorem eventually_finite_compact_zeros {P : Type*} [TopologicalSpace P]
    {p₀ : P} {g : P → ℝ → ℝ} {U K : Set ℝ} {b : ℝ}
    (hU : IsPreconnected U) (hK : IsCompact K) (hKU : K ⊆ U) (hb : b ∈ U)
    (ha : ∀ᶠ p in 𝓝 p₀, AnalyticOnNhd ℝ (g p) U)
    (hc : ContinuousAt (fun p => g p b) p₀) (hne : g p₀ b ≠ 0) :
    ∀ᶠ p in 𝓝 p₀, {x ∈ K | g p x = 0}.Finite := by
  filter_upwards [ha, hc.eventually_ne hne] with p hp hpb
  exact finite_compact_zeros hU hK hKU hp hb hpb

/-- Eventual containment of all solutions in an open set from sequential
compactness over the boundary. Parameters in the application are positive. -/
theorem eventually_covered {P X : Type*} [TopologicalSpace P] [FirstCountableTopology P]
    [TopologicalSpace X] {p₀ : P} {D : Set P} {S : P → Set X} {O : Set X}
    (hO : IsOpen O)
    (hcompact : ∀ (p : ℕ → P) (x : ℕ → X),
      Tendsto p atTop (𝓝 p₀) → (∀ n, p n ∈ D) → (∀ n, x n ∈ S (p n)) →
      ∃ (v : ℕ → ℕ) (z : X), StrictMono v ∧ z ∈ O ∧ Tendsto (x ∘ v) atTop (𝓝 z)) :
    ∀ᶠ p in 𝓝 p₀, p ∈ D → S p ⊆ O := by
  classical
  by_contra h
  rw [Filter.not_eventually] at h
  obtain ⟨p, hlim, hp⟩ := exists_seq_forall_of_frequently h
  have hbad : ∀ n, p n ∈ D ∧ ∃ x ∈ S (p n), x ∉ O := by
    intro n
    specialize hp n
    simpa only [Classical.not_imp, Set.not_subset] using hp
  choose x hmem hout using fun n => (hbad n).2
  obtain ⟨v, z, _, hz, hzlim⟩ := hcompact p x hlim (fun n => (hbad n).1) hmem
  obtain ⟨n, hn⟩ := (hzlim.eventually (hO.mem_nhds hz)).exists
  exact hout (v n) hn

/-- A chart specifies exactly the information used after implicit elimination.
It provides a parametrization of possible solutions by zeros, not finiteness. -/
structure ScalarChart (P X : Type*) [TopologicalSpace P] (p₀ : P) where
  domain : Set ℝ
  compactPart : Set ℝ
  witness : ℝ
  residual : P → ℝ → ℝ
  lift : P → ℝ → X
  connected : IsPreconnected domain
  compact : IsCompact compactPart
  inside : compactPart ⊆ domain
  test_mem : witness ∈ domain
  analytic : ∀ᶠ p in 𝓝 p₀, AnalyticOnNhd ℝ (residual p) domain
  continuousTest : ContinuousAt (fun p => residual p witness) p₀
  test_ne : residual p₀ witness ≠ 0

def ScalarChart.candidates {P X : Type*} [TopologicalSpace P] {p₀ : P}
    (c : ScalarChart P X p₀) (p : P) : Set X :=
  c.lift p '' {x ∈ c.compactPart | c.residual p x = 0}

/-- All fibers represented by finitely many implicit scalar charts are
finite near the limiting parameter, including along exceptional parameter loci. -/
theorem finite_fibers_of_scalar_charts {P X ι : Type*} [TopologicalSpace P]
    [Finite ι] {p₀ : P} (C : ι → ScalarChart P X p₀) {S : P → Set X} {D : Set P}
    (hcover : ∀ᶠ p in 𝓝 p₀, p ∈ D → S p ⊆ ⋃ i, (C i).candidates p) :
    ∀ᶠ p in 𝓝 p₀, p ∈ D → (S p).Finite := by
  have h : ∀ i, ∀ᶠ p in 𝓝 p₀, ((C i).candidates p).Finite := by
    intro i
    let c := C i
    filter_upwards [eventually_finite_compact_zeros c.connected c.compact
      c.inside c.test_mem c.analytic c.continuousTest c.test_ne] with p hp
    exact hp.image _
  filter_upwards [hcover, (Filter.eventually_all.mpr h)] with p hp hfin
  exact fun hd => (Set.finite_iUnion hfin).subset (hp hd)

#print axioms finite_compact_zeros
#print axioms eventually_covered
#print axioms finite_fibers_of_scalar_charts
end SmallMass
