import Mathlib.AlgebraicGeometry.ZariskisMainTheorem
import Mathlib.Topology.NoetherianSpace

/-!
# Quasi-finiteness at a compact physical boundary

The morphism and its fibers below are genuine mathlib schemes. The application
uses the physical Euclidean topology for compactness and the Zariski topology
for quasi-finiteness. The continuous map between the two spaces, the compact
physical locus, and isolation in its boundary fiber are inputs.
-/

open AlgebraicGeometry CategoryTheory Filter Set Topology TopologicalSpace

namespace SmallMass

/-- A finite type morphism over a Noetherian source has only finitely many
quasi-finite points in any specified fiber. Other components are allowed. -/
theorem finite_quasiFinite_points_in_fiber {X Y : Scheme}
    (f : X ⟶ Y) [LocallyOfFiniteType f] [NoetherianSpace X] (s : Y) :
    {x : X | f x = s ∧ f.QuasiFiniteAt x}.Finite := by
  let T : Set (f ⁻¹' ({s} : Set Y)) := {z | f.QuasiFiniteAt z.val}
  have hopen : ∀ z ∈ T, IsOpen ({z} : Set (f ⁻¹' ({s} : Set Y))) := by
    rintro ⟨z, hz⟩ hq
    change f z = s at hz
    subst s
    have h := Scheme.Hom.quasiFiniteAt_iff_isOpen_singleton_asFiber.mp hq
    rw [← (f.fiberHomeo (f z)).isOpen_image] at h
    simpa only [Set.image_singleton, Scheme.Hom.asFiber,
      Homeomorph.apply_symm_apply] using h
  have hdisc : _root_.IsDiscrete T := by
    apply isDiscrete_iff_forall_exists_isOpen.mpr
    intro z hz
    exact ⟨{z}, hopen z hz, Set.inter_eq_left.mpr (Set.singleton_subset_iff.mpr hz)⟩
  have hfin := ((NoetherianSpace.isCompact T).finite hdisc).image Subtype.val
  apply hfin.subset
  rintro x ⟨hx, hq⟩
  exact ⟨⟨x, hx⟩, hq, rfl⟩

/-- Euclidean compactness of the total physical solution set near the
parameter and isolation in the boundary fiber force nearby physical fibers
to be finite. The base map into scheme points need not be continuous. -/
theorem eventually_finite_physical_fibers {X Y : Scheme}
    (f : X ⟶ Y) [LocallyOfFiniteType f] [NoetherianSpace X]
    {E P : Type*} [TopologicalSpace E] [TopologicalSpace P] [T2Space P]
    (lift : E → X) (param : E → P) (base : P → Y)
    (hlift : Continuous lift) (hparam : Continuous param)
    (hcomm : ∀ e, f (lift e) = base (param e))
    {K : Set E} (hK : IsCompact K) (hinj : Set.InjOn lift K) {p₀ : P}
    (hboundary : ∀ e ∈ K, param e = p₀ →
      IsOpen ({f.asFiber (lift e)} : Set (f.fiber (f (lift e))))) :
    ∀ᶠ p in 𝓝 p₀, {e ∈ K | param e = p}.Finite := by
  let good : Set E := lift ⁻¹' {x : X | f.QuasiFiniteAt x}
  have hgood : IsOpen good := f.isOpen_quasiFiniteAt.preimage hlift
  have hbad : IsClosed (param '' (K ∩ goodᶜ)) :=
    ((hK.inter_right hgood.isClosed_compl).image hparam).isClosed
  have hzero : p₀ ∉ param '' (K ∩ goodᶜ) := by
    rintro ⟨e, ⟨he, hnot⟩, heq⟩
    exact hnot (Scheme.Hom.quasiFiniteAt_iff_isOpen_singleton_asFiber.mpr
      (hboundary e he heq))
  filter_upwards [hbad.isOpen_compl.mem_nhds hzero] with p hp
  let Z := {e ∈ K | param e = p}
  have hm : Set.MapsTo lift Z {x : X | f x = base p ∧ f.QuasiFiniteAt x} := by
    intro e he
    obtain ⟨heK, hep⟩ := he
    refine ⟨(hcomm e).trans (congrArg base hep), ?_⟩
    by_contra hn
    exact hp ⟨e, ⟨heK, hn⟩, hep⟩
  exact Set.Finite.of_injOn hm (hinj.mono fun _ he => he.1)
    (finite_quasiFinite_points_in_fiber f (base p))

#print axioms finite_quasiFinite_points_in_fiber
#print axioms eventually_finite_physical_fibers

end SmallMass
