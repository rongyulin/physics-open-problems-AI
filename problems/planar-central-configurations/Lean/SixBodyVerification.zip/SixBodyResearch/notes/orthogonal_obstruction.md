# Two-body extensions perpendicular to a collinear central configuration

**Proposition.** Take a Newtonian planar collinear central configuration of at least four positive bodies. Adjoining two positive bodies off the base line on a common perpendicular cannot make the enlarged configuration central with the base positions and masses retained. The heights and masses of the two added bodies may differ. This excludes a subclass of stacked configurations for all positive masses, including five equal masses plus an arbitrary sixth. It gives no obstruction when the collinear subconfiguration is not itself central.

Place the base on the horizontal axis and the added bodies at $(0,h_1),(0,h_2)$ with $h_1h_2\ne0$ and $h_1\ne h_2$. For base abscissa $t$, the added horizontal and vertical accelerations are $-tU(t^2)$ and $V(t^2)$ with

$$U(z)=\sum_{j=1}^2m_j(z+h_j^2)^{-3/2},\qquad V(z)=\sum_{j=1}^2m_jh_j(z+h_j^2)^{-3/2}.$$

Subtracting the central equations of the two systems, there must be constants $A,B,C$ for which $tU(t^2)=At+B$ and $V(t^2)=C$ at every base abscissa. The function $U$ is strictly decreasing on $[0,\infty)$.

If $h_1^2\ne h_2^2$, the ratio $((z+h_1^2)/(z+h_2^2))^{5/2}$ is strictly monotone. The equation $V'(z)=0$ has at most one solution. If the squares agree, $V$ is either strictly monotone or identically zero. Thus, whenever $V$ is nonconstant, four different abscissas impose exactly two distinct squares, with all four signs $\pm r,\pm s$ and $0<r<s$. The horizontal equations at $\pm r$ force $B=0$ and $U(r^2)=A$; the other pair gives $U(s^2)=A$, contrary to strict decrease.

In the remaining case the added masses are equal, with opposite heights, and rescaling reduces the horizontal equation to $g(t)=at+b$, where $g(t)=t/(1+t^2)^{3/2}$. Every affine function meets this graph at most three times. Indeed,

$$g'(t)=(1-2t^2)(1+t^2)^{-5/2},\qquad g''(t)=3t(2t^2-3)(1+t^2)^{-7/2}.$$

For $a\ge0$, $g'(t)=a$ has at most two roots, since $g'$ can be nonnegative only on $[-1/\sqrt2,1/\sqrt2]$, increasing up to zero and decreasing thereafter on that interval. Rolle's theorem gives the claim. For $a<0$, $g(t)-at$ has the sign of $t$. If $b=0$, the unique intersection abscissa is zero. Otherwise all abscissas have the sign of $b$. On each open half-line $g''$ has one zero, so $g'-a$ has at most two zeros and $g(t)-at-b$ has at most three. This exhausts the cases.

Three base bodies can admit such an extension. The classical Euler-plus-two study gives rhombus-plus-center examples. See [Gidea and Llibre](https://web.ma.utexas.edu/mp_arc/c/09/09-198.pdf). A search of the literature used the phrases *stacked collinear central configurations*, *Euler plus two*, *four collinear bodies*, and *perpendicular bisector*. I did not find a source explicitly stating the proposition. Priority remains unverified. This note records an independently derived obstruction, not a resolution of Smale's sixth problem.
