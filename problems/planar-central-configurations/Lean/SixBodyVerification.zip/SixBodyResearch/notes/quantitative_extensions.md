# Two quantitative extensions from the distance equations

The estimates below count isolated roots. They need no assumption that the entire complex polynomial variety has dimension zero. All reported additional bounds are independently derived comparisons with specific published estimates. Priority has not been established.

## Rotating planar Newtonian centers

Fix distinct points $A_j=(X_j,Y_j)$ in the plane, masses $m_j>0$, and unit angular frequency. Put $z=x+iy$, $w=x-iy$, $Z_j=X_j+iY_j$, $W_j=X_j-iY_j$. With inverse distances $p_j$, the distance equations are

$$p_j^2(z-Z_j)(w-W_j)=1.$$

The complexified force equations have left sides $z-\sum_j m_j(z-Z_j)p_j^3$ and $w-\sum_j m_j(w-W_j)p_j^3$. Include an arbitrary constant shift in each force without changing the multidegrees. Work in $\mathbb P^1_z\times\mathbb P^1_w\times\mathbb P^n_p$ and denote the three hyperplane classes by $Z,W,P$. The sum of multiplicities of isolated roots is bounded by the coefficient of $ZWP^n$ in

$$(Z+W+2P)^n(Z+3P)(W+3P).$$

This follows from multihomogeneous Bézout, or by generic perturbation of the multihomogenized sections and local conservation of multiplicity at isolated roots. After imposing $Z^2=W^2=0$, the coefficient is

$$D_n=2^n+6n2^{n-1}+9n(n-1)2^{n-2}=2^{n-2}(9n^2+3n+4).$$

Every isolated physical equilibrium is isolated in its complex inverse-distance sheet. In fact, the real planar Hessian of $|q|^2/2+\sum m_j/|q-A_j|$ has trace $2+\sum m_j/|q-A_j|^3>0$. A nonzero real diagonal derivative eliminates one real coordinate analytically; if the remaining holomorphic scalar equation vanished identically, its real restriction would give a curve of physical equilibria. All physical distance sheets are holomorphically regular at their collision-free real points.

The other real sign choices use some of the Bézout budget. Each $\sigma\in\{+1,-1\}^n$ defines a real field

$$F_\sigma(q)=q-\sum_j \sigma_j m_j(q-A_j)/|q-A_j|^3.$$

This is a proper map from the punctured plane to the plane. On a sufficiently large circle, the normalized field has winding $+1$. On a small circle about each center, traversed counterclockwise, its winding is also $+1$, since multiplication by either sign preserves planar orientation. Inner boundary circles have the opposite induced orientation. For any fixed finite target the total mapping degree is $1-n$. Sard's theorem supplies a single arbitrarily small real vector $v$ regular for every one of the finitely many maps $F_\sigma$. Thus each nonphysical sign choice gives at least $n-1$ distinct nonsingular complex roots of the shifted polynomial system, by lifting its regular *real* solutions. Lifts of different sign choices are distinct.

Take disjoint complex neighborhoods of all isolated physical roots, small enough that every $p_j$ has positive real part. Holomorphic local mapping degree preserves their total multiplicity under sufficiently small shifts. A real shift can simultaneously satisfy the preceding regularity requirement. Locally the holomorphic map is finite at each isolated zero, so the perturbed roots in these neighborhoods remain isolated. The neighborhoods contain none of the real roots on the other sign sheets. Consequently the sum of multiplicities of isolated physical equilibria is at most

$$D_n-(2^n-1)(n-1).$$

For $n=5$, this gives $1952-124=1828$. Multiplication by the 354 labelled, oriented equal-mass primary configurations gives $647112$ as a uniform bound for the light-sixth-body transfer. It gives no lower estimate of the mass cutoff or prediction of the actual count.

Arustamyan, Cox, Lundberg, Perry and Rosen used the same inverse-distance encoding and obtained the ordinary total-degree bound $4^{n+2}$ for generic planar parameters. Zolotov established a more general real isolated-critical-point bound $4\cdot7^{d+n}$ in dimension $d$. These results differ in scope. [Arustamyan et al., Sect. 3.1](https://arxiv.org/abs/2106.11416) · [Zolotov, Theorem 4](https://arxiv.org/abs/2307.00312)

## Coulomb equilibria of positive point charges

For coplanar positive charges, every spatial Coulomb equilibrium lies in the source plane: the normal component away from that plane is a nonzero common normal displacement times a positive sum. The planar Hessian of $\sum_j m_j/|q-A_j|$ has positive trace $\sum_jm_j/|q-A_j|^3$, so isolated real equilibria again lift to isolated complex roots.

There is no quadratic background. Using the distance equations gives $(z-Z_j)p_j^3=p_j/(w-W_j)$ and its counterpart with $z,w$ exchanged. The denominators are nonzero on the distance variety. Clearing them gives forces of multidegrees $(0,n-1,1)$ and $(n-1,0,1)$. The coefficient of $ZWP^n$ in

$$(Z+W+2P)^n((n-1)W+P)((n-1)Z+P)$$

is $2^{n-2}(n-1)(9n-4)$. Each physical isolated equilibrium contributes two distinct complex lifts $p$ and $-p$, since the no-background force equations are homogeneous in $p$. The involution preserves local multiplicity. Therefore for $n\ge2$ the isolated equilibria of arbitrary coplanar positive charges number at most

$$2^{n-3}(n-1)(9n-4).$$

For five charges this gives 656. Killian's planar bound quoted in the literature is $2^{2n-2}(3n-2)^2$. The Maxwell inequality $(n-1)^2$ for unrestricted spatial arrangements was disproved in 2026; the estimate here does not imply a specific small sharp maximum. [Killian](https://digitalcommons.usf.edu/etd/333/) · [Arathoon, Ball and Kvalheim](https://arxiv.org/abs/2607.27197).

An optional sharpening also reserves room on the mixed sign sheets. Perturb the positive masses slightly to avoid zero total charge for every sign choice, and perturb the distinct source positions within the plane to make all signed real force maps transverse to zero. To see the latter, differentiating the contribution of a single source with respect to its position gives an invertible two-by-two matrix off that source (up to a nonzero factor the eigenvalues are $1$ and $-2$). Parametric Sard applies to all finitely many signed maps simultaneously. At infinity each perturbed signed map has radial leading term of nonzero strength. On a large punctured disk its degree at zero is again $1-n$, so each of the $2^n-2$ mixed sheets supplies at least $n-1$ nonsingular roots. For sufficiently small perturbations the multiplicities near each original all-positive and all-negative lift persist by local holomorphic degree. Their disjoint neighborhoods, on which all inverse distances have real parts of the originally prescribed signs, contain none of the mixed real lifts. Thus one may subtract $(2^n-2)(n-1)$ from the coefficient before dividing by two. At $n=5$ this gives $(1312-120)/2=596$. Perturbing positions preserves the reduced multidegrees used in this argument.

For arbitrary spatial positions there is a separate estimate applying to *nondegenerate* physical equilibria. Use $\mathbb P^3_q\times\mathbb P^n_p$. The distance equations have bidegree $(2,2)$ and the three force equations $\sum m_j(q-A_j)p_j^3=0$ have bidegree $(1,3)$. At a physical nondegenerate equilibrium the distance sheets are regular, and its complex lift is a simple root. Dividing again by the simultaneous sign involution yields

$$2^{n-1}\sum_{k=0}^3 3^k {3\choose k}{n\choose k}.$$

At $n=5$ this equals 9376. For comparison, $2^n(3n-2)^3$ gives 70304. Edelsbrunner, Fillmore and Oliveira use a generic source-position condition in their published theorem. The lift at a Morse critical point supplies a local justification for comparing the same prior Bézout bound in this class. Degenerate isolated *spatial* equilibria are outside our argument. [Edelsbrunner, Fillmore and Oliveira, 2026](https://doi.org/10.1112/plms.70163) · [Comparison and scope](https://shivakintali.github.io/papers/Maxwell-Superlinear.pdf)
