"""Numerical survey of the test-particle equilibria for five equal primaries.

Published starting positions are from Moczurad and Zgliczynski (2019),
arXiv:1812.07279 Appendix A.2.3. All masses are 1/5 and the multiplier is 1.
Run: python scan.py [grid_side] > scan.json
"""
import json
import sys

import numpy as np
from scipy.optimize import least_squares, root

STARTS = {
    "line": [(-1.019255982, 0), (-.480767439, 0), (.480767439, 0),
             (1.019255982, 0), (0, 0)],
    "square_center": [(-.7315026092, -.0000122322208),
                      (-.000004380645756, -.7315035144),
                      (-.000003486361374, -.000006548894919),
                      (.7314993242, 0), (-.00001115205008, .7314794181)],
    "two_triangles": [(-.7609899148, .4684633687),
                      (-.1902473651, -.6719536689),
                      (.3050645568, .02352925245), (.8936238356, 0),
                      (-.2474515264, .1799604652)],
    "trapezium": [(-.6591405438, .1800138879),
                  (-.2807232123, -.7143993153),
                  (.09876565526, -.1449273191), (.767575262, 0),
                  (.07352247002, .6793125102)],
    "pentagon": [(-.5262827178, .3823582109), (.2010155547, -.6186815315),
                 (.2010162837, .6186717554), (.6505104284, 0),
                 (-.526293415, -.3823760565)],
}


def primary_residual(flat):
    q = flat.reshape((5, 2))
    vectors = q[:, None, :] - q[None, :, :]
    d2 = np.sum(vectors**2, axis=2)
    np.fill_diagonal(d2, np.inf)
    residual = q - .2 * (vectors * d2[:, :, None]**-1.5).sum(axis=1)
    return np.append(residual.ravel(), q[3, 1])


def test_equation(q, point):
    vectors = point - q
    d2 = np.sum(vectors**2, axis=1)
    d3 = d2**-1.5
    value = point - .2 * (vectors * d3[:, None]).sum(axis=0)
    jacobian = (1 - .2 * d3.sum()) * np.eye(2)
    jacobian += .6 * ((vectors.T * (d3 / d2)) @ vectors)
    return value, jacobian


def scan(initial, grid_side):
    fit = least_squares(primary_residual, np.ravel(initial), xtol=1e-14,
                        ftol=1e-14, gtol=1e-14)
    q = fit.x.reshape((5, 2))
    solutions = []
    for x in np.linspace(-2, 2, grid_side):
        for y in np.linspace(-2, 2, grid_side):
            seed = np.array([x, y])
            if np.min(np.linalg.norm(q - seed, axis=1)) < 1e-7:
                continue
            with np.errstate(divide="ignore", invalid="ignore", over="ignore"):
                candidate = root(lambda p: test_equation(q, p), seed, jac=True, tol=1e-11)
            p = candidate.x
            if (np.all(np.isfinite(p)) and np.min(np.linalg.norm(q - p, axis=1)) > 1e-7
                    and np.linalg.norm(test_equation(q, p)[0]) < 1e-9
                    and all(np.linalg.norm(p - old) > 1e-6 for old in solutions)):
                solutions.append(p)
    results = []
    for p in sorted(solutions, key=lambda a: tuple(a.round(11))):
        residual, jac = test_equation(q, p)
        results.append(dict(point=p.tolist(), residual=float(np.linalg.norm(residual)),
                            eigenvalues=np.linalg.eigvalsh(jac).tolist()))
    return dict(primaries=q.tolist(),
                primary_residual=float(np.max(np.abs(primary_residual(q.ravel())))),
                hits=len(results), equilibria=results)


if __name__ == "__main__":
    grid_side = int(sys.argv[1]) if len(sys.argv) > 1 else 21
    print(json.dumps({name: scan(q, grid_side) for name, q in STARTS.items()}, indent=2))
