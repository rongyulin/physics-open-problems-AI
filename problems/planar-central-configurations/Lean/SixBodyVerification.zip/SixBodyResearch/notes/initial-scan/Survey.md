# Massless sixth body, five equal primaries

Moczurad and Zgliczyński supply coordinates of the five equal-mass Newtonian planar shapes in Appendix A.2.3 of [arXiv:1812.07279](https://arxiv.org/pdf/1812.07279). The primary masses are $1/5$, the barycenter is zero and the angular frequency is one. Their [2020 paper, Table 3](https://arxiv.org/pdf/2006.06768) reports the corresponding 207 fully labelled primary shapes modulo orthogonal transformations, and 354 modulo rotations.

| Primary shape | Labelled modulo reflections and rotations | Labelled modulo rotations | Distinct numerical hits | Smallest absolute Jacobian eigenvalue at a hit |
|---|---:|---:|---:|---:|
| Collinear | 60 | 60 | 8 | 0.67682 |
| Square with center | 15 | 30 | 12 | 0.93824 |
| Two isosceles triangles | 60 | 120 | 10 | 0.80611 |
| Trapezium | 60 | 120 | 14 | 0.23459 |
| Regular pentagon | 12 | 24 | 16 | 0.61201 |

Multiplicities are the 120 labellings divided by the order of the induced permutation group of each shape. In the collinear case the reflection across the line fixes every point, hence it is trivial in that group.

The script refines the tabulated primaries by least squares and applies a Newton hybrid solver to the test-particle equation $x-\sum_j(x-q_j)/(5|x-q_j|^3)=0$, starting from grids on $[-2,2]^2$. With both 21 and 37 mesh points per coordinate the solver found the same number of distinct roots for each of the five shapes. The 21-point run's largest test residual norm was below $9\times10^{-15}$. Algebraic multiplicity is not counted, and a finite start grid cannot exclude missed roots. If certification were to establish precisely these five counts with nondegeneracy, the candidate weighted count would be 4104 fully labelled configurations modulo rotations with a distinguished test body.

Run `OPENBLAS_NUM_THREADS=1 python scan.py 21 > scan.json` using NumPy and SciPy. The JSON lists the polished primary coordinates, every candidate position and both Jacobian eigenvalues. Rerun with argument 37 for the independent seed grid. Values in the last column are truncated downward to five decimals for display; they are floating-point diagnostics.
