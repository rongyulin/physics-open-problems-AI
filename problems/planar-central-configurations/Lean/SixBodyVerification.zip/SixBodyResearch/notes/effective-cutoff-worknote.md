# Unverified route to an explicit cutoff with impractical size

The manuscript proves existence of a positive cutoff and does not use this work note. The proposal below has not been independently checked or formalized.

Use 27 coordinates for a labelled oriented six-body configuration (12 Cartesian coordinates and 15 positive inverse distances). Let Φ(t,u) be the polynomial sign conditions for masses (1,1,1,1,1,t), with multiplier one, y₁=y₂ and x₁>x₂. Consider

    ∃u [Φ(t,u) ∧ ∀δ (δ>0 → ∃v (Φ(t,v) ∧ 0<∥v−u∥²<δ²))].

This asks whether the physical fiber has a nonisolated point. A semialgebraic set is infinite exactly if it has a nonisolated point. There are 55 variables to project away. The joint polynomials, including t itself, have total degree at most 5 and sum of absolute integer coefficients at most 128 (the bound for δ² minus the squared 27-coordinate difference is 109).

For a possible complete projection bound use all coefficients of every polynomial, and all square minors of the Sylvester matrices for every pair of degree truncations of polynomials, including each truncation paired with its derivative. True specialized degrees and Sylvester ranks should then remain fixed on each projected cell. For the active polynomials the degrees of the specialized gcds with their derivatives and with each other remain fixed. Locally, constant degree and constant numbers of distinct complex roots should give continuously distinct real-root branches and constant multiplicities. Pairwise gcd rank should make coincidences of the ordered branches locally constant. Identically zero polynomials on a cell carry no constraint at that lifting stage. These are the delineability and nullification details to audit against a complete projection theorem before using this bound in the paper.

For input coefficient norm H and total degree D, the entries of these matrices have norm at most D H and total degree at most D. Their side length is at most 2D. Expansion of a determinant gives candidate bounds D' = 2D² and H' = (2D)! (D H)^(2D). Apply them 55 times starting from D=5, H=128. Each nonzero real root of a nonzero integer univariate polynomial of final norm H₅₅, after factoring out any power of t, has absolute value at least 1/(1+H₅₅). A sign-invariant decomposition whose first coordinate obeys this projection would therefore force the displayed truth value to be constant throughout (0,1/(1+H₅₅)). The qualitative theorem would then establish this particular, extraordinarily small interval. No practical rational range or configuration count has been computed.
