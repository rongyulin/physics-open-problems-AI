# Pentagonal balance and its sharpness

## Physical question

Let five equal positive masses lie at positions $r_j u_j$ in a plane, where $u_j$ are the five successive unit directions of a regular pentagon, $r_j>0$, and the index is read modulo five. Put a sixth positive mass at the origin. Suppose the origin is the barycenter of the six bodies. In any Newtonian central configuration the acceleration of a body at the barycenter vanishes. After cancelling common positive constants, these two necessary conditions become

$$
\sum_j r_j u_j=0,\qquad \sum_j r_j^{-2}u_j=0.
$$

The inverse-square power comes from the vector acceleration $Gm(r_j u_j)/r_j^3$ of the central body due to one outer mass. The following argument uses only these two vector equations. The outer bodies need not satisfy any prescribed equations of motion.

**Proposition.** Let $f$ be strictly convex on an interval containing $r_0,\ldots,r_4$. If both $\sum_j r_j u_j=0$ and $\sum_j f(r_j)u_j=0$, then all five radii coincide. In particular, the regular pentagon is the unique shape under the six-body assumptions just stated. Its existence for every positive central mass follows from symmetry. Reflection about the radius through an outer body makes its acceleration radial, the cyclic symmetry gives the same radial coefficient at every vertex, all individual inward radial components are positive, and the center experiences zero total force.

### Proof

Write $c=2\cos(2\pi/5)=(\sqrt5-1)/2$, so $0<c<1$ and $c^2+c=1$. In the oblique basis $u_2,u_3$, the five unit rays have successive coordinates
$$
(-c,-c),\quad(c,-1),\quad(1,0),\quad(0,1),\quad(-1,c).
$$
These follow from $u_{j+1}+u_{j-1}=c u_j$. Consequently, a balanced list of scalars $x_j$, meaning $\sum_j x_j u_j=0$, satisfies
$$
x_2=x_4+c(x_0-x_1),\qquad x_3=x_1+c(x_0-x_4).
$$
The relations survive cyclic permutations and reversal. Choose the origin of the indexing and its direction to arrange that $r_0$ is maximal and $r_1\le r_4$. If $r_0=r_4$, then $r_2=r_0+c(r_0-r_1)\le r_0$ gives $r_1=r_0$. The two relations now give equal radii throughout.

Otherwise $r_4<r_0$. We have $r_1<r_3<r_0$, because $r_3=r_1+c(r_0-r_4)$ and $r_1\le r_4$. Applying that same balance equation to $f(r_j)$ gives
$$
\frac{f(r_3)-f(r_1)}{r_3-r_1}
=
\frac{f(r_0)-f(r_4)}{r_0-r_4}.
$$
Strict convexity contradicts this identity. More explicitly, holding $r_1$ fixed and increasing the right endpoint from $r_3$ to $r_0$ strictly increases the secant slope. Then holding $r_0$ fixed and increasing the left endpoint from $r_1$ to $r_4$ can only increase it further. The gravitational result follows with $f(r)=r^{-2}$ on $r>0$.

## Which regular ray systems have this Newtonian rigidity?

**Classification.** For $n\ge2$, let $u_j=(\cos(2\pi j/n),\sin(2\pi j/n))$ and let all $r_j>0$. The implication
$$
\sum_j r_j u_j=\sum_j r_j^{-2}u_j=0
\quad\Longrightarrow\quad
r_0=\cdots=r_{n-1}
$$
holds for every choice of radii exactly when $n\in\{2,3,5\}$.

For two rays the centroid equation alone gives equality. For three rays they sum to zero and any two are linearly independent. The space of dependencies is one-dimensional, so again the centroid equation gives equality. The proposition treats five rays.

For even $n\ge4$ assign equal radii within each opposite pair, with two pairs assigned different radii. Both vector sums vanish pairwise.

For odd $n\ge7$ use reflection symmetry about the first ray, assigning the same radius to $j$ and $n-j$. After reflection the vertical coordinates cancel in both sums. The horizontal weight of an orbit is $1$ at zero and $2\cos(2\pi j/n)$ at the two-point orbits. The four distinct indices $0,1,(n-3)/2,(n-1)/2$ have weights $A,B,-C,-D$, respectively, with $A,B,C,D>0$. For example, $\cos(2\pi((n-3)/2)/n)=-\cos(3\pi/n)<0$ since $n>6$. Initially give all radii the value one, for which both sums vanish. Change the radii of these four orbits to
$$
1-s,\quad 1+As/B,\quad 1-t,\quad 1+Ct/D.
$$
For $0\le s,t<1$ all radii are positive and the changes in the centroid sum cancel within each pair of orbits. The change in the inverse-square sum is $P(s)-N(t)$, where
$$
P(s)=A[(1-s)^{-2}-1]+B[(1+As/B)^{-2}-1],
$$
and $N(t)$ has the same formula with $C,D,t$ in place of $A,B,s$. Take $s=1/2$. The weighted mean of $1-s$ and $1+As/B$ is one, and $r^{-2}$ is strictly convex, so $P(s)>0$. The continuous function $N(t)$ takes the value zero at zero and diverges to $+\infty$ as $t\uparrow1$. The intermediate value theorem gives $0<t<1$ with $N(t)=P(s)$. This gives unequal radii with both vector sums exactly zero. Only the balance conditions have been imposed in these counterexamples.

The classification also holds for any finite strictly convex radial law on an open interval of positive radii. In the odd construction, choose a baseline radius in the interior of that interval. Fix a small positive perturbation of the negative pair. Its excess is strictly positive by Jensen's inequality. Then choose a positive perturbation of the positive pair so small that its excess lies strictly between zero and that negative-pair excess. Finite convex functions are continuous on an open interval. The intermediate value theorem again matches the two excesses, with all radii inside the interval. The remaining cases use exactly the proofs above.

## A global lower bound for the Newtonian field

The qualitative rigidity proof gives a scale-covariant quantitative estimate without assuming nearly equal radii. For any centroid-balanced set of five radii, put $a=\max_j r_j$, $b=\min_j r_j$, $F=\sum_j r_j^{-2}u_j$. Then
$$
 |F|\ \ge\ 3\sin(2\pi/5)c^2(1-c)\frac{(a-b)^2}{a^4},
 \qquad c=(\sqrt5-1)/2 .
$$
To see this, orient the indices as in the proof with $a=r_0$, $r_1\le g=r_4$, $d=r_2$ and $e=r_3$. The centroid relations show that $r_1=b$ since $d\ge g$ and $e\ge r_1$. If $a=b$ the bound is immediate. Otherwise $d=g+c(a-b)\le a$ gives $a-g\ge c(a-b)>0$, and $e=b+c(a-g)$ gives $a-e\ge(1-c)(a-b)>0$. Write $S_h(x,y)=(h(y)-h(x))/(y-x)$. For $f(x)=x^{-2}$ on $[b,a]$, the function $h(x)=f(x)-3x^2/a^4$ is convex since $h''(x)=6/x^4-6/a^4\ge 0$. Secant monotonicity applied to $h$ gives $S_h(g,a)\ge S_h(b,e)$. Hence
$$
 S_f(g,a)-S_f(b,e)
 \ge \frac{3}{a^4}(g+a-b-e)
 \ge \frac{3}{a^4}(1-c)(a-b).
$$
The second oblique coordinate of $F$ is $D=f(e)-f(b)-c(f(a)-f(g))$, so its absolute value is $c(a-g)[S_f(g,a)-S_f(b,e)]$. The component of $F$ perpendicular to the first oblique basis vector has magnitude $\sin(2\pi/5)|D|$. Combining the bounds proves the assertion. The lower bound measures how far a centered equiangular placement with a specified radial spread must be from balancing the central force.

## Quantitative behavior near the regular pentagon

There is also a test for almost-balanced numerical data. Normalize the mean radius to one, write $r_j=1+x_j$, assume the centroid equation, and let $E=\sum_j x_j^2$ and $\varepsilon=\max_j |x_j|<1$. Identify the plane with the complex numbers, put $\zeta=e^{2\pi i/5}$, and define $F=\sum_j (1+x_j)^{-2}\zeta^j$. Then
$$
\left|\, |F|-\tfrac32 E\,\right|
\le \frac{(4+3\varepsilon)\varepsilon}{(1-\varepsilon)^2}E .
$$
In particular, $E\le |F|\le 2E$ for $\varepsilon\le 1/12$. This estimate applies to exactly centroid-balanced radii. The Newtonian field is written in units of the common outer mass times the gravitational constant divided by the square of the mean radius.

To verify the estimate, the zero mean and centroid equations imply that $x_j=b\zeta^{2j}+\bar b\zeta^{-2j}$ for some complex $b$, by the Fourier expansion on five points. Thus $\sum_j x_j^2\zeta^j=5b^2$ while $E=10|b|^2$. In the identity
$$
(1+x)^{-2}=1-2x+3x^2-\frac{x^3(4+3x)}{(1+x)^2}
$$
the constant and linear terms have zero first Fourier coefficient. Multiplying by $\zeta^j$ and summing, the norm of the quadratic contribution is exactly $3E/2$, and the remainder has norm at most the displayed bound. For $\varepsilon\le 1/12$, the coefficient on the right is at most $51/121<1/2$. Thus the Newtonian field in any nontrivial small centroid-preserving deformation first appears at second order, with the same leading normalized magnitude in every direction. This quantitative refinement is an analytic calculation in the note.

## Relation to existing work and scope

Moeckel records the centered regular polygon with an arbitrary central mass as a classical central configuration. The added conclusion above is uniqueness under the equal-angle and central-barycenter hypotheses using the central force equation alone. Campa-Raymundo and Franco-Pérez treated five equal outer bodies with equal angular separation and no central particle. They employed the central configuration equations at the outer masses. In their setting the barycenter need not have zero gravitational field, since there is no body there. Conversely, even after adding a central mass, the equations at the outer bodies change. Their theorem and the present argument therefore cover different hypotheses. A search under regular pentagonal rays, centered star central configurations, five equal masses and zero field identified their paper as the nearest match. Independent priority has not been established. A GitHub code search on 27 November 2026 for the four quoted terms `"pentagonal" "equally spaced" "radii" "central configuration"` returned no files. A search by the identifier `2505.16101` found a copy and provenance record for the five-body paper in the [cross-theory formal database](https://github.com/AlexenderSokolov/cross-theory-formal-database/blob/3b9207c03d9dc146f393f68bcb683bbc4583979a/editable-corpus/sources/178553/provenance.json).

- Richard Moeckel, [Lectures on Central Configurations](https://www-users.cse.umn.edu/~rmoeckel/notes/CentralConfigurations.pdf).
- L. A. Campa-Raymundo and L. Franco-Pérez, [Uniqueness of star central configurations in the 5-body problem](https://arxiv.org/abs/2505.16101), 2025.

The pentagonal physical conclusion covers all positive values of the sixth mass inside the stated geometric class. The central-barycenter assumption is essential to the proof. If the sixth mass is placed at the ray intersection but the barycenter is elsewhere, its central-configuration equation merely gives $\sum_j r_j^{-2}u_j=\lambda(5+\mu)^{-1}\sum_j r_j u_j$ with unit outer masses and gravitational constant normalized to one. The two sums need not vanish individually. Central configurations with a noncentral sixth body, unequal angular gaps, or a center outside the barycenter still have to be controlled for Smale's finiteness problem. The sharp classification for arbitrary $n$ concerns only the two balance equations. The accompanying Lean source concerns the pentagonal case and its strictly convex extension.
