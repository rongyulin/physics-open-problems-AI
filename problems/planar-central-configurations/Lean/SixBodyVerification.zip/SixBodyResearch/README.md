# Planar central configurations with a light sixth body

There are **exactly 4,104 labelled planar Newtonian central configurations** for five masses sufficiently close to one and one sufficiently light positive mass. Precisely, the count holds throughout a product $V \times (0,\epsilon)$, where $V$ is an open neighborhood of $(1,1,1,1,1)$ in five independent mass coordinates. Translations, rotations and positive scalings are identified. Identifying reflections as well gives **2,232** labelled classes. The 360 collinear configurations are precisely the fixed classes of reflection. The calculation establishes existence of this region but gives no numerical cutoff for the light mass.

When the five heavy masses are exactly equal, one can also identify permutations of those five bodies, keeping the light body distinguished and continuing to use orientation-preserving similarities. This convention gives **35 shapes**, with contributions $4+3+10+14+4$ from the five primary types.

With labels retained, the five limiting primary shapes contribute $60(8)+30(12)+120(10)+120(14)+24(16)=4{,}104$. The **384 branches** in the final term approach a regular pentagon of heavy bodies. Its 16 restricted equilibria comprise the center and three five-point rotation orbits. A separate symmetry-based interval check verifies these representatives and their nonsingularity. The exact count uses the published primary enumeration, conventional mathematical arguments and exact Python and C++/GMP interval certificates. Lean verifies selected components of this main proof.

On the ray $(1,1,1,1,1,t)$, the oriented labelled count falls from 4,104 for sufficiently small $t$ to the previously established 3,624 at $t=1$. Compactness for positive masses and local continuation at nondegenerate configurations imply that **some $t$ strictly between zero and one admits a degenerate configuration**. Its location and bifurcation type remain undetermined. The general six-body finiteness question for arbitrary positive masses remains open.

[papers/SmallMass.pdf](papers/SmallMass.pdf) contains the main paper. The [Chinese research log](ResearchLog_zh.md) records prior work, how the count was obtained, additional questions and unsuccessful approaches.

The third English paper, `papers/HamptonMorse.pdf`, verifies two named parts of Hampton's conjectures. In the Newtonian six- and seven-body equal-mass problems it establishes the predicted complete Morse polynomials using the published global catalogues and certified interval inertias. The sufficiently large exponent clause for six bodies and the eight- and nine-body clauses remain open in this work. See `certificates/hampton/` for the arithmetic and replication instructions.

## Files

- `papers/SmallMass.tex` is the self-contained source for the main paper. Compile twice with pdfLaTeX.
- `papers/NonconcentricTriangles.pdf` and its matching source prove the existence and local uniqueness of a branch of two nonconcentric equilateral triangles in an explicit corridor. The wide corridor uses 4,000 rational interval checks and the implicit function theorem.
- `lean/` contains the main proof components and the narrow, directly verified pentagonal rigidity theorem. The physical definitions and conditional top-level theorem are in `SixBodyApplication.lean`. Its hypotheses state compactness and the availability of the regular scalar coordinate charts. The paper proves the chart construction and invokes published compactness. The main physical theorem as a whole has a conventional mathematical proof and a partial formalization.
- `certificates/restricted/` contains the exhaustive verifier for the test-body equilibria at the five primary shapes, its inputs and output. The main article explains the independent checks on the primaries and the regular-pentagon case.
- `certificates/triangles/` contains a separate pinned Lean project and the wide-corridor verifier. On the smaller rectangle the end-to-end theorem `SixTriangles.physical_six_body_standard` verifies pairwise distinct positions, positive masses, two equilateral triples with different centroids, and each particle’s Newtonian acceleration relative to the actual mass-weighted center with a strictly positive common multiplier.
- `certificates/diagram93/` contains the exact positive-mass classification checker, all defining polynomials, and the output for the eight branches. The two-equal-mass specialization has its own Lean sources under `certificates/diagram93/lean/`. The global elimination and real-root classification use the exact Python computation and the accompanying argument.
- `notes/` contains the pentagonal rigidity proof and its generalizations, the orthogonal extension obstruction, and the auxiliary electrostatic and amended-potential bounds. The explicit small-mass cutoff work note is an unverified proposal.
- `checks/` contains selected compiler and kernel reports. The distributed project contains sources and certificates, so it can be rebuilt against the pinned dependencies.

With five exactly equal heavy bodies, identifying their permutations and mirror images gives **27 geometric shapes**. The orbit counts for the five heavy limits are 4, 3, 7, 9 and 4. A first count-transition parameter can be chosen real algebraic. All collinear configurations are nondegenerate, so the change necessarily involves a noncollinear shape.

The five closed local-test theorems in `certificates/restricted/RestrictedReplay.lean` verify the integer acceptance conditions for all 60 root boxes in the Lean kernel. Independent C++ and Lean executables also replay the full 54,489-node coverage computation. `lean/BranchGluing.lean` uses the inverse function theorem to obtain local branches from strict invertible derivatives and constructs a uniform bijection under its explicit compactness and neighbourhood assumptions, and `lean/SixBodyCount.lean` verifies the cardinality and orbit-count deductions.

The exact small-mass Morse index counts are 264, 1,080, 1,440, 960 and 360 at indices zero through four. The arithmetic, individual signs and Schur-complement argument are in `certificates/inertia/`.

## Rebuild the main Lean sources

With Lean 4.28.0 and Lake installed, run the following from the root of this package.

```sh
cd lean
lake update
lake exe cache get
lake build
lake env lean SixBodyApplication.lean
```

The package pins mathlib to commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365`. To replay a compiled module in a fresh checker process, use `lake env leanchecker SixBodyApplication`. Rebuild the triangle project separately using its supplied Lake configuration. The scope of every statement is visible in its hypotheses. In the main project, the input papers' celestial-mechanics enumerations and the topological degree and intersection theorems used for the count were not reconstructed from first principles.

## Reproduce the exact computations

Run `python3 certificates/primaries/certify_primaries.py` for the primary boxes and `python3 certificates/primaries/check_orbits.py certificates/restricted/seeds.txt` for the symmetry action. Run `python3 certificates/pentagon/pentagon_restricted.py` for an independent check of the regular-pentagon Hessians. These commands require the Python standard library and enabled assertions.

The program `python3 certificates/check_inputs.py` compares every primary center and test-root input in the three implementations exactly. For the main count, follow the build and replay instructions in [certificates/restricted/README.md](certificates/restricted/README.md). The C++17 verifier uses GMP integer arithmetic and outward-rounded intervals.

Run `python3 certificates/diagram93/diagram93_global.py` with NumPy and SymPy installed and assertions enabled. From the triangle project directory run `python3 verify_intervals.py`, `python3 verify_derivative.py` and `python3 continuation.py`. The continuation uses 4,000 intervals. Its output and the analytic proof together yield the broad branch result.

The literature and public-code search was last checked on 27 November 2026. No priority or peer-review certification is asserted.
