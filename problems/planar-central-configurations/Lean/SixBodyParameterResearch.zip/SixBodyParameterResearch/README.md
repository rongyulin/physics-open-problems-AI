# Five equal masses in the planar Newtonian six-body problem

Research release by Chatgpt, 27 November 2026. The six original mass entries are positive, the five primary masses equal one, and the marked mass is denoted by t. The conventions in the numerical census retain all labels, distinguish reflected configurations when they differ by more than a rotation, and identify translations and scale.

## Papers and research record

- [Algebraic and symmetry reductions](papers/FiveEqualSixBody.pdf) and [standalone LaTeX](papers/FiveEqualSixBody.tex). The key result on the mass line excludes diagram 98 for every positive mass outside a finite set of algebraic exceptions and also at t = 3. The same diagram is excluded on a Zariski open subset of the three-parameter family (1,1,1,a,b,c), including (1,1,1,2,3,7). The paper includes a refined census, three certified folds, one two-axial pitchfork, the inverse mass calculation and local analysis at the central pentagon.
- [Two symmetry-breaking bifurcations](papers/Pitchfork.pdf) and [standalone LaTeX](papers/Pitchfork.tex). This companion gives the other two pitchforks, including their cusp unfoldings under a physical mass splitting.
- [Signed collinear configurations](papers/SignedCollinear.pdf) and [standalone LaTeX](papers/SignedCollinear.tex). This paper proves the signed all-collinear case and rules out the five unit bodies lying on one line with the sixth off that line, also on the complex signed sheets. It also rules out any five-collinear/off-axis assignment at the generic mass on this line.
- [Chinese research log](SixBodyProgress_zh.md). The mathematical and computational status of each conclusion is recorded there.
- [Earlier release with the three starting manuscripts](https://github.com/rongyulin/physics-open-problems-AI/tree/523559700ce3c996afe6b08f4744309cfb631d3f/problems/planar-central-configurations).

These are research manuscripts. The full unrestricted generic fibre over Q(t) and the remaining singular diagrams are open in this work. An exclusion at t = 3 for one diagram gives no global count there. The six isolated transitions in the open interval from 0 to 1 recover the net change of the endpoint counts. There is no certificate excluding further transitions with zero net contribution.

## Reproduction

Run the following from the release root with unoptimized Python 3.10+ and SymPy. The core interval scripts for the bifurcations and the diagram use the standard library; symbolic polynomial and number-field calculations use SymPy. Every seed is checked by its associated verifier.

```sh
python3 verify/replay.py
```

The verification summary and the formal theorem interfaces are in [Lean/README.md](Lean/README.md). To rebuild the manuscripts use pdfLaTeX twice on each standalone source. Full license texts are in LICENSE and LICENSES. The code is MIT; the manuscripts and original documentation are CC BY 4.0. Please credit the author as **Chatgpt**. Third-party work retains its original notices. The three small files in the symmetry verifier are copies from the [prior release](https://github.com/rongyulin/physics-open-problems-AI/tree/523559700ce3c996afe6b08f4744309cfb631d3f/problems/planar-central-configurations); they include seed data from Moczurad and Zgliczyński's numerical catalogue. The endpoint proof depends on the complete published enumeration and the previous small-mass interval certificates.
