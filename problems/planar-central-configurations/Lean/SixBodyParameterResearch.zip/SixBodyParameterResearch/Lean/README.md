# What Lean checks

Use Lean 4.28.0 and mathlib v4.28.0. From this directory run the following commands.

```sh
lake exe cache get
lake build
```

The compact sources contain the checked integers where tables are involved. Standard-library modules can also be checked directly with the pinned compiler.

- `DiagramAlgebra.lean` proves the equal and mixed projected shape factorizations and equal-triangle torque identity in any commutative ring.
- `DiagramDisks.lean` checks all rational inequalities used in the Rouché disk arguments at t = 3. It checks the number of disks per factor, pairwise separation, and three radical enclosures for each root.
- `DiagramSigns.lean` checks signed nonvanishing at all relevant pairs of those boxes. Its row normalization of the 3-by-3 sign matrices is equivalent to enumerating each of the 256 matrices up to overall sign. It skips the entire equilateral, rank-one class, where no nonvanishing assertion is required.
- `DiagramCubic.lean` checks the two cubic-order rejection inequalities on all 840 mixed cases at t = 3. Its incoming rectangles enclose the disks from the previous step. All four diagram files use kernel-checkable proofs. Rouché's theorem, the link to the Newtonian singular places, the analytic elimination and the generic resultant argument are provided in the paper.
- `CollinearValuation.lean` proves finiteness for the signed collinear equations. Its closed specializations cover the geometric generic mass and every positive real mass inside the complex model.
- `FiveAxialArithmetic.lean` checks the finite-field arithmetic for the five-collinear/off-axis exclusion. Its use for the original characteristic-zero force equations is explained in SignedCollinear.pdf. The wider three-parameter diagram-98 specializations are checked by the exact Python certificates.
- `Pitchfork.lean` proves the local three/one or one/three root counts from the stated regularity and certified sign hypotheses on the reduced scalar equation. `CubicBound.lean` uses Rolle's theorem to prove the local upper bound of three under perturbations. The reduction, Newtonian interval Jacobians and derivative enclosures are in the manuscripts and Python verifiers.
- `MassRecovery.lean` checks the radial/angular decomposition and inverse mass formula against explicit Newtonian force expressions. The denominator-zero classification uses the published cocircular theorems in the paper.
- `PentagonAlgebra.lean` verifies the algebraic relation of the positive pentagon critical mass and signs of two higher-order coefficients. Extracting these coefficients from the physical potential and proving multiplicity eleven use the number-field code and the analytic argument.

The six-body finiteness claim for all planar configurations is not a theorem of this project. The diagram and bifurcation calculations each have their stated scope. Original code is under MIT.
