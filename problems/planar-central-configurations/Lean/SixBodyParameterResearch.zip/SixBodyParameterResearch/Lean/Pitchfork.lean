import Mathlib

/-!
# Counting the real zeros of a reflection-odd reduced equation

The first variable of `H` is squared amplitude and the second is mass.
Changing the sign of an entire reduced equation preserves the roots.
-/

noncomputable section
open Set Filter Topology

namespace Pitchfork

/-- The allowed amplitude window is open at both ends. -/
def roots (h : ℝ → ℝ) (r : ℝ) : Set ℝ :=
  {s | s ∈ Ioo (-r) r ∧ s * h (s ^ 2) = 0}

private theorem sq_mem {r s : ℝ} (hs : s ∈ Ioo (-r) r) :
    s ^ 2 ∈ Icc 0 (r ^ 2) := by
  obtain ⟨hl, hu⟩ := hs
  have hprod := mul_pos (sub_pos.mpr hu) (show 0 < r + s by linarith)
  exact ⟨sq_nonneg _, by nlinarith⟩

theorem roots_single {h : ℝ → ℝ} {r : ℝ} (hr : 0 < r)
    (hm : StrictMonoOn h (Icc 0 (r ^ 2))) (h0 : 0 ≤ h 0) :
    roots h r = {0} := by
  ext s
  change (s ∈ Ioo (-r) r ∧ s * h (s ^ 2) = 0) ↔ s = 0
  constructor
  · rintro ⟨hs, he⟩
    rcases mul_eq_zero.mp he with he | he
    · exact he
    · by_contra hn
      have hsq : 0 < s ^ 2 := sq_pos_of_ne_zero hn
      have := hm (left_mem_Icc.mpr (sq_nonneg r)) (sq_mem hs) hsq
      linarith
  · rintro rfl
    exact ⟨⟨by linarith, hr⟩, zero_mul _⟩

theorem roots_triple {h : ℝ → ℝ} {r : ℝ} (hr : 0 < r)
    (hc : ContinuousOn h (Icc 0 (r ^ 2))) (hm : StrictMonoOn h (Icc 0 (r ^ 2)))
    (h0 : h 0 < 0) (hend : 0 < h (r ^ 2)) :
    ∃ a : ℝ, 0 < a ∧ a < r ∧ roots h r = {-a, 0, a} ∧ (roots h r).ncard = 3 := by
  obtain ⟨w, hw, he⟩ := intermediate_value_Icc (sq_nonneg r) hc ⟨h0.le, hend.le⟩
  have hw0 : 0 < w := lt_of_le_of_ne hw.1 (by rintro rfl; linarith)
  have hwr : w < r ^ 2 := lt_of_le_of_ne hw.2 (by rintro rfl; linarith)
  let a := Real.sqrt w
  have ha : 0 < a := Real.sqrt_pos.2 hw0
  have hasq : a ^ 2 = w := Real.sq_sqrt hw0.le
  have har : a < r := by nlinarith
  have hz (s : ℝ) (hs : s ∈ Ioo (-r) r) : h (s ^ 2) = 0 ↔ s = -a ∨ s = a := by
    constructor
    · intro hsz
      have hsw : s ^ 2 = w := hm.injOn (sq_mem hs) hw (hsz.trans he.symm)
      have hp : (s + a) * (s - a) = 0 := by nlinarith
      rcases mul_eq_zero.mp hp with h | h
      · exact Or.inl (by linarith)
      · exact Or.inr (by linarith)
    · rintro (rfl | rfl) <;> simpa [hasq] using he
  have hset : roots h r = {-a, 0, a} := by
    ext s
    simp only [roots, mem_setOf_eq, mem_insert_iff, mem_singleton_iff]
    constructor
    · rintro ⟨hs, heq⟩
      rcases mul_eq_zero.mp heq with hsz | hsq
      · exact Or.inr (Or.inl hsz)
      · rcases (hz s hs).mp hsq with h | h
        · exact Or.inl h
        · exact Or.inr (Or.inr h)
    · rintro (rfl | rfl | rfl)
      · have hs : -a ∈ Ioo (-r) r := ⟨by linarith, by linarith⟩
        exact ⟨hs, mul_eq_zero.mpr (Or.inr ((hz _ hs).mpr (Or.inl rfl)))⟩
      · exact ⟨⟨by linarith, hr⟩, zero_mul _⟩
      · have hs : a ∈ Ioo (-r) r := ⟨by linarith, har⟩
        exact ⟨hs, mul_eq_zero.mpr (Or.inr ((hz _ hs).mpr (Or.inr rfl)))⟩
  refine ⟨a, ha, har, hset, ?_⟩
  rw [hset, ncard_insert_of_notMem, ncard_insert_of_notMem, ncard_singleton]
  · simp; linarith
  · simp; constructor <;> linarith

/-- The exact zero pattern for all masses in some neighborhood of the critical mass. -/
def Pattern (H : ℝ → ℝ → ℝ) (r tc : ℝ) : Prop :=
  ∀ᶠ t in 𝓝 tc,
    (t < tc → ∃ a : ℝ, 0 < a ∧ a < r ∧ roots (fun w => H w t) r = {-a, 0, a} ∧
      (roots (fun w => H w t) r).ncard = 3) ∧
    (tc ≤ t → roots (fun w => H w t) r = {0})

/-- `H` may be sign-adjusted so its two partial derivatives are positive. For every
mass sufficiently close to the bifurcation value the complete zero set is identified.
The endpoint mass-continuity assumption lets the proof shrink the mass window. -/
theorem local_pitchfork {H : ℝ → ℝ → ℝ} {r tc δ : ℝ}
    (hr : 0 < r) (hδ : 0 < δ) (hcrit : H 0 tc = 0)
    (hmassC : ContinuousOn (H 0) (Icc (tc - δ) (tc + δ)))
    (hmassD : ∀ t ∈ Ioo (tc - δ) (tc + δ), 0 < deriv (H 0) t)
    (hendC : ContinuousAt (H (r ^ 2)) tc)
    (hwC : ∀ t ∈ Ioo (tc - δ) (tc + δ), ContinuousOn (fun w => H w t) (Icc 0 (r ^ 2)))
    (hwD : ∀ t ∈ Ioo (tc - δ) (tc + δ), ∀ w ∈ Ioo 0 (r ^ 2),
      0 < deriv (fun v => H v t) w) :
    Pattern H r tc := by
  unfold Pattern
  have ht0 : tc ∈ Ioo (tc - δ) (tc + δ) := ⟨by linarith, by linarith⟩
  have hm := strictMonoOn_of_deriv_pos (convex_Icc (tc-δ) (tc+δ)) hmassC
    (by simpa only [interior_Icc] using hmassD)
  have hw (t : ℝ) (ht : t ∈ Ioo (tc-δ) (tc+δ)) :
      StrictMonoOn (fun w => H w t) (Icc 0 (r ^ 2)) :=
    strictMonoOn_of_deriv_pos (convex_Icc 0 (r^2)) (hwC t ht)
      (by simpa only [interior_Icc] using hwD t ht)
  have he : 0 < H (r ^ 2) tc := by
    have hh := hw tc ht0 (left_mem_Icc.mpr (sq_nonneg r)) (right_mem_Icc.mpr (sq_nonneg r))
      (sq_pos_of_pos hr)
    simpa [hcrit] using hh
  filter_upwards [Ioo_mem_nhds ht0.1 ht0.2, hendC.eventually (lt_mem_nhds he)] with t ht he
  constructor
  · intro hlt
    apply roots_triple hr (hwC t ht) (hw t ht) _ he
    simpa [hcrit] using hm (Ioo_subset_Icc_self ht) (Ioo_subset_Icc_self ht0) hlt
  · intro hle
    apply roots_single hr (hw t ht)
    simpa [hcrit] using hm.monotoneOn (Ioo_subset_Icc_self ht0) (Ioo_subset_Icc_self ht) hle

def partialW (H : ℝ → ℝ → ℝ) (p : ℝ × ℝ) : ℝ := deriv (fun w => H w p.2) p.1

def partialT (H : ℝ → ℝ → ℝ) (p : ℝ × ℝ) : ℝ := deriv (H p.1) p.2

/-- Only continuity of each partial derivative at the event is needed. Positive
partials automatically give differentiability of the slices on a small rectangle. -/
theorem local_from_partials {H : ℝ → ℝ → ℝ} {tc : ℝ}
    (hcrit : H 0 tc = 0)
    (cw : ContinuousAt (partialW H) (0,tc)) (ct : ContinuousAt (partialT H) (0,tc))
    (pw : 0 < partialW H (0,tc)) (pt : 0 < partialT H (0,tc)) :
    ∃ r : ℝ, 0 < r ∧ Pattern H r tc := by
  have hpos : {p : ℝ × ℝ | 0 < partialW H p ∧ 0 < partialT H p} ∈ 𝓝 (0,tc) :=
    (cw.eventually (lt_mem_nhds pw)).and (ct.eventually (lt_mem_nhds pt))
  obtain ⟨ε, he, hball⟩ := Metric.mem_nhds_iff.mp hpos
  let d := ε / 2
  let r := Real.sqrt d
  have hd : 0 < d := by dsimp [d]; linarith
  have hr : 0 < r := Real.sqrt_pos.mpr hd
  have hrsq : r ^ 2 = d := Real.sq_sqrt hd.le
  have h0 : (0 : ℝ) ∈ Icc 0 (r ^ 2) := left_mem_Icc.mpr (sq_nonneg r)
  have heR : r ^ 2 ∈ Icc 0 (r ^ 2) := right_mem_Icc.mpr (sq_nonneg r)
  have heT : tc ∈ Icc (tc-d) (tc+d) := ⟨by linarith, by linarith⟩
  have hrect (w t : ℝ) (hw : w ∈ Icc 0 (r^2)) (ht : t ∈ Icc (tc-d) (tc+d)) :
      0 < partialW H (w,t) ∧ 0 < partialT H (w,t) := by
    apply hball
    change max (dist w 0) (dist t tc) < ε
    rw [max_lt_iff, Real.dist_eq, Real.dist_eq, sub_zero, abs_of_nonneg hw.1, abs_lt]
    have hw' := hw.2
    rw [hrsq] at hw'
    obtain ⟨htl,htr⟩ := ht
    dsimp [d] at hw' htl htr
    exact ⟨by linarith, by linarith, by linarith⟩
  refine ⟨r, hr, local_pitchfork hr hd hcrit ?_ ?_ ?_ ?_ ?_⟩
  · intro t ht
    exact (differentiableAt_of_deriv_ne_zero (hrect 0 t h0 ht).2.ne').continuousAt.continuousWithinAt
  · intro t ht
    exact (hrect 0 t h0 (Ioo_subset_Icc_self ht)).2
  · exact (differentiableAt_of_deriv_ne_zero (hrect (r^2) tc heR heT).2.ne').continuousAt
  · intro t ht w hw
    exact (differentiableAt_of_deriv_ne_zero
      (hrect w t hw (Ioo_subset_Icc_self ht)).1.ne').continuousAt.continuousWithinAt
  · intro t ht w hw
    exact (hrect w t (Ioo_subset_Icc_self hw) (Ioo_subset_Icc_self ht)).1

theorem sign_reversal (h : ℝ → ℝ) (r : ℝ) : roots (fun w => -h w) r = roots h r := by
  ext s
  simp [roots]

/-- For both numerical rectangles, the mass derivative and the squared-amplitude
derivative after a common reorientation are strictly positive. The derivative
of the mass graph at zero is strictly negative in either orientation. -/
theorem certified_signs {A C : ℝ}
    (h : (A ∈ Icc (-1.156345486) (-1.156345485) ∧ C ∈ Icc (-18.273751235) (-18.273751232)) ∨
      (A ∈ Icc 1.560693022 1.560693023 ∧ C ∈ Icc 11.082693253 11.082693257)) :
    (∃ σ : ℝ, (σ = 1 ∨ σ = -1) ∧ 0 < σ * A ∧ 0 < σ * (C / 6)) ∧ -(C / (6 * A)) < 0 := by
  rcases h with ⟨⟨_, ha⟩, ⟨_, hc⟩⟩ | ⟨⟨ha, _⟩, ⟨hc, _⟩⟩
  · have hA : A < 0 := by linarith
    have hC : C < 0 := by linarith
    exact ⟨⟨-1, Or.inr rfl, by linarith, by linarith⟩, neg_lt_zero.mpr
      (div_pos_of_neg_of_neg hC (mul_neg_of_pos_of_neg (by norm_num) hA))⟩
  · have hA : 0 < A := by linarith
    have hC : 0 < C := by linarith
    exact ⟨⟨1, Or.inl rfl, by linarith, by linarith⟩, neg_lt_zero.mpr
      (div_pos hC (mul_pos (by norm_num) hA))⟩

private theorem partialW_neg (H : ℝ → ℝ → ℝ) :
    partialW (fun w t => -H w t) = fun p => - partialW H p := by
  funext p
  exact deriv.neg

private theorem partialT_neg (H : ℝ → ℝ → ℝ) :
    partialT (fun w t => -H w t) = fun p => - partialT H p := by
  funext p
  exact deriv.neg

/-- For either event, the certified interval membership, the identification
of these coefficients with the two partials, their continuity at the event,
and the vanishing condition imply the exact count in the original orientation. -/
theorem both_events {H : ℝ → ℝ → ℝ} {tc A C : ℝ}
    (hcrit : H 0 tc = 0)
    (cw : ContinuousAt (partialW H) (0,tc)) (ct : ContinuousAt (partialT H) (0,tc))
    (hw : partialW H (0,tc) = C / 6) (ht : partialT H (0,tc) = A)
    (hbox : (A ∈ Icc (-1.156345486) (-1.156345485) ∧ C ∈ Icc (-18.273751235) (-18.273751232)) ∨
      (A ∈ Icc 1.560693022 1.560693023 ∧ C ∈ Icc 11.082693253 11.082693257)) :
    ∃ r : ℝ, 0 < r ∧ Pattern H r tc := by
  obtain ⟨⟨σ, hσ, hA, hC⟩, _⟩ := certified_signs hbox
  rcases hσ with rfl | rfl
  · exact local_from_partials hcrit cw ct (by simpa [hw] using hC) (by simpa [ht] using hA)
  · obtain ⟨r, hr, hh⟩ := local_from_partials (H := fun w t => -H w t) (tc := tc)
      (by simp [hcrit]) (by rw [partialW_neg]; exact cw.neg) (by rw [partialT_neg]; exact ct.neg)
      (by simpa [partialW_neg, hw] using hC) (by simpa [partialT_neg, ht] using hA)
    refine ⟨r, hr, ?_⟩
    simpa only [Pattern, sign_reversal] using hh

/-- For the third event the two derivatives have opposite signs. Reflect the mass
coordinate to obtain the same theorem with the inequalities reversed. -/
theorem third_event {H : ℝ → ℝ → ℝ} {tc A C : ℝ}
    (hcrit : H 0 tc = 0)
    (cw : ContinuousAt (partialW H) (0,tc)) (ct : ContinuousAt (partialT H) (0,tc))
    (hw : partialW H (0,tc) = C / 6) (ht : partialT H (0,tc) = A)
    (hA : A ∈ Icc (-0.941439597) (-0.941439596))
    (hC : C ∈ Icc 2.336689820 2.336689821) :
    ∃ r : ℝ, 0 < r ∧ ∀ᶠ t in 𝓝 tc,
      (tc < t → ∃ a : ℝ, 0 < a ∧ a < r ∧ roots (fun w => H w t) r = {-a, 0, a} ∧
        (roots (fun w => H w t) r).ncard = 3) ∧
      (t ≤ tc → roots (fun w => H w t) r = {0}) := by
  let R := fun (w u : ℝ) => H w (-u)
  let S := fun (p : ℝ × ℝ) => (p.1, -p.2)
  have hS : ContinuousAt S (0,-tc) := by dsimp [S]; fun_prop
  have hSp : S (0,-tc) = (0,tc) := by simp [S]
  have hcw : ContinuousAt (partialW H) (S (0,-tc)) := hSp ▸ cw
  have hct : ContinuousAt (partialT H) (S (0,-tc)) := hSp ▸ ct
  have hW : partialW R = partialW H ∘ S := rfl
  have hT : partialT R = fun p => -(partialT H (S p)) := by
    funext p
    exact deriv_comp_neg (H p.1) p.2
  obtain ⟨r, hr, hh⟩ := local_from_partials (H := R) (tc := -tc) (by simpa [R] using hcrit)
    (by rw [hW]; exact hcw.comp hS) (by rw [hT]; exact (hct.comp hS).neg)
    (by rw [hW, Function.comp_apply, hSp, hw]; linarith [hC.1])
    (by simp only [hT, hSp, ht]; linarith [hA.2])
  refine ⟨r, hr, ?_⟩
  have hrev : Tendsto (fun t : ℝ => -t) (𝓝 tc) (𝓝 (-tc)) := continuous_neg.continuousAt
  unfold Pattern at hh
  filter_upwards [hrev.eventually hh] with t he
  constructor
  · intro hgt
    simpa only [R, neg_neg] using he.1 (neg_lt_neg hgt)
  · intro hle
    simpa only [R, neg_neg] using he.2 (neg_le_neg hle)

end Pitchfork
