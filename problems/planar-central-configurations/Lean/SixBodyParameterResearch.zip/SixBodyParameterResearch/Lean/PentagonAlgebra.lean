import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Data.Real.Basic

/-! Algebraic subcertificates for the critical six-body pentagon.
The Newtonian Hessian and the reduced Taylor coefficients are derived in
the accompanying SymPy scripts. Here Lean independently verifies the
polynomial identity for the critical value and the coefficient signs. -/

namespace PentagonCertificate

noncomputable def criticalMass (a : ℝ) : ℝ :=
  (-345208*a^3-320500*a^2+1180980*a+1216925)/247215

def massPolynomial (t : ℝ) : ℝ :=
  6674805*t^4-44892900*t^3+8565750*t^2+13531500*t+2057501

theorem criticalMass_is_root (a : ℝ) (ha : a^4-5*a^2+5=0) :
    massPolynomial (criticalMass a) = 0 := by
  unfold massPolynomial criticalMass
  linear_combination ((a*(a*(a*(a*(a*(a*(a*(14201146470405970333696*a + 52738840858440285184000) - 49880464062262413506560) - 363962830648588284160000) - 182379644331622991527680) + 624918257370297313280000) + 674656677003050828550400) + 10206528299118475200000) - 129756790752409379449600) / 559578076580125) * ha

noncomputable def fourthCoefficient (a : ℝ) : ℝ :=
  (63682593686398729372317891042824252*a^3 + 71045903435876823554645469291409900*a^2 - 228006467262605550151673239336091950*a - 262365777983766454200491198806859575)/4715341450595005257759613548684375

noncomputable def fifthCoefficient (a : ℝ) : ℝ :=
  (-73084863238269525188679365651046820375609507545625322*a^3 - 85199954715678587396895564732430466740583868695966168*a^2 + 263826982748892727002764241677912657712011258267701220*a + 309107170710330405530896826469179556859174379264512442)/176596903403330506052959812532863833710704982153125

theorem coefficientSigns (a : ℝ) (lo : 1 ≤ a) (hi : a ≤ 6/5) :
    1 < criticalMass a ∧ fourthCoefficient a < 0 ∧ 0 < fifthCoefficient a := by
  have hsq : a^2 ≤ 3/2 := by nlinarith only [mul_nonneg (sub_nonneg.mpr hi) (show 0 ≤ a+6/5 by linarith)]
  have hcub : a^3 ≤ 2 := by nlinarith only [mul_nonneg (sub_nonneg.mpr hi) (show 0 ≤ a^2 by positivity), hsq]
  unfold criticalMass fourthCoefficient fifthCoefficient
  refine ⟨?_, ?_, ?_⟩ <;> linarith only [lo, hsq, hcub]

end PentagonCertificate
