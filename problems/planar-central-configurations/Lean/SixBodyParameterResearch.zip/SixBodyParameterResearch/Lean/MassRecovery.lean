import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Tactic

/-! A marked sixth body sits at the origin. Relative accelerations give an
affine regression of a radial observable on the five inverse cubed radii. -/
noncomputable section
namespace MassRecovery
open scoped BigOperators

abbrev P := Fin 5 → ℝ
def rInv (x y : ℝ) := ((Real.sqrt (x^2 + y^2))^3)⁻¹
def s (x y : P) (i : Fin 5) := rInv (x i) (y i)
/-- The acceleration component of heavy i from the other heavy bodies. -/
def hub (m x y z : P) (i : Fin 5) :=
  ∑ j, m j * (z j-z i) * rInv (x j-x i) (y j-y i)
/-- The acceleration of the test body from the five heavy bodies. -/
def centerAcc (m x y z : P) := ∑ j, m j * z j * s x y j
def dx (m x y : P) (i : Fin 5) := hub m x y x i - centerAcc m x y x
def dy (m x y : P) (i : Fin 5) := hub m x y y i - centerAcc m x y y
def radial (m x y : P) (i : Fin 5) :=
  (dx m x y i*x i+dy m x y i*y i)/(x i^2+y i^2)
def wedge (m x y : P) (i : Fin 5) := x i * dy m x y i - y i * dx m x y i
/-- Heavy acceleration minus sixth-body acceleration equals -(multiplier) times
their displacement. At distinct positions these are Newton's relative CC equations. -/
def Relative (m x y : P) (t l : ℝ) :=
  ∀ i, dx m x y i - t*s x y i*x i = -l*x i ∧
       dy m x y i - t*s x y i*y i = -l*y i
def weight (X : P) : ℝ := 5*(∑ i, X i^2) - (∑ i, X i)^2
def numerator (X K : P) : ℝ := 5*(∑ i, X i*K i) - (∑ i, X i)*(∑ i, K i)

theorem radial_of_relative {m x y : P} {t l : ℝ} (h : Relative m x y t l)
    (hn : ∀ i, x i^2+y i^2 ≠ 0) :
    ∀ i, wedge m x y i = 0 ∧ radial m x y i = t*s x y i-l := by
  intro i
  obtain ⟨hx,hy⟩ := h i
  have h1 : dx m x y i = (t*s x y i-l)*x i := by linarith
  have h2 : dy m x y i = (t*s x y i-l)*y i := by linarith
  constructor
  · unfold wedge
    rw [h1,h2]
    ring
  · unfold radial
    rw [h1,h2]
    apply (div_eq_iff (hn i)).2
    ring

theorem relative_of_radial {m x y : P} {t l : ℝ}
    (hn : ∀ i, x i^2+y i^2 ≠ 0)
    (h : ∀ i, wedge m x y i=0 ∧ radial m x y i=t*s x y i-l) :
    Relative m x y t l := by
  intro i
  obtain ⟨hw, hk⟩ := h i
  unfold wedge at hw
  unfold radial at hk
  have hd := (div_eq_iff (hn i)).1 hk
  constructor
  · apply mul_right_cancel₀ (hn i)
    linear_combination (x i)*hd - (y i)*hw
  · apply mul_right_cancel₀ (hn i)
    linear_combination (y i)*hd + (x i)*hw

theorem weight_eq_central_squares (X : P) :
    weight X = (∑ i, (5*X i-(∑ j, X j))^2)/5 := by
  simp [weight, Fin.sum_univ_succ]
  ring

theorem positive_weight_of_distinct {X : P} (i j : Fin 5) (h : X i ≠ X j) :
    0 < weight X := by
  rw [weight_eq_central_squares]
  apply div_pos _ (by norm_num)
  apply Finset.sum_pos' (fun k _ => sq_nonneg _)
  by_cases hi : 5*X i-(∑ j, X j) = 0
  · refine ⟨j,Finset.mem_univ _,sq_pos_of_ne_zero ?_⟩
    intro hj
    apply h
    linarith
  · exact ⟨i,Finset.mem_univ _,sq_pos_of_ne_zero hi⟩

theorem affine_numerator {X K : P} {t l : ℝ} (hk : ∀ i, K i=t*X i-l) :
    numerator X K = t*weight X := by
  simp only [numerator,weight,hk,Fin.sum_univ_succ,Finset.univ_unique,
    Finset.sum_singleton]
  ring

theorem exact_mass_from_marked_shape {m x y : P} {t l : ℝ}
    (hn : ∀ i, x i^2+y i^2 ≠ 0) (h : Relative m x y t l)
    (i j : Fin 5) (hsep : s x y i ≠ s x y j) :
    t = numerator (s x y) (radial m x y) / weight (s x y) := by
  have ht := affine_numerator (t:=t) (l:=l)
    (fun i => (radial_of_relative h hn i).2)
  exact (eq_div_iff (positive_weight_of_distinct i j hsep).ne').2 ht.symm

/-- Two different positive choices of the sixth mass force all inverse-cube
radii to coincide. Positivity is not needed for this formal implication. -/
theorem two_masses_force_one_radius {m x y : P} {t₁ t₂ l₁ l₂ : ℝ}
    (hn : ∀ i, x i^2+y i^2 ≠ 0) (h₁ : Relative m x y t₁ l₁)
    (h₂ : Relative m x y t₂ l₂) (ht : t₁ ≠ t₂) :
    ∀ i j, s x y i = s x y j := by
  intro i j
  by_contra hsep
  exact ht ((exact_mass_from_marked_shape hn h₁ i j hsep).trans
    (exact_mass_from_marked_shape hn h₂ i j hsep).symm)

/-- An actual solution on a sphere about the sixth body persists at every
sixth mass, with the stated change of multiplier. -/
theorem common_radius_preserves_shape {m x y : P} {t l u : ℝ}
    (h : Relative m x y t l) (he : ∀ i, s x y i = u) (t' : ℝ) :
    Relative m x y t' (l+(t'-t)*u) := by
  intro i
  obtain ⟨hx,hy⟩ := h i
  rw [he i] at hx hy ⊢
  constructor
  · linear_combination hx
  · linear_combination hy

#print axioms two_masses_force_one_radius
#print axioms common_radius_preserves_shape
#print axioms exact_mass_from_marked_shape
#print axioms relative_of_radial
end MassRecovery
