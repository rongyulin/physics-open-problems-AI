import Mathlib

/-!
# Local cardinal bound without reflection symmetry

Repeated Rolle's theorem bounds arbitrary perturbations of a scalar germ whose
third derivative does not vanish. `encard` counts finite sets and takes the value
infinity for an infinite set, so the inequality also proves finiteness.
-/

noncomputable section
open Set Filter Topology

namespace Pitchfork

def third (f : ℝ → ℝ) := deriv (deriv (deriv f))

private theorem rolle_step {f : ℝ → ℝ} {l u a b : ℝ}
    (hc : ContinuousOn f (Ioo l u)) (ha : a ∈ Ioo l u) (hb : b ∈ Ioo l u)
    (hab : a < b) (hz : f a = f b) :
    ∃ v ∈ Ioo l u, a < v ∧ v < b ∧ deriv f v = 0 := by
  have hsub : Icc a b ⊆ Ioo l u := fun x hx => ⟨ha.1.trans_le hx.1, hx.2.trans_lt hb.2⟩
  obtain ⟨v, hv, hv'⟩ := exists_deriv_eq_zero hab (hc.mono hsub) hz
  exact ⟨v, ⟨ha.1.trans hv.1, hv.2.trans hb.2⟩, hv.1, hv.2, hv'⟩

private theorem no_four {f : ℝ → ℝ} {l u : ℝ}
    (hc : ContinuousOn f (Ioo l u)) (hc' : ContinuousOn (deriv f) (Ioo l u))
    (hc'' : ContinuousOn (deriv (deriv f)) (Ioo l u))
    (hn : ∀ x ∈ Ioo l u, third f x ≠ 0)
    {a b c d : ℝ} (ha : a ∈ Ioo l u) (hb : b ∈ Ioo l u)
    (hc0 : c ∈ Ioo l u) (hd : d ∈ Ioo l u)
    (hab : a < b) (hbc : b < c) (hcd : c < d)
    (za : f a = 0) (zb : f b = 0) (zc : f c = 0) (zd : f d = 0) : False := by
  obtain ⟨x, hx, _, hxb, hx'⟩ := rolle_step hc ha hb hab (za.trans zb.symm)
  obtain ⟨y, hy, hby, hyc, hy'⟩ := rolle_step hc hb hc0 hbc (zb.trans zc.symm)
  obtain ⟨z, hz, hcz, _, hz'⟩ := rolle_step hc hc0 hd hcd (zc.trans zd.symm)
  obtain ⟨v, hv, _, hvy, hv'⟩ := rolle_step hc' hx hy (hxb.trans hby) (hx'.trans hy'.symm)
  obtain ⟨w, hw, hyw, _, hw'⟩ := rolle_step hc' hy hz (hyc.trans hcz) (hy'.trans hz'.symm)
  obtain ⟨p, hp, _, _, hp'⟩ := rolle_step hc'' hv hw (hvy.trans hyw) (hv'.trans hw'.symm)
  exact hn p hp hp'

/-- Any scalar function satisfying the three slice continuity hypotheses and the
nonvanishing third derivative has at most three real roots in the interval. -/
theorem cubic_bound {f : ℝ → ℝ} {l u : ℝ}
    (hc : ContinuousOn f (Ioo l u)) (hc' : ContinuousOn (deriv f) (Ioo l u))
    (hc'' : ContinuousOn (deriv (deriv f)) (Ioo l u)) (hn : ∀ x ∈ Ioo l u, third f x ≠ 0) :
    {x ∈ Ioo l u | f x = 0}.encard ≤ 3 := by
  classical
  by_contra! hh
  have h4 : (4 : ℕ∞) ≤ {x ∈ Ioo l u | f x = 0}.encard :=
    (ENat.add_one_le_iff (show (3 : ℕ∞) ≠ ⊤ by simp)).mpr hh
  obtain ⟨s, hsub, hs⟩ := exists_subset_encard_eq h4
  have hfin : s.Finite := finite_of_encard_eq_coe (k := 4) hs
  have hcard : hfin.toFinset.card = 4 := by
    rw [hfin.encard_eq_coe_toFinset_card] at hs
    exact_mod_cast hs
  let e := hfin.toFinset.orderEmbOfFin hcard
  have hmem (i : Fin 4) : e i ∈ Ioo l u ∧ f (e i) = 0 :=
    hsub (hfin.mem_toFinset.mp (hfin.toFinset.orderEmbOfFin_mem hcard i))
  exact no_four hc hc' hc'' hn (hmem 0).1 (hmem 1).1 (hmem 2).1 (hmem 3).1
    (e.strictMono (by decide : (0 : Fin 4) < 1)) (e.strictMono (by decide : (1 : Fin 4) < 2))
    (e.strictMono (by decide : (2 : Fin 4) < 3)) (hmem 0).2 (hmem 1).2 (hmem 2).2 (hmem 3).2

/-- A critical scalar germ with nonzero third amplitude derivative has a uniform
three-root bound for every sufficiently small perturbation in a general parameter
space. This theorem also applies to parameters that break reflection symmetry. -/
theorem perturbations_bound {P : Type*} [TopologicalSpace P] (G : P → ℝ → ℝ)
    {pc : P} {z : ℝ}
    (hreg : ∀ᶠ q : ℝ × P in 𝓝 (z,pc), ContinuousAt (G q.2) q.1 ∧
      ContinuousAt (deriv (G q.2)) q.1 ∧ ContinuousAt (deriv (deriv (G q.2))) q.1)
    (hc : ContinuousAt (fun q : ℝ × P => third (G q.2) q.1) (z,pc))
    (hn : third (G pc) z ≠ 0) :
    ∃ l u : ℝ, z ∈ Ioo l u ∧ ∀ᶠ p in 𝓝 pc, {s ∈ Ioo l u | G p s = 0}.encard ≤ 3 := by
  have hne : ∀ᶠ q : ℝ × P in 𝓝 (z,pc), third (G q.2) q.1 ≠ 0 :=
    hc.eventually (isOpen_ne.mem_nhds hn)
  obtain ⟨U, hU, V, hV, hUV⟩ := mem_nhds_prod_iff.mp (hreg.and hne)
  obtain ⟨l, u, hz, hI⟩ := mem_nhds_iff_exists_Ioo_subset.mp hU
  refine ⟨l, u, hz, ?_⟩
  filter_upwards [hV] with p hp
  have hslice (s : ℝ) (hs : s ∈ Ioo l u) := hUV (Set.mk_mem_prod (hI hs) hp)
  apply cubic_bound
  · intro s hs; exact (hslice s hs).1.1.continuousWithinAt
  · intro s hs; exact (hslice s hs).1.2.1.continuousWithinAt
  · intro s hs; exact (hslice s hs).1.2.2.continuousWithinAt
  · intro s hs; exact (hslice s hs).2

end Pitchfork
