import Std

/-! Arithmetic replay for the off-axis exclusion, performed in the prime field
of order 61 with the cube root w=13. Coefficients are listed in ascending
order. The row tables are checked against the force-row norm formulas at 17
points. Their formal degrees are at most 8 and 16 respectively. A division
algorithm then tests all 256 gcds. -/
namespace FiveAxialArithmetic
private def add (a b : Nat) := (a+b)%61
private def mul (a b : Nat) := (a*b)%61
private def sub (a b : Nat) := (a+61-b%61)%61
private def sq (a : Nat) := mul a a
private def sg (m j : Nat) := if m.testBit j then 1 else 60
private def sum (l : List Nat) := l.foldl add 0
private def prod (l : List Nat) := l.foldl mul 1

-- B=b², C=c²; return the biquadratic norm of f+gb+uc+vbc.
private def norm (B C f g u v : Nat) : Nat :=
  let h := sub (add (sq f) (mul B (sq g))) (add (mul C (sq u)) (prod [B,C,sq v]))
  let j := mul 2 (sub (mul f g) (prod [C,u,v]))
  sub (sq h) (mul B (sq j))

private def forceRow (which mask a : Nat) : Nat :=
  let B := add (sq a) 12
  let C := add (sq a) 46
  let e := sg mask
  if which = 0 then
    let f := sub (mul 12 a) (sum [prod [14, add (sq a) B, add (e 0) (e 1)],
                                  prod [48, add (sq a) C, add (e 2) (e 3)]])
    let g := sub 0 (prod [2,a,14,sub (e 0) (e 1)])
    let u := sub 0 (prod [2,a,48,sub (e 2) (e 3)])
    norm B C f g u 0
  else
    let f := sub 0 (sum [prod [12,B,a], prod [4,B,e 0,14,add (sq a) B],
                         prod [4,B,60,add B C,add (e 2) (e 3)],mul 3 (e 1)])
    let g := sub (mul 60 B) (prod [8,B,e 0,14,a])
    let v := sub 0 (prod [8,B,60,sub (e 2) (e 3)])
    norm B C f g 0 v

private def rowsA : List (List Nat) := [
  [15, 2, 15, 4, 44, 38, 27, 22, 12],
  [58, 55, 17, 33, 35, 12, 37, 36, 25],
  [58, 55, 17, 33, 35, 12, 37, 36, 25],
  [22, 6, 9, 14, 28, 33, 36, 13, 47],
  [42, 6, 28, 45, 42, 46, 2, 20, 25],
  [0, 0, 0, 0, 35, 0, 55, 0, 25],
  [0, 0, 0, 0, 35, 0, 55, 0, 25],
  [42, 55, 28, 16, 42, 15, 2, 41, 25],
  [42, 6, 28, 45, 42, 46, 2, 20, 25],
  [0, 0, 0, 0, 35, 0, 55, 0, 25],
  [0, 0, 0, 0, 35, 0, 55, 0, 25],
  [42, 55, 28, 16, 42, 15, 2, 41, 25],
  [22, 55, 9, 47, 28, 28, 36, 48, 47],
  [58, 6, 17, 28, 35, 49, 37, 25, 25],
  [58, 6, 17, 28, 35, 49, 37, 25, 25],
  [15, 59, 15, 57, 44, 23, 27, 39, 12]]
private def rowsB : List (List Nat) := [
  [12, 41, 29, 22, 11, 31, 37, 56, 38, 42, 7, 30, 24, 7, 43, 42, 58],
  [42, 40, 51, 23, 25, 32, 27, 52, 11, 44, 46, 0, 26, 48, 7, 53, 9],
  [45, 46, 4, 7, 53, 30, 57, 25, 19, 20, 21, 36, 36, 7, 43, 42, 58],
  [52, 49, 34, 13, 56, 9, 39, 30, 32, 2, 30, 60, 21, 48, 7, 53, 9],
  [60, 54, 19, 1, 48, 14, 52, 5, 43, 37, 18, 39, 2, 13, 18, 43, 41],
  [20, 53, 45, 17, 30, 15, 43, 5, 4, 29, 18, 27, 50, 48, 18, 18, 41],
  [20, 8, 45, 44, 30, 46, 43, 56, 4, 32, 18, 34, 50, 13, 18, 43, 41],
  [60, 7, 19, 60, 48, 47, 52, 56, 43, 24, 18, 22, 2, 48, 18, 18, 41],
  [60, 54, 19, 1, 48, 14, 52, 5, 43, 37, 18, 39, 2, 13, 18, 43, 41],
  [20, 53, 45, 17, 30, 15, 43, 5, 4, 29, 18, 27, 50, 48, 18, 18, 41],
  [20, 8, 45, 44, 30, 46, 43, 56, 4, 32, 18, 34, 50, 13, 18, 43, 41],
  [60, 7, 19, 60, 48, 47, 52, 56, 43, 24, 18, 22, 2, 48, 18, 18, 41],
  [52, 12, 34, 48, 56, 52, 39, 31, 32, 59, 30, 1, 21, 13, 7, 8, 9],
  [45, 15, 4, 54, 53, 31, 57, 36, 19, 41, 21, 25, 36, 54, 43, 19, 58],
  [42, 21, 51, 38, 25, 29, 27, 9, 11, 17, 46, 0, 26, 13, 7, 8, 9],
  [12, 20, 29, 39, 11, 30, 37, 5, 38, 19, 7, 31, 24, 54, 43, 19, 58]]
private def evalPoly (p : List Nat) (a : Nat) := p.foldr (fun v r => add v (mul a r)) 0
private def tablesCorrect (which : Nat) (rows : List (List Nat)) :=
  rows.length == 16 && (List.range 16).all (fun i => (List.range 17).all (fun a =>
    evalPoly rows[i]! a == forceRow which i a))

private def inverses : Array Nat := (List.range 61).map (fun a =>
  (List.range 61).find? (fun b => mul a b == 1) |>.getD 0) |>.toArray
private def trim (p : List Nat) := (p.reverse.dropWhile (· == 0)).reverse
private def residue : Nat → List Nat → List Nat → List Nat
  | 0, p, _ => trim p
  | fuel+1, p, q =>
      if q.isEmpty || p.length < q.length then p else
        let c := mul p.getLast! inverses[q.getLast!]!
        let aligned := List.replicate (p.length - q.length) 0 ++ q.map (mul c)
        residue fuel (trim (List.zipWith sub p aligned)) q
private def unitGcd : Nat → List Nat → List Nat → Bool
  | 0, _, _ => false
  | fuel+1, p, q => if q.isEmpty then p.length == 1 && p.head! != 0 else
      let r := residue (p.length+1) p q
      (r.length < q.length) && unitGcd fuel q r

set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
/-- Every tabulated polynomial agrees with the force-row formula on 17 points. -/
theorem force_tables_match : tablesCorrect 0 rowsA && tablesCorrect 1 rowsB = true := by decide +kernel
/-- Both leading coefficients are nonzero for every sign choice. -/
theorem degrees_preserved : rowsA.all (fun p => p.length == 9 && p.getLast! != 0) &&
    rowsB.all (fun p => p.length == 17 && p.getLast! != 0) = true := by decide +kernel
/-- All 256 pairs have a nonzero constant as their last Euclidean remainder. -/
theorem gcd_sweep : rowsA.all (fun p => rowsB.all (fun q => unitGcd 26 p q)) = true := by decide +kernel
#print axioms force_tables_match
#print axioms gcd_sweep
end FiveAxialArithmetic
