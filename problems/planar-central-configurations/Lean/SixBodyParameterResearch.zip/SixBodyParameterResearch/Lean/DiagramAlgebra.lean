import Mathlib.Tactic.Ring

/- Factorizations for the projected shape equation in Tomar, §6.4.
   Formal variables and coefficients are interpreted in any commutative ring. -/
namespace ShapeAlgebra
variable {R : Type*} [CommRing R]
def E (z : R) := z^2-z+1
def L (z : R) := E z * (z^4-5*z^3+9*z^2-5*z+1) *
  (z^4+z^3-2*z+1)*(z^4-2*z^3+z+1)
def signedShape (k z a b : R) := 2*(z-1)^3*z^2 + (z-1)^2*z^2 +
  a*k*(z-1)^3 - b*k*z^3 - a*(z-1)^2 - b*z^2
def raw (k z : R) := L z * signedShape k z 1 1 * signedShape k z 1 (-1) *
  signedShape k z (-1) 1 * signedShape k z (-1) (-1)
def mixed (k z : R) := L z *
 (2*z^5-5*z^4+4*z^3-(3*k+3)*z^2+(3*k+2)*z-(k+1)) *
 (z^4-2*z^3+(k+1)*z^2-k*z+k+1) *
 (2*z^5-5*z^4+4*z^3+(3*k+1)*z^2-(3*k+2)*z+k+1) *
 (z^2-z-k-1)
def equal (z : R) := L z *
 (2*z^4-z^3+2*z^2-2*z+1)*(z^4-2*z^3+2*z^2-z+2)*
 (2*z^4-7*z^3+11*z^2-7*z+2)

set_option maxHeartbeats 0 in
theorem mixed_factor (k z : R) :
 raw k z = (2*z-1)^2*E z*mixed k z := by
  unfold raw mixed signedShape
  generalize L z = common
  unfold E
  ring

set_option maxHeartbeats 0 in
theorem equal_factor (z : R) :
 raw 1 z = (2*z-1)^2*E z*(z+1)^2*(z-2)^2*equal z := by
  unfold raw equal signedShape
  generalize L z = common
  unfold E
  ring

def torque (a b c : R) := a^2+b^2+c^2-2*(a*b+b*c+c*a)
theorem equal_torque (z : R) :
 torque ((z-2)*(1-2*z)) ((1+z)*(1-2*z)) ((1+z)*(z-2)) = 9*(E z)^2 := by
  unfold torque E
  ring

#print axioms mixed_factor
#print axioms equal_factor
#print axioms equal_torque
end ShapeAlgebra
