"""Bound the O(2) symmetries acting on all certified restricted roots.

Usage: python3 check_orbits.py /path/to/seeds.txt
Input must be the same as for the independently executed primary and restricted
certificates. This check uses only fractions and an upper bound on the error.
"""
from fractions import Fraction as Q
from pathlib import Path
from math import isqrt
from hashlib import sha256
import sys
from collections import Counter


class I:
    def __init__(self,lo,hi=None):
        self.lo=Q(lo); self.hi=Q(lo if hi is None else hi)
        if self.lo>self.hi: raise ValueError('inverted interval')

    def __add__(x,y):
        return I(x.lo+y.lo,x.hi+y.hi)

    def __neg__(x):
        return I(-x.hi,-x.lo)

    def __sub__(x,y):
        return x + (-y)

    def __mul__(x,y):
        products=[a*b for a in (x.lo,x.hi) for b in (y.lo,y.hi)]
        return I(min(products),max(products))

    def __truediv__(x,y):
        if y.lo*y.hi<=0: raise ValueError('division through zero')
        return x * I(1/y.hi,1/y.lo)

    def sqrt(x):
        assert x.lo>0
        S=10**30
        def down(q): return isqrt(q.numerator*S*S//q.denominator)
        return I(Q(down(x.lo),S),Q(down(x.hi)+1,S))

    def inside(x,y): return y.lo<=x.lo and x.hi<=y.hi

    def overlaps(x,y):
        return max(x.lo,y.lo)<=min(x.hi,y.hi)


def image(matrix,p):
    return tuple(row[0]*p[0]+row[1]*p[1] for row in matrix)


def if_permutation(matrix, boxes):
    perm=[]
    for p in boxes:
        x,y=image(matrix,p)
        candidates=[i for i,(x2,y2) in enumerate(boxes)
                    if x.overlaps(x2) and y.overlaps(y2)]
        if not candidates: return None
        if len(candidates)>1: raise AssertionError('unresolved image')
        perm.append(candidates[0])
    if sorted(perm)!=list(range(len(boxes))): return None
    return tuple(perm)


def count_orbits(actions,n):
    # On certified data every true action occurs. Check group closure as an
    # independent check of labels and computed permutations.
    perms={p for sig,p in actions}
    assert tuple(range(n)) in perms
    for p in perms:
        for q in perms: assert tuple(p[i] for i in q) in perms
    return sorted([len({p[i] for p in perms}) for i in range(n)
                   if min(p[i] for p in perms)==i])


def analyze(name, original, q, roots, expected):
    # q encloses the actual primary root with the sharper a posteriori radius.
    # An O(2) symmetry sends some q[j] to the positive horizontal fourth primary.
    # Rotate that q[j] onto the positive x-axis; there are two determinant signs.
    # The proposed map need not a priori be a symmetry: prove it by primary
    # uniqueness after relabelling in the original nine-dimensional gauge box.
    assert q[3][0].lo>0
    q[3]=(q[3][0],I(0)); original[3]=(original[3][0],I(0))
    actions=[]
    for sign in (1,-1):
        for j,(h,k) in enumerate(q):
            if h.overlaps(I(0)) and k.overlaps(I(0)):
                # This tiny-radius primary cannot map to q[3].
                assert (h*h+k*k).hi < (q[3][0]*q[3][0]).lo
                continue
            radius=(h*h+k*k).sqrt()
            if not radius.overlaps(q[3][0]): continue
            c,s=h/radius,k/radius
            matrix=((c,s),(-s if sign==1 else s,c if sign==1 else -c))
            images=[image(matrix,p) for p in q]
            # R(q[j])=(|q[j]|,0) is an exact identity for the true positions.
            images[j]=(radius,I(0))
            perm=[]
            possible=True
            for (x,y) in images:
                candidates=[i for i,(a,b) in enumerate(original) if x.overlaps(a) and y.overlaps(b)]
                if not candidates: possible=False; break
                assert len(candidates)==1
                i=candidates[0];a,b=original[i]
                # Overlap only gives a candidate; require strict inclusion on
                # every independent coordinate for a POSITIVE symmetry proof.
                assert x.inside(a) and y.inside(b)
                perm.append(i)
            if not possible: continue
            assert sorted(perm)==list(range(5)) and perm[j]==3
            p=if_permutation(matrix,roots)
            assert p is not None
            actions.append((sign,p))
    assert (len([1 for s,_ in actions if s==1]),len([1 for s,_ in actions if s==-1]))==expected
    allorbits=count_orbits(actions,len(roots))
    posorbits=count_orbits([(s,p) for s,p in actions if s==1], len(roots))
    print(name, 'orbits:', allorbits, 'orient-preserving:', posorbits,
          'fixed-point counts by det:',[(s, sorted(sum(i==j for i,j in enumerate(p)) for sig,p in actions if sig==s)) for s in (1,-1)])
    return len(allorbits),len(posorbits)


def main():
    if not __debug__: raise RuntimeError('run without -O')
    path=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name('seeds.txt')
    tokens=path.read_text().split()
    if sha256(" ".join(tokens).encode()).hexdigest() != "73ce6efe526a367f6b837c47a90e637a542ec4d9a3b417e915b29eb9a9486397":
        raise ValueError("this input differs from the audited restricted and primary certificate data")
    words=iter(tokens)
    def point(radius):
        co=[Q(int(next(words)),10**12) for _ in range(2)]
        return tuple(I(v-radius,v+radius) for v in co)
    # Restricted boxes from the GMP checker have halfwidth 2^-14 plus at most
    # one 2^-72 rounding error on either side of the exact decimal center.
    found={}; reflected=0; oriented=0
    groups={'line':(2,2),'square_center':(4,4),'two_triangles':(1,1),
            'trapezium':(1,1),'pentagon':(5,5)}
    for name in words:
        assert name not in found
        n=int(next(words));q=[point(Q(1,10**11)) for _ in range(5)]
        roots=[point(Q(1,2**14)+Q(1,2**72)) for _ in range(n)]
        # All five primary certificates give beta≤488e-15 and L≤14924e-12.
        # Banach yields ||q-c||∞ ≤ beta/(1-L) < 5e-13.
        assert Q(488,10**15)/(1-Q(14924,10**12)) < Q(5,10**13)
        def sharpen(x):
            center=(x.lo+x.hi)/2
            return I(center-Q(5,10**13),center+Q(5,10**13))
        tight=[tuple(sharpen(x) for x in pos) for pos in q]
        found[name]=analyze(name,q,tight,roots,groups[name]); reflected+=found[name][0];oriented+=found[name][1]
    assert set(found)==set(groups)
    print('Total O(2) orbits:',reflected,'; Total SO(2) orbits:',oriented)
    assert reflected==27 and oriented==35


if __name__=='__main__': main()
