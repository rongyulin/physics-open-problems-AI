"""Refine the two published endpoint catalogues by the stabilizer of a marked body.
Usage: python symmetry_counts.py /path/to/extracted/SixBodyResearch
Requires Python 3, and the certified coordinate boxes from the three-paper release.
"""
import argparse
import hashlib
import json
import sys
from collections import Counter
from fractions import Fraction as Q
from pathlib import Path


def coordinates(centres, radius):
    return [tuple(I(x-radius, x+radius) for x in point) for point in centres]


def match_symmetries(points, wide_radius, tight_radius, anchor, satellites=None):
    wide = coordinates(points, wide_radius)
    tight = coordinates(points, tight_radius)
    assert points[anchor][1] == 0 and tight[anchor][0].lo > 0
    wide[anchor] = wide[anchor][0], I(0)
    tight[anchor] = tight[anchor][0], I(0)
    group = []
    for j, (x,y) in enumerate(tight):
        if x.overlaps(I(0)) and y.overlaps(I(0)):
            assert (x*x+y*y).hi < (tight[anchor][0]*tight[anchor][0]).lo
            continue
        r = (x*x+y*y).sqrt()
        if not r.overlaps(tight[anchor][0]):
            continue
        c, s = x/r, y/r
        for sign in (1,-1):
            matrix = ((c,s), (-s,c) if sign == 1 else (s,-c))
            images = [image(matrix,p) for p in tight]
            images[j] = (r,I(0))
            perm = []
            for a,b in images:
                options = [k for k,(h,v) in enumerate(wide) if a.overlaps(h) and b.overlaps(v)]
                if not options:
                    break
                assert len(options)==1
                k, = options
                assert a.inside(wide[k][0]) and b.inside(wide[k][1])
                perm.append(k)
            if len(perm) != len(points):
                continue
            assert sorted(perm)==list(range(len(points))) and perm[j]==anchor
            act = if_permutation(matrix,satellites) if satellites is not None else tuple(perm)
            assert act is not None
            group.append((sign,tuple(perm),act))
    group_set=set(group)
    assert len(group_set)==len(group)
    for sign,p,a in group:
        for sig,q,b in group:
            assert (sign*sig,tuple(p[j] for j in q),tuple(a[j] for j in b)) in group_set
    return group


def mark(group, additional):
    counts=Counter()
    number=len(group[0][2])
    for i in range(number):
        if min(a[i] for _,_,a in group)!=i:
            continue
        stab=[(s,p) for s,p,a in group if a[i]==i]
        rot=sum(s==1 for s,p in stab)
        fixed={sum(k==j for k,j in enumerate(p))+int(additional) for s,p in stab if s==-1}
        if not fixed:
            kind="chiral"
        elif rot==5 and fixed=={2}:
            kind="pentagon"
        else:
            assert rot==1 and len(fixed)==1
            kind={2:"axis2",4:"axis4",6:"line"}[fixed.pop()]
        counts[kind]+=1
    return counts


def read_checked(path,digest):
    data=path.read_bytes()
    assert hashlib.sha256(data).hexdigest()==digest
    return data.decode()


def run(base):
    seed=read_checked(base/'certificates/restricted/seeds.txt','9f420465acb26b9f5187b589e946fd5af1038722d4462105cb26b4f4ba9b6854')
    data=iter(seed.split())
    small=Counter()
    for family in data:
        n=int(next(data))
        def take(k):
            return [[Q(int(next(data)),10**12) for _ in range(2)] for _ in range(k)]
        p, sat=take(5),take(n)
        g=match_symmetries(p,Q(1,10**11),Q(5,10**13),3,coordinates(sat,Q(1,2**14)+Q(1,2**72)))
        result=mark(g,True)
        print('small',family,dict(result))
        small.update(result)
    six=json.loads(read_checked(base/'certificates/hampton/six_centers.json','6abed39804836913d2ab83787d18a5cebc473025852888b9e6cfd463232fe7f3'))
    one=Counter()
    for family,p in six.items():
        g=match_symmetries([[Q(a),Q(b)] for a,b in p],Q(1,10**12),Q(1,10**14),4)
        result=mark(g,False)
        print('equal',family,dict(result))
        one.update(result)
    weights={'line':120,'axis4':120,'axis2':120,'pentagon':24,'chiral':240}
    for name,data in [('small',small),('equal',one)]:
        print(name,{k:data[k] for k in weights},'labelled:',sum(data[k]*w for k,w in weights.items()))
    return small,one


if __name__=='__main__':
    if not __debug__:
        raise RuntimeError('run without Python optimization')
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('release_root',type=Path)
    base=cli.parse_args().release_root.resolve()
    sys.path.insert(0,str(base/'certificates/primaries'))
    from check_orbits import I, image, if_permutation
    run(base)
