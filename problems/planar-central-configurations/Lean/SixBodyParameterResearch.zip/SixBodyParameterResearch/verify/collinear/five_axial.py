"""Exact exclusion test for five collinear signed heavy bodies and an off-axis sixth.
Python 3, SymPy. Norms and gcds are univariate over the cyclotomic field Q(zeta_3).
"""
from itertools import combinations, product
from functools import lru_cache
import sys
from sympy import QQ, GF, sqrt
from sympy.polys.rings import ring

if len(sys.argv)>1:
    p=int(sys.argv[1]); D=GF(p); w=next(D(i) for i in range(2,p) if (i*i+i+1)%p==0)
else:
    w0=(-1+sqrt(-3))/2; D=QQ.algebraic_field(w0); w=D.from_sympy(w0)
R,a=ring('a',D); un=R.one; zero=R.zero; w=R.ground_new(w)
A=a*a; B=A+w-1; C=A+w*w-1
zero4=(zero,zero,zero,zero)
def scalar(x): return (x,zero,zero,zero)
def plus(x,y): return tuple(v+z for v,z in zip(x,y))
def times(s,x): return tuple(s*v for v in x)
def mult(x,y):
    r=list(zero4)
    for i,vi in enumerate(x):
        for j,vj in enumerate(y):
            if vi and vj:
                r[i^j] += vi*vj*(B if i&j&1 else un)*(C if i&j&2 else un)
    return tuple(r)
def norm(x):
    f,g,h,k=x
    return ((f*f+B*g*g-C*h*h-B*C*k*k)**2 - B*(2*f*g-2*C*h*k)**2)
coords=[scalar(a),(zero,un,zero,zero),(zero,-un,zero,zero),(zero,zero,un,zero),(zero,zero,-un,zero)]
shell=[0,1,1,2,2]; delta=[None,B,C]; coeff={(0,1):-w*w,(0,2):-w,(1,2):-un}
pairs=list(combinations(range(5),2))
@lru_cache(None)
def row(i,sgns):
    radial= delta[shell[i]] if i else None
    mult0=4*radial if i else un
    F=times(3*mult0,plus(times(5*un,coords[i]),scalar(-a)))
    for j,e in zip([j for j in range(5) if j!=i],sgns):
        if shell[i]==shell[j]:
            F=plus(F,scalar(-3*e*un))
        else:
            z=plus(coords[i],coords[j]); W=coeff[tuple(sorted([shell[i],shell[j]]))]
            F=plus(F,times(-e*mult0*W,mult(z,z)))
    return norm(F)

def main():
    # Each of the two necessary force rows has four signs. Checking them
    # independently also covers sign choices inconsistent along the shared edge.
    masks=list(product((1,-1), repeat=4))
    first=[row(0,signs) for signs in masks]
    second=[row(1,signs) for signs in masks]
    from collections import Counter
    degrees=Counter(int(f.gcd(g).degree()) for f in first for g in second)
    print('coefficient field:',D)
    print('row polynomial degrees:',sorted({int(f.degree()) for f in first}),
          sorted({int(f.degree()) for f in second}))
    print('gcd degrees for all 256 pairs:',dict(degrees))
    assert degrees=={0:256}

if __name__=='__main__': main()
