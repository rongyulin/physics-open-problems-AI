# Two six-body pitchforks and their cusp unfoldings

The six Newtonian masses have ratios `(1, 1, 1, 1, 1, t)`. At each of two certified, reflection-symmetric configurations the count of nearby labelled shapes, up to orientation-preserving similarity, changes from three to one as `t` increases through the indicated value. At the critical value the unique nearby shape is degenerate and isolated. The two additional shapes below the threshold have no line of reflection symmetry.

| Position of body 5 among the four axial bodies (left to right in the chosen chart) | Critical mass ratio, rounded | Quadratic coefficient of mass along the asymmetric branches |
|---|---:|---:|
| Second | 0.089353633682323 | −1.18352265 |
| First | 0.175165824529870 | −2.63383673 |

Small independent perturbations of all six masses preserve a local upper bound of three solutions near either configuration. When the reflected pair is assigned masses proportional to `1+δ` and `1−δ`, the physical parameters `(t, δ)` give a cusp unfolding. The proof and counting convention are in `Pitchfork.pdf`; `Pitchfork.tex` is its self-contained source. These conclusions concern neighbourhoods of the certified shapes. Finiteness of the entire fibre for a given mass ratio requires a separate argument for all other configurations.

## Reproduce the certificate

With Python 3.8 or later, run the following command in this directory.

```sh
python3 verify.py
```

`inner.json` and `data.json` store decimal-rational box centres and preconditioners for the inner and outer cases respectively. The verifier checks both in one run. It uses integer endpoints with outward rounding, including integer square roots, and has no third-party dependencies. It checks the twelve-equation contraction estimate, noncollision and gauge conditions, invertibility of the even and bordered odd linear systems, and the mixed, cubic and symmetry-breaking derivatives of the reduced force. The signed coefficients vary with the choice of kernel and cokernel coordinates. The mass ratio and the geometric type of the bifurcation are invariant. `results.txt` records the complete stdout from a successful run.

Compile the paper by running `pdflatex Pitchfork.tex` twice. All equations use zero-based particle indices: the first five masses, indexed 0 to 4, equal one on the symmetry line, and particle 5 has mass ratio `t`.
