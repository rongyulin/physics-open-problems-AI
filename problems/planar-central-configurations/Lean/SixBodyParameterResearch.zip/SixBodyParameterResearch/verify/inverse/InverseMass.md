# Recovering the sixth mass from a marked planar shape

Fix five positive masses $a_1,\ldots,a_5$. The positions, including the distinguished sixth position, are given up to a common translation, orthogonal transformation and positive scale. The labels of the five known masses are retained (or permuted together with their values). The unknown mass is $t>0$. Every assertion below concerns a collision-free planar Newtonian central configuration. The normalization of the position scale need not be fixed.

## The inverse formula and residual equations

Translate the sixth body to the origin and write $x_i=q_i-q_6$ for $1\le i\le5$. Let

$$
s_i=|x_i|^{-3},\quad
A=\sum_{j=1}^5 a_jx_j s_j,\quad
H_i=\sum_{j\ne i} a_j(x_j-x_i)|x_j-x_i|^{-3}.
$$

The absolute accelerations are $A$ for the sixth body and $H_i-ts_ix_i$ for body $i$. Hence their differences have the required central form precisely when
$$
H_i-A=(ts_i-\lambda)x_i .
$$
This relative form is sufficient: every acceleration has the form $-\lambda q_i+d$ for a common vector $d$, and pairwise-force cancellation implies $d=\lambda c$ at the actual center of mass $c$. For positive masses $\lambda=U/I>0$ by the Newtonian virial identity, with $I=\sum m_i|q_i-c|^2$.

Set $K_i=(H_i-A)\cdot x_i/|x_i|^2$. The five relative equations are equivalent to $x_i\wedge(H_i-A)=0$ and $K_i=ts_i-\lambda$ for all $i$. If $s_i\ne s_j$, this gives the explicit value
$$
t=\frac{K_i-K_j}{s_i-s_j}.
$$

A permutation-invariant choice avoiding case splits is
$$
D=5\sum_i s_i^2-(\sum_i s_i)^2=\sum_{i<j}(s_i-s_j)^2,
\qquad N=5\sum_i s_iK_i-(\sum_i s_i)(\sum_i K_i).
$$
At $D>0$ the answer is $t=N/D$. Under scaling all positions by $h$, each $s_i$ and $K_i$ scales by $h^{-3}$, so the mass is determined by the shape. The necessary and sufficient **shape-only** conditions at $D>0$ are the five wedges, $N>0$, and
$$
D(5K_i-\sum_jK_j)=N(5s_i-\sum_js_j)\quad(i=1,\ldots,5).
$$
Indeed these identities imply $K_i=ts_i-\lambda$ with $t=N/D$ and $\lambda=(t\sum_i s_i-\sum_i K_i)/5$. Multiplying through by positive distances yields semialgebraic conditions. A prescribed mass is enforced by the extra equation $N-tD=0$.

## Classifying the denominator-zero geometry for all positive primary masses

Suppose $D=0$ and that the shape solves the central-configuration equations at some positive $t$. All five radii are $R>0$, with $s=R^{-3}$. Let $M=\sum_i a_i$ and $c=M^{-1}\sum_i a_i x_i$ be the primary barycenter, and put $\gamma=\lambda-ts$. Then $A=sMc$ and $H_i=A-\gamma x_i$. Summing with weights $a_i$ and using $\sum a_iH_i=0$ gives $A=\gamma c$ and
$$
H_i=-\gamma(x_i-c),\qquad (\gamma-Ms)c=0.
$$
In particular, the five primaries are themselves a central configuration, so $\gamma>0$ by their own virial identity. If $c\ne0$, then $\gamma=M/R^3$ and $R=(M/\gamma)^{1/3}$. Proposition 2 of Yu and Zhu shows that every co-circular five-body central configuration satisfies the **strict opposite to equality**, $R<(M/\gamma)^{1/3}$. Thus $c=0$. The five primary bodies now form a centered co-circular Newtonian central configuration. Wang's theorem for $n\le6$ states that such a figure is a regular polygon and that its masses are equal. Conversely, a regular pentagon of equal masses with the marked sixth body at its center is central for every positive value of that sixth mass.

Therefore even when the five known masses are arbitrary, the regular pentagon with the sixth body at its center is the only marked six-body shape that can occur at two different values of the sixth mass. This assertion is a deduction from the relative acceleration equations and existing classification theorems. No bibliographic priority claim is made. It is a uniqueness theorem for the **inverse** problem, and does not bound the number of different shapes at a fixed mass. The shape-only residual equations above give a smaller system to attack that remaining question. The denominator-zero argument works without change for four or six primaries, using the same two cited theorems.

## Verification and sources

- The accompanying Lean source implements the five primary accelerations and the sixth acceleration in Cartesian coordinates. It checks radial/wedge equivalence, positivity of the variance when two inverse radii differ, and the mass formula against those actual expressions. The geometric classification at $D=0$ uses the cited papers. Compilation is with Lean 4.28.0 and Mathlib.
- Xiang Yu and Shuqiang Zhu, *Classification of stacked central configurations in $\mathbb R^3$*, Proposition 2 and §4.4. The proposition gives $R<(M/\gamma)^{1/3}$ at four, five and six bodies. Their extension classification connects this inequality to planar stacked configurations. [Preprint](https://arxiv.org/pdf/1812.00200)
- Zhiqiang Wang, *On the centered co-circular central configurations for the n-body problem*, Journal of Differential Equations 361 (2023), 376–390. The Newtonian result applies through six bodies, allowing arbitrary positive masses as input. [Journal article](https://doi.org/10.1016/j.jde.2023.02.066)
- J. M. Cors, G. R. Hall and G. E. Roberts, *Uniqueness results for co-circular central configurations for power-law potentials*, Physica D 280–281 (2014), 44–47. The centered co-circular result for equal masses is sufficient when the five known masses are all specified to be equal. [Journal article](https://doi.org/10.1016/j.physd.2014.05.003)
