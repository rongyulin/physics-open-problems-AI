"""Rational interval certification of the symmetric degeneracy and cubic coefficient."""
from fractions import Fraction as Q
from math import isqrt
from pathlib import Path
import json

D=10**42
class I:
 def __init__(self,l,h=None):
  self.l=l;self.h=l if h is None else h
 def __add__(s,t):
  t=ii(t);return I(s.l+t.l,s.h+t.h)
 __radd__=__add__
 def __neg__(s):return I(-s.h,-s.l)
 def __sub__(s,t):return s+-ii(t)
 def __rsub__(s,t):return ii(t)+-s
 def __mul__(s,t):
  t=ii(t);vals=(s.l*t.l,s.l*t.h,s.h*t.l,s.h*t.h);return I(min(vals)//D,-(-max(vals)//D))
 __rmul__=__mul__
 def inv(s):
  if s.l<=0<=s.h:raise ArithmeticError("zero divisor")
  return I(D*D//s.h,-(-D*D//s.l))
 def root(s):
  if s.l<0:raise ArithmeticError("negative lower sqrt")
  a=isqrt(s.h*D);return I(isqrt(s.l*D),a+(a*a!=s.h*D))
 def mid(s):return Q(s.l+s.h,2*D)
 def norm(s):return max(-s.l,s.h)
def ii(x):
 if isinstance(x,I):return x
 a=Q(x)*D;return I(a.numerator//a.denominator,-(-a.numerator//a.denominator))
O=ii(0);E=ii(1)
def pack(q):return [c for j,p in enumerate(q) for b,c in enumerate(p) if (j,b)!=(3,1)]
def positions(q):
 a=list(q);a.insert(7,O);return [a[k:k+2] for k in range(0,12,2)]
def plus(z):
 return [[z[0],z[1]],[z[2],z[3]],[z[0],-z[1]],[z[4],O],[z[2],-z[3]],[z[5],O]]
def minus(z):
 return [[z[0],z[1]],[z[2],z[3]],[-z[0],z[1]],[O,O],[-z[2],z[3]],[O,z[4]]]
def xp(p):return p[0]+p[1]+[p[3][0],p[5][0]]
def xm(p):return p[0]+p[1]+[p[5][1]]
def add(a,b):return [x+y for x,y in zip(a,b)]
def mult(a,c):return [x*c for x in a]
def sub(a,b):return [x-y for x,y in zip(a,b)]
def dot(a,b):return sum((x*y for x,y in zip(a,b)),O)
def unit(n,j):return [E if k==j else O for k in range(n)]
def transpose(a):return list(map(list,zip(*a)))
def matvec(A,v):return [dot(r,v) for r in A]
def imat(A):return [[ii(a) for a in row] for row in A]
def field(p,t,derivatives=(),dt=False,split=False):
 """F or a positional directional derivative of F; dt differentiates in t."""
 n=len(derivatives)
 m=[ii(Q(1,5))]*5+[t*Q(1,5)] if not dt else [O]*5+[ii(Q(1,5))]
 if split:
  m=[O,ii(Q(1,5)),O,O,ii(Q(-1,5)),O]
 mat=p if n==0 else derivatives[0] if n==1 else None
 out=[[z for z in row] for row in mat] if not dt and not split and n<=1 else [[O,O] for _ in range(6)]
 for i in range(6):
  for j in range(i):
   d=sub(p[i],p[j]); rr=dot(d,d); inv=rr.inv(); h=inv*inv.root()
   vs=[sub(v[i],v[j]) for v in derivatives]
   if n==0: f=mult(d,h)
   elif n==1:
    v=vs[0];f=mult(add(v,mult(d,-3*dot(d,v)*inv)),h)
   elif n==2:
    v,w=vs;dv=dot(d,v);dw=dot(d,w)
    f=mult(add(add(mult(v,-3*dw),mult(w,-3*dv)),mult(d,15*dv*dw*inv-3*dot(v,w))),h*inv)
   elif n==3:
    v,w,u=vs
    if not(derivatives[0] is derivatives[1] and derivatives[0] is derivatives[2]):raise ValueError("only diagonal third derivative supported")
    dv=dot(d,v);vv=dot(v,v)
    f=add(mult(d,h*inv*inv*(45*dv*vv-105*dv*dv*dv*inv)),mult(v,h*inv*(45*dv*dv*inv-9*vv)))
   else:raise ValueError
   out[i]=sub(out[i],mult(f,m[j]));out[j]=add(out[j],mult(f,m[i]))
 return out
def tensors(z,k=3,needJ=True):
 p=plus(z[:6]);t=z[6];vo=minus(z[7:])
 ev=xp(field(p,t));od=xm(field(p,t,(vo,)))
 g=ev+od+[z[7+k]-1]
 if not needJ:return g
 columns=[]
 for j in range(6):
  h=plus(unit(6,j))
  columns.append(xp(field(p,t,(h,)))+xm(field(p,t,(vo,h)))+[O])
 columns.append(xp(field(p,t,dt=True))+xm(field(p,t,(vo,),dt=True))+[O])
 for j in range(5):
  h=minus(unit(5,j))
  columns.append([O]*6+xm(field(p,t,(h,)))+[E if j==k else O])
 return g,transpose(columns)
def interval_solve(A,b):
 """Plain interval Gaussian elimination. Pivot choices use only safe intervals."""
 z=[list(r)+[x] for r,x in zip(A,b)];n=len(z)
 for i in range(n):
  valid=[k for k in range(i,n) if z[k][i].l*z[k][i].h>0]
  if not valid:raise ArithmeticError("no pivot")
  k=max(valid,key=lambda k:min(abs(z[k][i].l),abs(z[k][i].h)));z[i],z[k]=z[k],z[i]
  inv=z[i][i].inv()
  for k in range(i+1,n):
   mul=z[k][i]*inv
   for j in range(i+1,n+1):z[k][j]=z[k][j]-mul*z[i][j]
 x=[O]*n
 for i in reversed(range(n)):
  x[i]=(z[i][-1]-dot(z[i][i+1:n],x[i+1:]))*z[i][i].inv()
 return x
def verify(obj):
 c=[ii(s) for s in obj['center']];r=ii(Q(1,10**15));X=[I(v.l-r.h,v.h+r.h) for v in c]
 k=obj['k'];g=tensors(c,k,False);gg,A=tensors(X,k)
 # Nondegen self-map using rational preconditioner stored as rounded decimal fractions
 R=imat(obj['inverse']);dr=max(x.norm() for x in matvec(R,g));lip=max(sum((ii(j==i)-dot(R[i],col)).norm() for j,col in enumerate(transpose(A))) for i in range(12))
 if not(lip<D and dr*D+lip*r.h<r.l*D):raise ValueError(("failed Krawczyk",dr/D,lip/D))
 p=plus(X[:6]);t=X[6];v=minus(X[7:]);n=5
 Jp=transpose([xp(field(p,t,(plus(unit(6,j)),))) for j in range(6)])
 Jm=transpose([xm(field(p,t,(minus(unit(5,j)),))) for j in range(5)])
 if p[3][0].l<=0 or any(dot(sub(p[i],p[j]),sub(p[i],p[j])).l<=0 for i in range(6) for j in range(i)):raise ValueError("invalid gauge or collision")
 radii=[dot(y,y) for y in p]
 if not 0<t.l<=t.h<D or radii[5].l<=0:raise ValueError("invalid mass ratio or centered light body")
 for i in (0,1,2,4):
  if not(radii[i].h<radii[3].l or radii[3].h<radii[i].l):raise ValueError("anchor radius may repeat")
 # left null vector proxy: bordered solve, coefficient along the fixed forcing vector e_b
 b=obj['b'];boundary=[row+[u] for row,u in zip(Jm,unit(5,b))]+[unit(5,k)+[O]]
 u2=plus(interval_solve(Jp,mult(xp(field(p,t,(v,v))),-1)))
 xdot=plus(interval_solve(Jp,mult(xp(field(p,t,dt=True)),-1)))
 cubic=add(xm(field(p,t,(v,v,v))),mult(xm(field(p,t,(v,u2))),3))
 slope=add(xm(field(p,t,(v,),dt=True)),xm(field(p,t,(v,xdot))))
 cub=interval_solve(boundary,cubic+[O])[-1]
 sl=interval_solve(boundary,slope+[O])[-1]
 split=interval_solve(boundary,xm(field(p,t,split=True))+[O])[-1]
 if (sl*cub).h>=0 or split.l*split.h<=0:raise ValueError("failed normal form factors")
 curvature=(-cub)*(6*sl).inv()
 opening=(-8*sl*sl*sl*(9*split*split*cub).inv()).root()
 # Rigorous rational interval endpoints below.
 print('scaled integer interval arithmetic denominator',D)
 print('fixed-point displacement <',(-(-dr*10**25//D)),'e-25 ; derivative row norm <',-(-lip*10**12//D),'e-12')
 print('t in',Q(t.l,D),Q(t.h,D))
 print('mixed derivative coefficient interval / 1e9:',sl.l*10**9//D,-(-sl.h*10**9//D))
 print('cubic derivative coefficient interval / 1e9:',cub.l*10**9//D,-(-cub.h*10**9//D))
 print('symmetry-breaking mass coefficient interval / 1e9:',split.l*10**9//D,-(-split.h*10**9//D))
 print('quadratic mass curvature interval / 1e9:',curvature.l*10**9//D,-(-curvature.h*10**9//D))
 print('leading cusp half-width interval / 1e9:',opening.l*10**9//D,-(-opening.h*10**9//D))
 return sl,cub
if __name__=='__main__':
 for f in ('two-axis.json',):
  print(f)
  verify(json.loads(Path(__file__).with_name(f).read_text()))
