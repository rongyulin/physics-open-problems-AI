"""Replay the exact Python certificates from the root of an extracted release."""
from pathlib import Path
import subprocess
import sys

base = Path(__file__).resolve().parent
tasks = [
    ("diagram98", ["SourceAlgebra.py"]),
    ("diagram98", ["Diagram98.py"]),
    ("diagram98", ["NextTorque.py"]),
    ("diagram98", ["SourceAligned.py"]),
    ("diagram98", ["AlignedWitness.py"]),
    ("diagram98", ["Split98.py"]),
    ("collinear", ["five_axial.py"]),
    ("collinear", ["five_axial.py", "61"]),
    ("folds", ["two_axial_three_folds.py"]),
    ("pitchfork4", ["verify.py"]),
    ("pitchfork2", ["verify_two_axis.py"]),
    ("folds", ["two_axial_pitchfork.py"]),
    ("symmetry", ["symmetry_counts.py", "SixBodyResearch"]),
    ("pentagon", ["pentagon_hessian.py"]),
    ("pentagon", ["quartic_reduction.py"]),
]
for directory, arguments in tasks:
    print(f"\n[{directory}/{arguments[0]}]", flush=True)
    subprocess.run([sys.executable, *arguments], cwd=base / directory, check=True)
