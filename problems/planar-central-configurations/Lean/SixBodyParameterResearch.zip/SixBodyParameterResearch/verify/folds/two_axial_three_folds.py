"""Two saddle-nodes for a planar six-body symmetry class. Standard Python 3."""
from fractions import Fraction as F
from itertools import permutations
from math import isqrt
S=2**132
N=5

class I:
    def __init__(self,l,h):
        assert l<=h
        self.l,self.h=l,h
    def __add__(self,b):
        if isinstance(b,Jet): return NotImplemented
        b=iv(b);return I(self.l+b.l,self.h+b.h)
    __radd__=__add__
    def __neg__(self): return I(-self.h,-self.l)
    def __sub__(self,b): return self+(-b)
    def __rsub__(self,b): return (-self)+b
    def __mul__(self,b):
        if isinstance(b,Jet): return NotImplemented
        b=iv(b);p=[v*w for v in (self.l,self.h) for w in (b.l,b.h)]
        return I(min(p)//S,-(-max(p)//S))
    __rmul__=__mul__
    def inv(self):
        assert self.l*self.h>0
        return I(S*S//self.h,-(-S*S//self.l))
    def __truediv__(self,b): return self*iv(b).inv()
    def sqrt(self):
        assert self.l>0
        return I(isqrt(self.l*S),isqrt(self.h*S)+1)
    def mag(self):return max(-self.l,self.h)
    def mid(self):return F(self.h+self.l,2*S)
    def __repr__(self):return str((float(F(self.l,S)),float(F(self.h,S))))

def iv(x):
    if isinstance(x,I):return x
    z=F(x)*S
    return I(z//1,-(-z//1))
def cap(c,r):
    a,b=iv(F(c)-r),iv(F(c)+r)
    return I(a.l,b.h)

class Jet:
    """Second derivatives with respect to four shape variables and the mass."""
    def __init__(self,v,d,h):self.v,self.d,self.h=v,d,h
    def __add__(self,y):
        if not isinstance(y,Jet):return Jet(self.v+y,self.d,self.h)
        return Jet(self.v+y.v,[v+w for v,w in zip(self.d,y.d)],
                   [[v+w for v,w in zip(p,q)] for p,q in zip(self.h,y.h)])
    __radd__=__add__
    def __neg__(self):return -1*self
    def __sub__(self,y):return self+(-y)
    def __rsub__(self,y):return y+(-self)
    def __mul__(self,y):
        if not isinstance(y,Jet):
            return Jet(self.v*y,[v*y for v in self.d],[[v*y for v in p] for p in self.h])
        return Jet(self.v*y.v,[a*y.v+self.v*b for a,b in zip(self.d,y.d)],
                   [[self.h[i][j]*y.v+self.v*y.h[i][j]+self.d[i]*y.d[j]+self.d[j]*y.d[i]
                     for j in range(N)]for i in range(N)])
    __rmul__=__mul__
    def unary(self,a,b,c):
        return Jet(a,[b*v for v in self.d],
                   [[b*self.h[i][j]+c*self.d[i]*self.d[j] for j in range(N)]for i in range(N)])
    def invsquare(self):
        p=self.v.inv();v=p*p
        return self.unary(v,-2*v*p,6*v*p*p)
    def invcube_dist(self):
        z=self.v; p=z.inv(); v=p/z.sqrt()
        return self.unary(v,F(-3,2)*v*p,F(15,4)*v*p*p)
def lift(Z):
    return [Jet(v,[iv(i==j) for j in range(N)],[[iv(0)]*N for _ in range(N)]) for i,v in enumerate(Z)]

def force(Z):
    a,b,c,d,t=lift(Z)
    def pot(x,y):return (x*x+y*y).invcube_dist()
    z1,z2,w1,w2,s,v=(pot(a,b),pot(c,d),pot(a-1,b),pot(c-1,d),pot(a-c,b-d),pot(a-c,b+d))
    A=t+2*a*z1+2*c*z2
    lam=A+1-2*(a-1)*w1-2*(c-1)*w2
    return [a*(lam-z1)-A+t*(1-a)*w1+(c-a)*(s+v),
            b*(lam-z1-t*w1)+(d-b)*s+(-d-b)*v-F(1,4)*b.invsquare(),
            c*(lam-z2)-A+t*(1-c)*w2+(a-c)*(s+v),
            d*(lam-z2-t*w2)+(b-d)*s+(-b-d)*v-F(1,4)*d.invsquare()]

def det(A):
    n=len(A);v=iv(0)
    for p in permutations(range(n)):
        s=iv((-1)**sum(p[i]>p[j] for i in range(n) for j in range(i+1,n)))
        for i,j in enumerate(p):s=s*A[i][j]
        v=v+s
    return v

def aug(Z):
    E=force(Z);J=[e.d[:4] for e in E]
    D=det(J)
    dD=[sum(det([E[i].h[k][:4] if i==r else J[i] for i in range(4)]) for r in range(4))
        for k in range(N)]
    return [e.v for e in E]+[D],[e.d for e in E]+[dD]

def solve(A,B):
    """Interval Gaussian elimination; B is a matrix of RHS columns."""
    n=len(A);rows=[a[:]+b[:] for a,b in zip(A,B)]
    for i in range(n):
        j=max(range(i,n),key=lambda j:abs(rows[j][i].mid()))
        rows[i],rows[j]=rows[j],rows[i]
        v=rows[i][i].inv()
        rows[i]=[x*v for x in rows[i]]
        for j in range(n):
            if i==j:continue
            v=rows[j][i]
            rows[j]=[x-v*y for x,y in zip(rows[j],rows[i])]
    return [row[n:] for row in rows]

def odd(Z):
    a,b,c,d,t=Z;o=iv(0);e=iv(1)
    q=[[o,o],[e,o],[a,b],[a,-b],[c,d],[c,-d]]
    mass=[e,t,e,e,e,e]
    acc=[[[o,o][k] for k in range(2)] for i in range(6)]
    H={}
    for i in range(6):
        for j in range(6):
            if i==j:continue
            delta=[q[j][k]-q[i][k] for k in range(2)]
            w=sum(v*v for v in delta);v=w.sqrt().inv()*w.inv()
            for k in range(2):acc[i][k]=acc[i][k]+mass[j]*delta[k]*v
            H[i,j]=[[mass[j]*v*(int(k==l)-3*delta[k]*delta[l]/w) for l in range(2)]for k in range(2)]
    lam=acc[0][0]-acc[1][0]
    cols=[]
    for j in range(4):
        h=[[o,o] for i in range(6)]
        k=j//2;comp=j%2
        h[2+2*k][comp]=e;h[3+2*k][comp]=(e if comp else -e)
        dif=[[sum(H[i,p][k][l]*(h[p][l]-h[i][l]) for p in range(6) if i!=p for l in range(2))
              for k in range(2)] for i in range(6)]
        Domega=dif[1][1]-dif[0][1]
        cols.append([dif[i][k]-dif[0][k]+lam*h[i][k]-Domega*[-q[i][1],q[i][0]][k]
                     for i in (2,4) for k in range(2)])
    return det(list(map(list,zip(*cols))))

def ratio(x): return F(x,S)
def verify(center,side=-1):
    r=F(1,10**11)
    X=[cap(c,r) for c in center];z=[iv(c) for c in center]
    e0,j0=aug(z)
    _,J=aug(X)
    n=N
    B=solve(j0,[[iv(i==j) for j in range(n)] for i in range(n)])
    B=[[iv(v.mid().limit_denominator(10**11)) for v in row] for row in B]
    q=max(sum((int(i==j)-sum(B[i][k]*J[k][j] for k in range(n))).mag() for j in range(n)) for i in range(n))
    res=max(sum(B[i][j]*e0[j] for j in range(n)).mag() for i in range(n))
    assert ratio(q)+ratio(res)/r<F(1,100)
    E=force(X)
    A=[e.d[1:] for e in E]
    v=[iv(1)]+[row[0] for row in solve(A,[[-e.d[0]] for e in E])]
    d2=[[-sum(e.h[i][j]*v[i]*v[j] for i in range(n) for j in range(n))] for e in E]
    curvature=solve(A,d2)[-1][0]
    odd_det=odd(X)
    assert (side*curvature).l>0 and odd_det.l*odd_det.h>0
    print('t center, radius',center[-1],r,'; ceil(10^6*q), ceil(10^6*res/r)',
          -(-ratio(q)*10**6//1),-(-ratio(res)/r*10**6//1))
    for name,interval in [('d2t/da2',curvature),('odd det',odd_det)]:
        print(name,'outward bounds / 10^6',ratio(interval.l)*10**6//1,-(-ratio(interval.h)*10**6//1))

if __name__=='__main__':
    verify(['-.7911253428899216','.5846088254460650','.4342183395280731','.7716720497801106','.1150143634630535'])
    verify(['-.44250667261699284','1.0932144759048747','1.1986043027427624','.76472498380027676','.00095963933728700494'])
    verify([".26644477713942927",".4232449094272942",".7660799396625364",".4417435075744236",".99770185629795693"],side=1)
