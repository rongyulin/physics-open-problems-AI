"""A planar pitchfork via w=s^2 and regularized odd residuals. Python 3."""
from fractions import Fraction as F
from two_axial_three_folds import I,iv,cap,solve,det,S

N=8
class D:
    def __init__(self,v,d=None):
        self.v=iv(v);self.d=([iv(0)]*N if d is None else d)
    def __add__(self,y):
        if not isinstance(y,D):y=D(y)
        return D(self.v+y.v,[a+b for a,b in zip(self.d,y.d)])
    __radd__=__add__
    def __neg__(self):return D(-self.v,[-z for z in self.d])
    def __sub__(self,y):return self+(-y)
    def __mul__(self,y):
        if not isinstance(y,D):y=D(y)
        return D(self.v*y.v,[a*y.v+b*self.v for a,b in zip(self.d,y.d)])
    __rmul__=__mul__
    def inv(self):
        p=self.v.inv()
        return D(p,[-p*p*a for a in self.d])
    def min3half(self):
        p=self.v.inv()/self.v.sqrt()
        return D(p,[F(-3,2)*p*a/self.v for a in self.d])

class P:
    """Power series in the odd amplitude s through degree three."""
    def __init__(self,L):
        self.a=[v if isinstance(v,D) else D(v) for v in L]+[D(0)]*(4-len(L))
    def __add__(self,b):
        if not isinstance(b,P):b=P([b])
        return P([a+w for a,w in zip(self.a,b.a)])
    __radd__=__add__
    def __neg__(self):return P([-v for v in self.a])
    def __sub__(self,b):return self+(-b)
    def __mul__(self,b):
        if not isinstance(b,P):b=P([b])
        return P([sum(self.a[i]*b.a[j-i] for i in range(j+1)) for j in range(4)])
    __rmul__=__mul__
    def min3half(self):
        h=P([0,*self.a[1:]])*P([self.a[0].inv()])
        return (1+F(-3,2)*h+F(15,8)*h*h-F(35,16)*h*h*h)*P([self.a[0].min3half()])

def desingularized(Z):
    a,b,c,d,t,h1,h2,h3=[D(v,[iv(i==j) for j in range(N)]) for i,v in enumerate(Z)]
    z=P([0]);one=P([1])
    q=[[z,z],[one,z],[P([a,1]),P([b,h1])],[P([a,-1]),P([-b,h1])],
       [P([c,h2]),P([d,h3])],[P([c,-h2]),P([-d,h3])]]
    m=[one,P([t]),one,one,one,one];acc=[[z,z] for i in range(6)]
    for i in range(6):
        for j in range(i+1,6):
            v=[q[j][k]-q[i][k] for k in range(2)]
            H=(v[0]*v[0]+v[1]*v[1]).min3half()
            for k in range(2):
                u=v[k]*H
                acc[i][k]=acc[i][k]+m[j]*u
                acc[j][k]=acc[j][k]-m[i]*u
    la=acc[0][0]-acc[1][0];W=acc[1][1]-acc[0][1]
    upper=[acc[i][k]-acc[0][k]+la*q[i][k]-W*[-q[i][1],q[i][0]][k]
           for i in (2,4) for k in (0,1)]
    first=[p.a[k] for k in (0,1) for p in upper]
    nexts=[p.a[k].v for k in (2,3) for p in upper]
    return [e.v for e in first],[e.d for e in first],nexts

if __name__=='__main__':
    center=['-1.5168162058259320','0.6465101421845377','-0.2614860952350456',
            '1.1780792718118827','0.2972453330040613','2.5872896642109118',
            '1.8100599771601533','0.5282102911688537']
    radius=F(1,10**11)
    U=[cap(c,radius) for c in center];x=[iv(c) for c in center]
    e,J0,_=desingularized(x)
    _,J,g=desingularized(U)
    B=solve(J0,[[iv(i==j) for j in range(N)] for i in range(N)])
    B=[[iv(v.mid().limit_denominator(10**11)) for v in row] for row in B]
    q=max(sum((int(i==j)-sum(B[i][k]*J[k][j] for k in range(N))).mag()
              for j in range(N)) for i in range(N))
    res=max(sum(B[i][j]*e[j] for j in range(N)).mag() for i in range(N))
    assert F(q,S)+F(res,S)/radius<F(1,100)
    slope=solve(J,[[-v] for v in g])[4][0]
    assert slope.l>0
    E4=[row[:4] for row in J[:4]]
    De=det(E4)
    assert De.l*De.h>0
    # Odd residual linear in (1,h1,h2,h3). Rank-three lower bound
    # follows because the 8x8 bordered chart is invertible, or directly.
    minor=det([row[5:] for row in J[4:7]])
    assert minor.l*minor.h>0
    print('radius',radius,'; ceil(10^6*q), ceil(10^6*res/r)',
          -(-F(q,S)*10**6//1),-(-F(res,S)/radius*10**6//1))
    for name,v in [('dt/dw',slope),('even determinant',De),('odd 3x3 minor',minor)]:
        print(name,'outward bounds / 10^6',F(v.l,S)*10**6//1,-(-F(v.h,S)*10**6//1))
