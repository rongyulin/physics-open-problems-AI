from pathlib import Path
import json,sys
sys.path.insert(0,str(Path(sys.argv[1]).resolve().parent))
from Diagram98 import shape_polynomials
rows=json.loads(Path(sys.argv[1]).read_text())
code='''import Std
/- Rational Rouché disk tests for the two diagram-98 shape lists at k=3. -/
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace DiskCertificate
structure G where
  x : Rat
  y : Rat
  deriving Inhabited
def gr (x : Rat) : G := ⟨x,0⟩
instance : Add G := ⟨fun a b => ⟨a.x+b.x,a.y+b.y⟩⟩
instance : Sub G := ⟨fun a b => ⟨a.x-b.x,a.y-b.y⟩⟩
instance : Mul G := ⟨fun a b => ⟨a.x*b.x-a.y*b.y,a.x*b.y+a.y*b.x⟩⟩
def ab (x : Rat) := max x (-x)
def up (s : G) := ab s.x + ab s.y
def low (s : G) := max (ab s.x) (ab s.y)
def B : Rat := 2^48
def rad : Rat := 1/(2^39)
def eta : Rat := 1/(2^32)
def gc (x y : Int) : G := ⟨(x : Rat)/B,(y : Rat)/B⟩
structure Row where
  fac : Nat
  c : G
  roots : List G
  deriving Inhabited
-- Given p(c+z), compute (c+z)p(c+z)+k, with coefficients in ascending order.
def horner (c : G) (p : List G) (k : Int) :=
  ((p.map (fun a => c*a) ++ [gr 0]).zipWith (·+·) (gr (k : Rat)::p))
def checkDisk (p : List Int) (c : G) := Id.run do
  let d := p.foldl (horner c) []
  let tail := ((d.drop 2).zipIdx.map (fun (v,i) => up v * rad^(i+2))).sum
  return decide (low d[1]! * rad > up d[0]! + tail)
def checkInv (c w : G) (mass off slope : Rat) := Id.run do
  let ell := (gr off) + (gr slope)*c
  let delta := ab slope*rad
  let res := up (ell*w*w - gr (mass^2))
  return (decide (low ell > delta)) && (decide (low w > eta)) &&
    (decide (2*low (ell*w)*eta > res + up ell*eta^2 + delta*(up w+eta)^2))
def rowOK (p : List (List Int)) (m : Rat) (r : Row) :=
  checkDisk p[r.fac]! r.c && (r.roots.length==3) && checkInv r.c r.roots[0]! 1 1 m &&
   checkInv r.c r.roots[1]! 1 (-1-m) m && checkInv r.c r.roots[2]! m 1 (-2)
def shapeOK (p : List (List Int)) (m : Rat) (rows : List Row) :=
  rows.all (rowOK p m) && rows.all (fun r => decide (r.fac < p.length)) &&
  p.zipIdx.all (fun (f,i) => (rows.filter (fun r => r.fac==i)).length == f.length-1) &&
  rows.zipIdx.all (fun (r,i) => (rows.drop (i+1)).all (fun s => decide (low (r.c-s.c)>2*rad)))
'''
for k in [1,3]:
 def vec(p):return f'gc ({p[0]}) ({p[1]})'
 code+=f'def factors{k} : List (List Int) := '+str(shape_polynomials(k))+'\n'
 code+=f'def rows{k} : List Row := [\n'+',\n'.join('⟨'+str(f)+','+vec(p)+',['+','.join(vec(z) for z in zs)+']⟩' for f,p,zs in rows[str(k)])+']\n'
 code+=f'theorem disks{k} : shapeOK factors{k} {k} rows{k} = true := by decide +kernel\n#print axioms disks{k}\n'
code+='end DiskCertificate\n'
Path(__file__).with_name('DiagramDisks.lean').write_text(code)
