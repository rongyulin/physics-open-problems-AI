> This note describes the first-order stage. The cubic-order exclusion, its extension and the complete proof are in the main manuscript.

# A reduction of the diagram-98 torque condition on the five-equal-mass line

Consider masses proportional to \( (1,1,1,1,1,k) \), with \(k>0\). In a diagram-98 singular place, two triples separate in opposite complex coordinates. After interchanging the triples and relabelling bodies, their masses are \(\mu=(1,1,1)\) and \(\nu=(1,1,k)\). This note restricts their leading coefficients. It does not prove the existence of such a place or the finiteness of the six-body configurations.

**Proposition.** There exists an explicitly defined nonzero polynomial \(P\in\mathbb Z[k]\) with \(P(3)\ne0\) such that, for every \(k>0\) with \(P(k)\ne0\), every solution to the diagram-98 leading shape and cross-torque conditions has both of the following properties.

1. The projected shape \(x\) of the all-equal triple satisfies \(x^2-x+1=0\).
2. The cross sign matrix is of rank one over the complex numbers. Its signs can be written as \(\epsilon_{jl}=\delta_j\eta_l\), independently of the chosen square-root branches.

The proposition includes \(k=3\). It restricts every labelled allocation of the five interchangeable unit masses. It is a statement about the projected complex shape, not a claim that the limiting three-body configuration is real.

## Input from the central-configuration equations

Tomar, *Smale's sixth problem for six bodies in the plane: finiteness of central configurations for generic masses, with a proof formalized in Lean*, [§§6.4–6.6](https://hexagonmath.org/pdf/2611.00377v1), Lemmas 6.9 and 6.11, and Theorem 6.12, gives the following necessary conditions. For the triple with masses \(m=(1,1,h)\) and shape \(z\), set

$$
(\ell_1,\ell_2,\ell_3)=(1+hz,hz-1-h,1-2z),\qquad
\Lambda_j=\prod_{i\ne j}\ell_i.
$$

All three linear forms are nonzero at a diagram-98 place. Write \(S_h\) for Tomar's degree-34 shape polynomial. With \(S_1(x)=S_k(y)=0\), the cross-torque vanishes only if some signed sum

$$
\sum_{j,l=1}^{3}\epsilon_{jl} r_j s_l = 0,\qquad
r_j^2=\mu_j^2\Lambda_j(x;1),\quad
s_l^2=\nu_l^2\Lambda_l(y;k)
$$

vanishes. The signs of a row or column change when a corresponding square-root branch changes. Rank and the equation with the transformed sign matrix are invariant. Overall sign is irrelevant, so require \(\epsilon_{11}=1\). Tomar's Remark 6.14 observes that rank-one matrices include the factorable sums that vanish for an equal-mass triple. His polynomial therefore vanishes identically on this line. The proposition tests the other signs and the other equal-triple shapes separately.

## Reduction of the shape equations

Put \(E(z)=z^2-z+1\) and

$$
L=E(z)(z^4-5z^3+9z^2-5z+1)(z^4+z^3-2z+1)(z^4-2z^3+z+1).
$$

For the equal triple retain the degree-26 polynomial

$$
A=L(2z^4-z^3+2z^2-2z+1)(z^4-2z^3+2z^2-z+2)
(2z^4-7z^3+11z^2-7z+2).
$$

For the other triple put

$$
\begin{aligned}
B_k=L{}&[2z^5-5z^4+4z^3-(3k+3)z^2+(3k+2)z-(k+1)]\\
&[z^4-2z^3+(k+1)z^2-kz+k+1]\\
&[2z^5-5z^4+4z^3+(3k+1)z^2-(3k+2)z+k+1]\,
[z^2-z-k-1].
\end{aligned}
$$

Its degree is 30 for every \(k\). Direct multiplication in \(\mathbb Z[k,z]\) gives

$$
S_1=A(z)(2z-1)^2 E(z)(z+1)^2(z-2)^2,\qquad
S_k=B_k(z)(2z-1)^2 E(z).
$$

In both products the retained polynomial already contains \(E\). Every other removed root makes at least one \(\ell_i\) vanish. Thus these equations retain every admissible shape even at special masses. The equal-triple polynomial \(A/E\) has no common root with \(E\); in particular, a non-equilateral equal-triple branch cannot specialize to an equilateral root at 3. Both retained polynomials have constant leading coefficient 4; no shape escapes to infinity by a degree drop. These identities and the checks on specialization are reproduced by `SourceAlgebra.py`.

## An integer obstruction polynomial

Let \(\mathcal N\) be the 240 canonical matrices of rank greater than one and \(\mathcal F\) the 16 canonical matrices of rank one. For either class \(\mathcal C\), define

$$
H_{\mathcal C}(r,s)=
\prod_{e\in\mathcal C}\left(\sum_{j,l} e_{jl}r_js_l\right).
$$

Changing the sign of any \(r_j\) or \(s_l\) permutes these factors up to overall signs. If \(e_{11}\) is affected, *every* factor needs a minus sign to restore the normalization, and the number of factors is even. Hence every exponent of every radical in the product is even. Substituting the six square identities above yields \(h_{\mathcal C}(x,y,k)\in\mathbb Z[x,y,k]\). Define

$$
P(k)=\operatorname{Res}_x\big(A,\operatorname{Res}_y(B_k,h_{\mathcal N})\big)
\operatorname{Res}_x\big(A/E,\operatorname{Res}_y(B_k,h_{\mathcal F})\big).
$$

All polynomial evaluations take place after replacing radicals by their squares in the invariant product. This is an explicit polynomial specified by products and determinants rather than by expanded coefficients. A root pair with either a nonfactorable sign matrix, or a non-equilateral equal-triple shape and a factorable matrix, makes the corresponding nested resultant zero.

It suffices to check \(P(3)\ne0\). At 3 both shape polynomials have their full degrees and all roots are simple. The product formula for a resultant of a fixed-degree outer polynomial multiplies the inner values over all outer roots, up to a nonzero power of the leading coefficient, even if the degree of the inner polynomial drops in a specialization. Thus the finite check below establishes \(P(3)\ne0\) without assuming that a component of any system of rational equations meets the tested affine chart. No inversion of a parameter, radical, or shape coordinate is needed to construct \(P\). For a sign class of size \(M\), \(H_{\mathcal C}\) is homogeneous of degree \(M/2\) in the squared coordinates of each triple separately. The substituted entries have shape degree at most two, and the mixed entries have parameter degree at most four. Hence \(h_{\mathcal C}\) has degrees at most \((M,M,2M)\) in \((x,y,k)\). The mixed-shape polynomial has parameter degree at most four and shape degree 30. The Sylvester determinant bounds the inner resultant's parameter degree by \(30(2M)+4M=64M\); the outer shape polynomials are constant in the parameter. In particular,

$$
\deg P \le 26\cdot64\cdot240+24\cdot64\cdot16=423936.
$$

A nonzero univariate polynomial has finitely many roots, proving the proposition.

## The finite witness

The computation at 3 uses \(a_j=\mu_j/\sqrt{\ell_j(x;1)}\) and \(b_l=\nu_l/\sqrt{\ell_l(y;3)}\). All linear forms are nonzero on both root sets, so multiplying by one nonzero common scalar for each triangle, with harmless changes of row/column signs, identifies this test with the signed sums in \(r,s\).

The input file `seeds98.json` contains Gaussian dyadic centres of denominator \(B=2^{48}\). A floating-point calculation can be used to generate them; the verifier treats them as arbitrary untrusted input. Set \(R=2^{-39}\) and \(H=2^{-32}\). For a proposed root centre \(c\), write the exact Taylor coefficients of its assigned factor as \(f(c+w)=\sum d_i w^i\). The verifier proves \(|d_1|R>|d_0|+\sum_{i\ge2}|d_i|R^i\). Rouché's theorem gives exactly one zero in each disk. Disjointness and the degrees certify completeness.

For the proposed radical centre \(w\), let \(\ell_0=\ell(c)\) and let \(s\) be the slope of this linear form. The true value differs from \(\ell_0\) by at most \(|s|R\). The verifier proves

$$
2|\ell_0w|H>
|\ell_0w^2-m_j^2|+|\ell_0|H^2+|s|R(|w|+H)^2.
$$

A second application of Rouché's theorem isolates a radical root in each disk. The other root is its negative. The global sign enumeration covers all choices. Given centres \(w_j,v_l\) with error at most \(H\), the product \(a_jb_l\) has error at most \((|w_j|+|v_l|)H+H^2\). The verifier sums these errors and compares them to a lower bound on the modulus of every signed sum. It bounds \(|z|\) below by \(\max(|\Re z|,|\Im z|)\) and above by \(|\Re z|+|\Im z|\), so every comparison uses integers or exact rational arithmetic.

There are 26 equal-triple roots and 30 mixed-triple roots. All \(26\cdot30\cdot240=187200\) rank-greater-than-one combinations are excluded. All \(24\cdot30\cdot16=11520\) non-equilateral rank-one combinations are also excluded. The least certified lower bound on the modulus over these two classes exceeds 0.036477197 in the inverse-root coordinates used for this finite witness. Among 199680 total combinations, 240 fall within the interval error. Every one has an equilateral equal-triple root and factorable signs. This count is a count of signed algebraic tests, not of central configurations.

For either equilateral root, set \(Y_j=\mu_j^2\Lambda_j(x;1)\). The product of the four three-term signed sums equals

$$
Y_1^2+Y_2^2+Y_3^2-2(Y_1Y_2+Y_2Y_3+Y_3Y_1)=9E(x)^2.
$$

It follows that for both equilateral roots some signed sum over the equal triangle vanishes. Multiplying this identity by an arbitrary signed sum over the mixed triangle produces a factorable solution of the scalar torque equation. Additional information from the governing equations is required to decide whether any such leading solution extends to a singular place.

## Reproduction

Run `python3 Diagram98.py` (Python 3.10+ standard library) and `python3 SourceAlgebra.py` (SymPy). The optional `generate98.py` regenerates the untrusted dyadic input with NumPy. The certificate is an exact-arithmetic program applying the two stated mathematical theorems; there is no Lean formalization of the full proposition here.
