"""Check the physical-torus shape factors directly from Tomar, Sec. 6.4.

Usage: python SourceAlgebra.py (SymPy 1.13+).
"""
import sympy as s
from itertools import product
from Diagram98 import shape_polynomials
x, k, u = s.symbols("x k u")
L = [x**2-x+1, x**4-5*x**3+9*x**2-5*x+1,
     x**4+x**3-2*x+1, x**4-2*x**3+x+1]

def source(u, v):
    M = 1+u+v
    ell1 = u+v*x
    ell = [ell1, ell1-M, ell1-M*x]
    Q = [((1+u)*(x-1)**3*x**2 + (x-1)**2*x**2
          + a*v*(x-1)**3 - b*v*x**3 - a*(x-1)**2 - b*u*x**2)
         for a,b in product([1,-1],repeat=2)]
    return ell, L+Q

def check(v):
    ell, shapes = source(1,v)
    factors = [s.Poly.from_list(f,x).as_expr() for f in shape_polynomials(v)]
    retained = s.prod(factors)
    discarded = (2*x-1)**2 * (x*x-x+1)
    if v==1:
        discarded *= (x+1)**2*(x-2)**2
    # Product identity in Z[v,x], including every possibly exceptional specialization.
    if s.Poly(s.prod(shapes)-discarded*retained,x).as_expr()!=0:
        raise ValueError("Incorrect factor decomposition")
    if not any(s.rem(f,x*x-x+1,x)==0 for f in factors):
        raise ValueError("Lost the equilateral roots")
    print(f"mass (1,1,{v}): raw degree 34, retained degree {sum(len(f)-1 for f in shape_polynomials(v))}")
    return retained, ell

if __name__ == '__main__':
    check(1)
    generic,ell = check(k)
    special,_ = check(3)
    if s.expand(generic.subs(k,3)-special)!=0:
        raise ValueError('degree changed at 3')
    for v in (1,3):
        eq = s.Poly(s.prod([s.Poly.from_list(z,x).as_expr() for z in shape_polynomials(v)]),x)
        e = s.Poly(s.prod(source(1,v)[0]),x)
        if eq.gcd(eq.diff()).degree()!=0 or eq.gcd(e).degree()!=0:
            raise ValueError('non-simple root or vanishing denominator at 3')
    equal_ell, _ = source(1,1)
    y = [s.prod(equal_ell[:j]+equal_ell[j+1:]) for j in range(3)]
    phi = sum(yi**2 for yi in y) - 2*(y[0]*y[1]+y[0]*y[2]+y[1]*y[2])
    if s.expand(phi-9*L[0]**2)!=0:
        raise ValueError("factorable equal-triangle identity failed")
    print("Specialization at k=3, simple roots, nonzero denominators, and the equal-triangle identity: PASS")

    # Test the rank-one three-term cancellation on (1,1,k) for every k>0.
    ell = source(1,k)[0]
    mass = [1,1,k]
    y = [mass[j]**2*s.prod(ell[:j]+ell[j+1:]) for j in range(3)]
    phi = sum(z**2 for z in y) - 2*(y[0]*y[1]+y[0]*y[2]+y[1]*y[2])
    positive = set()
    for f in shape_polynomials(k):
        resultant = s.resultant(s.Poly.from_list(f,x).as_expr(),phi,x)
        if not resultant:
            raise ValueError('identically vanishing triangle resultant')
        for q,_ in s.factor_list(resultant)[1]:
            if q==k-1:
                positive.add(q)
            elif s.Poly(q,k).count_roots(0,s.oo)!=0:
                raise ValueError('additional positive zero of mixed-triple cancellation')
    if positive!={k-1}:
        raise ValueError('missing expected positive root')
    print("Mixed-triangle signed cancellation for k>0 requires k=1: PASS")
