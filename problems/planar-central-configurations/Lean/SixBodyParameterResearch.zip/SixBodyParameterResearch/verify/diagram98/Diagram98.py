"""Certificate for the generic nonfactorable-sign exclusion on the five-equal line.

Uses exact Gaussian integers and rational arithmetic. Input algebra and
specialization proof are explained in Diagram98.md. Run python3 Diagram98.py.
"""
from pathlib import Path
from fractions import Fraction as Q
from itertools import product, combinations
from math import comb
import json

B=2**48
R=Q(1,2**39)       # root isolation radius
H=Q(1,2**32)       # radical isolation radius

def add(a,b): return (a[0]+b[0],a[1]+b[1])
def mul(a,b): return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def sub(a,b): return (a[0]-b[0],a[1]-b[1])
def scale(a,s): return (s*a[0],s*a[1])
def upper(a): return abs(a[0])+abs(a[1])
def lower(a): return max(abs(a[0]),abs(a[1]))

def shape_polynomials(m):
    # Descending coefficients, one copy of each admissible factor for this mass.
    common=[[1,-1,1],[1,-5,9,-5,1],[1,1,0,-2,1],[1,-2,0,1,1]]
    if m==1:
        return common+[[2,-1,2,-2,1],[1,-2,2,-1,2],[2,-7,11,-7,2]]
    return common+[[2,-5,4,-3*m-3,3*m+2,-m-1],
                   [1,-2,m+1,-m,m+1],
                   [2,-5,4,3*m+1,-3*m-2,m+1],[1,-1,-m-1]]

def require(condition, message):
    if not condition: raise ValueError(message)

def taylor_at(coeff,c):
    """Coefficients of p(c+z), ascending, via exact polynomial Horner."""
    out=[]
    for k in coeff:
        out=[add((k,0),mul(out[0],c)) if out else (k,0)]+[
            add(out[i-1],mul(out[i],c)) for i in range(1,len(out))]+out[-1:]
    return out

def check_shape(m, rows):
    polys=shape_polynomials(m)
    fids=[r[0] for r in rows]
    require(all(fids.count(i)==len(p)-1 for i,p in enumerate(polys)), "wrong degree cover")
    require(len(fids)==sum(len(p)-1 for p in polys), "extra root")
    for x,y in combinations(rows,2):
        require(lower(sub(x[1],y[1]))>2*R*B,"overlapping roots")
    for k,center,radicals in rows:
        c=scale(center,Q(1,B))
        p=taylor_at(polys[k],c)
        require(lower(p[1])*R>upper(p[0])+sum(upper(z)*R**i for i,z in enumerate(p) if i>=2),
                "failed to isolate shape with Rouche")
        for b,(m_j,a,s) in zip(radicals,[(1,1,m),(1,-1-m,m),(m,1,-2)],strict=True):
            # For true shape c+h the linear form ell=a+s(c+h) differs
            # from ell0 by at most abs(s)*R. Check ell(w+z)^2-m_j^2 against
            # 2*ell0*w*z on |z|=H; all complex norms use simple rational bounds.
            w=scale(b,Q(1,B)); ell=add((a,0),scale(c,s))
            diff=abs(s)*R
            require(lower(ell)>diff and lower(w)>H,"zero coordinate or radical")
            constant=upper(sub(mul(ell,mul(w,w)),(m_j**2,0)))
            require(2*lower(mul(ell,w))*H >
                    constant+upper(ell)*H**2+diff*(upper(w)+H)**2,
                    "failed to isolate inverse square root")
    return rows

def rank_one(e):
    return all(e[0][0]*e[j][k]==e[j][0]*e[0][k] for j in (1,2) for k in (1,2))

def verify():
    data=json.loads(Path(__file__).with_name('seeds98.json').read_text())
    require(set(data)=={'1','3'},'input masses')
    A=check_shape(1,data['1']); C=check_shape(3,data['3'])
    signs=[]
    for choices in product((1,-1),repeat=8):
        entries=(1,)+choices
        e=[entries[0:3],entries[3:6],entries[6:9]]
        signs.append((entries,rank_one(e)))
    total, cand, nonrank, extra=0,0,0,0
    minscaled=None
    for k,x,a in A:
        for _,y,b in C:
            products=[mul(p,q) for p in a for q in b]
            # All bilinear signed sums have approximation error <= err/B^2;
            # the same bound holds for every root and choice of signs.
            err=sum((upper(p)+upper(q))*int(B*H)+int(B*H)**2 for p in a for q in b)
            for entries,rank1 in signs:
                total+=1
                p=(sum(s*z[0] for s,z in zip(entries,products)),
                   sum(s*z[1] for s,z in zip(entries,products)))
                if lower(p)<=err:
                    require(k==0 and rank1,"possible vanishing sum outside equilateral rank-one family")
                    cand+=1
                else:
                    if not rank1: nonrank+=1
                    elif k!=0: extra+=1
                    if not (k==0 and rank1): 
                        margin=(lower(p)-err)
                        minscaled=margin if minscaled is None else min(margin,minscaled)
    print("Physical torus in the two polished triangular shape equations at parameter 3.")
    print("Equal/mixed admissible roots:",len(A),len(C))
    print("Sign matrices modulo simultaneous negation:",len(signs))
    print("All combinations:",total)
    print("Excluded nonfactorable-sign combinations:",nonrank)
    print("Excluded rank-one combinations with a non-equilateral equal triple:",extra)
    print("Combinations not excluded by interval inequalities:",cand)
    print("Certified lower bound (nonfactorable or non-equilateral equal triple):",
          minscaled*10**9//(B**2),"/ 10^9")
    require(nonrank==26*30*240 and extra==24*30*16 and cand==240,'unexpected output')
    print("PASS")
if __name__=='__main__':
    verify()
