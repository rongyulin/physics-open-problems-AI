"""Audit diagram-98 torques for (1,1,1) with (1,2,7) or (2,3,7).

Keep Diagram98.py, NextTorque.py and seeds98.json beside this script or in
a neighbouring qt-diagrams directory; the exact verifier is stdlib only.
"""
import sys
import json
from itertools import product,combinations
from pathlib import Path
from math import isqrt
from fractions import Fraction as Q
here=Path(__file__).resolve().parent
sys.path.insert(0,str(here.parent/'qt-diagrams'))
from Diagram98 import B,H,R, upper,lower,add,sub,mul,scale,taylor_at,rank_one,check_shape
from NextTorque import Box,Interval,SCALE,bilinear

def verify_mixed(polys,rows,m):
    a,b,c=m
    eq=[(b,c),(-a-c,c),(b,-a-b)]
    if len(rows)!=32 or any(sum(row[0]==i for row in rows)!=len(p)-1 for i,p in enumerate(polys)):
        raise ValueError('uncovered root')
    for r,s in combinations(rows,2):
        if lower(sub(r[1],s[1]))<=2*R*B: raise ValueError('overlapping disks')
    for j,q,rad in rows:
        c=scale(q,Q(1,B)); a=taylor_at(polys[j],c)
        if lower(a[1])*R<=upper(a[0])+sum(upper(z)*R**i for i,z in enumerate(a) if i>=2):
            raise ValueError('shape disk')
        for mass,(v,s),w0 in zip(m,eq,rad,strict=True):
            w=scale(w0,Q(1,B)); ell=add((v,0),scale(c,s)); diff=abs(s)*R
            const=upper(sub(mul(ell,mul(w,w)),(mass**2,0)))
            if lower(ell)<=diff or lower(w)<=H or (2*lower(mul(ell,w))*H <=
                    const+upper(ell)*H**2+diff*(upper(w)+H)**2):
                raise ValueError('radical disk')
    return rows

def runfirst(A,G):
    signs=[]
    for v in product((1,-1),repeat=8):
        flat=(1,)+v
        signs.append((flat,rank_one([flat[:3],flat[3:6],flat[6:]])))
    n=0; marg=None
    for j,_,a in A:
        for _,_,b in G:
            prod=[mul(z,w) for z in a for w in b]
            err=sum((upper(z)+upper(w))*int(B*H)+int(B*H)**2 for z in a for w in b)
            for v,rank in signs:
                if rank and j==0:continue
                xy=tuple(sum(sign*z[d] for sign,z in zip(v,prod)) for d in (0,1))
                margin=lower(xy)-err
                if margin<=0: raise ValueError('possible unwanted leading cancellation')
                marg=margin if marg is None else min(margin,marg)
                n+=1
    if n!=26*32*240+24*32*16: raise ArithmeticError
    print(f'Leading exclusions: {n}; modulus lower bound {marg*10**6//B**2}/10^6')

def coordinates(y,m):
    a,b,c=map(Box.integer,m)
    M=Box.integer(sum(m))
    return [(b+c*y)/M,(c*y-a-c)/M,(b-(a+b)*y)/M]

def runcubic(rows,m):
    one=Box.integer(1)
    q=isqrt(3*SCALE**2)
    omega=Box(Interval(-SCALE//2),Interval(q//2,(q+2)//2))
    n=0; mins=[None]*3
    for _,center,rc in rows:
        y=Box.seed(center,R); b=[Box.seed(v,H) for v in rc]
        W=coordinates(y,m); invW=[one/w for w in W]
        cases=[(Box.integer(sum(m)**2),coordinates(d/y,m)) for d in (one,omega,omega*omega)]
        for s,t in product((1,-1),repeat=2):
            F=Box.integer(m[0]+m[1])+Box.integer(m[2]*s)/(y*y)-Box.integer(m[2]*t)/((y-one)*(y-one))
            cases.append((F*F,W))
        for t1,t2 in product((1,-1),repeat=2):
            v=[b[0],Box.integer(t1)*b[1],Box.integer(t2)*b[2]]
            mixed=sum(v,Box.integer(0)).lower()
            if mixed<=0: raise ValueError('zero mixed-triple radical sum')
            T=bilinear(v,invW).cube()
            for s,qform in cases:
                U=bilinear(v,qform)
                low=[(Box.integer(3)*s*U.cube()+T).lower(),U.lower(),mixed]
                if min(low)<=0: raise ValueError('cubic torque possibly zero')
                mins=[val if mn is None else min(val,mn) for mn,val in zip(mins,low,strict=True)]
                n+=1
    if n!=896: raise ArithmeticError
    print('Cubic tests per equal lift:',n)
    print('Lower bounds, first cubic, zero-inertia test, mixed leading triangle:',
          [m*10**6//SCALE for m in mins], '/ 10^6')

def main():
    from pathlib import Path
    aux=here/'seeds98.json'
    if not aux.exists():aux=here.parent/'qt-diagrams'/'seeds98.json'
    A=check_shape(1,json.loads(aux.read_text())['1'])
    mixed=json.loads((here/'aligned-seeds.json').read_text())
    other=json.loads((here/'aligned-237.json').read_text())
    # All coefficient integers explicitly rederived in SourceAligned.py.
    for coeff, rows, m in [(MIXED_FACTORS,mixed,(1,2,7)),(OTHER_FACTORS,other,(2,3,7))]:
        print("Mixed triple",m)
        G=verify_mixed(coeff,rows,m)
        runfirst(A,G)
        runcubic(G,m)
    print('PASS')

MIXED_FACTORS=[[1, -1, 1], [1, -5, 9, -5, 1], [1, 1, 0, -2, 1], [1, -2, 0, 1, 1], [3, -8, 7, -26, 23, -8], [3, -8, 21, -22, 23, -8], [3, -8, 7, 22, -23, 8], [3, -5, -15, 8]]

OTHER_FACTORS=[[1, -1, 1], [1, -5, 9, -5, 1], [1, 1, 0, -2, 1], [1, -2, 0, 1, 1], [5, -13, 11, -29, 25, -9], [5, -13, 25, -23, 25, -9], [5, -13, 11, 23, -25, 9], [5, -8, -16, 9]]

if __name__=='__main__': main()
