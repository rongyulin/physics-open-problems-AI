"""Exact cubic-order mixed-triangle tests for both kinds of equal-triangle lift.

The rectangular intervals use integer bounds with a common denominator 2**80.
Run python3 NextTorque.py; no external dependencies.
"""
from itertools import product
from math import isqrt
from pathlib import Path
import json
from Diagram98 import R, H, B, check_shape

SCALE = 2**80

def ceildiv(a,b):
    return -(-a//b)

class Interval:
    def __init__(self, low, high=None):
        self.a=low
        self.b=low if high is None else high
        if self.a>self.b: raise ValueError("reversed interval")

    def __add__(self,z): return Interval(self.a+z.a,self.b+z.b)
    def __neg__(self): return Interval(-self.b,-self.a)
    def __sub__(self,z): return self + (-z)
    def __mul__(self,z):
        values=[a*b for a in (self.a,self.b) for b in (z.a,z.b)]
        return Interval(min(values)//SCALE,ceildiv(max(values),SCALE))

    def sq(self):
        lo=0 if self.a<=0<=self.b else min(self.a**2,self.b**2)
        return Interval(lo//SCALE,ceildiv(max(self.a**2,self.b**2),SCALE))

    def inv(self):
        if self.a<=0<=self.b: raise ZeroDivisionError("interval with 0")
        return Interval(SCALE**2//self.b,ceildiv(SCALE**2,self.a))

    def lower(self): return max(self.a,-self.b,0)

class Box:
    def __init__(self,r,i): self.r=r; self.i=i

    @staticmethod
    def integer(n): return Box(Interval(n*SCALE), Interval(0))

    @staticmethod
    def seed(pair,radius):
        w=int(radius*SCALE)
        if radius*SCALE!=w: raise ValueError("inexact dyadic radius")
        def iv(c): return Interval(c*(SCALE//B)-w,c*(SCALE//B)+w)
        return Box(iv(pair[0]),iv(pair[1]))

    def __add__(self,z): return Box(self.r+z.r,self.i+z.i)
    def __neg__(self): return Box(-self.r,-self.i)
    def __sub__(self,z): return self + (-z)
    def __mul__(self,z): return Box(self.r*z.r-self.i*z.i,self.r*z.i+self.i*z.r)
    def __truediv__(self,z):
        scale=(z.r.sq()+z.i.sq()).inv()
        return self*Box(z.r*scale,-z.i*scale)

    def cube(self): return self*self*self
    def lower(self): return max(self.r.lower(),self.i.lower())

def lcoords(z,m):
    one=Box.integer(1)
    mass=Box.integer(m)
    total=Box.integer(m+2)
    return [(one+mass*z)/total,(mass*z-one-mass)/total,(one-Box.integer(2)*z)/total]

def bilinear(a,b):
    return sum((x*y for x,y in zip(a,b,strict=True)),Box.integer(0))

def main():
    one=Box.integer(1)
    three=Box.integer(3)
    q=isqrt(3*SCALE**2)
    omega=Box(Interval(-SCALE//2),Interval(q//2,(q+2)//2))
    powers=[one,omega,omega*omega]
    if q*q>=3*SCALE**2 or (q+1)**2<=3*SCALE**2: raise ArithmeticError
    data=json.loads(Path(__file__).with_name('seeds98.json').read_text())
    m=3
    rows=check_shape(m,data[str(m)])
    n=0
    minimum=None
    zeromin=None
    for fid,center,rad in rows:
        y=Box.seed(center,R)
        b=[Box.seed(c,H) for c in rad]
        W=lcoords(y,m)
        invW=[one/w for w in W]
        cases=[]
        # Lagrange: Z' = R * lcoords(d/y,m) with R^3=(m+2)^2, d^3=1.
        for d in powers:
            cases.append((Box.integer((m+2)**2),lcoords(d/y,m)))
        # Euler: Z' = lambda W, lambda^3=(F1-F2)^2.
        for s,t in product((1,-1),repeat=2):
            F=Box.integer(2)+Box.integer(m*s)/(y*y)-Box.integer(m*t)/((y-one)*(y-one))
            cases.append((F*F,W))
        for ss,tt in product((1,-1),repeat=2):
            signed=[b[0], Box.integer(ss)*b[1],Box.integer(tt)*b[2]]
            V=bilinear(signed,invW).cube()
            for scale, form in cases:
                term=bilinear(signed,form)
                if term.lower()<=0: raise ArithmeticError("inconclusive isotropic-lift test")
                zeromin=term.lower() if zeromin is None else min(zeromin,term.lower())
                test=three*scale*term.cube()+V
                low=test.lower()
                if low<=0: raise ArithmeticError(f"inconclusive test, shape factor {fid}")
                minimum=low if minimum is None else min(minimum,low)
                n+=1
    if n!=840: raise ArithmeticError
    print("Mixed shape x sign x type combinations:",n)
    print("Certified modulus lower bound in cubed inverse-root coordinates:",
          minimum*10**6//SCALE,"/ 10^6")
    print("Certified modulus lower bound in zero-inertia tests:", zeromin*10**6//SCALE, "/ 10^6")
    print("PASS")
if __name__=="__main__": main()
