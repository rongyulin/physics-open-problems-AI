"""Exact witness for every 2+1 allocation in diagram 98 with three equal masses.

Run python Split98.py. Optional --generate recreates the untrusted input using
NumPy. The verifier uses SymPy only for polynomial identities and fractions
or integers for all enclosures.
"""
from fractions import Fraction
from itertools import combinations, product
from pathlib import Path
import json
import sympy as sp

x, a, b, c = sp.symbols('x a b c')
B = 2**48
R = Fraction(1, 2**39)
H = Fraction(1, 2**32)
DATA = Path(__file__).with_name('split_seeds.json')
WITNESSES = ((3,2,7),(2,3,7),(7,2,3))

def check(condition, message):
    if not condition:
        raise ArithmeticError(message)

def triangle(u, v):
    """Tomar's polynomial for three masses (1,u,v), with x=Z13/Z12."""
    forms = (u+v*x, v*x-1-v, u-(1+u)*x)
    lagrange = (x*x-x+1, x**4-5*x**3+9*x*x-5*x+1,
                x**4+x**3-2*x+1, x**4-2*x**3+x+1)
    eulers = [((1+u)*(x-1)**3*x*x + (x-1)**2*x*x
             + s*v*(x-1)**3 - t*v*x**3 - s*(x-1)**2 - t*u*x*x)
             for s,t in product((1,-1),repeat=2)]
    return forms, [*lagrange,*eulers]

def retained(u,v,first):
    forms,polys=triangle(u,v)
    # The repeated equilateral factor is retained once. Another universal
    # factor for (1,1,a) is inadmissible since ell_3=1-2*x.
    removed = x*x-x+1
    if first:
        removed *= (2*x-1)**2
    result = sp.Poly(sp.prod(polys),x).exquo(sp.Poly(removed,x))
    check(result.degree()==(30 if first else 32),'wrong retained degree')
    check(result.rem(sp.Poly(x*x-x+1,x)).is_zero,'lost an equilateral root')
    return result

def factors(u,v,first):
    f = retained(u,v,first)
    linear = sp.Poly(sp.prod(triangle(u,v)[0]),x)
    check(f.gcd(f.diff()).degree()==0 and f.gcd(linear).degree()==0,
          'singular specialized shape list or zero linear form')
    return [p.all_coeffs() for p,e in f.factor_list()[1]]

def gen():
    import numpy as np
    obj={}
    specifications = {(1,alpha,True) for alpha,_,_ in WITNESSES} | {(beta,gamma,False) for _,beta,gamma in WITNESSES}
    for u,v,first in sorted(specifications):
        rows=[]
        for i,f in enumerate(factors(u,v,first)):
            coordinates=lambda z: [round(z.real*B),round(z.imag*B)]
            for r in sorted(np.roots([float(z) for z in f]),key=lambda y:(round(y.real,8),y.imag)):
                z=complex(r)
                linear=[u+v*z,v*z-1-v,u-(1+u)*z]
                rows.append([i,coordinates(z),[coordinates(m/np.sqrt(w)) for m,w in zip([1,u,v],linear)]])
        obj[f'{u},{v}']=rows
    DATA.write_text(json.dumps(obj,indent=1)+'\n')

def add(z,w): return (z[0]+w[0],z[1]+w[1])
def mul(z,w): return (z[0]*w[0]-z[1]*w[1],z[1]*w[0]+z[0]*w[1])
def scale(z,k): return (z[0]*k,z[1]*k)
def lower(z): return max(abs(z[0]),abs(z[1]))
def upper(z): return abs(z[0])+abs(z[1])
def taylor(f,c):
    g=[]
    for k in f:
        g=[add((int(k),0),mul(g[0],c)) if g else (int(k),0)]+[
               add(g[i-1],mul(g[i],c)) for i in range(1,len(g))]+g[-1:]
    return g

def certify(uv,first,rows):
    u,v=uv
    polys=factors(u,v,first)
    check(len(rows)==sum(len(p)-1 for p in polys),'incomplete root list')
    for i,p in enumerate(polys):
        check(sum(r[0]==i for r in rows)==len(p)-1,'incomplete factor list')
    for lhs,rhs in combinations(rows,2):
        check(lower(add(lhs[1],scale(rhs[1],-1)))>2*B*R,'root overlap')
    for i,center,rad in rows:
        z=scale(center,Fraction(1,B))
        d=taylor(polys[i],z)
        check(lower(d[1])*R>upper(d[0])+sum(upper(d[j])*R**j for j in range(2,len(d))),'shape Rouche failed')
        for (mass,offset,slope),root in zip(((1,u,v),(u,-1-v,v),(v,u,-1-u)),rad,strict=True):
            w=scale(root,Fraction(1,B))
            ell=add((offset,0),scale(z,slope))
            err=abs(slope)*R
            check(lower(ell)>err and lower(w)>H,'zero coordinate')
            const=add(mul(ell,mul(w,w)),(-mass**2,0))
            check(2*lower(mul(ell,w))*H>upper(const)+upper(ell)*H**2+err*(upper(w)+H)**2,'radical Rouche failed')
    return [r[2] for r in rows]

def run():
    genericA=retained(1,a,True)
    genericB=retained(b,c,False)
    check(genericA.LC()==4 and sp.expand(genericB.LC()-(1+b)**4)==0,
          'unexpected leading coefficients')
    obj=json.loads(DATA.read_text())
    for alpha,beta,gamma in WITNESSES:
        check(sp.Poly(genericA.as_expr().subs(a,alpha),x)==retained(1,alpha,True) and
              sp.Poly(genericB.as_expr().subs({b:beta,c:gamma}),x)==retained(beta,gamma,False),
              'specialization mismatch')
        outer=certify((1,alpha),True,obj[f'1,{alpha}'])
        inner=certify((beta,gamma),False,obj[f'{beta},{gamma}'])
        signs=[(1,)+s for s in product((1,-1),repeat=8)]
        counts=0
        margin=None
        radius=int(B*H)
        for A in outer:
            for D in inner:
                terms=[mul(r,s) for r in A for s in D]
                error=sum((upper(r)+upper(s))*radius+radius**2 for r in A for s in D)
                for sign in signs:
                    approximate=tuple(sum(e*f[j] for e,f in zip(sign,terms)) for j in (0,1))
                    certified=lower(approximate)-error
                    check(certified>0,'inconclusive torque exclusion')
                    margin=certified if margin is None else min(margin,certified)
                    counts+=1
        print(f'Split (1,1,{alpha}) | (1,{beta},{gamma}): polynomial identities PASS')
        print(f'{len(outer)} x {len(inner)} x {len(signs)} = {counts} signed sums excluded')
        print('Certified lower bound on modulus:',margin*10**9//B**2,'/ 10^9')
    print('PASS')

if __name__=='__main__':
    import sys
    if '--generate' in sys.argv: gen()
    run()
