"""Derive branch factors before specializing equal and mixed masses."""
import sympy as s
from itertools import product
z,a,b,c=s.symbols('z a b c')
E=z*z-z+1
L=[E,z**4-5*z**3+9*z**2-5*z+1,z**4+z**3-2*z+1,z**4-2*z**3+z+1]
def quintic(e,f):
    return ((a+b)*(z-1)**3*z*z+a*(z-1)**2*z*z+c*e*(z-1)**3-c*f*z**3-
            a*e*(z-1)**2-b*f*z*z)
Q=[quintic(e,f) for e,f in [(1,1),(1,-1),(-1,-1),(-1,1)]]
final=s.div(Q[-1],E,z)
if final[1]!=0:raise ValueError('lost shape')
G=L+Q[:3]+[final[0]]
def specific(m=(1,2,7)):
    return [[int(v) for v in s.Poly(q.subs(dict(zip((a,b,c),m))),z).all_coeffs()] for q in G]
if __name__=='__main__':
    from AlignedWitness import MIXED_FACTORS,OTHER_FACTORS
    for mass,checks in [((1,2,7),MIXED_FACTORS),((2,3,7),OTHER_FACTORS)]:
        if specific(mass)!=checks:raise ValueError('coefficient mismatch')
        sub=dict(zip((a,b,c),mass))
        full=s.Poly(s.prod(G).subs(sub),z)
        d=s.Poly((z*(z-1)*(b+c*z)*(-a-c+c*z)*(b-(a+b)*z)).subs(sub),z)
        if full.degree()!=32 or full.gcd(full.diff()).degree()!=0 or full.gcd(d).degree()!=0:
            raise ArithmeticError('singular specialization')
        print(f'All 32 specialized shapes at {mass} simple, finite, all denominators nonzero. PASS')
