from pathlib import Path
import json
import sys
data=json.loads(Path(sys.argv[1]).read_text())
prefix="""import Std
/- Exact sign tests for diagram 98, evaluated by the Lean kernel. -/
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace SignCertificate

structure Gaussian where
  re : Int
  im : Int
  deriving Repr, Inhabited
instance : Add Gaussian := ⟨fun a b => ⟨a.re+b.re,a.im+b.im⟩⟩
instance : Sub Gaussian := ⟨fun a b => ⟨a.re-b.re,a.im-b.im⟩⟩
instance : Mul Gaussian := ⟨fun a b => ⟨a.re*b.re-a.im*b.im,a.re*b.im+a.im*b.re⟩⟩
def upper (a : Gaussian) := a.re.natAbs + a.im.natAbs
def lower (a : Gaussian) := max a.re.natAbs a.im.natAbs
structure Triple where
  a : Gaussian
  b : Gaussian
  c : Gaussian
  deriving Inhabited
def sumUpper (v : Triple) := upper v.a + upper v.b + upper v.c
-- The scaled Gaussian centers have denominator 2^48 and each radius is 2^-32.
def err (v w : Triple) : Nat := 3*2^16*(sumUpper v + sumUpper w) + 9*2^32
def forms (w : Triple) := [w.a+w.b+w.c,w.a+w.b-w.c,w.a-w.b+w.c,w.a-w.b-w.c]
def allowed (x y z : Gaussian) (e : Nat) : Bool :=
  lower (x+y+z)>e && lower (x+y-z)>e && lower (x-y+z)>e && lower (x-y-z)>e
def good (equilateral : Bool) (v w : Triple) : Bool := Id.run do
  let f := (forms w).zipIdx
  let e := err v w
  for (a,i) in f do
    let x := v.a*a
    for (b,j) in f do
      let y := v.b*b
      for (c,k) in f do
        if !(equilateral && i==j && j==k) then
          if !(allowed x y (v.c*c) e) then return false
  return true
"""
def point(z):return '⟨'+str(z[0])+','+str(z[1])+'⟩'
def rows(field,prefix):
 s=''
 for i,(_,_,p) in enumerate(data[field]):
  s+='def '+prefix+str(i)+' : Triple := ⟨'+','.join(map(point,p))+'⟩\n'
 return s
s=prefix+rows('1','eq')+rows('3','mix')
s+='def mixed : List Triple := ['+','.join('mix'+str(i) for i in range(30))+']\n'
for i,(k,_,p) in enumerate(data['1']):
 s+='theorem row'+str(i)+' : mixed.all (good '+('true' if k==0 else 'false')+' eq'+str(i)+') = true := by decide +kernel\n'
s+='def equalShapes : List (Bool × Triple) := ['+','.join('('+('true' if k==0 else 'false')+',eq'+str(i)+')' for i,(k,_,_) in enumerate(data['1']))+']\n'
s+='theorem sign_exclusion : equalShapes.all (fun a => mixed.all (good a.1 a.2)) = true := by\n  simp [equalShapes, '+', '.join('row'+str(i) for i in range(26))+']\n#print axioms sign_exclusion\nend SignCertificate\n'
Path(__file__).with_name('DiagramSigns.lean').write_text(s)
