"""Build exact Lean cubic-test input from the previously isolated mixed radicals."""
import json,sys
from pathlib import Path
rows=json.loads(Path(sys.argv[1]).read_text())['3']
prefix="""import Std
/- Dyadic rectangles for the cubic-order torque tests at t=3. -/
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace CubicTorque
structure I where
  l : Int
  h : Int
  deriving Inhabited
def S : Int := 2^80
def ceil (x y : Int) := -((-x)/y)
def ofI (n : Int) : I := ⟨n*S,n*S⟩
instance : Add I := ⟨fun a b => ⟨a.l+b.l,a.h+b.h⟩⟩
instance : Neg I := ⟨fun a => ⟨-a.h,-a.l⟩⟩
instance : Sub I := ⟨fun a b => a+(-b)⟩
instance : Mul I := ⟨fun a b =>
  ⟨min (min (a.l*b.l) (a.l*b.h)) (min (a.h*b.l) (a.h*b.h)) / S,
   ceil (max (max (a.l*b.l) (a.l*b.h)) (max (a.h*b.l) (a.h*b.h))) S⟩⟩
def sq (a : I) : I :=
  ⟨(if a.l≤0 && 0≤a.h then 0 else min (a.l^2) (a.h^2))/S,
   ceil (max (a.l^2) (a.h^2)) S⟩
structure C where
  r : I
  i : I
  deriving Inhabited
def v (a : Int) : C := ⟨ofI a,ofI 0⟩
instance : Add C := ⟨fun a b => ⟨a.r+b.r,a.i+b.i⟩⟩
instance : Neg C := ⟨fun a => ⟨-a.r,-a.i⟩⟩
instance : Sub C := ⟨fun a b => a+(-b)⟩
instance : Mul C := ⟨fun a b => ⟨a.r*b.r-a.i*b.i,a.r*b.i+a.i*b.r⟩⟩
def inv (a : C) : Option C := do
  let norm := sq a.r + sq a.i
  if norm.l ≤ 0 then none else
    let u : I := ⟨S*S/norm.h,ceil (S*S) norm.l⟩
    return ⟨a.r*u,-(a.i*u)⟩
def seed (x y h : Int) : C :=
  ⟨⟨x*2^32-h,x*2^32+h⟩,⟨y*2^32-h,y*2^32+h⟩⟩
def lowerI (a : I) := max (max a.l (-a.h)) 0
def lower (a : C) := max (lowerI a.r) (lowerI a.i)
def root3 : Int := 2093920942154385339393396
def omega : C := ⟨⟨-S/2,-S/2⟩,⟨root3/2,(root3+2)/2⟩⟩
theorem root_bound : root3^2 < 3*S^2 ∧ 3*S^2 < (root3+1)^2 := by decide +kernel
abbrev Triple := C × C × C
def scale (x : C) (y : Triple) : Triple := (x*y.1,x*y.2.1,x*y.2.2)
def W (x : C) (invM : C) : Triple := scale invM
 (v 1+v 3*x, v 3*x-v 4,v 1-v 2*x)
def dot (x y : Triple) : C := x.1*y.1+x.2.1*y.2.1+x.2.2*y.2.2
def cube (x : C) := x*x*x
def passes (a b c : C) : Bool :=
  lower a > S/20 && lower ((v 3)*b*cube a+c) > 2*S
structure Row where
  y : C
  rad : Triple
  deriving Inhabited
def check (r : Row) : Option Bool := do
  let invM ← inv (v 5)
  let y := r.y
  let w := W y invM
  let wy : Triple := (← inv w.1,← inv w.2.1,← inv w.2.2)
  let iy ← inv y
  let sy ← inv (y*y)
  let sy1 ← inv ((y-v 1)*(y-v 1))
  let four : List (C × C) := [(v 1,v 1),(v 1,v (-1)),(v (-1),v 1),(v (-1),v (-1))]
  for (sg,sh) in four do
    let a : Triple := (r.rad.1,sg*r.rad.2.1,sh*r.rad.2.2)
    let test := cube (dot a wy)
    for d in [v 1,omega,omega*omega] do
      if !(passes (dot a (W (d*iy) invM)) (v 25) test) then return false
    for (u,z) in four do
      let f := v 2+v 3*u*sy-v 3*z*sy1
      if !(passes (dot a w) (f*f) test) then return false
  return true
"""
s=prefix
def pt(p,e):return f'seed ({p[0]}) ({p[1]}) (2^{e})'
for i,(_,y,a) in enumerate(rows):
 s+=f'def mix{i} : Row := ⟨'+pt(y,41)+',('+','.join(pt(z,48) for z in a)+')⟩\n'
 s+=f'theorem cubic{i} : check mix{i} = some true := by decide +kernel\n'
s+='def rows : List Row := ['+','.join('mix'+str(i) for i in range(len(rows)))+']\n'
s+='theorem all_cubic_tests : rows.all (fun r => check r == some true) = true := by\n  simp [rows,'+','.join('cubic'+str(i) for i in range(len(rows)))+']\n#print axioms all_cubic_tests\nend CubicTorque\n'
Path(__file__).with_name('DiagramCubic.lean').write_text(s)
