"""Exact fourth and fifth Taylor coefficients of the reduced critical potential."""
from itertools import combinations
from sympy.polys.matrices import DomainMatrix
from pentagon_hessian import Q, K, zero, one, positions, matrix, aspoly, sign_of, a, b

def col(values):
    return DomainMatrix([[v] for v in values],(len(values),1),K)
def dot(U,V):
    return sum((u*v for u,v in zip(U,V)),zero)

def calculate():
    if not __debug__:
        raise RuntimeError('Assertions must be enabled.')
    m=(-Q(345208)*a**3-Q(320500)*a**2+Q(1180980)*a+Q(1216925))/Q(247215)
    masses=[one]*5+[m]
    tau=[v for XX,YY in positions for v in (-YY,XX)]
    # D5-invariant slice perpendicular to the rotation vector.  Omit variable
    # y_0 from the free coordinates, and solve tau dot v=0 for its value.
    free=[i for i in range(12) if i!=1]
    basis=DomainMatrix([[-tau[j] if i==1 else one if i==j else zero for j in free] for i in range(12)],(12,11),K)
    assert (col(tau).transpose()*basis).is_zero_matrix
    H=matrix(m,full=True)
    M=basis.transpose()*H*basis
    ring=range(9)
    A=M.extract(ring,ring)
    V=M.extract(ring,[9])
    inv=A.inv()
    u=-(inv*V)
    v=col([p[0] for p in u.to_list()]+[one,zero])
    assert (M*v).is_zero_matrix
    fullv=[e[0] for e in (basis*v).to_list()]
    total4=zero
    bdir=[zero]*12
    for i,j in combinations(range(6),2):
        d=[positions[i][k]-positions[j][k] for k in range(2)]
        e=[fullv[2*i+k]-fullv[2*j+k] for k in range(2)]
        r=one if j==5 else a if j-i in (1,4) else b
        p,q=Q(2)*dot(d,e)/r**2,dot(e,e)/r**2
        mm=masses[i]*masses[j]
        total4+=mm/r*(Q(3,8)*q**2-Q(15,16)*p**2*q+Q(35,128)*p**4)
        for k in range(2):
            val=-Q(2)*mm/r**3*(d[k]*(-Q(3,2)*q+Q(15,8)*p*p)-Q(3,2)*p*e[k])
            bdir[2*i+k]+=val
            bdir[2*j+k]-=val
    bb=(basis.transpose()*col(bdir)).extract(ring,[0])
    corr=(bb.transpose()*inv*bb).to_list()[0][0]/Q(8)
    k4=total4-corr
    # The ring graph is stationary to second order at z=(sigma,0). Its
    # quadratic Taylor approximation therefore gives energy correct to order 5.
    w=-(inv*bb).scalarmul(Q(1,2))
    liftw=[v[0] for v in (basis*col([v[0] for v in w.to_list()]+[zero,zero])).to_list()]
    coefficients=[zero]*6
    from pentagon_hessian import base_multiplier
    coefficients[4]=(m+base_multiplier)*sum((masses[i//2]*h*h for i,h in enumerate(liftw)),zero)/Q(2)
    for i,j in combinations(range(6),2):
        d=[positions[i][k]-positions[j][k] for k in range(2)]
        e=[fullv[2*i+k]-fullv[2*j+k] for k in range(2)]
        g=[liftw[2*i+k]-liftw[2*j+k] for k in range(2)]
        r=one if j==5 else a if j-i in (1,4) else b
        A=[zero,Q(2)*dot(d,e)/r**2,(dot(e,e)+Q(2)*dot(d,g))/r**2,Q(2)*dot(e,g)/r**2,dot(g,g)/r**2,zero]
        power=[one,zero,zero,zero,zero,zero]
        binom=one
        for k in range(6):
            for n in (4,5):
                coefficients[n]+=masses[i]*masses[j]/r*binom*power[n]
            power=[sum((power[n-h]*A[h] for h in range(1,n+1)),zero) for n in range(6)]
            binom*=Q(-1-2*k,2*(k+1))
    assert coefficients[4]==k4
    assert sign_of(k4)==-1
    for n in (4,5):
        exact=coefficients[n]
        sign=sign_of(exact)
        assert sign != 0
        val=exact*Q(sign)
        lo,hi=0,1
        while sign_of(val-Q(hi,1000000))>0:
            hi*=2
        while hi-lo>1:
            mid=(hi+lo)//2
            if sign_of(val-Q(mid,1000000))>0: lo=mid
            else: hi=mid
        bounds=(lo,hi) if sign>0 else (-hi,-lo)
        print(f'Order {n} exact coefficient: {aspoly(exact)}')
        print(f'{bounds[0]}/1000000 < c_{n} < {bounds[1]}/1000000')
    print('PASS')
if __name__=='__main__':
    calculate()
