"""Exact Hessian on a rotation slice of a pentagon of unit masses and central mass t."""
from itertools import combinations
import sympy as sp
from sympy.polys.matrices import DomainMatrix

x,t=sp.symbols('x t')
minimal=x**4-5*x*x+5
K=sp.QQ.alg_field_from_poly(sp.Poly(minimal,x),alias='a',root_index=2)
a=K.unit
def Q(num,den=1):
    return K.convert(sp.Rational(num,den))
zero,one=Q(0),Q(1)
phi=Q(3)-a*a
b=phi*a
C=one-a*a/Q(2)
S=b/Q(2)
positions=[(one,zero)]
for j in range(4):
    X,Y=positions[-1]
    positions.append((C*X-S*Y,S*X+C*Y))
positions.append((zero,zero))
base_multiplier=one/a+one/b
def matrix(m,full=False):
    mass=[one]*5+[m]
    lam=m+base_multiplier
    H=[[lam*mass[i//2] if i==j else zero for j in range(12)] for i in range(12)]
    for (i,j) in combinations(range(6),2):
        d=[positions[i][k]-positions[j][k] for k in range(2)]
        chord=one if j==5 else a if j-i in (1,4) else b
        assert sum([v*v for v in d],zero)==chord**2
        for k in range(2):
            for l in range(2):
                entry=mass[i]*mass[j]*(Q(3)*d[k]*d[l]/chord**5-(one if k==l else zero)/chord**3)
                I,J=2*i+k,2*j+k
                H[I][2*i+l]+=entry
                H[J][2*j+l]+=entry
                H[I][2*j+l]-=entry
                H[J][2*i+l]-=entry
    q=[z for P in positions for z in P]
    rotation=[z for X,Y in positions for z in (-Y,X)]
    def mv(v):
        return [sum((h*y for h,y in zip(row,v)),zero) for row in H]
    assert mv(rotation)==[zero]*12
    assert mv(q)==[Q(3)*lam*mass[i//2]*q[i] for i in range(12)]
    if full:
        return DomainMatrix(H,(12,12),K)
    choice=[i for i in range(12) if i!=1]
    data=[[H[i][j] for j in choice] for i in choice]
    return DomainMatrix(data,(11,11),K)

def aspoly(v):
    return sp.Poly.from_list(v.to_list(),x,domain=sp.QQ).as_expr()

def detpoly():
    # Nine outer-only rows have degree at most one, two central rows at most two.
    # A determinant of this 11 by 11 matrix therefore has degree at most 13.
    values=[matrix(Q(i)).det() for i in range(14)]
    output=0
    for n in range(14):
        output+=aspoly(values[0])*sp.prod(t-i for i in range(n))/sp.factorial(n)
        values=[v-u for u,v in zip(values,values[1:])]
    pt=sp.Poly(output,t)
    from sympy.polys.rings import ring as poly_ring
    R,T=poly_ring('t',K)
    p=R.zero
    for (i,),v in pt.terms():
        digit=zero
        for h in sp.Poly(v,x).all_coeffs(): digit=digit*a+K.convert(h)
        p+=T**i*digit
    return p

def sign_of(v):
    lo=sp.Rational(1175570504584946,10**15)
    hi=sp.Rational(1175570504584947,10**15)
    assert minimal.subs(x,lo)>0 and minimal.subs(x,hi)<0
    bound=(0,0)
    for c in sp.Poly(aspoly(v),x).all_coeffs():
        candidates=[q*s for q in bound for s in (lo,hi)]
        bound=(min(candidates)+c,max(candidates)+c)
    if bound[0]>0: return 1
    if bound[1]<0: return -1
    if v==zero: return 0
    raise ValueError(f'Sign could not be exact-certified: {aspoly(v)}')
def inertia(m):
    data=matrix(m).to_list()
    pivots=[]
    while data:
        pivot=data[0][0]
        pivots.append(sign_of(pivot))
        data=[[data[i][j]-data[i][0]*data[0][j]/pivot for j in range(1,len(data))] for i in range(1,len(data))]
    return pivots
def run():
    if not __debug__:
        raise RuntimeError("Python assertions must be enabled.")
    p = detpoly()
    # Coefficients of the known candidate factors are independently checked
    # against the determinant computed directly from the Cartesian Hessian.
    neg = -Q(24,605)*a**3-Q(37,242)*a
    critical = (-Q(345208)*a**3-Q(320500)*a**2+Q(1180980)*a+Q(1216925))/Q(247215)
    T=p.ring.gens[0]
    assert p.degree()==9
    assert p.monic()==T**2*(T+base_multiplier)**3*(T-neg)**2*(T-critical)**2
    assert sign_of(base_multiplier)==1 and sign_of(neg)==-1
    lower=sp.Rational(6478190058,10**9)
    upper=sp.Rational(6478190060,10**9)
    assert sign_of(critical - K.convert(lower))==1 and sign_of(K.convert(upper)-critical)==1
    quartic=sp.Poly(6674805*t**4-44892900*t**3+8565750*t*t+13531500*t+2057501,t)
    norm=sp.Poly(sp.resultant(minimal,t-aspoly(critical),x),t)
    assert norm.monic()==quartic.monic()
    assert quartic.is_irreducible and quartic.count_roots(lower,upper)==1
    Hstar=matrix(critical)
    assert Hstar.rank()==9
    # In this slice the final two coordinates are the central body's two
    # displacement components. The projection of the kernel onto them is an
    # isomorphism iff appending the two projection rows gives full rank.
    central_projection=[[one if j==9+i else zero for j in range(11)] for i in range(2)]
    assert Hstar.vstack(DomainMatrix(central_projection,(2,11),K)).rank()==11
    sides=[]
    for val in (1,7):
        signs=inertia(Q(val))
        sides.append(signs.count(-1))
        print(f"At t = {val}, all pivot signs: {signs}")
    assert sides==[0,2]
    print("Rotation-slice determinant: degree 9, monic factorization verified exactly.")
    print("Unique positive critical value:",lower,"< t_c <",upper)
    print("Primitive irreducible polynomial:",quartic.as_expr())
    print("Critical slice rank: 9/11. Projection of kernel to central displacement: rank 2.")
    print("Shape Morse index: 0 below t_c, 2 above t_c.")
    print("PASS")
if __name__ == "__main__":
    run()
