import EntropyModel
import SharpStability
import OrbitParseval

namespace SicEntropy
open scoped BigOperators

/-- Upper bound, in bits, on the order-two stabilizer Rényi entropy for the
two-qubit–qutrit local Weyl displacement basis, for every normalized pure state. -/
theorem local_entropy_upper (F : SicMarginal.Pure)
    (unit : (∑ i, ∑ k, Complex.normSq (F i k)) = 1) :
    let t := 1/Real.sqrt 13
    let h := (1-3*t)/Real.sqrt 3
    stabilizerEntropy F ≤ Real.logb 2 (13/2) -
      Real.logb 2 (1+13/24*(h^2*(2*t-h)^2)) := by
  apply entropy_from_moments F unit
  · simpa only [probability, Complex.normSq_eq_norm_sq] using
      SicOrbitParseval.total_squared_overlap F unit
  · exact SicStability.sharp_lower F unit

#print axioms local_entropy_upper
end SicEntropy
