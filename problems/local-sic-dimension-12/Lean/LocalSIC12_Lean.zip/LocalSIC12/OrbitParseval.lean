import PauliCoordinates
import LocalOrbit
import Mathlib.Tactic

/-! Full, coordinate-level Parseval identity for the 144 displacements of the
two-qubit–qutrit Weyl orbit. -/
namespace SicOrbitParseval
open Matrix SicPauli SicExpansion SicMarginal SicLocalOrbit
open scoped BigOperators Matrix ComplexConjugate
noncomputable section

private theorem sumSq_dot {ι : Type*} [Fintype ι] (v : ι → ℂ) :
    ((∑ i, Complex.normSq (v i) : ℝ) : ℂ) = star v ⬝ᵥ v := by
  simp only [Complex.ofReal_sum, Complex.normSq_eq_conj_mul_self, dotProduct]
  rfl

private theorem frame_identity {ι κ : Type*} [Fintype ι] [Fintype κ] [DecidableEq κ]
    (M : Matrix ι κ ℂ) (c : ℝ) (hM : Mᴴ * M = (c : ℂ) • 1) (v : κ → ℂ) :
    ∑ i, Complex.normSq ((M *ᵥ v) i) = c * ∑ j, Complex.normSq (v j) := by
  apply Complex.ofReal_injective
  rw [Complex.ofReal_mul, sumSq_dot, sumSq_dot, star_mulVec, dotProduct_mulVec, vecMul_vecMul,
    hM, vecMul_smul, vecMul_one, smul_dotProduct, smul_eq_mul]

private def pauliFrame : Matrix (Fin 16) (Fin 4 × Fin 4) ℂ :=
  fun p ij => twoPauli p ij.1 ij.2

private theorem pauli_gram : pauliFrameᴴ * pauliFrame = (4 : ℂ) • 1 := by
  ext ⟨i,j⟩ ⟨k,l⟩
  have h := congrArg (fun R : Local => R k l) (reconstruct (Matrix.single i j (1:ℂ)))
  have hc (p : Fin 16) : star (twoPauli p i j) = twoPauli p j i :=
    congrArg (fun T : Local => T j i) (pauli_hermitian p).eq
  simp only [Matrix.mul_apply, Matrix.conjTranspose_apply, pauliFrame, hc,
    Matrix.smul_apply, Matrix.one_apply, Prod.mk.injEq, smul_eq_mul]
  simpa only [Matrix.sum_apply, Matrix.smul_apply, Matrix.trace_mul_single, MulOpposite.op_one,
    one_smul, Matrix.single_apply, smul_eq_mul] using h

private def colPair (F : Pure) (p : Fin 16) (k l : Fin 3) : ℂ :=
  ∑ i, star (F i k) * (twoPauli p * F) i l

private theorem colPair_frame (F : Pure) (p : Fin 16) (k l : Fin 3) :
    colPair F p k l =
    (pauliFrame *ᵥ fun ij => star (F ij.1 k) * F ij.2 l) p := by
  simp only [colPair, Matrix.mul_apply, Matrix.mulVec, dotProduct, pauliFrame,
    Fintype.sum_prod_type, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i _
  apply Finset.sum_congr rfl
  intro j _
  ring

private def columnMass (F : Pure) (k : Fin 3) : ℝ := ∑ i, Complex.normSq (F i k)

private theorem pauli_parseval (F : Pure) (k l : Fin 3) :
    ∑ p, Complex.normSq (colPair F p k l) = 4 * (columnMass F k * columnMass F l) := by
  simp only [colPair_frame]
  rw [frame_identity pauliFrame 4 (by exact_mod_cast pauli_gram)]
  simp only [Fintype.sum_prod_type, Complex.normSq_mul, Complex.normSq_conj,
    columnMass, Finset.sum_mul, Finset.mul_sum, Complex.star_def]
  exact Finset.sum_comm

private def qFrame : Matrix (Fin 3) (Fin 3) ℂ := fun b l => omega3 ^ (b.val * l.val)

private theorem q_gram : qFrameᴴ * qFrame = (3 : ℂ) • 1 := by
  have hr := omega3_primitive.geom_sum_eq_zero (by decide)
  have h2 : omega3^2 = -omega3-1 := by
    simp [Finset.sum_range_succ] at hr
    linear_combination hr
  have h3 := omega3_primitive.pow_eq_one
  have h4 : omega3^4 = omega3 := by rw [show 4=3+1 by decide, pow_succ, h3, one_mul]
  have h5 : omega3^5 = -omega3-1 := by rw [show 5=3+2 by decide, pow_add, h3, one_mul, h2]
  have hc : star omega3 = -omega3-1 := by
    have hmul : star omega3 * omega3 = 1 := by
      rw [Complex.star_def, Complex.conj_mul', omega3_primitive.norm'_eq_one (by decide)]
      norm_num
    have hn : omega3 ≠ 0 := by intro h; simp [h] at h3
    apply mul_right_cancel₀ hn
    rw [hmul]
    linear_combination h2
  ext i j
  fin_cases i <;> fin_cases j <;>
    norm_num [Matrix.mul_apply, Fin.sum_univ_succ, Matrix.conjTranspose_apply,
      qFrame, Matrix.one_apply, h4, h2, hc] <;>
    ring_nf <;> simp only [h5,h4,h3,h2] <;> ring

private theorem amplitude_frame (F : Pure) (p : Fin 16) (a b : Fin 3) :
    amplitude F (orbit (p,a,b) F) =
      (qFrame *ᵥ fun l => colPair F p (l+a) l) b := by
  unfold amplitude
  rw [Finset.sum_comm]
  rw [← Equiv.sum_comp (Equiv.addRight a)
    (fun k => ∑ i, star (F i k) * orbit (p, a, b) F i k)]
  simp only [Equiv.coe_addRight, orbit, add_sub_cancel_right, Matrix.mulVec, dotProduct,
    qFrame, colPair, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro k _
  apply Finset.sum_congr rfl
  intro i _
  ring

private theorem qutrit_parseval (F : Pure) (p : Fin 16) (a : Fin 3) :
    ∑ b, Complex.normSq (amplitude F (orbit (p,a,b) F)) =
      3 * ∑ l, Complex.normSq (colPair F p (l+a) l) := by
  simp only [amplitude_frame]
  exact frame_identity qFrame 3 (by exact_mod_cast q_gram) _

/-- Parseval for all 144 physical two-qubit--qutrit overlaps. -/
theorem total_squared_overlap (F : Pure) (hunit : (∑ i, ∑ k, Complex.normSq (F i k)) = 1) :
    (∑ g : Label, Complex.normSq (amplitude F (orbit g F))) = 12 := by
  have hcol : (∑ l, columnMass F l) = 1 := by
    unfold columnMass
    rw [Finset.sum_comm, hunit]
  have htranslate (l : Fin 3) : (∑ a, columnMass F (l+a)) = 1 := by
    simpa only [Equiv.coe_addLeft] using (Equiv.sum_comp (Equiv.addLeft l) (columnMass F)).trans hcol
  simp only [Fintype.sum_prod_type, qutrit_parseval, Finset.mul_sum]
  rw [Finset.sum_comm]
  calc
    _ = ∑ a, ∑ l, 3 * (4 * (columnMass F (l+a) * columnMass F l)) := by
      apply Finset.sum_congr rfl
      intro a _
      rw [Finset.sum_comm]
      apply Finset.sum_congr rfl
      intro l _
      rw [← Finset.mul_sum, pauli_parseval]
    _ = 12 * ∑ l, columnMass F l := by
      rw [Finset.sum_comm, Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro l _
      calc
        _ = (∑ a, columnMass F (l+a)) * (12 * columnMass F l) := by
          rw [Finset.sum_mul]
          apply Finset.sum_congr rfl
          intro a _
          ring
        _ = _ := by rw [htranslate, one_mul]
    _ = _ := by rw [hcol]; norm_num

end
end SicOrbitParseval
