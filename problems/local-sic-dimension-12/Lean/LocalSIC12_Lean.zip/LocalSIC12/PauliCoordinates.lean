import PauliTables
import Mathlib.LinearAlgebra.Matrix.Hermitian
set_option maxHeartbeats 12000000
set_option maxRecDepth 16000

noncomputable section
open scoped Matrix BigOperators
namespace SicExpansion
open SicPauli
attribute [local simp] two_0 two_1 two_2 two_3 two_4 two_5 two_6 two_7 two_8 two_9 two_10 two_11 two_12 two_13 two_14 two_15

private theorem expand4 {A : Type*} [AddCommMonoid A] (f : Fin 4 → A) :
    ∑ i, f i = f 0 + (f 1 + (f 2 + (f 3))) := by
  simp only [Fin.sum_univ_succ, Finset.univ_unique, Finset.sum_singleton]
  rfl

private theorem expand16 {A : Type*} [AddCommMonoid A] (f : Fin 16 → A) :
    ∑ i, f i = f 0 + (f 1 + (f 2 + (f 3 + (f 4 + (f 5 + (f 6 + (f 7 + (f 8 + (f 9 + (f 10 + (f 11 + (f 12 + (f 13 + (f 14 + (f 15))))))))))))))) := by
  simp only [Fin.sum_univ_succ, Finset.univ_unique, Finset.sum_singleton]
  rfl

/-- The two-qubit Pauli matrices form a trace-orthogonal coordinate system. -/
theorem reconstruct (R : Matrix (Fin 4) (Fin 4) ℂ) :
    (∑ p : Fin 16, (twoPauli p * R).trace • twoPauli p) = (4:ℂ) • R := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [expand16, expand4, Matrix.trace, Matrix.diag, Matrix.mul_apply,
      Matrix.smul_apply, Matrix.add_apply, smul_eq_mul] <;> ring_nf <;> simp <;> ring

theorem pauli_hermitian (p : Fin 16) : (twoPauli p).IsHermitian := by
  unfold Matrix.IsHermitian
  ext i j
  fin_cases p <;> fin_cases i <;> fin_cases j <;> simp [Matrix.conjTranspose_apply]

theorem pauli_zero : twoPauli 0 = 1 := by
  ext i j
  fin_cases i <;> fin_cases j <;> simp

end SicExpansion
