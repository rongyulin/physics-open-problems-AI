import Marginal
import Mathlib.Analysis.Matrix.Spectrum
import Mathlib.Tactic

/-! Four-dimensional Hilbert--Schmidt estimates used in the sharp local stability bound. -/
namespace SicTraceBounds
noncomputable section
open scoped Matrix BigOperators
open Matrix Unitary SicMarginal

private theorem scalar4 (a b c d : ℝ) (h : a+b+c+d=0) :
    4*a^2 ≤ 3*(a^2+b^2+c^2+d^2) := by
  have ha : a= -(b+c+d) := by linarith
  rw [ha]
  nlinarith [sq_nonneg (b-c),sq_nonneg (b-d),sq_nonneg (c-d)]

theorem spectrum_sq_trace {K : Local} (hK : K.IsHermitian) :
    (K*K).trace.re = ∑ j, (hK.eigenvalues j)^2 := by
  let D : Local := diagonal (RCLike.ofReal ∘ hK.eigenvalues)
  let e := conjStarAlgAut ℂ _ hK.eigenvectorUnitary
  have h : e D = K := hK.spectral_theorem.symm
  have hh : K*K = e (D*D) := by rw [map_mul,h]
  rw [hh]
  dsimp only [e,D]
  rw [conjStarAlgAut_apply, trace_mul_cycle, coe_star_mul_self, one_mul,
    diagonal_mul_diagonal, trace_diagonal, Complex.re_sum]
  simp [pow_two]

theorem traceless_eigenvalue_bound {K : Local} (hK : K.IsHermitian) (htr : K.trace=0)
    (j : Fin 4) : (hK.eigenvalues j)^2 ≤ 3/4 * (K*K).trace.re := by
  rw [spectrum_sq_trace hK]
  have hz : ∑ j, hK.eigenvalues j = 0 := by
    have hh := congrArg Complex.re (htr.symm.trans hK.trace_eq_sum_eigenvalues)
    simpa using hh.symm
  let f := hK.eigenvalues
  change f j ^ 2 ≤ 3 / 4 * ∑ k, f k ^ 2
  change ∑ k, f k = 0 at hz
  simp only [Fin.sum_univ_four] at hz ⊢
  have s0 := scalar4 (f 0) (f 1) (f 2) (f 3) (by linarith)
  have s1 := scalar4 (f 1) (f 0) (f 2) (f 3) (by linarith)
  have s2 := scalar4 (f 2) (f 0) (f 1) (f 3) (by linarith)
  have s3 := scalar4 (f 3) (f 0) (f 1) (f 2) (by linarith)
  fin_cases j <;> simp <;> linarith

theorem unit_null_vector {R : Local} (herm : R.IsHermitian) (sing : R.det=0) :
    ∃ v : Fin 4 → ℂ, (∑ i, Complex.normSq (v i)) = 1 ∧ R *ᵥ v = 0 := by
  rw [herm.det_eq_prod_eigenvalues, Finset.prod_eq_zero_iff] at sing
  obtain ⟨j,_,hz⟩ := sing
  have he : herm.eigenvalues j=0 := by simpa using congrArg Complex.re hz
  refine ⟨⇑(herm.eigenvectorBasis j), ?_, ?_⟩
  · simp_rw [Complex.normSq_eq_norm_sq]
    rw [← EuclideanSpace.norm_sq_eq, OrthonormalBasis.norm_eq_one, one_pow]
  · simp [herm.mulVec_eigenvectorBasis, he]

#print axioms traceless_eigenvalue_bound
#print axioms unit_null_vector
end
end SicTraceBounds
