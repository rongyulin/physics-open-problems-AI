import PauliMatrixLink
import DetPolynomial
import Mathlib.Tactic.NormNum.Irrational
import Mathlib.Data.ZMod.Basic
import Mathlib.Tactic

/-!
The real determinant is A + 8L sqrt(13), with A,L integers.
L is a sum of fifteen signed odd products, hence is odd and nonzero.
As sqrt(13) is irrational, the determinant cannot vanish.
-/
namespace SicPauli
open scoped Matrix BigOperators
noncomputable section
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000

private theorem sign_mod2 (s : Fin 16 → Bool) (p : Fin 16) :
    (signs s p : ZMod 2) = 1 := by
  cases h : s p <;> simp [signs, h]

theorem oddCoeff_ne_zero (s : Fin 16 → Bool) : oddCoeff (signs s) ≠ 0 := by
  have ho : (oddCoeff (signs s) : ZMod 2) = 1 := by
    simp only [oddCoeff, Int.cast_add, Int.cast_mul, Int.cast_neg, Int.cast_one, sign_mod2]
    decide
  intro h
  rw [h] at ho
  simpa using ho

/-- In fact every irrational scale whose square is rational gives a
nonsingular shift of every two-qubit Pauli sign sum. -/
theorem signed_det_nonzero_general (s : Fin 16 → Bool) (t : ℝ) (r : ℚ)
    (ht : Irrational t) (hsq : t^2 = (r:ℝ)) :
    ((t : ℂ) • (1 : Matrix (Fin 4) (Fin 4) ℂ) + signedPauli s).det ≠ 0 := by
  intro h
  rw [matrix_link] at h
  have hd := congrArg Complex.re h
  rw [coordinate_det_re, Complex.zero_re] at hd
  have h4 : t^4 = (r:ℝ)^2 := by rw [show (4:ℕ)=2*2 by decide, pow_mul, hsq]
  rw [h4,hsq] at hd
  let A : ℚ := r^2 + r*(quadCoeff (signs s) : ℚ) + constantCoeff (signs s)
  let B : ℤ := 8*oddCoeff (signs s)
  have nz : B ≠ 0 := mul_ne_zero (by decide) (oddCoeff_ne_zero s)
  have hb : (B:ℝ) ≠ 0 := by exact_mod_cast nz
  apply ht
  refine ⟨-A / (B:ℚ), ?_⟩
  push_cast
  apply (div_eq_iff hb).mpr
  dsimp [A,B]
  push_cast
  linarith

theorem signed_det_nonzero (s : Fin 16 → Bool) :
    ((Real.sqrt 13 : ℂ) • (1 : Matrix (Fin 4) (Fin 4) ℂ) + signedPauli s).det ≠ 0 := by
  apply signed_det_nonzero_general s (Real.sqrt 13) 13
  · norm_num
  · norm_num

#print axioms signed_det_nonzero
end
end SicPauli
