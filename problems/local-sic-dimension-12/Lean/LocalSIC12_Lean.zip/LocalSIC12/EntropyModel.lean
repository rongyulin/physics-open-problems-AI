import EntropyGap
import LocalOrbit

namespace SicEntropy
open SicMarginal SicPauli SicLocalOrbit
open scoped BigOperators

noncomputable def probability (F : Pure) (g : Label) : ℝ := ‖amplitude F (orbit g F)‖^2

/-- Stabilizer Rényi entropy of order two, in bits, for the local displacement basis. -/
noncomputable def stabilizerEntropy (F : Pure) : ℝ :=
  -Real.logb 2 ((∑ g, (probability F g)^2) / 12)

private def qubitLabel : Fin 16 ↪ Label :=
  ⟨fun p => (p, 0, 0), fun _ _ e => congrArg Prod.fst e⟩

private theorem origin_probability (F : Pure) (unit : (∑ i, ∑ k, Complex.normSq (F i k)) = 1) :
    probability F (0,0,0) = 1 := by
  have hc : amplitude F F = 1 := by
    have hh := congrArg (fun z : ℝ => (z:ℂ)) unit
    unfold amplitude
    simpa only [Complex.ofReal_sum, Complex.ofReal_one, Complex.normSq_eq_conj_mul_self,
      Complex.star_def] using hh
  simp [probability, twoPauli_identity, hc]

/-- Translate the full displacement Parseval identity and the sharp local modulus bound
into the stated upper bound on the actual protocol's entropy. -/
theorem entropy_from_moments (F : Pure) (unit : (∑ i, ∑ k, Complex.normSq (F i k)) = 1)
    (total : ∑ g, probability F g = 12)
    (localGap : (1-3/Real.sqrt 13)^2/3 ≤ ∑ p : Fin 16,
      if p=0 then 0 else (‖overlap F (twoPauli p)‖ - 1/Real.sqrt 13)^2) :
    let t := 1/Real.sqrt 13
    let h := (1-3*t)/Real.sqrt 3
    stabilizerEntropy F ≤ Real.logb 2 (13/2) -
      Real.logb 2 (1+13/24*(h^2*(2*t-h)^2)) := by
  classical
  let t : ℝ := 1/Real.sqrt 13
  let h : ℝ := (1-3*t)/Real.sqrt 3
  let z := fun p => ‖overlap F (twoPauli p)‖
  let s : Finset (Fin 16) := Finset.univ.erase 0
  let e : Finset Label := Finset.univ.erase (0,0,0)
  have st : (Real.sqrt 13)^2 = 13 := Real.sq_sqrt (by norm_num)
  have sh : (Real.sqrt 3)^2 = 3 := Real.sq_sqrt (by norm_num)
  have spos : 0 < Real.sqrt 13 := by positivity
  have spos3 : 0 < Real.sqrt 3 := by positivity
  have hl : 3 < Real.sqrt 13 := by nlinarith
  have hh0 : 0 ≤ h := by
    dsimp [h,t]
    apply div_nonneg _ spos3.le
    field_simp
    linarith
  have ht : h ≤ t := by
    dsimp [h,t]
    rw [div_le_iff₀ spos3]
    field_simp
    have h4 : Real.sqrt 13 < 4 := by nlinarith
    have h1 : 1 < Real.sqrt 3 := by nlinarith
    linarith
  have t2 : t^2=1/13 := by dsimp [t]; rw [div_pow,st]; norm_num
  have h2 : h^2=(1-3/Real.sqrt 13)^2/3 := by
    dsimp [h,t]; rw [div_pow,sh]; ring
  have gap : h^2 ≤ ∑ i ∈ s, (z i - t)^2 := by
    rw [h2]
    let f := fun p : Fin 16 => if p=0 then 0 else (z p-t)^2
    have hx := Finset.sum_erase_add (Finset.univ : Finset (Fin 16)) f (Finset.mem_univ 0)
    have hf : f 0 = 0 := by simp [f]
    rw [hf, add_zero] at hx
    have hr : (∑ i ∈ s, (z i-t)^2) = ∑ i ∈ s, f i := by
      apply Finset.sum_congr rfl
      intro i hi
      simp [f, (Finset.mem_erase.mp hi).1]
    rw [hr, hx]
    exact localGap
  have small := square_overlap_gap s z hh0 ht (fun i _ => norm_nonneg _) gap
  have subset : s.map qubitLabel ⊆ e := by
    intro g hg
    obtain ⟨p,hp,rfl⟩ := Finset.mem_map.mp hg
    apply Finset.mem_erase.mpr
    exact ⟨fun he => (Finset.mem_erase.mp hp).1 (congrArg Prod.fst he), Finset.mem_univ _⟩
  have hlocal : ∑ p ∈ s, ((z p)^2-t^2)^2 =
      ∑ g ∈ s.map qubitLabel, (probability F g-1/13)^2 := by
    rw [Finset.sum_map]
    apply Finset.sum_congr rfl
    intro p _
    simp [z,qubitLabel,probability,amplitude_qubit,t2]
  rw [hlocal] at small
  have strong := small.trans (Finset.sum_le_sum_of_subset_of_nonneg subset
    (fun g _ _ => sq_nonneg (probability F g-1/13)))
  have origin := origin_probability F unit
  have sumQ : (∑ g ∈ e, probability F g) = 11 := by
    have h0 := Finset.sum_erase_add (Finset.univ : Finset Label) (probability F)
      (Finset.mem_univ (0,0,0))
    change (∑ g ∈ e, probability F g) + probability F (0,0,0) = _ at h0
    linarith
  have card : e.card=143 := by simp [e,Label,Fintype.card_prod]
  have sumQ2 := Finset.sum_erase_add (Finset.univ : Finset Label) (fun g => (probability F g)^2)
      (Finset.mem_univ (0,0,0))
  change (∑ g ∈ e, (probability F g)^2) + (probability F (0,0,0))^2 = _ at sumQ2
  rw [origin] at sumQ2
  have hv : (∑ g ∈ e, (probability F g-1/13)^2) =
      (∑ g ∈ e, (probability F g)^2) - (2/13)*(∑ g ∈ e, probability F g)+e.card*(1/169) := by
    simp only [Finset.mul_sum, ← Finset.sum_sub_distrib]
    rw [show (e.card:ℝ)*(1/169) = ∑ _g ∈ e, (1/169:ℝ) by simp]
    rw [← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro g _
    ring
  rw [sumQ,card] at hv
  have fourth : 24/13+h^2*(2*t-h)^2 ≤ ∑ g, (probability F g)^2 := by linarith
  change -Real.logb 2 ((∑ g, (probability F g)^2) / 12) ≤ Real.logb 2 (13/2) -
    Real.logb 2 (1 + 13/24*(h^2*(2*t-h)^2))
  rw [show (13:ℝ)/24*(h^2*(2*t-h)^2) = 13*(h^2*(2*t-h)^2)/24 by ring]
  exact
    (entropy_of_fourth_moment (v:=h^2*(2*t-h)^2) (by positivity) fourth)
end SicEntropy
