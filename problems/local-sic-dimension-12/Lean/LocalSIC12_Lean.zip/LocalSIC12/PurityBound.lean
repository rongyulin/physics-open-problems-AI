import Mathlib.Algebra.Order.BigOperators.Ring.Finset
import Mathlib.Data.Real.Sqrt
import Mathlib.Tactic

/-!
After the Galois-conjugate eigenvalue pairs have been identified, multiply
each remaining eigenvalue of the reduced state by the subsystem dimension
`m`. Their nonnegativity, sum, and second moment imply a lower bound on the
ancillary dimension `q`. The spectral pairing itself is proved in the paper.
-/
namespace SicPurity
open scoped BigOperators

/-- A trace-one marginal has `m-q` guaranteed pairs of eigenvalues `0,2/m`.
The positive-mass remainder, scaled by `m`, is `e`. The second equality is
the flat-Pauli purity `tr ρ² = (m+q)/(mq+1)` with denominators cleared. -/
theorem ancilla_bound_of_paired_spectrum {ι : Type*} [Fintype ι] (m q : ℝ)
    (hm : 4 ≤ m) (hq : 0 < q) (hsmall : q < m)
    (e : ι → ℝ) (hne : ∀ i, 0 ≤ e i)
    (htrace : 2*(m-q) + ∑ i, e i = m)
    (hpurity : (m*q+1) * (4*(m-q) + ∑ i, (e i)^2) = m^2*(m+q)) :
    (m + Real.sqrt m)/2 < q := by
  let r := 2*q-m
  have hsum : ∑ i, e i = r := by dsimp [r]; linarith
  have hr : 0 ≤ r := hsum ▸ Finset.sum_nonneg (fun i _ => hne i)
  have hrm : r < m := by dsimp [r]; linarith
  have hsumsq : ∑ i, (e i)^2 ≤ r^2 := by
    rw [← hsum]
    exact Finset.sum_sq_le_sq_sum_of_nonneg (fun i _ => hne i)
  have hmpos : 0 < m := by linarith
  have hfactor : 0 ≤ (m+r-2)*(m*r^2+2*r-m^2-2*m) := by
    calc
      0 ≤ 2*(m*q+1)*(r^2-∑ i, (e i)^2) :=
        mul_nonneg (by positivity) (sub_nonneg.mpr hsumsq)
      _ = _ := by dsimp [r]; nlinarith only [hpurity]
  have hinner : 0 ≤ m*r^2+2*r-m^2-2*m :=
    nonneg_of_mul_nonneg_right hfactor (by linarith : 0 < m+r-2)
  by_contra! hle
  have hrroot : r ≤ Real.sqrt m := by dsimp [r]; linarith
  have hsquare : r^2 ≤ m := by
    rw [← Real.sq_sqrt hmpos.le]
    exact (sq_le_sq₀ hr (Real.sqrt_nonneg m)).mpr hrroot
  have hproduct := mul_le_mul_of_nonneg_left hsquare hmpos.le
  nlinarith only [hinner, hproduct, hrm]

#print axioms ancilla_bound_of_paired_spectrum
end SicPurity
