#!/usr/bin/env sh
# Compile the pinned project, then replay each module in a separate Lean kernel process.
# On a fresh checkout, 'lake exe cache get' downloads precompiled mathlib dependencies.
set -eu
cd "$(dirname "$0")"
lake build
modules=$(awk '/^\[\[lean_lib\]\]$/ { getline; gsub(/"/, "", $3); print $3 }' lakefile.toml)
test -n "$modules"
# The manifest uses one whitespace-free Lean identifier for each module name.
lake env sh -ec '
    for module do
        leanchecker --verbose "$module"
    done
    printf "All %s project modules passed kernel replay.\n" "$#"
' sh $modules
