import SignSpectra
import DetPolynomial
import PauliMatrixLink
import PauliCoordinates
import Mathlib.Analysis.Matrix.Spectrum
import Mathlib.Tactic

/-!
Transfer the normalized ten-sign certificate to the characteristic polynomial
of the fifteen actual two-qubit Pauli terms. For a raw coefficient matrix C
and local sign vectors a,b, replace Cᵢⱼ with aᵢ Cᵢⱼ bⱼ and retain the
product of all six local signs. Every product is represented by Boolean
equality. All coefficient identifications below are checked as polynomial
identities using that every sign has square one.
-/
namespace SicSignedGap
open SicSignSpectra SicPauli

set_option maxRecDepth 100000
set_option maxHeartbeats 100000000

private def sg (s : Bool) : ℤ := if s then 1 else -1

private theorem sg_mul (a b : Bool) : sg (a == b) = sg a * sg b := by
  cases a <;> cases b <;> decide

private def coefficientsZ (a b c d e f g h i η : ℤ) : ℤ × ℤ := Id.run do
  let det := a*(e*i-f*h) + b*(f*g-d*i) + c*(d*h-e*g)
  let linear := -8*(a+b+c+d+e+f+g+h+i-η*det)
  let rowNorm := (a+b+c)^2 + (d+e+f)^2 + (g+h+i)^2
  let colNorm := (a+d+g)^2 + (b+e+h)^2 + (c+f+i)^2
  let cofactorNorm := (1-η*(e*i-f*h))^2 + (1-η*(f*g-d*i))^2 + (1-η*(d*h-e*g))^2
       + (1-η*(c*h-b*i))^2 + (1-η*(a*i-c*g))^2 + (1-η*(b*g-a*h))^2
       + (1-η*(b*f-c*e))^2 + (1-η*(c*d-a*f))^2 + (1-η*(a*e-b*d))^2
  return (linear, 225-4*(rowNorm+colNorm+cofactorNorm))

private theorem coefficients_decode (a b c d e f g h i η : Bool) :
    coefficients a b c d e f g h i η =
    coefficientsZ (sg a) (sg b) (sg c) (sg d) (sg e) (sg f) (sg g) (sg h) (sg i) (sg η) := rfl

private theorem s2 (a : Bool) : (sg a)^2 = 1 := by cases a <;> decide
private theorem s4 (a : Bool) : (sg a)^4 = 1 := by cases a <;> decide

private theorem quadratic (s : Fin 16 → Bool) : quadCoeff (fun i => sg (s i)) = -30 := by
  simp only [quadCoeff, s2]
  norm_num

private theorem classification (s : Fin 16 → Bool) :
    allowed (-8*oddCoeff (fun i => sg (s i)), constantCoeff (fun i => sg (s i))) := by
  have hc := coefficient_classification
    ((s 4 == s 5) == s 1)
    ((s 4 == s 6) == s 2)
    ((s 4 == s 7) == s 3)
    ((s 8 == s 9) == s 1)
    ((s 8 == s 10) == s 2)
    ((s 8 == s 11) == s 3)
    ((s 12 == s 13) == s 1)
    ((s 12 == s 14) == s 2)
    ((s 12 == s 15) == s 3)
    (((((s 4 == s 8) == s 12) == s 1) == s 2) == s 3)
  rw [coefficients_decode] at hc
  simp only [sg_mul] at hc
  convert hc using 1
  congr 1
  all_goals
    simp only [oddCoeff, constantCoeff]
    ring_nf
    simp only [s2, s4]
    ring

/-- No signed 4-by-4 Pauli coordinate matrix has a characteristic root
of magnitude strictly between 3 and 17/4. The sign convention in the
determinant identity is det(t I + S). -/
private theorem coordinate_det_gap (s : Fin 16 → Bool) (t : ℝ) (hl : 3 < |t|)
    (hu : |t| < 17 / 4) :
    (coordinateMatrix (fun i => sg (s i)) t).det ≠ 0 := by
  intro he
  have hq := classification s
  have hroot := quartic_abs_gap hq (-t) (by simpa only [abs_neg] using hl)
    (by simpa only [abs_neg] using hu)
  apply hroot
  have hz := congrArg Complex.re he
  rw [coordinate_det_re, quadratic, Complex.zero_re] at hz
  push_cast at hz ⊢
  norm_num only [Prod.fst, Prod.snd] at *
  linarith only [hz]

/-- The open annuli 3 < |t| < 17/4 contain no signed Pauli eigenvalue.
The shift t in the matrix is arbitrary and real. -/
theorem signed_det_gap (s : Fin 16 → Bool) (t : ℝ) (hl : 3 < |t|)
    (hu : |t| < 17 / 4) :
    ((t : ℂ) • (1 : Matrix (Fin 4) (Fin 4) ℂ) + signedPauli s).det ≠ 0 := by
  rw [matrix_link]
  exact coordinate_det_gap s t hl hu

open scoped Matrix ComplexOrder
private abbrev CM := Matrix (Fin 4) (Fin 4) ℂ

noncomputable def shifted (s : Fin 16 → Bool) : CM :=
  (Real.sqrt 13 : ℂ) • (1 : CM) + signedPauli s

theorem shifted_hermitian (s : Fin 16 → Bool) : (shifted s).IsHermitian := by
  unfold shifted
  apply Matrix.IsHermitian.add
  · change _ᴴ = _
    simp [Matrix.conjTranspose_smul]
  · change _ᴴ = _
    rw [signedPauli, Matrix.conjTranspose_sum]
    apply Finset.sum_congr rfl
    intro p _
    by_cases hp : p = 0
    · simp [hp]
    · cases s p <;> simp [hp, (SicExpansion.pauli_hermitian p).eq]

private theorem eigenvalue_of_det_gap (S : CM)
    (hg : ∀ t : ℝ, 3 < |t| → |t| < 17/4 → ((t : ℂ) • (1:CM) + S).det ≠ 0)
    (hH : (((Real.sqrt 13 : ℂ) • (1 : CM)) + S).IsHermitian)
    (j : Fin 4) : Real.sqrt 13 - 3 ≤ |hH.eigenvalues j| := by
  by_contra! h
  let v := hH.eigenvalues j
  have habs : |v| < Real.sqrt 13 - 3 := h
  obtain ⟨hl,hr⟩ := abs_lt.mp habs
  have hc : Real.sqrt 13 < 29/8 := by
    nlinarith [Real.sq_sqrt (show (0:ℝ) ≤ 13 by norm_num)]
  have ha : 3 < Real.sqrt 13-v := by linarith
  have hb : Real.sqrt 13-v < 17/4 := by linarith
  have hpos := abs_of_pos (show 0 < Real.sqrt 13-v by linarith)
  have gap := hg (Real.sqrt 13-v) (hpos.trans_gt ha) (hpos.trans_lt hb)
  have hmem := hH.eigenvalues_mem_spectrum_real j
  rw [spectrum.mem_iff, Matrix.isUnit_iff_isUnit_det, isUnit_iff_ne_zero, not_not] at hmem
  change (algebraMap ℝ CM v - ((Real.sqrt 13:ℂ) • (1:CM) + S)).det = 0 at hmem
  have hm : algebraMap ℝ CM v - ((Real.sqrt 13:ℂ) • (1:CM) + S) =
      - (((Real.sqrt 13-v:ℝ) : ℂ) • (1:CM) + S) := by
    rw [Algebra.algebraMap_eq_smul_one]
    change (v:ℂ) • (1:CM) - _ = _
    rw [Complex.ofReal_sub, sub_smul]
    abel
  rw [hm, Matrix.det_neg] at hmem
  exact gap (by simpa using hmem)


/-- Every eigenvalue of the shifted signed Pauli operator has absolute
value at least √13 − 3. -/
theorem signed_eigenvalue_gap (s : Fin 16 → Bool) (j : Fin 4) :
    Real.sqrt 13 - 3 ≤ |(shifted_hermitian s).eigenvalues j| :=
  eigenvalue_of_det_gap (signedPauli s) (signed_det_gap s) (shifted_hermitian s) j

#print axioms signed_det_gap
#print axioms signed_eigenvalue_gap
end SicSignedGap
