import Mathlib.LinearAlgebra.Matrix.Rank
import Mathlib.LinearAlgebra.Matrix.Hermitian
import Mathlib.LinearAlgebra.Matrix.Trace
import Mathlib.Data.Complex.BigOperators
import Mathlib.Tactic.Ring

/-! A 12-component pure state, written as a 4 by 3 coefficient matrix.
The reduced density matrix and its rank obstruction need no normalization hypothesis. -/
namespace SicMarginal

open scoped BigOperators Matrix ComplexConjugate
abbrev Pure := Matrix (Fin 4) (Fin 3) ℂ
abbrev Local := Matrix (Fin 4) (Fin 4) ℂ

noncomputable def density (F : Pure) : Local := F * Fᴴ

theorem density_apply (F : Pure) (i j : Fin 4) :
    density F i j = ∑ k, F i k * star (F j k) := by
  rfl

theorem density_isHermitian (F : Pure) : (density F).IsHermitian :=
  Matrix.isHermitian_mul_conjTranspose_self _

theorem density_rank_le (F : Pure) : (density F).rank ≤ 3 :=
  (Matrix.rank_mul_le_left F Fᴴ).trans F.rank_le_width

theorem density_det_zero (F : Pure) : (density F).det = 0 := by
  by_contra h
  have hunit : IsUnit (density F) := (density F).isUnit_iff_isUnit_det.mpr (isUnit_iff_ne_zero.mpr h)
  have hfull : (density F).rank = 4 := by
    simpa using (density F).rank_of_isUnit hunit
  have hsmall := density_rank_le F
  omega

theorem scaled_density_det_zero (F : Pure) (z : ℂ) : (z • density F).det = 0 := by
  simp [density_det_zero]

/-- Matrix-element expectation of a four-dimensional observable tensored with
the identity on the three-dimensional subsystem. -/
noncomputable def overlap (F : Pure) (P : Local) : ℂ :=
  ∑ i, ∑ j, ∑ k, star (F i k) * P i j * F j k

theorem trace_mul_density (F : Pure) (P : Local) :
    (P * density F).trace = overlap F P := by
  classical
  simp only [Matrix.trace, Matrix.diag_apply, Matrix.mul_apply, density_apply, overlap,
    Finset.mul_sum]
  refine Finset.sum_congr rfl fun i _ => Finset.sum_congr rfl fun j _ =>
    Finset.sum_congr rfl fun k _ => ?_
  ring

theorem density_mul_trace (F : Pure) (P : Local) :
    (density F * P).trace = overlap F P := by
  rw [Matrix.trace_mul_comm, trace_mul_density]

theorem density_trace (F : Pure) :
    (density F).trace = ((∑ i, ∑ k, Complex.normSq (F i k) : ℝ) : ℂ) := by
  simp only [Matrix.trace, Matrix.diag_apply, density_apply, Complex.star_def, Complex.mul_conj,
    Complex.ofReal_sum]

theorem density_trace_of_unit (F : Pure)
    (unit : (∑ i, ∑ k, Complex.normSq (F i k)) = 1) : (density F).trace = 1 := by
  simp [density_trace, unit]

#print axioms density_det_zero
#print axioms trace_mul_density
end SicMarginal
