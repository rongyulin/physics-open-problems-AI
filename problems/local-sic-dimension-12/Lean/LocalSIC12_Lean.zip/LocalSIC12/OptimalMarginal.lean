import PauliTables
import Marginal
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Tactic

/-! An explicit purification for the signed positive marginal on the symmetric
subspace. Its two-qubit Pauli expectations equal the local SIC target except
for XX, YY, ZZ, whose common expectation is one third. -/
namespace SicOptimal
open scoped Matrix BigOperators
open SicExpansion SicMarginal SicPauli
noncomputable section
set_option maxHeartbeats 5000000
set_option maxRecDepth 8000
set_option linter.unusedSimpArgs false
private def c : ℝ := 1 / Real.sqrt 13
private def a : ℝ := Real.sqrt (1 / 6)
private def b : ℝ := Real.sqrt (1 / 3 - c / 2)
private def u : ℝ := c / (2 * a)
private def v : ℝ := c / (2 * b)
private def w : ℝ := Real.sqrt (1/3 + c/2 - 2*u^2 - v^2)

/-- The second and third rows coincide, as the state has no component on
the antisymmetric two-qubit singlet. -/
def attainingState : Pure := !![
  ⟨u,-u⟩, ⟨0,-v⟩, (w:ℂ);
  (a:ℂ), 0, 0;
  (a:ℂ), 0, 0;
  0, (b:ℂ), 0]

private def target : Local := !![
  ((1/3+c/2:ℝ):ℂ), ⟨c/2,-c/2⟩, ⟨c/2,-c/2⟩, ⟨0,-c/2⟩;
  ⟨c/2,c/2⟩, 1/6, 1/6, 0;
  ⟨c/2,c/2⟩, 1/6, 1/6, 0;
  ⟨0,c/2⟩, 0, 0, ((1/3-c/2:ℝ):ℂ)]

private theorem scalars : a^2=1/6 ∧ b^2=1/3-c/2 ∧ a*u=c/2 ∧ b*v=c/2 ∧
    2*u^2+v^2+w^2=1/3+c/2 := by
  have h13 : (Real.sqrt 13)^2 = 13 := Real.sq_sqrt (by norm_num)
  have hs : 3 < Real.sqrt 13 := by nlinarith [Real.sqrt_nonneg 13]
  have ht : Real.sqrt 13 < 4 := by nlinarith [Real.sqrt_nonneg 13]
  have hc : 1/4 < c := by change 1/4 < 1/Real.sqrt 13; apply (lt_div_iff₀ (by positivity)).mpr; linarith
  have hc' : c < 1/3 := by change 1/Real.sqrt 13 < 1/3; apply (div_lt_iff₀ (by positivity)).mpr; linarith
  have hc2 : c^2 = 1/13 := by dsimp [c]; rw [div_pow,h13]; norm_num
  have ha : 0 < a := by unfold a; positivity
  have hb : 0 < b := Real.sqrt_pos.mpr (by linarith)
  have ha2 : a^2=1/6 := Real.sq_sqrt (by norm_num)
  have hb2 : b^2=1/3-c/2 := Real.sq_sqrt (by linarith)
  have hu : a*u = c/2 := by dsimp [u]; field_simp
  have hv : b*v = c/2 := by dsimp [v]; field_simp
  have hu' := congrArg (fun t : ℝ => t^2) hu
  have hv' := congrArg (fun t : ℝ => t^2) hv
  change (a*u)^2=(c/2)^2 at hu'
  change (b*v)^2=(c/2)^2 at hv'
  rw [mul_pow,ha2,div_pow,hc2] at hu'
  rw [mul_pow,hb2,div_pow,hc2] at hv'
  have hvbound : v^2 ≤ 3/26 := by nlinarith [mul_nonneg (show 0 ≤ 1/3-c/2-1/6 by linarith) (sq_nonneg v)]
  have hw : w^2=1/3+c/2-2*u^2-v^2 := Real.sq_sqrt (by nlinarith)
  exact ⟨ha2,hb2,hu,hv,by linarith⟩

private theorem state_density : density attainingState = target := by
  obtain ⟨ha,hb,hu,hv,hw⟩ := scalars
  apply Matrix.ext
  intro i j
  fin_cases i <;> fin_cases j <;> apply Complex.ext <;>
    norm_num [target, attainingState, density_apply, Fin.sum_univ_succ, Complex.star_def,
      Complex.mul_re, Complex.mul_im, Complex.add_re, Complex.add_im] <;> nlinarith

theorem attainingState_unit : (∑ i, ∑ k, Complex.normSq (attainingState i k)) = 1 := by
  have h := congrArg Complex.re (density_trace attainingState)
  have ht : target.trace = (1:ℂ) := by
    apply Complex.ext <;> norm_num [target, Matrix.trace, Matrix.diag, Fin.sum_univ_succ] <;> ring
  rw [state_density, ht, Complex.one_re, Complex.ofReal_re] at h
  exact h.symm

/-- Pauli indices 5, 10, 15 correspond to XX, YY, ZZ. -/
theorem attainingState_pauli (p : Fin 16) : overlap attainingState (twoPauli p) =
    if p=0 then 1 else if p=5 ∨ p=10 ∨ p=15 then 1/3 else ((1 / Real.sqrt 13 : ℝ):ℂ) := by
  change _ = if p=0 then 1 else if p=5 ∨ p=10 ∨ p=15 then 1/3 else (c:ℂ)
  rw [← trace_mul_density, state_density]
  fin_cases p
  case' «0» => change (twoPauli 0 * target).trace = (1:ℂ); rw [two_0]
  case' «1» => change (twoPauli 1 * target).trace = (c:ℂ); rw [two_1]
  case' «2» => change (twoPauli 2 * target).trace = (c:ℂ); rw [two_2]
  case' «3» => change (twoPauli 3 * target).trace = (c:ℂ); rw [two_3]
  case' «4» => change (twoPauli 4 * target).trace = (c:ℂ); rw [two_4]
  case' «5» => change (twoPauli 5 * target).trace = (1/3:ℂ); rw [two_5]
  case' «6» => change (twoPauli 6 * target).trace = (c:ℂ); rw [two_6]
  case' «7» => change (twoPauli 7 * target).trace = (c:ℂ); rw [two_7]
  case' «8» => change (twoPauli 8 * target).trace = (c:ℂ); rw [two_8]
  case' «9» => change (twoPauli 9 * target).trace = (c:ℂ); rw [two_9]
  case' «10» => change (twoPauli 10 * target).trace = (1/3:ℂ); rw [two_10]
  case' «11» => change (twoPauli 11 * target).trace = (c:ℂ); rw [two_11]
  case' «12» => change (twoPauli 12 * target).trace = (c:ℂ); rw [two_12]
  case' «13» => change (twoPauli 13 * target).trace = (c:ℂ); rw [two_13]
  case' «14» => change (twoPauli 14 * target).trace = (c:ℂ); rw [two_14]
  case' «15» => change (twoPauli 15 * target).trace = (1/3:ℂ); rw [two_15]
  all_goals apply Complex.ext <;>
    norm_num [Fin.ext_iff,target, Fin.sum_univ_succ, Matrix.trace, Matrix.diag,
      Matrix.mul_apply, Complex.mul_re, Complex.mul_im, Complex.add_re, Complex.add_im] <;> ring

#print axioms attainingState_unit
#print axioms attainingState_pauli
end
end SicOptimal
