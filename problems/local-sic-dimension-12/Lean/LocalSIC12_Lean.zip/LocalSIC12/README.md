# Lean verification of local Weyl–Heisenberg nonexistence in dimension twelve

The entry point is `SicNoGo.no_local_hw_sic_dim12` in `NoLocalSIC.lean`. It rules out a 144-ray SIC orbit under the tensor product of the qubit, qubit, and qutrit Weyl–Heisenberg actions for every pure state in the twelve-dimensional Hilbert space. The theorem `SicNoGo.no_local_hw_sic_dim12_with_phases` permits an arbitrary choice of unit scalar for each orbit representative.

## Reproduce the checks

Install elan, the standard Lean toolchain manager, and run these commands in this directory.

```sh
lake exe cache get
sh audit.sh
```

The toolchain file selects Lean 4.28.0. The Lake manifest pins mathlib to revision `8f9d9cff6bd728b17a24e163c9402775d9e6a365` and pins its transitive dependencies. The first command downloads the dependencies and their precompiled mathlib cache. The script builds the project from its Lean sources and starts a separate `leanchecker` process for each project module. This replays its declarations using the Lean kernel. The source files print the axioms of the named results during the build.

## Coverage

| Source | Result checked by Lean |
| --- | --- |
| `LocalOrbit`, `Marginal` | The action on amplitudes, its 144 labels, invariance under global phases, the trace expression for a Pauli expectation, and the singularity of every two-qubit marginal of a pure state on four by three levels. |
| `SicPauliBase`, `PauliTables`, `PauliCoordinates`, `PauliExpansion` | Explicit tensor Pauli operators, Hermiticity, Pauli reconstruction, and the signed expansion forced by flat expectations. |
| `DetFour`, `DetDefinitions`, `DetPolynomial`, `PauliMatrixLink`, `PauliObstruction` | A symbolic determinant for the true signed Pauli matrix. Every irrational real shift whose square is rational gives a nonzero determinant. |
| `NoLocalSIC` | The fifteen flat marginal expectations are impossible for an arbitrary unit pure state. The local SIC and its phased version are therefore impossible. |
| `SignSpectra`, `SignedGap` | Classification of the normalized sign coefficients and exclusion of determinant zeros for every signed Pauli matrix when the absolute shift lies strictly between 3 and 17/4. |
| `PauliParseval`, `PauliResidual`, `SpectralAction`, `TracelessBound`, `GapOnKernel` | Squared Pauli errors equal a matrix trace. Combining the null vector, the spectral gap, and the trace-zero constraint bounds the error of every pure state. |
| `OptimalMarginal`, `SharpStability` | `SicStability.sharp_minimum` identifies the least possible sum of fifteen squared Pauli-modulus errors as (1 − 3/√13)²/3. A normalized explicit witness has twelve target moduli 1/√13 and three equal to 1/3. |
| `EntropyGap`, `EntropyModel`, `OrbitParseval`, `EntropyBound` | The squared overlaps over all 144 local displacements sum to 12 for a unit pure state. `SicEntropy.local_entropy_upper` converts the sharp modulus bound into the stated inequality for the order-two stabilizer Rényi entropy in bits. |
| `PurityBound` | For a general subsystem dimension m and a smaller ancillary dimension q, a finite list of nonnegative residual eigenvalues with the specified trace and purity implies q > (m + √m)/2. The paper derives the hypotheses on this list by Galois conjugacy. |

The paper supplies the classification of abelian transitive projective unitary groups, the general Galois-conjugacy reduction, and the characterization of ancillary dimensions for the fifteen two-qubit expectations.
