import DetDefinitions
import PauliTables
import Mathlib.Tactic

namespace SicPauli
noncomputable section
open scoped BigOperators Matrix
set_option maxRecDepth 100000
set_option maxHeartbeats 100000000
set_option linter.unusedSimpArgs false

private theorem expand16 {A : Type*} [AddCommMonoid A] (f : Fin 16 → A) :
    ∑ i, f i = f 0 + (f 1 + (f 2 + (f 3 + (f 4 + (f 5 + (f 6 + (f 7 + (f 8 + (f 9 + (f 10 + (f 11 + (f 12 + (f 13 + (f 14 + (f 15))))))))))))))) := by
  simp only [Fin.sum_univ_succ, Finset.univ_unique, Finset.sum_singleton, Finset.univ_eq_empty, Finset.sum_empty, add_zero]
  all_goals rfl

def signs (s : Fin 16 → Bool) (p : Fin 16) : ℤ := if s p then 1 else -1

private theorem complex_sign (s : Fin 16 → Bool) (p : Fin 16) :
    (if s p then (1:ℂ) else -1) = (signs s p : ℂ) := by
  cases h : s p <;> simp [signs, h]

private theorem coord00 (z : Fin 16 → ℤ) (t : ℝ) :
    coordinateMatrix z t 0 0 = ⟨t + ((z 3 : ℝ) + (z 12 : ℝ) + (z 15 : ℝ)), 0⟩ := rfl

private theorem coord01 (z : Fin 16 → ℤ) (t : ℝ) :
    coordinateMatrix z t 0 1 = ⟨(z 1 : ℝ) + (z 13 : ℝ), - (z 2 : ℝ) - (z 14 : ℝ)⟩ := rfl

private theorem coord02 (z : Fin 16 → ℤ) (t : ℝ) :
    coordinateMatrix z t 0 2 = ⟨(z 4 : ℝ) + (z 7 : ℝ), - (z 8 : ℝ) - (z 11 : ℝ)⟩ := rfl

private theorem coord03 (z : Fin 16 → ℤ) (t : ℝ) :
    coordinateMatrix z t 0 3 = ⟨(z 5 : ℝ) - (z 10 : ℝ), - (z 6 : ℝ) - (z 9 : ℝ)⟩ := rfl

private theorem coord10 (z : Fin 16 → ℤ) (t : ℝ) :
    coordinateMatrix z t 1 0 = ⟨(z 1 : ℝ) + (z 13 : ℝ), (z 2 : ℝ) + (z 14 : ℝ)⟩ := rfl

private theorem coord11 (z : Fin 16 → ℤ) (t : ℝ) :
    coordinateMatrix z t 1 1 = ⟨t + (- (z 3 : ℝ) + (z 12 : ℝ) - (z 15 : ℝ)), 0⟩ := rfl

private theorem coord12 (z : Fin 16 → ℤ) (t : ℝ) :
    coordinateMatrix z t 1 2 = ⟨(z 5 : ℝ) + (z 10 : ℝ), (z 6 : ℝ) - (z 9 : ℝ)⟩ := rfl

private theorem coord13 (z : Fin 16 → ℤ) (t : ℝ) :
    coordinateMatrix z t 1 3 = ⟨(z 4 : ℝ) - (z 7 : ℝ), - (z 8 : ℝ) + (z 11 : ℝ)⟩ := rfl

private theorem coord20 (z : Fin 16 → ℤ) (t : ℝ) :
    coordinateMatrix z t 2 0 = ⟨(z 4 : ℝ) + (z 7 : ℝ), (z 8 : ℝ) + (z 11 : ℝ)⟩ := rfl

private theorem coord21 (z : Fin 16 → ℤ) (t : ℝ) :
    coordinateMatrix z t 2 1 = ⟨(z 5 : ℝ) + (z 10 : ℝ), - (z 6 : ℝ) + (z 9 : ℝ)⟩ := rfl

private theorem coord22 (z : Fin 16 → ℤ) (t : ℝ) :
    coordinateMatrix z t 2 2 = ⟨t + ((z 3 : ℝ) - (z 12 : ℝ) - (z 15 : ℝ)), 0⟩ := rfl

private theorem coord23 (z : Fin 16 → ℤ) (t : ℝ) :
    coordinateMatrix z t 2 3 = ⟨(z 1 : ℝ) - (z 13 : ℝ), - (z 2 : ℝ) + (z 14 : ℝ)⟩ := rfl

private theorem coord30 (z : Fin 16 → ℤ) (t : ℝ) :
    coordinateMatrix z t 3 0 = ⟨(z 5 : ℝ) - (z 10 : ℝ), (z 6 : ℝ) + (z 9 : ℝ)⟩ := rfl

private theorem coord31 (z : Fin 16 → ℤ) (t : ℝ) :
    coordinateMatrix z t 3 1 = ⟨(z 4 : ℝ) - (z 7 : ℝ), (z 8 : ℝ) - (z 11 : ℝ)⟩ := rfl

private theorem coord32 (z : Fin 16 → ℤ) (t : ℝ) :
    coordinateMatrix z t 3 2 = ⟨(z 1 : ℝ) - (z 13 : ℝ), (z 2 : ℝ) - (z 14 : ℝ)⟩ := rfl

private theorem coord33 (z : Fin 16 → ℤ) (t : ℝ) :
    coordinateMatrix z t 3 3 = ⟨t + (- (z 3 : ℝ) - (z 12 : ℝ) + (z 15 : ℝ)), 0⟩ := rfl

attribute [local simp] SicExpansion.two_0 SicExpansion.two_1 SicExpansion.two_2 SicExpansion.two_3 SicExpansion.two_4 SicExpansion.two_5 SicExpansion.two_6 SicExpansion.two_7 SicExpansion.two_8 SicExpansion.two_9 SicExpansion.two_10 SicExpansion.two_11 SicExpansion.two_12 SicExpansion.two_13 SicExpansion.two_14 SicExpansion.two_15
attribute [local simp] coord00 coord01 coord02 coord03 coord10 coord11 coord12 coord13 coord20 coord21 coord22 coord23 coord30 coord31 coord32 coord33

local macro "checkPauliEntry" : tactic =>
  `(tactic| (simp_rw [signedPauli, complex_sign, expand16]; apply Complex.ext <;>
    simp [Matrix.one_apply, Matrix.smul_apply, Matrix.add_apply, smul_eq_mul,
          Complex.add_re, Complex.add_im, Complex.mul_re, Complex.mul_im] <;> ring))

private theorem link00 (s : Fin 16 → Bool) (t : ℝ) :
 ((t:ℂ) • (1 : Matrix (Fin 4) (Fin 4) ℂ) + signedPauli s) 0 0 =
 coordinateMatrix (signs s) t 0 0 := by
  checkPauliEntry

private theorem link01 (s : Fin 16 → Bool) (t : ℝ) :
 ((t:ℂ) • (1 : Matrix (Fin 4) (Fin 4) ℂ) + signedPauli s) 0 1 =
 coordinateMatrix (signs s) t 0 1 := by
  checkPauliEntry

private theorem link02 (s : Fin 16 → Bool) (t : ℝ) :
 ((t:ℂ) • (1 : Matrix (Fin 4) (Fin 4) ℂ) + signedPauli s) 0 2 =
 coordinateMatrix (signs s) t 0 2 := by
  checkPauliEntry

private theorem link03 (s : Fin 16 → Bool) (t : ℝ) :
 ((t:ℂ) • (1 : Matrix (Fin 4) (Fin 4) ℂ) + signedPauli s) 0 3 =
 coordinateMatrix (signs s) t 0 3 := by
  checkPauliEntry

private theorem link10 (s : Fin 16 → Bool) (t : ℝ) :
 ((t:ℂ) • (1 : Matrix (Fin 4) (Fin 4) ℂ) + signedPauli s) 1 0 =
 coordinateMatrix (signs s) t 1 0 := by
  checkPauliEntry

private theorem link11 (s : Fin 16 → Bool) (t : ℝ) :
 ((t:ℂ) • (1 : Matrix (Fin 4) (Fin 4) ℂ) + signedPauli s) 1 1 =
 coordinateMatrix (signs s) t 1 1 := by
  checkPauliEntry

private theorem link12 (s : Fin 16 → Bool) (t : ℝ) :
 ((t:ℂ) • (1 : Matrix (Fin 4) (Fin 4) ℂ) + signedPauli s) 1 2 =
 coordinateMatrix (signs s) t 1 2 := by
  checkPauliEntry

private theorem link13 (s : Fin 16 → Bool) (t : ℝ) :
 ((t:ℂ) • (1 : Matrix (Fin 4) (Fin 4) ℂ) + signedPauli s) 1 3 =
 coordinateMatrix (signs s) t 1 3 := by
  checkPauliEntry

private theorem link20 (s : Fin 16 → Bool) (t : ℝ) :
 ((t:ℂ) • (1 : Matrix (Fin 4) (Fin 4) ℂ) + signedPauli s) 2 0 =
 coordinateMatrix (signs s) t 2 0 := by
  checkPauliEntry

private theorem link21 (s : Fin 16 → Bool) (t : ℝ) :
 ((t:ℂ) • (1 : Matrix (Fin 4) (Fin 4) ℂ) + signedPauli s) 2 1 =
 coordinateMatrix (signs s) t 2 1 := by
  checkPauliEntry

private theorem link22 (s : Fin 16 → Bool) (t : ℝ) :
 ((t:ℂ) • (1 : Matrix (Fin 4) (Fin 4) ℂ) + signedPauli s) 2 2 =
 coordinateMatrix (signs s) t 2 2 := by
  checkPauliEntry

private theorem link23 (s : Fin 16 → Bool) (t : ℝ) :
 ((t:ℂ) • (1 : Matrix (Fin 4) (Fin 4) ℂ) + signedPauli s) 2 3 =
 coordinateMatrix (signs s) t 2 3 := by
  checkPauliEntry

private theorem link30 (s : Fin 16 → Bool) (t : ℝ) :
 ((t:ℂ) • (1 : Matrix (Fin 4) (Fin 4) ℂ) + signedPauli s) 3 0 =
 coordinateMatrix (signs s) t 3 0 := by
  checkPauliEntry

private theorem link31 (s : Fin 16 → Bool) (t : ℝ) :
 ((t:ℂ) • (1 : Matrix (Fin 4) (Fin 4) ℂ) + signedPauli s) 3 1 =
 coordinateMatrix (signs s) t 3 1 := by
  checkPauliEntry

private theorem link32 (s : Fin 16 → Bool) (t : ℝ) :
 ((t:ℂ) • (1 : Matrix (Fin 4) (Fin 4) ℂ) + signedPauli s) 3 2 =
 coordinateMatrix (signs s) t 3 2 := by
  checkPauliEntry

private theorem link33 (s : Fin 16 → Bool) (t : ℝ) :
 ((t:ℂ) • (1 : Matrix (Fin 4) (Fin 4) ℂ) + signedPauli s) 3 3 =
 coordinateMatrix (signs s) t 3 3 := by
  checkPauliEntry
theorem matrix_link (s : Fin 16 → Bool) (t : ℝ) :
 (t:ℂ) • (1 : Matrix (Fin 4) (Fin 4) ℂ) + signedPauli s =
 coordinateMatrix (signs s) t := by
  ext i j : 1
  fin_cases i <;> fin_cases j
  · exact link00 s t
  · exact link01 s t
  · exact link02 s t
  · exact link03 s t
  · exact link10 s t
  · exact link11 s t
  · exact link12 s t
  · exact link13 s t
  · exact link20 s t
  · exact link21 s t
  · exact link22 s t
  · exact link23 s t
  · exact link30 s t
  · exact link31 s t
  · exact link32 s t
  · exact link33 s t
end
end SicPauli
