import PauliCoordinates
import Marginal
import Mathlib.LinearAlgebra.Matrix.Hermitian
import Mathlib.LinearAlgebra.Matrix.Trace
import Mathlib.Analysis.Complex.Norm
import Mathlib.Tactic

noncomputable section
open scoped Matrix ComplexOrder BigOperators
namespace SicExpansion
private abbrev M := Matrix (Fin 4) (Fin 4) ℂ
open SicPauli

theorem hermitian_trace_real {P R : M} (hP : P.IsHermitian) (hR : R.IsHermitian) :
    (((P * R).trace.re : ℝ) : ℂ) = (P * R).trace := by
  have e : star ((P * R).trace) = (P * R).trace := by
    rw [← Matrix.trace_conjTranspose, Matrix.conjTranspose_mul, hR.eq, hP.eq,
        Matrix.trace_mul_comm]
  apply Complex.ext
  · rfl
  · have e' := congrArg Complex.im e
    simp at e'
    simp only [Complex.ofReal_im]
    linarith

theorem scaled_sign {z : ℂ} (hreal : ((z.re : ℝ) : ℂ) = z)
    (habs : ‖z‖ = 1 / Real.sqrt 13) :
    (Real.sqrt 13 : ℂ) * z = if 0 ≤ z.re then 1 else -1 := by
  have hn : |z.re| = 1 / Real.sqrt 13 := by
    calc |z.re| = ‖((z.re : ℝ) : ℂ)‖ := by simp
         _ = ‖z‖ := by rw [hreal]
         _ = _ := habs
  have hp : Real.sqrt 13 ≠ 0 := by positivity
  split_ifs with hz
  · rw [abs_of_nonneg hz] at hn
    rw [← hreal, ← Complex.ofReal_mul, hn, mul_one_div_cancel hp, Complex.ofReal_one]
  · rw [abs_of_neg (lt_of_not_ge hz)] at hn
    have hz' : z.re = -(1 / Real.sqrt 13) := by linarith
    rw [← hreal, ← Complex.ofReal_mul, hz', mul_neg, mul_one_div_cancel hp]
    norm_num

/-- If all fifteen nonidentity local Pauli expectations have the SIC modulus,
then the marginal is a signed two-qubit Pauli sum with a fixed identity term. -/
theorem signed_expansion (R : M) (herm : R.IsHermitian) (unit : R.trace = 1)
    (flat : ∀ p : Fin 16, p ≠ 0 → ‖(twoPauli p * R).trace‖ = 1 / Real.sqrt 13) :
    ∃ s : Fin 16 → Bool, ((4:ℂ) * (Real.sqrt 13 : ℂ)) • R =
      (Real.sqrt 13 : ℂ) • (1 : M) + signedPauli s := by
  classical
  let s (p : Fin 16) : Bool := decide (0 ≤ (twoPauli p * R).trace.re)
  refine ⟨s, ?_⟩
  let c : ℂ := (Real.sqrt 13 : ℂ)
  have hexp := congrArg (fun Q : M => c • Q) (reconstruct R)
  have hcoeff (p : Fin 16) (hz : p ≠ 0) :
      c * (twoPauli p * R).trace = if s p then 1 else -1 := by
    simpa [s, c] using scaled_sign (hermitian_trace_real (pauli_hermitian p) herm) (flat p hz)
  have hsum (p : Fin 16) :
      c • ((twoPauli p * R).trace • twoPauli p) =
      (if p = 0 then c • (1:M) else 0) +
      (if p = 0 then 0 else (if s p then (1:ℂ) else -1) • twoPauli p) := by
    by_cases hz : p = 0
    · subst p; simp [pauli_zero, unit]
    · simp [hz, smul_smul, hcoeff p hz]
  change c • (∑ p : Fin 16, (twoPauli p * R).trace • twoPauli p) = c • ((4:ℂ) • R) at hexp
  rw [Finset.smul_sum, smul_smul, mul_comm c] at hexp
  calc
    _ = ∑ p : Fin 16, c • ((twoPauli p * R).trace • twoPauli p) := hexp.symm
    _ = _ := by simp_rw [hsum, Finset.sum_add_distrib]; simp [signedPauli, c]

theorem pure_signed_expansion (F : SicMarginal.Pure)
    (unit : (∑ i, ∑ k, Complex.normSq (F i k)) = 1)
    (flat : ∀ p : Fin 16, p ≠ 0 → ‖SicMarginal.overlap F (twoPauli p)‖ = 1 / Real.sqrt 13) :
    ∃ s : Fin 16 → Bool, ((4:ℂ) * (Real.sqrt 13 : ℂ)) • SicMarginal.density F =
      (Real.sqrt 13 : ℂ) • (1 : M) + signedPauli s := by
  apply signed_expansion _ (SicMarginal.density_isHermitian F) (SicMarginal.density_trace_of_unit F unit)
  simpa only [SicMarginal.trace_mul_density] using flat

#print axioms pure_signed_expansion
end SicExpansion
