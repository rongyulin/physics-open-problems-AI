import TracelessBound
import SpectralAction
import SignedGap

/-! A singular marginal forces a quantitative Hilbert--Schmidt error from
every candidate signed Pauli marginal. -/
namespace SicStability
noncomputable section
open scoped Matrix BigOperators
open SicMarginal SicSignedGap SicTraceBounds SicSpectralAction

theorem gap_on_kernel (R K : Local) (hR : R.IsHermitian) (hdet : R.det = 0)
    (hK : K.IsHermitian) (htr : K.trace = 0) (s : Fin 16 → Bool) (z : ℂ)
    (heq : K + shifted s = z • R) :
    (Real.sqrt 13 - 3)^2 ≤ 3 / 4 * (K*K).trace.re := by
  obtain ⟨v, hv, hnull⟩ := unit_null_vector hR hdet
  have h13 : (Real.sqrt 13)^2 = 13 := Real.sq_sqrt (by norm_num)
  have hpos : 0 ≤ Real.sqrt 13 - 3 := by nlinarith [Real.sqrt_nonneg 13]
  have hlow := lower_sq (shifted_hermitian s) (b:=(Real.sqrt 13-3)^2)
    (fun j => by simpa only [sq_abs] using pow_le_pow_left₀ hpos (signed_eigenvalue_gap s j) 2) v hv
  have hup := upper_sq hK (traceless_eigenvalue_bound hK htr) v hv
  have hboth := congrArg (fun M : Local => M *ᵥ v) heq
  change (K+shifted s) *ᵥ v = (z • R) *ᵥ v at hboth
  rw [Matrix.add_mulVec,Matrix.smul_mulVec,hnull,smul_zero] at hboth
  have hneg : (shifted s) *ᵥ v = -(K *ᵥ v) := by
    rw [eq_neg_iff_add_eq_zero, add_comm]; exact hboth
  simpa [hneg] using hlow.trans (by simpa [hneg] using hup :
    (∑ i, Complex.normSq (((shifted s) *ᵥ v) i)) ≤ 3/4*(K*K).trace.re)

#print axioms gap_on_kernel
end
end SicStability
