import Mathlib.Tactic

/-!
Exact arithmetic in the normalized signed-Pauli characteristic-polynomial
calculation. A Boolean represents one sign in the 3-by-3 correlation matrix.
The tenth sign is the product of the six original local signs.
-/
namespace SicSignSpectra

private def sign (s : Bool) : ℤ := if s then 1 else -1

/-- (Linear coefficient, constant coefficient) of the normalized quartic.
The nine entries are given in row-major order. -/
def coefficients (a b c d e f g h i parity : Bool) : ℤ × ℤ := Id.run do
  let a := sign a
  let b := sign b
  let c := sign c
  let d := sign d
  let e := sign e
  let f := sign f
  let g := sign g
  let h := sign h
  let i := sign i
  let η := sign parity
  let det := a*(e*i-f*h) + b*(f*g-d*i) + c*(d*h-e*g)
  let linear := -8*(a+b+c+d+e+f+g+h+i-η*det)
  let rowNorm := (a+b+c)^2 + (d+e+f)^2 + (g+h+i)^2
  let colNorm := (a+d+g)^2 + (b+e+h)^2 + (c+f+i)^2
  let cofactorNorm := (1-η*(e*i-f*h))^2 + (1-η*(f*g-d*i))^2 + (1-η*(d*h-e*g))^2
       + (1-η*(c*h-b*i))^2 + (1-η*(a*i-c*g))^2 + (1-η*(b*g-a*h))^2
       + (1-η*(b*f-c*e))^2 + (1-η*(c*d-a*f))^2 + (1-η*(a*e-b*d))^2
  return (linear, 225-4*(rowNorm+colNorm+cofactorNorm))

def signedPair (q : ℤ × ℤ) (b d : ℤ) : Prop :=
  q = (b,d) ∨ q = (-b,d)

def allowed (q : ℤ × ℤ) : Prop :=
  signedPair q 72 (-27) ∨ signedPair q 56 (-27) ∨ signedPair q 40 5 ∨
  signedPair q 24 69 ∨ signedPair q 8 37 ∨ signedPair q 8 165

instance (q : ℤ × ℤ) (b d : ℤ) : Decidable (signedPair q b d) := by
  unfold signedPair
  infer_instance

instance (q : ℤ × ℤ) : Decidable (allowed q) := by
  unfold allowed
  infer_instance

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem coefficient_classification :
    ∀ a b c d e f g h i η : Bool, allowed (coefficients a b c d e f g h i η) := by
  decide +kernel

/-- Coefficients of the homogeneous polynomial on the interval after the
substitution `l = 4*x - 12`, `r = 17 - 4*x`, in descending powers of l. -/
private def transformed (b d : ℝ) : Nat → ℝ
  | 0 => 1088*b + 256*d - 55199
  | 1 => 4032*b + 1024*d - 237456
  | 2 => 5568*b + 1536*d - 349824
  | 3 => 3392*b + 1024*d - 216576
  | _ => 768*b + 256*d - 48384

-- Writing a sign explicitly makes one positive polynomial cover both signs.
private theorem signs {q : ℤ × ℤ} (hq : allowed q) :
    ∃ k : ℝ, 0 < k * transformed q.1 q.2 0 ∧
      0 ≤ k * transformed q.1 q.2 1 ∧ 0 ≤ k * transformed q.1 q.2 2 ∧
      0 ≤ k * transformed q.1 q.2 3 ∧ 0 ≤ k * transformed q.1 q.2 4 := by
  rcases hq with (h|h|h|h|h|h) <;> rcases h with (rfl|rfl)
  · exact ⟨1, by norm_num [transformed]⟩
  all_goals exact ⟨-1, by norm_num [transformed]⟩

/-- No quartic on the finite list has a real root between 3 and 17/4. -/
theorem quartic_gap {q : ℤ × ℤ} (hq : allowed q) (x : ℝ)
    (hx : 3 < x) (hx' : x < 17 / 4) :
    x^4 - 30*x^2 + (q.1:ℝ)*x + (q.2:ℝ) ≠ 0 := by
  intro he
  let l := 4*x-12
  let r := 17-4*x
  have hl : 0 < l := by dsimp [l]; linarith
  have hr : 0 < r := by dsimp [r]; linarith
  obtain ⟨k, h₀, h₁, h₂, h₃, h₄⟩ := signs hq
  let c := transformed (q.1 : ℝ) (q.2 : ℝ)
  have hzero : (k*c 0)*l^4 + (k*c 1)*l^3*r + (k*c 2)*l^2*r^2 +
      (k*c 3)*l*r^3 + (k*c 4)*r^4 = 0 := by
    calc
      _ = 20^4*k*(x^4 - 30*x^2 + (q.1:ℝ)*x + (q.2:ℝ)) := by
        dsimp [c, transformed, l, r]
        ring
      _ = 0 := by rw [he, mul_zero]
  change 0 < k*c 0 at h₀
  change 0 ≤ k*c 1 at h₁
  change 0 ≤ k*c 2 at h₂
  change 0 ≤ k*c 3 at h₃
  change 0 ≤ k*c 4 at h₄
  exact (ne_of_gt (show 0 < (k*c 0)*l^4 + (k*c 1)*l^3*r + (k*c 2)*l^2*r^2 +
      (k*c 3)*l*r^3 + (k*c 4)*r^4 by positivity)) hzero

private theorem reflect {q : ℤ × ℤ} (hq : allowed q) : allowed (-q.1,q.2) := by
  rcases hq with (h|h|h|h|h|h) <;> rcases h with (rfl|rfl) <;> decide

/-- The two gaps around the positive and negative square roots of 13. -/
theorem quartic_abs_gap {q : ℤ × ℤ} (hq : allowed q) (x : ℝ)
    (hx : 3 < |x|) (hx' : |x| < 17 / 4) :
    x^4 - 30*x^2 + (q.1:ℝ)*x + (q.2:ℝ) ≠ 0 := by
  rcases le_total 0 x with hp | hm
  · rw [abs_of_nonneg hp] at hx hx'
    exact quartic_gap hq x hx hx'
  · rw [abs_of_nonpos hm] at hx hx'
    have h := quartic_gap (reflect hq) (-x) hx hx'
    push_cast at h
    intro he
    apply h
    calc
      _ = x^4 - 30*x^2 + (q.1:ℝ)*x + (q.2:ℝ) := by ring
      _ = 0 := he

#print axioms coefficient_classification
#print axioms quartic_abs_gap
end SicSignSpectra
