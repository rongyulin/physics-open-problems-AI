import PauliParseval
import PauliExpansion

/-! Reconstruct the exact displacement from an arbitrary trace-one Hermitian
matrix to a signed Pauli target. Its squared Hilbert–Schmidt distance is the
sum of the fifteen squared errors in the Pauli expectation moduli. -/
namespace SicResidual
open SicPauli SicExpansion SicParseval SicMarginal
open scoped BigOperators Matrix
noncomputable section

private theorem sign_error_sq (x : ℝ) :
    (Real.sqrt 13 * x - (if 0 ≤ x then 1 else -1)) ^ 2 =
    13 * (|x| - 1 / Real.sqrt 13)^2 := by
  have hpos : Real.sqrt 13 ≠ 0 := by positivity
  have hinv : Real.sqrt 13 * (1 / Real.sqrt 13) = 1 := by field_simp
  calc
    _ = (Real.sqrt 13 * |x| - 1)^2 := by
      by_cases hx : 0 ≤ x
      · simp [hx, abs_of_nonneg hx]
      · simp [hx, abs_of_neg (lt_of_not_ge hx)]
        ring
    _ = (Real.sqrt 13 * (|x| - 1 / Real.sqrt 13))^2 := by rw [mul_sub, hinv]
    _ = _ := by rw [mul_pow, Real.sq_sqrt (by norm_num : (0:ℝ) ≤ 13)]

theorem residual (R : Local) (herm : R.IsHermitian) (unit : R.trace = 1) :
    ∃ (s : Fin 16 → Bool) (K : Local), K.IsHermitian ∧ K.trace = 0 ∧
      K + ((Real.sqrt 13 : ℂ) • (1 : Local) + signedPauli s) =
        ((4 : ℂ) * (Real.sqrt 13 : ℂ)) • R ∧
      (K*K).trace.re = 52 * ∑ p : Fin 16, if p = 0 then 0 else
        (‖(twoPauli p * R).trace‖ - 1 / Real.sqrt 13)^2 := by
  classical
  let r (p : Fin 16) := (twoPauli p * R).trace.re
  let s (p : Fin 16) := decide (0 ≤ r p)
  let sign (p : Fin 16) : ℝ := if 0 ≤ r p then 1 else -1
  let d (p : Fin 16) : ℝ := if p = 0 then 0 else Real.sqrt 13 * r p - sign p
  let a (p : Fin 16) : ℂ := if p = 0 then (Real.sqrt 13 : ℂ) else 0
  let b (p : Fin 16) : ℂ := if p = 0 then 0 else (sign p : ℂ)
  let K := ∑ p, (d p : ℂ) • twoPauli p
  have realTrace (p : Fin 16) : (r p : ℂ) = (twoPauli p * R).trace :=
    hermitian_trace_real (pauli_hermitian p) herm
  have hcoef (p : Fin 16) :
      (d p : ℂ) + a p + b p = (Real.sqrt 13 : ℂ) * (twoPauli p * R).trace := by
    by_cases hp : p = 0
    · subst p
      simp [d, a, b, pauli_zero, unit]
    · simp [d, a, b, hp, realTrace]
  have ha : (∑ p, a p • twoPauli p) = (Real.sqrt 13 : ℂ) • (1 : Local) := by
    simp [a, ite_smul, pauli_zero]
  have hb : (∑ p, b p • twoPauli p) = signedPauli s := by
    unfold signedPauli
    refine Finset.sum_congr rfl fun p _ => ?_
    by_cases hp : p = 0
    · simp [b, hp]
    · by_cases hx : 0 ≤ r p <;> simp [b, sign, s, hp, hx]
  refine ⟨s, K, ?_, ?_, ?_, ?_⟩
  · unfold Matrix.IsHermitian
    simp [K, Matrix.conjTranspose_sum, Matrix.conjTranspose_smul, (pauli_hermitian _).eq]
  · simpa [K, d, pauli_zero] using trace_pauli_sum (fun p => (d p : ℂ)) 0
  · calc
      _ = ∑ p, ((d p : ℂ) + a p + b p) • twoPauli p := by
        simp only [add_smul, Finset.sum_add_distrib, ha, hb, K]
        abel
      _ = (Real.sqrt 13 : ℂ) • (∑ p, (twoPauli p * R).trace • twoPauli p) := by
        simp only [hcoef, Finset.smul_sum, smul_smul]
      _ = _ := by rw [reconstruct, smul_smul, mul_comm]
  · have hnorm (p : Fin 16) : ‖(twoPauli p * R).trace‖ = |r p| := by
      rw [← realTrace]
      simp
    have hd (p : Fin 16) : (d p)^2 = 13 * (if p = 0 then 0 else
        (‖(twoPauli p * R).trace‖ - 1 / Real.sqrt 13)^2) := by
      by_cases hp : p = 0
      · simp [d, hp]
      · simp only [d, if_neg hp, sign, hnorm]
        exact sign_error_sq _
    have hsq : (K*K).trace = ((4 * (∑ p, (d p)^2) : ℝ) : ℂ) := by
      simpa only [Complex.ofReal_mul, Complex.ofReal_ofNat, Complex.ofReal_sum,
        Complex.ofReal_pow, K] using trace_signed_sum_sq d
    rw [hsq, Complex.ofReal_re]
    simp_rw [hd]
    rw [← Finset.mul_sum]
    ring

#print axioms residual
end
end SicResidual
