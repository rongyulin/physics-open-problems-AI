import LocalOrbit
import PauliExpansion
import PauliObstruction

/-! Dimension 12 with the tensor-product projective displacement action on
two qubits and one qutrit. The fiducial may be arbitrarily entangled. -/
namespace SicNoGo
open SicPauli SicMarginal SicLocalOrbit
open scoped Matrix BigOperators
noncomputable section

/-- Any Hermitian, trace-one four-by-four matrix with all fifteen
nonidentity Pauli expectations of modulus 1/√13 has nonzero determinant. -/
theorem flat_marginal_det_ne_zero (R : Local) (herm : R.IsHermitian) (unit : R.trace = 1)
    (flat : ∀ p : Fin 16, p ≠ 0 → ‖(twoPauli p * R).trace‖ = 1 / Real.sqrt 13) :
    R.det ≠ 0 := by
  obtain ⟨s, h⟩ := SicExpansion.signed_expansion R herm unit flat
  intro hdet
  apply signed_det_nonzero s
  rw [← h, Matrix.det_smul, hdet, mul_zero]

/-- Fifteen fiducial overlaps already obstruct a pure state on ℂ⁴ ⊗ ℂ³. -/
theorem no_flat_pure_state (F : Pure) (unit : (∑ i, ∑ k, Complex.normSq (F i k)) = 1) :
    ¬ ∀ p : Fin 16, p ≠ 0 → ‖overlap F (twoPauli p)‖ = 1 / Real.sqrt 13 := by
  intro flat
  apply flat_marginal_det_ne_zero (density F) (density_isHermitian F)
    (density_trace_of_unit F unit) _ (density_det_zero F)
  simpa only [trace_mul_density] using flat

/-- There is no 144-ray local Heisenberg–Weyl SIC orbit in dimension
12 on ℂ² ⊗ ℂ² ⊗ ℂ³. The two assumptions in IsLocalOrbitSIC are exactly
unit norm and equal squared overlap 1/13 for all distinct orbit labels. -/
theorem no_local_hw_sic_dim12 : ¬ ∃ F : Pure, IsLocalOrbitSIC F := by
  rintro ⟨F, h⟩
  apply no_flat_pure_state F (unit_fiducial h)
  simpa only [trace_mul_density] using marginal_pauli_norm h

/-- The same statement with arbitrary unit phases on the 144 representatives.
This covers the phase conventions in displacement-operator definitions. -/
theorem no_local_hw_sic_dim12_with_phases :
    ¬ ∃ (F : Pure) (c : Label → ℂ), (∀ g, ‖c g‖ = 1) ∧
      IsSICFamily (fun g => c g • orbit g F) := by
  rintro ⟨F, c, hc, h⟩
  exact no_local_hw_sic_dim12 ⟨F, (phase_invariant _ c hc).mp h⟩

#print axioms no_local_hw_sic_dim12_with_phases
#print axioms flat_marginal_det_ne_zero
#print axioms no_flat_pure_state
#print axioms no_local_hw_sic_dim12
end
end SicNoGo
