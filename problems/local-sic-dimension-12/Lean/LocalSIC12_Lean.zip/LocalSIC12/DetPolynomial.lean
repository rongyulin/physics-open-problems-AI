import DetDefinitions
import DetFour
import Mathlib.Tactic

/-! Characteristic polynomial of the two-qubit Pauli sign sum.
The sign variables are first treated as unrestricted integers. Lean checks
the polynomial identity by expanding a 4 by 4 determinant over C. -/
namespace SicPauli
noncomputable section
open scoped Matrix BigOperators
set_option maxRecDepth 100000
set_option maxHeartbeats 100000000

private theorem coord00 (z : Fin 16 → ℤ) (t : ℝ) :
    coordinateMatrix z t 0 0 = ⟨t + ((z 3 : ℝ) + (z 12 : ℝ) + (z 15 : ℝ)), 0⟩ := rfl

private theorem coord01 (z : Fin 16 → ℤ) (t : ℝ) :
    coordinateMatrix z t 0 1 = ⟨(z 1 : ℝ) + (z 13 : ℝ), - (z 2 : ℝ) - (z 14 : ℝ)⟩ := rfl

private theorem coord02 (z : Fin 16 → ℤ) (t : ℝ) :
    coordinateMatrix z t 0 2 = ⟨(z 4 : ℝ) + (z 7 : ℝ), - (z 8 : ℝ) - (z 11 : ℝ)⟩ := rfl

private theorem coord03 (z : Fin 16 → ℤ) (t : ℝ) :
    coordinateMatrix z t 0 3 = ⟨(z 5 : ℝ) - (z 10 : ℝ), - (z 6 : ℝ) - (z 9 : ℝ)⟩ := rfl

private theorem coord10 (z : Fin 16 → ℤ) (t : ℝ) :
    coordinateMatrix z t 1 0 = ⟨(z 1 : ℝ) + (z 13 : ℝ), (z 2 : ℝ) + (z 14 : ℝ)⟩ := rfl

private theorem coord11 (z : Fin 16 → ℤ) (t : ℝ) :
    coordinateMatrix z t 1 1 = ⟨t + (- (z 3 : ℝ) + (z 12 : ℝ) - (z 15 : ℝ)), 0⟩ := rfl

private theorem coord12 (z : Fin 16 → ℤ) (t : ℝ) :
    coordinateMatrix z t 1 2 = ⟨(z 5 : ℝ) + (z 10 : ℝ), (z 6 : ℝ) - (z 9 : ℝ)⟩ := rfl

private theorem coord13 (z : Fin 16 → ℤ) (t : ℝ) :
    coordinateMatrix z t 1 3 = ⟨(z 4 : ℝ) - (z 7 : ℝ), - (z 8 : ℝ) + (z 11 : ℝ)⟩ := rfl

private theorem coord20 (z : Fin 16 → ℤ) (t : ℝ) :
    coordinateMatrix z t 2 0 = ⟨(z 4 : ℝ) + (z 7 : ℝ), (z 8 : ℝ) + (z 11 : ℝ)⟩ := rfl

private theorem coord21 (z : Fin 16 → ℤ) (t : ℝ) :
    coordinateMatrix z t 2 1 = ⟨(z 5 : ℝ) + (z 10 : ℝ), - (z 6 : ℝ) + (z 9 : ℝ)⟩ := rfl

private theorem coord22 (z : Fin 16 → ℤ) (t : ℝ) :
    coordinateMatrix z t 2 2 = ⟨t + ((z 3 : ℝ) - (z 12 : ℝ) - (z 15 : ℝ)), 0⟩ := rfl

private theorem coord23 (z : Fin 16 → ℤ) (t : ℝ) :
    coordinateMatrix z t 2 3 = ⟨(z 1 : ℝ) - (z 13 : ℝ), - (z 2 : ℝ) + (z 14 : ℝ)⟩ := rfl

private theorem coord30 (z : Fin 16 → ℤ) (t : ℝ) :
    coordinateMatrix z t 3 0 = ⟨(z 5 : ℝ) - (z 10 : ℝ), (z 6 : ℝ) + (z 9 : ℝ)⟩ := rfl

private theorem coord31 (z : Fin 16 → ℤ) (t : ℝ) :
    coordinateMatrix z t 3 1 = ⟨(z 4 : ℝ) - (z 7 : ℝ), (z 8 : ℝ) - (z 11 : ℝ)⟩ := rfl

private theorem coord32 (z : Fin 16 → ℤ) (t : ℝ) :
    coordinateMatrix z t 3 2 = ⟨(z 1 : ℝ) - (z 13 : ℝ), (z 2 : ℝ) - (z 14 : ℝ)⟩ := rfl

private theorem coord33 (z : Fin 16 → ℤ) (t : ℝ) :
    coordinateMatrix z t 3 3 = ⟨t + (- (z 3 : ℝ) - (z 12 : ℝ) + (z 15 : ℝ)), 0⟩ := rfl

theorem coordinate_det_re (z : Fin 16 → ℤ) (t : ℝ) :
    ((coordinateMatrix z t).det).re =
      t^4+(quadCoeff z : ℝ)*t^2+8*(oddCoeff z : ℝ)*t+(constantCoeff z : ℝ) := by
  rw [det_four]
  simp only [coord00, coord01, coord02, coord03, coord10, coord11, coord12, coord13, coord20, coord21, coord22, coord23, coord30, coord31, coord32, coord33,
    Complex.add_re, Complex.sub_re,
    Complex.mul_re, Complex.mul_im, Complex.add_im, Complex.sub_im,
    quadCoeff, oddCoeff, constantCoeff, Int.cast_add, Int.cast_mul,
    Int.cast_pow, Int.cast_neg, Int.cast_ofNat]
  ring
end
end SicPauli
