import Mathlib.LinearAlgebra.Matrix.Notation
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.Data.Complex.Basic
import Mathlib.Data.Real.Sqrt

/-! Hermitian Paulis in order I,X,Y,Z.  Two-qubit Pauli index 4*a+b
acts by operator a on the high-order qubit, b on the low-order one.
Computational basis vectors are ordered 00,01,10,11. -/
namespace SicPauli
open scoped BigOperators Matrix
noncomputable section

def onePauli (a : Fin 4) : Matrix (Fin 2) (Fin 2) ℂ :=
  ![!![1,0;0,1], !![0,1;1,0], !![0,-Complex.I;Complex.I,0],
    !![1,0;0,-1]] a

def twoPauli (p : Fin 16) : Matrix (Fin 4) (Fin 4) ℂ := fun i j =>
  onePauli (Fin.ofNat 4 (p.val/4)) (Fin.ofNat 2 (i.val/2)) (Fin.ofNat 2 (j.val/2)) *
  onePauli (Fin.ofNat 4 (p.val%4)) (Fin.ofNat 2 (i.val%2)) (Fin.ofNat 2 (j.val%2))

def signedPauli (s : Fin 16 → Bool) : Matrix (Fin 4) (Fin 4) ℂ :=
  ∑ p : Fin 16, if p=0 then 0 else (if s p then (1:ℂ) else -1) • twoPauli p

end
end SicPauli
