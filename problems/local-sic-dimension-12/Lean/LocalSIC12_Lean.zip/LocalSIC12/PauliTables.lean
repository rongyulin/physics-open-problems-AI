import SicPauliBase
import Mathlib.Tactic

set_option linter.unusedSimpArgs false
noncomputable section
open scoped Matrix BigOperators
namespace SicExpansion
open SicPauli

theorem two_0 : twoPauli 0 = !![
1, 0, 0, 0;
0, 1, 0, 0;
0, 0, 1, 0;
0, 0, 0, 1] := by
  have h : twoPauli 0 = !![1 * 1, 1 * 0, 0 * 1, 0 * 0;
1 * 0, 1 * 1, 0 * 0, 0 * 1;
0 * 1, 0 * 0, 1 * 1, 1 * 0;
0 * 0, 0 * 1, 1 * 0, 1 * 1] := by
    ext i j; fin_cases i <;> fin_cases j <;> rfl
  rw [h]
  simp

theorem two_1 : twoPauli 1 = !![
0, 1, 0, 0;
1, 0, 0, 0;
0, 0, 0, 1;
0, 0, 1, 0] := by
  have h : twoPauli 1 = !![1 * 0, 1 * 1, 0 * 0, 0 * 1;
1 * 1, 1 * 0, 0 * 1, 0 * 0;
0 * 0, 0 * 1, 1 * 0, 1 * 1;
0 * 1, 0 * 0, 1 * 1, 1 * 0] := by
    ext i j; fin_cases i <;> fin_cases j <;> rfl
  rw [h]
  simp

theorem two_2 : twoPauli 2 = !![
0, (-Complex.I), 0, 0;
Complex.I, 0, 0, 0;
0, 0, 0, (-Complex.I);
0, 0, Complex.I, 0] := by
  have h : twoPauli 2 = !![1 * 0, 1 * (-Complex.I), 0 * 0, 0 * (-Complex.I);
1 * Complex.I, 1 * 0, 0 * Complex.I, 0 * 0;
0 * 0, 0 * (-Complex.I), 1 * 0, 1 * (-Complex.I);
0 * Complex.I, 0 * 0, 1 * Complex.I, 1 * 0] := by
    ext i j; fin_cases i <;> fin_cases j <;> rfl
  rw [h]
  simp

theorem two_3 : twoPauli 3 = !![
1, 0, 0, 0;
0, (-1), 0, 0;
0, 0, 1, 0;
0, 0, 0, (-1)] := by
  have h : twoPauli 3 = !![1 * 1, 1 * 0, 0 * 1, 0 * 0;
1 * 0, 1 * (-1), 0 * 0, 0 * (-1);
0 * 1, 0 * 0, 1 * 1, 1 * 0;
0 * 0, 0 * (-1), 1 * 0, 1 * (-1)] := by
    ext i j; fin_cases i <;> fin_cases j <;> rfl
  rw [h]
  simp

theorem two_4 : twoPauli 4 = !![
0, 0, 1, 0;
0, 0, 0, 1;
1, 0, 0, 0;
0, 1, 0, 0] := by
  have h : twoPauli 4 = !![0 * 1, 0 * 0, 1 * 1, 1 * 0;
0 * 0, 0 * 1, 1 * 0, 1 * 1;
1 * 1, 1 * 0, 0 * 1, 0 * 0;
1 * 0, 1 * 1, 0 * 0, 0 * 1] := by
    ext i j; fin_cases i <;> fin_cases j <;> rfl
  rw [h]
  simp

theorem two_5 : twoPauli 5 = !![
0, 0, 0, 1;
0, 0, 1, 0;
0, 1, 0, 0;
1, 0, 0, 0] := by
  have h : twoPauli 5 = !![0 * 0, 0 * 1, 1 * 0, 1 * 1;
0 * 1, 0 * 0, 1 * 1, 1 * 0;
1 * 0, 1 * 1, 0 * 0, 0 * 1;
1 * 1, 1 * 0, 0 * 1, 0 * 0] := by
    ext i j; fin_cases i <;> fin_cases j <;> rfl
  rw [h]
  simp

theorem two_6 : twoPauli 6 = !![
0, 0, 0, (-Complex.I);
0, 0, Complex.I, 0;
0, (-Complex.I), 0, 0;
Complex.I, 0, 0, 0] := by
  have h : twoPauli 6 = !![0 * 0, 0 * (-Complex.I), 1 * 0, 1 * (-Complex.I);
0 * Complex.I, 0 * 0, 1 * Complex.I, 1 * 0;
1 * 0, 1 * (-Complex.I), 0 * 0, 0 * (-Complex.I);
1 * Complex.I, 1 * 0, 0 * Complex.I, 0 * 0] := by
    ext i j; fin_cases i <;> fin_cases j <;> rfl
  rw [h]
  simp

theorem two_7 : twoPauli 7 = !![
0, 0, 1, 0;
0, 0, 0, (-1);
1, 0, 0, 0;
0, (-1), 0, 0] := by
  have h : twoPauli 7 = !![0 * 1, 0 * 0, 1 * 1, 1 * 0;
0 * 0, 0 * (-1), 1 * 0, 1 * (-1);
1 * 1, 1 * 0, 0 * 1, 0 * 0;
1 * 0, 1 * (-1), 0 * 0, 0 * (-1)] := by
    ext i j; fin_cases i <;> fin_cases j <;> rfl
  rw [h]
  simp

theorem two_8 : twoPauli 8 = !![
0, 0, (-Complex.I), 0;
0, 0, 0, (-Complex.I);
Complex.I, 0, 0, 0;
0, Complex.I, 0, 0] := by
  have h : twoPauli 8 = !![0 * 1, 0 * 0, (-Complex.I) * 1, (-Complex.I) * 0;
0 * 0, 0 * 1, (-Complex.I) * 0, (-Complex.I) * 1;
Complex.I * 1, Complex.I * 0, 0 * 1, 0 * 0;
Complex.I * 0, Complex.I * 1, 0 * 0, 0 * 1] := by
    ext i j; fin_cases i <;> fin_cases j <;> rfl
  rw [h]
  simp

theorem two_9 : twoPauli 9 = !![
0, 0, 0, (-Complex.I);
0, 0, (-Complex.I), 0;
0, Complex.I, 0, 0;
Complex.I, 0, 0, 0] := by
  have h : twoPauli 9 = !![0 * 0, 0 * 1, (-Complex.I) * 0, (-Complex.I) * 1;
0 * 1, 0 * 0, (-Complex.I) * 1, (-Complex.I) * 0;
Complex.I * 0, Complex.I * 1, 0 * 0, 0 * 1;
Complex.I * 1, Complex.I * 0, 0 * 1, 0 * 0] := by
    ext i j; fin_cases i <;> fin_cases j <;> rfl
  rw [h]
  simp

theorem two_10 : twoPauli 10 = !![
0, 0, 0, (-1);
0, 0, 1, 0;
0, 1, 0, 0;
(-1), 0, 0, 0] := by
  have h : twoPauli 10 = !![0 * 0, 0 * (-Complex.I), (-Complex.I) * 0, (-Complex.I) * (-Complex.I);
0 * Complex.I, 0 * 0, (-Complex.I) * Complex.I, (-Complex.I) * 0;
Complex.I * 0, Complex.I * (-Complex.I), 0 * 0, 0 * (-Complex.I);
Complex.I * Complex.I, Complex.I * 0, 0 * Complex.I, 0 * 0] := by
    ext i j; fin_cases i <;> fin_cases j <;> rfl
  rw [h]
  simp

theorem two_11 : twoPauli 11 = !![
0, 0, (-Complex.I), 0;
0, 0, 0, Complex.I;
Complex.I, 0, 0, 0;
0, (-Complex.I), 0, 0] := by
  have h : twoPauli 11 = !![0 * 1, 0 * 0, (-Complex.I) * 1, (-Complex.I) * 0;
0 * 0, 0 * (-1), (-Complex.I) * 0, (-Complex.I) * (-1);
Complex.I * 1, Complex.I * 0, 0 * 1, 0 * 0;
Complex.I * 0, Complex.I * (-1), 0 * 0, 0 * (-1)] := by
    ext i j; fin_cases i <;> fin_cases j <;> rfl
  rw [h]
  simp

theorem two_12 : twoPauli 12 = !![
1, 0, 0, 0;
0, 1, 0, 0;
0, 0, (-1), 0;
0, 0, 0, (-1)] := by
  have h : twoPauli 12 = !![1 * 1, 1 * 0, 0 * 1, 0 * 0;
1 * 0, 1 * 1, 0 * 0, 0 * 1;
0 * 1, 0 * 0, (-1) * 1, (-1) * 0;
0 * 0, 0 * 1, (-1) * 0, (-1) * 1] := by
    ext i j; fin_cases i <;> fin_cases j <;> rfl
  rw [h]
  simp

theorem two_13 : twoPauli 13 = !![
0, 1, 0, 0;
1, 0, 0, 0;
0, 0, 0, (-1);
0, 0, (-1), 0] := by
  have h : twoPauli 13 = !![1 * 0, 1 * 1, 0 * 0, 0 * 1;
1 * 1, 1 * 0, 0 * 1, 0 * 0;
0 * 0, 0 * 1, (-1) * 0, (-1) * 1;
0 * 1, 0 * 0, (-1) * 1, (-1) * 0] := by
    ext i j; fin_cases i <;> fin_cases j <;> rfl
  rw [h]
  simp

theorem two_14 : twoPauli 14 = !![
0, (-Complex.I), 0, 0;
Complex.I, 0, 0, 0;
0, 0, 0, Complex.I;
0, 0, (-Complex.I), 0] := by
  have h : twoPauli 14 = !![1 * 0, 1 * (-Complex.I), 0 * 0, 0 * (-Complex.I);
1 * Complex.I, 1 * 0, 0 * Complex.I, 0 * 0;
0 * 0, 0 * (-Complex.I), (-1) * 0, (-1) * (-Complex.I);
0 * Complex.I, 0 * 0, (-1) * Complex.I, (-1) * 0] := by
    ext i j; fin_cases i <;> fin_cases j <;> rfl
  rw [h]
  simp

theorem two_15 : twoPauli 15 = !![
1, 0, 0, 0;
0, (-1), 0, 0;
0, 0, (-1), 0;
0, 0, 0, 1] := by
  have h : twoPauli 15 = !![1 * 1, 1 * 0, 0 * 1, 0 * 0;
1 * 0, 1 * (-1), 0 * 0, 0 * (-1);
0 * 1, 0 * 0, (-1) * 1, (-1) * 0;
0 * 0, 0 * (-1), (-1) * 0, (-1) * (-1)] := by
    ext i j; fin_cases i <;> fin_cases j <;> rfl
  rw [h]
  simp

end SicExpansion
