import PauliResidual
import GapOnKernel
import OptimalMarginal

/-! Exact local squared-error minimization over normalized pure states on two
qubits and one qutrit. The witness is the explicit purification in OptimalMarginal. -/
namespace SicStability
open scoped Matrix BigOperators
open SicPauli SicMarginal SicSignedGap
noncomputable section

theorem sharp_lower (F : Pure) (unit : (∑ i, ∑ k, Complex.normSq (F i k)) = 1) :
    (1 - 3 / Real.sqrt 13)^2 / 3 ≤ ∑ p : Fin 16, if p=0 then 0 else
      (‖overlap F (twoPauli p)‖ - 1 / Real.sqrt 13)^2 := by
  let R := density F
  have herm : R.IsHermitian := density_isHermitian F
  obtain ⟨s,K,hK,htr,heq,hnorm⟩ := SicResidual.residual R herm (density_trace_of_unit F unit)
  have hh := gap_on_kernel R K herm (density_det_zero F) hK htr s _ heq
  rw [hnorm] at hh
  dsimp only [R] at hh
  simp_rw [trace_mul_density] at hh
  have hy : Real.sqrt 13 ≠ 0 := by positivity
  have h13 : (Real.sqrt 13)^2=13 := Real.sq_sqrt (by norm_num)
  rw [show (1 - 3 / Real.sqrt 13) = (Real.sqrt 13-3)/ Real.sqrt 13 by field_simp]
  rw [div_pow,h13]
  linarith

open SicOptimal

/-- The construction attains the stated squared Euclidean mismatch. -/
theorem attainingState_error : (∑ p : Fin 16, if p=0 then 0 else
    (‖overlap attainingState (twoPauli p)‖ - 1 / Real.sqrt 13)^2) =
    (1 - 3 / Real.sqrt 13)^2 / 3 := by
  let t : ℝ := 1 / Real.sqrt 13
  let e : ℝ := (1/3-t)^2
  have ht : 0 ≤ t := by dsimp [t]; positivity
  have he (p : Fin 16) :
      (if p=0 then (0:ℝ) else (‖overlap attainingState (twoPauli p)‖ - t)^2) =
      (if p=5 then e else 0) + (if p=10 then e else 0) + (if p=15 then e else 0) := by
    rw [attainingState_pauli]
    change (if p=0 then 0 else (‖if p=0 then 1 else if p=5 ∨ p=10 ∨ p=15 then (1/3:ℂ) else (t:ℂ)‖-t)^2) = _
    by_cases h0 : p=0
    · subst p; norm_num [Fin.ext_iff]
    by_cases h5 : p=5
    · subst p; norm_num [Fin.ext_iff,norm_div,e]
    by_cases h10 : p=10
    · subst p; norm_num [Fin.ext_iff,norm_div,e]
    by_cases h15 : p=15
    · subst p; norm_num [Fin.ext_iff,norm_div,e]
    simp [h0,h5,h10,h15,abs_of_nonneg ht]
  change (∑ p : Fin 16, if p=0 then 0 else (‖overlap attainingState (twoPauli p)‖-t)^2) = _
  simp_rw [he, Finset.sum_add_distrib]
  simp only [Finset.sum_ite_eq',Finset.mem_univ,if_true]
  dsimp [e,t]
  ring

/-- Exact minimum over all normalized pure bipartite states, with the
minimizer provided by the explicit 4-by-3 coefficient matrix. -/
theorem sharp_minimum : IsLeast
    {x : ℝ | ∃ F : Pure, (∑ i, ∑ k, Complex.normSq (F i k)) = 1 ∧
      (∑ p : Fin 16, if p=0 then 0 else (‖overlap F (twoPauli p)‖-1/Real.sqrt 13)^2) = x}
    ((1-3/Real.sqrt 13)^2/3) := by
  refine ⟨⟨attainingState,attainingState_unit,attainingState_error⟩, ?_⟩
  rintro x ⟨F,h,rfl⟩
  exact sharp_lower F h

#print axioms sharp_minimum
#print axioms sharp_lower
end
end SicStability
