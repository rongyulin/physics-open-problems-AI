import Mathlib.Tactic
import Mathlib.Analysis.SpecialFunctions.Log.Base

/-! Scalar estimates converting the squared error of overlap moduli to an entropy gap. -/
namespace SicEntropy
open Finset
open scoped BigOperators

/-- A lower bound on squared distance from the positive constant t transfers
to a lower bound for squared distance between the corresponding squares. -/
theorem square_overlap_gap {ι : Type*} (s : Finset ι) (z : ι → ℝ)
    {t h : ℝ} (hh : 0 ≤ h) (ht : h ≤ t) (hz : ∀ i ∈ s, 0 ≤ z i)
    (gap : h^2 ≤ ∑ i ∈ s, (z i - t)^2) :
    h^2 * (2*t-h)^2 ≤ ∑ i ∈ s, ((z i)^2-t^2)^2 := by
  classical
  have ht₀ : 0 ≤ t := le_trans hh ht
  have slope : 0 ≤ 2*t-h := by linarith
  by_cases far : ∃ i ∈ s, z i ≤ t-h ∨ t+h ≤ z i
  · obtain ⟨i, hi, hfar⟩ := far
    have hn := hz i hi
    have single : h^2 * (2*t-h)^2 ≤ ((z i)^2-t^2)^2 := by
      rw [← mul_pow]
      rcases hfar with hl | hr
      · have hl' : (z i)^2 ≤ (t-h)^2 := by nlinarith [mul_nonneg (sub_nonneg.mpr hl) (show 0 ≤ t-h+z i by linarith)]
        have hd : h*(2*t-h) ≤ t^2-(z i)^2 := by linarith
        have hd' := pow_le_pow_left₀ (mul_nonneg hh slope) hd 2
        nlinarith
      · have hr' : (t+h)^2 ≤ (z i)^2 := by nlinarith [mul_nonneg (sub_nonneg.mpr hr) (show 0 ≤ z i+(t+h) by linarith)]
        have hd : h*(2*t-h) ≤ (z i)^2-t^2 := by nlinarith [sq_nonneg h]
        exact pow_le_pow_left₀ (mul_nonneg hh slope) hd 2
    exact le_trans single (Finset.single_le_sum (f:=fun j => ((z j)^2-t^2)^2)
      (fun j _ => sq_nonneg _) hi)
  · have point (i : ι) (hi : i ∈ s) : (z i-t)^2 * (2*t-h)^2 ≤ ((z i)^2-t^2)^2 := by
      have hnear : t-h < z i := lt_of_not_ge (fun hle => far ⟨i,hi,Or.inl hle⟩)
      have hle : 2*t-h ≤ z i+t := by linarith
      have hs := pow_le_pow_left₀ slope hle 2
      calc
        _ ≤ (z i-t)^2 * (z i+t)^2 := mul_le_mul_of_nonneg_left hs (sq_nonneg _)
        _ = _ := by ring
    calc
      _ ≤ (∑ i ∈ s, (z i-t)^2) * (2*t-h)^2 := mul_le_mul_of_nonneg_right gap (sq_nonneg _)
      _ = _ := Finset.sum_mul _ _ _
      _ ≤ _ := Finset.sum_le_sum point

/-- Real-logarithm form of the final bound, using no approximate constants. -/
theorem entropy_of_fourth_moment {f v : ℝ} (hv : 0 ≤ v) (hf : 24/13 + v ≤ f) :
    -Real.logb 2 (f/12) ≤ Real.logb 2 (13/2) - Real.logb 2 (1 + 13*v/24) := by
  have ha : 0 < 1 + 13*v/24 := by linarith
  have hb : 0 < (13/2 : ℝ) := by norm_num
  have hle : (1+13*v/24)/(13/2) ≤ f/12 := by linarith
  have hm := Real.strictMonoOn_logb (b:=2) (by norm_num)
  have hlog := hm.monotoneOn (show (1+13*v/24)/(13/2) ∈ Set.Ioi (0:ℝ) from div_pos ha hb)
    (show f/12 ∈ Set.Ioi (0:ℝ) from lt_of_lt_of_le (div_pos ha hb) hle) hle
  rw [Real.logb_div ha.ne' hb.ne'] at hlog
  linarith
#print axioms square_overlap_gap
#print axioms entropy_of_fourth_moment
end SicEntropy
