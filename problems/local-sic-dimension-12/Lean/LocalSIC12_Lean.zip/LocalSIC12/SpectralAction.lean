import Mathlib.Analysis.Matrix.Spectrum
import Mathlib.Tactic

/-! Bounds on the squared action of a finite Hermitian matrix, in ordinary
matrix-vector coordinates. -/
namespace SicSpectralAction
open Matrix
open scoped BigOperators Matrix ComplexConjugate
variable {n : Type*} [Fintype n] [DecidableEq n]

omit [DecidableEq n] in
private theorem normSq_as_dot (v : n → ℂ) :
    ((∑ i, Complex.normSq (v i) : ℝ) : ℂ) = star v ⬝ᵥ v := by
  simp only [Complex.ofReal_sum, Complex.normSq_eq_conj_mul_self, dotProduct]
  rfl

private theorem unitary_preserves (U : unitary (Matrix n n ℂ)) (v : n → ℂ) :
    ∑ i, Complex.normSq (((U : Matrix n n ℂ) *ᵥ v) i) = ∑ i, Complex.normSq (v i) := by
  apply Complex.ofReal_injective
  rw [normSq_as_dot, normSq_as_dot, star_mulVec, dotProduct_mulVec, vecMul_vecMul,
    ← Matrix.star_eq_conjTranspose, Unitary.coe_star_mul_self, vecMul_one]

private theorem spectral_weights {K : Matrix n n ℂ} (hK : K.IsHermitian) (v : n → ℂ) :
    ∃ w : n → ℂ, (∑ i, Complex.normSq (w i)) = ∑ i, Complex.normSq (v i) ∧
      (∑ i, Complex.normSq ((K *ᵥ v) i)) =
        ∑ i, (hK.eigenvalues i)^2 * Complex.normSq (w i) := by
  let U := hK.eigenvectorUnitary
  let w := ((star U : unitary (Matrix n n ℂ)) : Matrix n n ℂ) *ᵥ v
  refine ⟨w, unitary_preserves (star U) v, ?_⟩
  have hdiag : K *ᵥ v =
      (U : Matrix n n ℂ) *ᵥ (diagonal (fun i => (hK.eigenvalues i : ℂ)) *ᵥ w) := by
    conv_lhs => rw [hK.spectral_theorem, Unitary.conjStarAlgAut_apply]
    simp only [← Matrix.mulVec_mulVec]
    rfl
  rw [hdiag, unitary_preserves]
  simp only [Matrix.mulVec_diagonal, map_mul, Complex.normSq_ofReal, pow_two]

theorem lower_sq {K : Matrix n n ℂ} (hK : K.IsHermitian) {b : ℝ}
    (h : ∀ j, b ≤ (hK.eigenvalues j)^2) (v : n → ℂ)
    (hv : ∑ i, Complex.normSq (v i) = 1) :
    b ≤ ∑ i, Complex.normSq ((K *ᵥ v) i) := by
  obtain ⟨w, hw, hx⟩ := spectral_weights hK v
  calc
    b = ∑ i, b * Complex.normSq (w i) := by rw [← Finset.mul_sum, hw, hv, mul_one]
    _ ≤ ∑ i, (hK.eigenvalues i)^2 * Complex.normSq (w i) :=
      Finset.sum_le_sum fun i _ => mul_le_mul_of_nonneg_right (h i) (Complex.normSq_nonneg _)
    _ = _ := hx.symm

theorem upper_sq {K : Matrix n n ℂ} (hK : K.IsHermitian) {B : ℝ}
    (h : ∀ j, (hK.eigenvalues j)^2 ≤ B) (v : n → ℂ)
    (hv : ∑ i, Complex.normSq (v i) = 1) :
    (∑ i, Complex.normSq ((K *ᵥ v) i)) ≤ B := by
  obtain ⟨w, hw, hx⟩ := spectral_weights hK v
  calc
    _ = ∑ i, (hK.eigenvalues i)^2 * Complex.normSq (w i) := hx
    _ ≤ ∑ i, B * Complex.normSq (w i) :=
      Finset.sum_le_sum fun i _ => mul_le_mul_of_nonneg_right (h i) (Complex.normSq_nonneg _)
    _ = B := by rw [← Finset.mul_sum, hw, hv, mul_one]

end SicSpectralAction
