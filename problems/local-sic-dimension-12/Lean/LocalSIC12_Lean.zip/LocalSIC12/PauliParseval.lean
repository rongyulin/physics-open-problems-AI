import PauliCoordinates
import Mathlib.LinearAlgebra.Dimension.OrzechProperty
import Mathlib.LinearAlgebra.Dimension.Constructions

/-! Trace orthogonality and Parseval from the proved Pauli reconstruction formula. -/
namespace SicParseval
open SicPauli SicExpansion
open scoped Matrix BigOperators
noncomputable section
private abbrev M := Matrix (Fin 4) (Fin 4) ℂ

theorem pauli_independent : LinearIndependent ℂ twoPauli := by
  apply linearIndependent_of_top_le_span_of_card_eq_finrank
  · intro R _
    let V := Submodule.span ℂ (Set.range twoPauli)
    have hm : (4 : ℂ) • R ∈ V := by
      rw [← reconstruct]
      exact Submodule.sum_mem V fun p _ =>
        V.smul_mem _ (Submodule.subset_span ⟨p, rfl⟩)
    have hh := V.smul_mem (4:ℂ)⁻¹ hm
    simpa [smul_smul] using hh
  · simp [Module.finrank_matrix]

/-- The coordinate read off by a Pauli trace is four times the synthesis coefficient. -/
theorem trace_pauli_sum (a : Fin 16 → ℂ) (p : Fin 16) :
    (twoPauli p * (∑ q, a q • twoPauli q)).trace = 4 * a p := by
  apply (Fintype.linearIndependent_iffₛ.mp pauli_independent
    (fun k => (twoPauli k * (∑ q, a q • twoPauli q)).trace) (fun k => 4 * a k) _ p)
  simpa only [Finset.smul_sum, smul_smul] using reconstruct (∑ q, a q • twoPauli q)

theorem trace_pauli_pair (p q : Fin 16) :
    (twoPauli p * twoPauli q).trace = if p = q then 4 else 0 := by
  simpa [Finset.sum_ite_eq', apply_ite] using
    trace_pauli_sum (fun j => if j = q then 1 else 0) p

theorem trace_sum_sq (a : Fin 16 → ℂ) :
    let K := ∑ p, a p • twoPauli p
    (K * K).trace = (4 : ℂ) * ∑ p, a p ^ 2 := by
  dsimp only
  rw [Matrix.sum_mul, Matrix.trace_sum, Finset.mul_sum]
  refine Finset.sum_congr rfl fun p _ => ?_
  rw [Matrix.smul_mul, Matrix.trace_smul, trace_pauli_sum]
  change a p * (4 * a p) = 4 * (a p)^2
  ring

theorem trace_signed_sum_sq (a : Fin 16 → ℝ) :
    let K := ∑ p, (a p : ℂ) • twoPauli p
    (K * K).trace = (4 : ℂ) * ∑ p, (a p : ℂ) ^ 2 :=
  trace_sum_sq (fun p => (a p : ℂ))

#print axioms trace_signed_sum_sq
end
end SicParseval
