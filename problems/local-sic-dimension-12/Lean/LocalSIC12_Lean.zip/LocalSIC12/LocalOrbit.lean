import Marginal
import SicPauliBase
import Mathlib.RingTheory.RootsOfUnity.Complex
import Mathlib.Data.ZMod.Basic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity

/-! The local Heisenberg–Weyl orbit in dimensions 2, 2, and 3.
The four projective displacement representatives on each qubit are I, X, Y, Z.
On the qutrit we use X^a Z^b, with the cyclic shift X|k⟩ = |k+1⟩
and clock Z|k⟩ = exp(2πik/3) |k⟩. -/
namespace SicLocalOrbit
open scoped BigOperators
open SicMarginal SicPauli
noncomputable section

/-- Translation group in the notation used for finite abelian Gabor systems. -/
def translationGroupEquiv :
    (ZMod 2 × ZMod 2 × ZMod 3) ≃+ (ZMod 2 × ZMod 6) :=
  AddEquiv.prodCongr (AddEquiv.refl _) (ZMod.chineseRemainder (by decide : Nat.Coprime 2 3)).toAddEquiv.symm

theorem six_smul_translation (x : ZMod 2 × ZMod 2 × ZMod 3) : (6 : ℕ) • x = 0 := by
  rcases x with ⟨a,b,c⟩
  ext <;> simp [nsmul_eq_mul, show (6 : ZMod 2) = 0 by decide, show (6 : ZMod 3) = 0 by decide]
theorem translationGroup_not_Z12 : IsEmpty ((ZMod 2 × ZMod 2 × ZMod 3) ≃+ ZMod 12) := by
  constructor
  intro e
  obtain ⟨x, hx⟩ := e.surjective 1
  have hn : (6 : ZMod 12) ≠ 0 := by decide
  apply hn
  calc
    (6 : ZMod 12) = (6 : ℕ) • (1 : ZMod 12) := by decide
    _ = 6 • e x := by rw [hx]
    _ = e (6 • x) := (map_nsmul e 6 x).symm
    _ = 0 := by rw [six_smul_translation, map_zero]

abbrev Label := Fin 16 × Fin 3 × Fin 3

theorem label_count : Fintype.card Label = 144 := by norm_num [Label, Fintype.card_prod]

def omega3 : ℂ := Complex.exp (2 * (Real.pi : ℂ) * Complex.I / 3)

theorem omega3_primitive : IsPrimitiveRoot omega3 3 := by
  simpa [omega3] using (Complex.isPrimitiveRoot_exp 3 (by decide))

/-- Amplitudes in the computational basis. The two last label components
are the powers of the qutrit shift and clock. -/
def orbit (g : Label) (F : Pure) : Pure := fun i k =>
  omega3 ^ (g.2.2.val * (k - g.2.1).val) * (twoPauli g.1 * F) i (k - g.2.1)

def amplitude (F G : Pure) : ℂ := ∑ i, ∑ k, star (F i k) * G i k

/-- A SIC consists of 144 unit vectors with squared overlap 1/(12+1)
for every two distinct labels. Global phases leave this property unchanged. -/
structure IsSICFamily (V : Label → Pure) : Prop where
  unit (g : Label) : (∑ i, ∑ k, Complex.normSq (V g i k)) = 1
  equiangular (g h : Label) (hne : g ≠ h) :
    ‖amplitude (V g) (V h)‖ ^ 2 = (1 : ℝ) / 13

abbrev IsLocalOrbitSIC (F : Pure) : Prop := IsSICFamily (fun g => orbit g F)

theorem amplitude_smul (a b : ℂ) (F G : Pure) :
    amplitude (a • F) (b • G) = (star a * b) * amplitude F G := by
  simp only [amplitude, Matrix.smul_apply, smul_eq_mul, star_mul, Finset.mul_sum]
  refine Finset.sum_congr rfl fun i _ => Finset.sum_congr rfl fun k _ => ?_
  ring

/-- A separate phase choice for every vector leaves the SIC conditions invariant. -/
theorem phase_invariant (V : Label → Pure) (c : Label → ℂ) (hc : ∀ g, ‖c g‖ = 1) :
    IsSICFamily (fun g => c g • V g) ↔ IsSICFamily V := by
  have hu (g : Label) : (∑ i, ∑ k, Complex.normSq ((c g • V g) i k)) =
      ∑ i, ∑ k, Complex.normSq (V g i k) := by
    have hc' : Complex.normSq (c g) = 1 := by simp [Complex.normSq_eq_norm_sq, hc]
    simp [Matrix.smul_apply, Complex.normSq_mul, hc']
  have he (g h : Label) : ‖amplitude (c g • V g) (c h • V h)‖ =
      ‖amplitude (V g) (V h)‖ := by simp [amplitude_smul, hc]
  constructor
  · intro hs
    exact ⟨fun g => (hu g).symm.trans (hs.unit g),
      fun g h hn => by simpa only [he] using hs.equiangular g h hn⟩
  · intro hs
    exact ⟨fun g => (hu g).trans (hs.unit g),
      fun g h hn => by simpa only [he] using hs.equiangular g h hn⟩

theorem twoPauli_identity : twoPauli 0 = 1 := by
  ext i j
  fin_cases i <;> fin_cases j <;> norm_num [twoPauli, onePauli, Matrix.one_apply, Fin.last, Matrix.vecCons]

@[simp] theorem orbit_qubit (p : Fin 16) (F : Pure) :
    orbit (p, 0, 0) F = twoPauli p * F := by
  ext i k
  simp [orbit]

@[simp] theorem orbit_origin (F : Pure) : orbit (0, 0, 0) F = F := by
  simp [twoPauli_identity]

theorem amplitude_qubit (F : Pure) (P : Local) :
    amplitude F (P * F) = overlap F P := by
  classical
  unfold amplitude overlap
  refine Finset.sum_congr rfl fun i _ => ?_
  simp only [Matrix.mul_apply, Finset.mul_sum]
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun j _ => Finset.sum_congr rfl fun k _ => ?_
  ring

theorem norm_of_squared {z : ℂ} (h : ‖z‖ ^ 2 = (1 : ℝ) / 13) :
    ‖z‖ = 1 / Real.sqrt 13 := by
  have hs : (1 / Real.sqrt 13) ^ 2 = (1 : ℝ) / 13 := by
    rw [div_pow, Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 13), one_pow]
  exact (sq_eq_sq₀ (norm_nonneg _) (by positivity)).mp (h.trans hs.symm)

theorem unit_fiducial {F : Pure} (h : IsLocalOrbitSIC F) :
    (∑ i, ∑ k, Complex.normSq (F i k)) = 1 := by
  simpa only [orbit_origin] using h.unit (0, 0, 0)

theorem marginal_pauli_norm {F : Pure} (h : IsLocalOrbitSIC F)
    (p : Fin 16) (hp : p ≠ 0) :
    ‖(twoPauli p * density F).trace‖ = 1 / Real.sqrt 13 := by
  have hne : ((0, 0, 0) : Label) ≠ (p, 0, 0) := by
    intro heq
    exact hp (congrArg Prod.fst heq).symm
  have hsq := h.equiangular (0, 0, 0) (p, 0, 0) hne
  rw [orbit_origin, orbit_qubit, amplitude_qubit] at hsq
  rw [trace_mul_density]
  exact norm_of_squared hsq

#print axioms marginal_pauli_norm
end
end SicLocalOrbit
