import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.Tactic
namespace SicPauli
open scoped BigOperators Matrix
theorem det_four {R : Type*} [CommRing R] (A : Matrix (Fin 4) (Fin 4) R) :
  A.det = 
    A 0 0*A 1 1*A 2 2*A 3 3
  - A 0 0*A 1 1*A 2 3*A 3 2
  - A 0 0*A 1 2*A 2 1*A 3 3
  + A 0 0*A 1 2*A 2 3*A 3 1
  + A 0 0*A 1 3*A 2 1*A 3 2
  - A 0 0*A 1 3*A 2 2*A 3 1
  - A 0 1*A 1 0*A 2 2*A 3 3
  + A 0 1*A 1 0*A 2 3*A 3 2
  + A 0 1*A 1 2*A 2 0*A 3 3
  - A 0 1*A 1 2*A 2 3*A 3 0
  - A 0 1*A 1 3*A 2 0*A 3 2
  + A 0 1*A 1 3*A 2 2*A 3 0
  + A 0 2*A 1 0*A 2 1*A 3 3
  - A 0 2*A 1 0*A 2 3*A 3 1
  - A 0 2*A 1 1*A 2 0*A 3 3
  + A 0 2*A 1 1*A 2 3*A 3 0
  + A 0 2*A 1 3*A 2 0*A 3 1
  - A 0 2*A 1 3*A 2 1*A 3 0
  - A 0 3*A 1 0*A 2 1*A 3 2
  + A 0 3*A 1 0*A 2 2*A 3 1
  + A 0 3*A 1 1*A 2 0*A 3 2
  - A 0 3*A 1 1*A 2 2*A 3 0
  - A 0 3*A 1 2*A 2 0*A 3 1
  + A 0 3*A 1 2*A 2 1*A 3 0
 := by
  rw [Matrix.det_succ_row_zero]
  simp [Matrix.det_fin_three, Fin.sum_univ_succ, Matrix.submatrix_apply, Fin.succAbove]
  ring
end SicPauli
