import RankConnection
import Mathlib.Analysis.InnerProductSpace.Basic
import Mathlib.LinearAlgebra.Dimension.Finite
import Mathlib.Tactic.Ring

/-! An integer inverse certificate for a 37 by 37 principal block of the
scaled Gram matrix. The last theorem proves the physical dimension lower
bound for actual vectors in any finite-dimensional complex inner product
space having the rigid Perkel Gram matrix. -/
namespace PerkelDimension
open PerkelRank
open scoped BigOperators InnerProductSpace
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000

private theorem intSum_eq (f : Nat → ℤ) (n : Nat) :
    (∑ k : Fin n, f k.val) = intSum f n := by
  induction n with
  | zero => simp [intSum]
  | succ n ih =>
    rw [Fin.sum_univ_castSucc]
    simpa [intSum] using congrArg (fun t => t + f n) ih

private theorem complex_inverse (i j : Fin 37) :
    (∑ k : Fin 37, (B i k : ℂ) * (G k j : ℂ)) = if i=j then 627 else 0 := by
  have h := product_checked i j
  rw [← intSum_eq] at h
  have hc := congrArg (fun x : ℤ => (x : ℂ)) h
  simpa [Int.cast_sum, Int.cast_mul, apply_ite] using hc

variable {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℂ H]

/-- A fully saturated Perkel Gram matrix has 37 linearly independent event
vectors already among the first 37 vertices. -/
theorem independent_block (x : Fin 57 → H)
    (hGram : ∀ i j, (57:ℂ) * ⟪x i, x j⟫_ℂ =
      if i=j then 3 else if PerkelGraph.adj i j then 1 else 0) :
    LinearIndependent ℂ (fun i : Fin 37 => x (site i)) := by
  classical
  have entries (k j : Fin 37) :
      (G k j : ℂ) = 57 * ⟪x (site k), x (site j)⟫_ℂ := by
    rw [block_entries, hGram]
    split_ifs <;> simp
  apply Fintype.linearIndependent_iff.mpr
  intro c hc i
  have row (k : Fin 37) : (∑ j : Fin 37, (G k j : ℂ)*c j) = 0 := by
    calc
      _ = 57 * ⟪x (site k), ∑ j : Fin 37, c j • x (site j)⟫_ℂ := by
        rw [inner_sum, Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro j _
        rw [entries, inner_smul_right]
        ring
      _ = 0 := by rw [hc]; simp
  have hc' : (∑ j : Fin 37, (if i=j then (627:ℂ) else 0)*c j) = 0 := by
    calc
      _ = ∑ j : Fin 37, ∑ k : Fin 37, (B i k : ℂ)*((G k j : ℂ)*c j) := by
        apply Finset.sum_congr rfl
        intro j _
        rw [← complex_inverse i j, Finset.sum_mul]
        apply Finset.sum_congr rfl
        intro k _
        exact mul_assoc _ _ _
      _ = ∑ k : Fin 37, ∑ j : Fin 37, (B i k : ℂ)*((G k j : ℂ)*c j) :=
        Finset.sum_comm
      _ = 0 := by simp_rw [← Finset.mul_sum, row, mul_zero, Finset.sum_const_zero]
  simpa [ite_mul] using hc'

/-- The Perkel Gram matrix forces ambient complex dimension at least 37. -/
theorem dimension_lower [Module.Finite ℂ H] (x : Fin 57 → H)
    (hGram : ∀ i j, (57:ℂ) * ⟪x i, x j⟫_ℂ =
      if i=j then 3 else if PerkelGraph.adj i j then 1 else 0) :
    37 ≤ Module.finrank ℂ H := by
  simpa using (independent_block x hGram).fintype_card_le_finrank

#print axioms dimension_lower
end PerkelDimension
