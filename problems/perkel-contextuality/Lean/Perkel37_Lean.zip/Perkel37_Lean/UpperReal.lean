import UpperCertificate
import Mathlib.Data.Real.Sqrt
import Mathlib.Tactic.Ring
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Linarith

namespace Perkel37

/-- Ordinary Euclidean dot product on the specified 37 coordinates. -/
def dot37 (x y : Fin 37 → ℝ) : ℝ := ∑ k, x k * y k

/-- The real factor corresponding to the positive diagonal integer certificate. -/
noncomputable def raw (i : Fin 58) (k : Fin 37) : ℝ :=
  Real.sqrt ((w k : ℝ) / (scale : ℝ)) * (b k i : ℝ)

private theorem list_fin_sum (f : Nat → ℤ) (n : ℕ) :
    ((List.range n).map f).sum = ∑ k : Fin n, f k := by
  rw [Finset.sum_fin_eq_sum_range]
  calc
    _ = ∑ k ∈ Finset.range n, f k := by
      induction n with
      | zero => simp
      | succ n ih => simp [List.range_succ, Finset.sum_range_succ, ih]
    _ = _ := Finset.sum_congr rfl (fun k hk => by simp [Finset.mem_range.mp hk])

theorem raw_gram (i j : Fin 58) : dot37 (raw i) (raw j) = (target i j : ℝ) := by
  have hs : 0 < (scale : ℝ) := by exact_mod_cast scale_pos
  have hZ := gram_exact i j
  rw [gramInt, list_fin_sum] at hZ
  have hR : (∑ k : Fin 37, (w k : ℝ) * (b k i : ℝ) * (b k j : ℝ)) =
      (scale : ℝ) * (target i j : ℝ) := by exact_mod_cast hZ
  unfold dot37
  calc
    _ = (∑ k : Fin 37, (w k : ℝ) * (b k i : ℝ) * (b k j : ℝ)) / (scale : ℝ) := by
      conv_rhs => rw [div_eq_mul_inv, Finset.sum_mul]
      apply Finset.sum_congr rfl
      intro k _
      have hw : 0 < (w k : ℝ) := by exact_mod_cast weight_pos k
      unfold raw
      calc
        _ = Real.sqrt ((w k : ℝ) / scale)^2 * (b k i : ℝ) * (b k j : ℝ) := by ring
        _ = _ := by rw [Real.sq_sqrt (le_of_lt (div_pos hw hs))]; ring
    _ = _ := by rw [hR]; field_simp

private theorem dot_div (x y : Fin 37 → ℝ) (a b' : ℝ) :
    dot37 (fun k => x k / a) (fun k => y k / b') = dot37 x y / (a * b') := by
  unfold dot37
  conv_rhs => rw [div_eq_mul_inv, Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro k _
  rw [← div_eq_mul_inv]
  exact div_mul_div_comm ..

def spin (v : Fin 57) : Fin 58 := ⟨v.val, by omega⟩
noncomputable def ray (v : Fin 57) (k : Fin 37) : ℝ := raw (spin v) k / Real.sqrt 3
noncomputable def state (k : Fin 37) : ℝ := raw 57 k / Real.sqrt 57

theorem unit_ray (v : Fin 57) : dot37 (ray v) (ray v) = 1 := by
  unfold ray
  rw [dot_div, raw_gram, Real.mul_self_sqrt (by norm_num)]
  have hv : (spin v).val ≠ 57 := by simp [spin]; omega
  norm_num [target,hv]

theorem unit_state : dot37 state state = 1 := by
  unfold state
  rw [dot_div, raw_gram, Real.mul_self_sqrt (by norm_num)]
  norm_num [target]

theorem ray_gram (u v : Fin 57) :
    dot37 (ray u) (ray v) = if u = v then 1 else if adjacent u v then 1/3 else 0 := by
  unfold ray
  rw [dot_div, raw_gram, Real.mul_self_sqrt (by norm_num)]
  have hu : u.val ≠ 57 := by omega
  have hv : v.val ≠ 57 := by omega
  by_cases he : u = v
  · subst v
    norm_num [spin,target,hu]
  · have huv : u.val ≠ v.val := fun h => he (Fin.ext h)
    cases h : adjacent u v <;> norm_num [spin,target,hu,hv,huv,he,h]

theorem per_event_probability (v : Fin 57) : (dot37 state (ray v))^2 = 1/19 := by
  unfold state ray
  rw [dot_div, raw_gram, div_pow, mul_pow,
    Real.sq_sqrt (by norm_num), Real.sq_sqrt (by norm_num)]
  have hv : v.val ≠ 57 := by omega
  norm_num [target,spin,hv]

theorem each_context_saturates (context : Fin 19 → Fin 57) :
    ∑ j : Fin 19, (dot37 state (ray (context j)))^2 = 1 := by
  norm_num [per_event_probability]

#print axioms raw_gram
#print axioms ray_gram
#print axioms unit_ray
#print axioms unit_state
#print axioms per_event_probability
#print axioms each_context_saturates
end Perkel37
