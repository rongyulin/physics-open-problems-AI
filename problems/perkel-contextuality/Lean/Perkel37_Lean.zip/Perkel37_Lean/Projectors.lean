import Rigidity
import Dimension

/-! Connect the abstract Gram and rank theorems to orthogonal projective
measurements of arbitrary rank. The score is the sum of Born probabilities. -/
open scoped BigOperators InnerProductSpace

namespace PerkelModel
open PerkelGraph
variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E]

/-- Orthogonal projections with the exclusivities specified by the graph. -/
structure Measurements (E : Type*) [NormedAddCommGroup E] [InnerProductSpace ℂ E] where
  P : V → E →ₗ[ℂ] E
  selfAdj : ∀ i u v, ⟪P i u, v⟫_ℂ = ⟪u, P i v⟫_ℂ
  idem : ∀ i u, P i (P i u) = P i u
  exclusive : ∀ i j, i ≠ j → adj i j = false → ∀ u, P i (P j u) = 0

noncomputable def score (M : Measurements E) (ψ : E) : ℝ :=
  ∑ i, ‖M.P i ψ‖ ^ 2

/-- The Gram matrix of the projected state vectors in any perfect realization. -/
theorem saturated_gram (M : Measurements E) (ψ : E) (unit : ‖ψ‖ = 1)
    (sat : score M ψ = 3) :
    ∀ i j, (57 : ℂ) * ⟪M.P i ψ, M.P j ψ⟫_ℂ =
      if i = j then 3 else if adj i j then 1 else 0 := by
  apply PerkelRigidity.gram_rigidity ψ (fun i => M.P i ψ) unit
  · intro i
    calc
      ⟪M.P i ψ, ψ⟫_ℂ = ⟪M.P i (M.P i ψ), ψ⟫_ℂ := by rw [M.idem]
      _ = ⟪M.P i ψ, M.P i ψ⟫_ℂ := M.selfAdj i _ _
  · intro i j hij hex
    rw [M.selfAdj, M.exclusive i j hij hex ψ, inner_zero_right]
  · exact sat

/-- A unit state attaining total probability three forces complex dimension 37 or higher. -/
theorem minimum_dimension [Module.Finite ℂ E] (M : Measurements E) (ψ : E)
    (unit : ‖ψ‖ = 1) (sat : score M ψ = 3) : 37 ≤ Module.finrank ℂ E :=
  PerkelDimension.dimension_lower _ (saturated_gram M ψ unit sat)

#print axioms minimum_dimension
end PerkelModel
