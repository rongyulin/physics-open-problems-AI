import Std

/-! A finite certificate for the Perkel graph with Brouwer's labelling.
   Vertices are (layer,index) in Z/3 × Z/19. For consecutive layers in
   cyclic order, the cube of the index difference is 2^(6*layer) mod 19.
   The Boolean adjacency below is computed directly from this equation.
   Tables used as witnesses are checked against it in the Lean kernel. -/
namespace PerkelGraph
set_option maxHeartbeats 0
set_option maxRecDepth 300000
abbrev V := Fin 57
private def forward (v w : V) : Bool :=
  ((v.val / 19 + 1) % 3 == w.val / 19) &&
  ((19 + w.val % 19 - v.val % 19)^3 % 19 == 2^(6*(v.val / 19)) % 19)

def adj (v w : V) : Bool := forward v w || forward w v
private def nbData (i : Nat) : Nat := (0x85f7103c481e6cf3837dd68e34279c64d30175b60c2c071a5d22ca6d959128969855024865750f2076164ce1c695754d18591650c1448d54cb10396250a0c29214c90819638080409227d21c08e17924468a0751405baba512c7b6aa10286b299cf245ae898e204e2a9cd1c3de998c182e36a0b141df59ca100db4992243e35cd1202df4c901c1db3c4f180d72c12385d31bd1344cf0b90303cafb4f2c2c6eb0e281c2dacd240beca92308ce89dd653ca79a5718e319a46d7e37c23696df6be2655db5ba1614d74b605d3d33b257d6cf2ae4795cb1aa3754c70a62713c2fa2585bbee9e481abad9a37d9e2db22798decae1757dabaa0716d6aa5f6d5d29a1e694 >>> (6*i)) % 64
private def colorData (i : Nat) : Nat := (0x209400626981258a6a6056426585292108a16a81011298511496a546841a00246510869165662a606692800246510689165664218669280a98848114a554808859284a1a56a252251068009166421a459680a9819a486459a42a94544689064182a01290155262996609a2a225216209054009400626881258a6a6656426585019a42aa1914689065152a0129106059a42aa1904689065152a01291061aa92108a11481011299a11496a5490aa86459a24194544604a44182a2459a42aa1544689065182a012910108a16aa4811298520496a54684500626882508a6a6604966585015906459a42aa0544689065182a012912055498a6518268a889485882415055498a6580268a889465882415022aaaaaaaaa5555555554000000000 >>> (2*i)) % 4
private def witness (i : Nat) : Nat := (0xc32054018567481e80adc00b1022010251cc0384c52002819840431e30818223d0011201601a310500914e820086484405902e101a6414e049c4c300a3219a071584300a413060204ca480a8184800a84828062394205046b101216106018562801e669c201a0b00813040c207048340088135204888a300458242029829400c3415801bd85101ea10c804ac24500e91acc048c2658026110600a5e7601046a8200954938041239601896d381875104012924380e95056072987200a910600328e8081a24058009d281008b130e0644a25802a31ca0 >>> (5*i)) % 32
private def selData (i : Nat) : Nat := (0x240060908040400114600980524510218524404524858800800a18518504614020110054010a08400120940214400048980404050210800104561089191899211955a590458699555295851a9541469849925a29955 >>> (2*i)) % 4
private def parentData (i : Nat) : Nat := (0xf79a78068969418d5045090007a2a68a68369a00d33d00c34c2dc404a89f16b6534d1e529a1ab5eaeba40 >>> (6*i)) % 64

def nb (v : V) (i : Fin 6) : V := Fin.ofNat 57 (nbData (6*v.val+i.val))
private def baseColor (c : Fin 20) (v : V) : Fin 3 :=
  Fin.ofNat 3 (colorData (57*c.val+v.val))
private def which (v : V) (r : Fin 6) : Fin 20 := Fin.ofNat 20 (witness (6*v.val+r.val))
def col (v : V) (r : Fin 6) (w : V) : Fin 3 := baseColor (which v r) w
def sel (v : V) (r : Fin 6) : Fin 3 := Fin.ofNat 3 (selData (6*v.val+r.val))
def tr0 (r : Fin 6) : Fin 6 := #[0,0,0,0,0,1][r.val]!
def tr1 (r : Fin 6) : Fin 6 := #[1,1,1,1,2,2][r.val]!
def tr2 (r : Fin 6) : Fin 6 := #[2,3,4,5,3,3][r.val]!

private def allF {n : Nat} (p : Fin n → Bool) : Bool := (List.finRange n).all p
private theorem spec {n : Nat} {p : Fin n → Bool} (h : allF p = true) (v : Fin n) : p v = true :=
  List.all_eq_true.mp h v (List.mem_finRange _)
private theorem from2 {n m : Nat} (p : Fin n → Fin m → Prop) [∀x y, Decidable (p x y)]
    (h : allF (fun x => allF (fun y => decide (p x y))) = true) : ∀x y,p x y :=
  fun x y => of_decide_eq_true (spec (spec h x) y)
private theorem from3 {n m k : Nat} (p : Fin n → Fin m → Fin k → Prop)
    [∀ x y z, Decidable (p x y z)] (h : allF (fun x => allF (fun y => allF (fun z => decide (p x y z)))) = true) : ∀ x y z, p x y z :=
  fun x y z => of_decide_eq_true (spec (spec (spec h x) y) z)
theorem adjacent_symm : ∀ v w : V, adj v w = adj w v := by
  intro v w
  exact Bool.or_comm _ _

theorem sixth : ∀ v w : V, adj v w = true → ∃ i : Fin 6, w = nb v i  := by
  apply from2
  rfl

theorem neighborEdge : ∀ (v : V) (i : Fin 6), adj v (nb v i) = true  := by
  apply from2
  rfl

private theorem proper_on_nb : ∀ (c : Fin 20) (v : V) (i : Fin 6),
    baseColor c v ≠ baseColor c (nb v i)  := by
  apply from3
  rfl

theorem proper (v : V) (r : Fin 6) (u w : V) (h : adj u w = true) :
    col v r u ≠ col v r w := by
  obtain ⟨i,rfl⟩ := sixth u w h
  exact proper_on_nb (which v r) u i

theorem excluded : ∀ (v : V) (r : Fin 6), col v r v ≠ sel v r  := by
  apply from2
  rfl

private theorem local_slice : ∀ (v : V) (r i : Fin 6),
    col v r (nb v i) = sel v r ↔
    (i = tr0 r ∨ i = tr1 r ∨ i = tr2 r)  := by
  apply from3
  rfl

theorem slice3 (v : V) (r : Fin 6) (w : V) :
    (col v r w = sel v r ∧ adj v w = true) ↔
    (w = nb v (tr0 r) ∨ w = nb v (tr1 r) ∨ w = nb v (tr2 r)) := by
  constructor
  · rintro ⟨hc, he⟩
    obtain ⟨i,rfl⟩ := sixth v w he
    rcases (local_slice v r i).mp hc with h|h|h
    · exact Or.inl (congrArg (nb v) h)
    · exact Or.inr (Or.inl (congrArg (nb v) h))
    · exact Or.inr (Or.inr (congrArg (nb v) h))
  · intro h
    rcases h with rfl|rfl|rfl
    · exact ⟨(local_slice _ _ _).mpr (Or.inl rfl), neighborEdge _ _⟩
    · exact ⟨(local_slice _ _ _).mpr (Or.inr (Or.inl rfl)), neighborEdge _ _⟩
    · exact ⟨(local_slice _ _ _).mpr (Or.inr (Or.inr rfl)), neighborEdge _ _⟩

theorem triple_nodup : ∀ (v : V) (r : Fin 6),
    nb v (tr0 r) ≠ nb v (tr1 r) ∧ nb v (tr0 r) ≠ nb v (tr2 r) ∧
    nb v (tr1 r) ≠ nb v (tr2 r)  := by
  apply from2
  rfl

private def parent (v : V) : V := Fin.ofNat 57 (parentData (v.val))
private theorem spans : ∀ v, v = parent v ∨ adj v (parent v) = true := by decide
private theorem depth : ∀ v, parent (parent (parent v)) = 0 := by decide

theorem eq_of_edge_eq {α : Type u} {f : V → α}
    (h : ∀ v w, adj v w = true → f v = f w) (v : V) : f v = f 0 := by
  have hp (w : V) : f w = f (parent w) := by
    rcases spans w with e|e
    · exact congrArg f e
    · exact h _ _ e
  calc
    f v = f (parent v) := hp v
    _ = f (parent (parent v)) := hp _
    _ = f (parent (parent (parent v))) := hp _
    _ = f 0 := congrArg f (depth v)

#print axioms proper
#print axioms slice3
#print axioms eq_of_edge_eq
end PerkelGraph
