#!/usr/bin/env sh
# Run from any working directory. Lake uses the checked-in toolchain and dependency lock.
set -eu
cd "$(dirname "$0")"

lake build

# Replay each module's declarations in a separate Lean kernel process with its
# checked-in imports available. Sequential replay limits peak memory use.
for source in ./*.lean; do
    module=${source#./}
    module=${module%.lean}
    lake env leanchecker --verbose "$module"
done
