import UpperBridge
import Projectors
import Mathlib.Analysis.InnerProductSpace.PiL2

namespace Perkel37
open scoped BigOperators InnerProductSpace
open PerkelModel

abbrev Space := EuclideanSpace ℂ (Fin 37)
noncomputable def embed (v : Fin 37 → ℝ) : Space := WithLp.toLp 2 (fun k => (v k : ℂ))

private theorem embed_inner (v w' : Fin 37 → ℝ) :
    ⟪embed v, embed w'⟫_ℂ = (dot37 v w' : ℂ) := by
  unfold embed dot37
  rw [EuclideanSpace.inner_toLp_toLp]
  simp [dotProduct, mul_comm]

private theorem embed_norm {v : Fin 37 → ℝ} (unit : dot37 v v = 1) : ‖embed v‖ = 1 := by
  have hin := embed_inner v v
  rw [unit, inner_self_eq_norm_sq_to_K] at hin
  have hn : ‖embed v‖^2 = 1 := by
    simpa [← Complex.ofReal_pow] using congrArg Complex.re hin
  nlinarith [norm_nonneg (embed v)]

private noncomputable def proj (y : Space) : Space →ₗ[ℂ] Space where
  toFun x := ⟪y, x⟫_ℂ • y
  map_add' x z := by rw [inner_add_right, add_smul]
  map_smul' a x := by simp [inner_smul_right, smul_smul]

private theorem proj_apply (y x : Space) : proj y x = ⟪y, x⟫_ℂ • y := rfl

noncomputable def measurements37 : Measurements Space where
  P i := proj (embed (ray i))
  selfAdj i x y := by
    simp only [proj_apply, inner_smul_left, inner_smul_right, inner_conj_symm]
    ring
  idem i x := by
    simp only [proj_apply, inner_smul_right, embed_inner, unit_ray, Complex.ofReal_one, mul_one]
  exclusive i j hij hadj x := by
    simp only [proj_apply, inner_smul_right, embed_inner, explicit_perkel_gram, if_neg hij,
      hadj, Bool.false_eq_true, ↓reduceIte, Complex.ofReal_zero, mul_zero, zero_smul]

theorem complex_event (i : Fin 57) :
    ‖measurements37.P i (embed state)‖^2 = 1/19 := by
  change ‖⟪embed (ray i), embed state⟫_ℂ • embed (ray i)‖^2 = _
  have hsym : dot37 (ray i) state = dot37 state (ray i) :=
    Finset.sum_congr rfl (fun k _ => mul_comm _ _)
  rw [norm_smul, embed_inner, embed_norm (unit_ray i), mul_one,
    Complex.norm_real, Real.norm_eq_abs, sq_abs, hsym, per_event_probability]

theorem score37 : score measurements37 (embed state) = 3 := by
  unfold score
  simp only [complex_event, Finset.sum_const, Finset.card_univ, Fintype.card_fin]
  norm_num

theorem attained_by_complex_projectors :
    Module.finrank ℂ Space = 37 ∧
    ∃ (M : Measurements Space) (ψ : Space), ‖ψ‖ = 1 ∧ score M ψ = 3 :=
  ⟨finrank_euclideanSpace_fin, measurements37, embed state, embed_norm unit_state, score37⟩

#print axioms attained_by_complex_projectors
end Perkel37
