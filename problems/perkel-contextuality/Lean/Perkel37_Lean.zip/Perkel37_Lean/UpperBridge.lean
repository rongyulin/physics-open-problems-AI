import PerkelGraph
import UpperReal

namespace Perkel37

set_option maxHeartbeats 0
set_option maxRecDepth 30000

/-- The displacement presentation of the explicit coordinates agrees with the
    modular cubing presentation used for the dimension lower bound. -/
theorem adjacency_presentations : ∀ u v : Fin 57,
    adjacent u v = PerkelGraph.adj u v := by decide

theorem explicit_perkel_gram (u v : Fin 57) :
    dot37 (ray u) (ray v) = if u = v then 1 else if PerkelGraph.adj u v then 1/3 else 0 := by
  rw [ray_gram, adjacency_presentations]

/-- There are 57 real unit vectors and a real unit state in precisely 37
coordinates with the original ideal Gram entries and event probabilities. -/
theorem attained_in_37 :
    ∃ (rays : Fin 57 → Fin 37 → ℝ) (psi : Fin 37 → ℝ),
      (∀ i, dot37 (rays i) (rays i) = 1) ∧ dot37 psi psi = 1 ∧
      (∀ i j, dot37 (rays i) (rays j) =
        if i = j then 1 else if PerkelGraph.adj i j then 1/3 else 0) ∧
      (∀ i, (dot37 psi (rays i))^2 = 1/19) ∧
      (∀ ctx : Fin 19 → Fin 57, ∑ j, (dot37 psi (rays (ctx j)))^2 = 1) :=
  ⟨ray, state, unit_ray, unit_state, explicit_perkel_gram,
    per_event_probability, each_context_saturates⟩

#print axioms attained_in_37
end Perkel37
