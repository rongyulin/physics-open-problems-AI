import PerkelGraph
import Mathlib.Analysis.InnerProductSpace.Basic
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum

/-! At a saturated pure state, exclusion and the projection identities force
the whole 57 by 57 Gram matrix. No Gram entries or color-class saturation
conditions are assumed in the main theorem. -/

open scoped BigOperators InnerProductSpace
open PerkelGraph

namespace PerkelRigidity

variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E]

private theorem self_complex (u : E) : ⟪u,u⟫_ℂ = ((‖u‖^2 : ℝ) : ℂ) := by
  apply Complex.ext
  · exact @inner_self_eq_norm_sq ℂ E _ _ _ u
  · exact @inner_self_im ℂ E _ _ _ u

def fiber (c : V → Fin 3) (s : Fin 3) : Finset V :=
  Finset.univ.filter fun w => c w = s

/-- Orthogonality in a context gives an exact norm deficit, including its
equality case. -/
theorem deficit (ψ : E) (x : V → E) (S : Finset V) (unit : ‖ψ‖ = 1)
    (born : ∀ v, ⟪x v, ψ⟫_ℂ = ⟪x v, x v⟫_ℂ)
    (orth : ∀ i ∈ S, ∀ j ∈ S, i ≠ j → ⟪x i, x j⟫_ℂ = 0) :
    ‖(∑ i ∈ S, x i) - ψ‖ ^ 2 = 1 - ∑ i ∈ S, ‖x i‖^2 := by
  have hh (i : V) (hi : i ∈ S) :
      ⟪x i, ∑ j ∈ S, x j⟫_ℂ = ⟪x i, x i⟫_ℂ := by
    rw [inner_sum]
    apply Finset.sum_eq_single_of_mem i hi
    intro j hj hji
    exact orth i hi j hj hji.symm
  have both : ⟪∑ i ∈ S, x i, ∑ i ∈ S, x i⟫_ℂ =
      ((∑ i ∈ S, ‖x i‖^2 : ℝ) : ℂ) := by
    rw [sum_inner, Complex.ofReal_sum]
    apply Finset.sum_congr rfl
    intro i hi
    rw [hh i hi, self_complex]
  have cross : ⟪∑ i ∈ S, x i, ψ⟫_ℂ =
      ((∑ i ∈ S, ‖x i‖^2 : ℝ) : ℂ) := by
    rw [sum_inner, Complex.ofReal_sum]
    apply Finset.sum_congr rfl
    intro i _
    rw [born, self_complex]
  rw [@norm_sub_sq ℂ _ _ _ _ _ _, ← @inner_self_eq_norm_sq ℂ _ _ _ _ _, both,
      cross, unit]
  change (∑ i ∈ S, ‖x i‖^2) - 2 * (∑ i ∈ S, ‖x i‖^2) + (1:ℝ)^2 = _
  ring

/-- Saturation of the total through a partition into three orthogonal
classes implies that *each* class sums to the state vector. -/
private theorem context_sum (ψ : E) (x : V → E) (c : V → Fin 3)
    (unit : ‖ψ‖=1) (born : ∀ v, ⟪x v,ψ⟫_ℂ = ⟪x v,x v⟫_ℂ)
    (orth : ∀ i j, i ≠ j → c i = c j → ⟪x i,x j⟫_ℂ=0)
    (sat : ∑ v, ‖x v‖^2 = 3) (s : Fin 3) : ∑ i ∈ fiber c s, x i = ψ := by
  let m (z : Fin 3) := ∑ i ∈ fiber c z, ‖x i‖^2
  have hd (z : Fin 3) : ‖(∑ i ∈ fiber c z, x i) - ψ‖^2 = 1-m z := by
    apply deficit ψ x _ unit born
    intro i hi j hj hij
    exact orth i j hij ((Finset.mem_filter.mp hi).2.trans (Finset.mem_filter.mp hj).2.symm)
  have hm : ∑ z, m z = 3 := by
    calc
      ∑ z, m z = ∑ i, ∑ z : Fin 3, if c i = z then ‖x i‖ ^ 2 else 0 := by
        simp only [m, fiber, Finset.sum_filter]; rw [Finset.sum_comm]
      _ = _ := by simpa using sat
  have hzero : ∑ z : Fin 3, ‖(∑ i ∈ fiber c z, x i) - ψ‖^2 = 0 := by
    simp only [hd, Finset.sum_sub_distrib, hm]
    norm_num
  have hz := (Finset.sum_eq_zero_iff_of_nonneg
    (fun z (_ : z ∈ (Finset.univ : Finset (Fin 3))) =>
      sq_nonneg ‖(∑ i ∈ fiber c z, x i) - ψ‖)).mp hzero s (Finset.mem_univ s)
  exact sub_eq_zero.mp (norm_eq_zero.mp (sq_eq_zero_iff.mp hz))

private theorem six_equations (z : Fin 6 → ℂ) (p : ℂ)
    (h : ∀ r, z (tr0 r) + z (tr1 r) + z (tr2 r) = p) :
    ∀ i, 3 * z i = p := by
  have h0 : z 0 + z 1 + z 2 = p := h 0
  have h1 : z 0 + z 1 + z 3 = p := h 1
  have h2 : z 0 + z 1 + z 4 = p := h 2
  have h3 : z 0 + z 1 + z 5 = p := h 3
  have h4 : z 0 + z 2 + z 3 = p := h 4
  have h5 : z 1 + z 2 + z 3 = p := h 5
  intro i
  fin_cases i
  · change 3 * z 0 = p
    linear_combination h0 + h1 + h4 - 2*h5
  · change 3 * z 1 = p
    linear_combination h0 + h1 - 2*h4 + h5
  · change 3 * z 2 = p
    linear_combination h0 - 2*h1 + h4 + h5
  · change 3 * z 3 = p
    linear_combination -2*h0 + h1 + h4 + h5
  · change 3 * z 4 = p
    linear_combination -2*h0 - 2*h1 + 3*h2 + h4 + h5
  · change 3 * z 5 = p
    linear_combination -2*h0 - 2*h1 + 3*h3 + h4 + h5

/-- Exact complex Gram equality for the original events; the assumptions
are the Born identities of the projected vectors, exclusivity, normalization
of the state, and saturation of the total probability. -/
theorem gram_rigidity (ψ : E) (x : V → E) (unit : ‖ψ‖=1)
    (born : ∀ v, ⟪x v,ψ⟫_ℂ = ⟪x v,x v⟫_ℂ)
    (excl : ∀ v w, v ≠ w → adj v w = false → ⟪x v,x w⟫_ℂ = 0)
    (sat : ∑ v, ‖x v‖^2 = 3) :
    ∀ v w, (57:ℂ) * ⟪x v,x w⟫_ℂ =
      if v=w then 3 else if adj v w then 1 else 0 := by
  classical
  let p (v : V) : ℂ := ⟪x v,x v⟫_ℂ
  have hedges (v w : V) (hw : adj v w = true) : 3 * ⟪x v,x w⟫_ℂ = p v := by
    obtain ⟨i,rfl⟩ := sixth v w hw
    apply six_equations (fun j => ⟪x v, x (nb v j)⟫_ℂ) (p v) _ i
    intro r
    let c := col v r
    let s := sel v r
    let T : Finset V := {nb v (tr0 r), nb v (tr1 r), nb v (tr2 r)}
    have hT (u : V) : u ∈ T ↔ (c u = s ∧ adj v u = true) := by
      simpa [T,c,s] using (slice3 v r u).symm
    have sub : T ⊆ fiber c s := fun u hu =>
      Finset.mem_filter.mpr ⟨Finset.mem_univ _, ((hT u).mp hu).1⟩
    have hsum : ∑ u ∈ T, ⟪x v,x u⟫_ℂ = ∑ u ∈ fiber c s, ⟪x v,x u⟫_ℂ := by
      apply Finset.sum_subset sub
      intro u hu hnu
      have hc := (Finset.mem_filter.mp hu).2
      have hne : v ≠ u := by
        rintro rfl; exact excluded v r hc
      apply excl v u hne
      cases he : adj v u with
      | false => rfl
      | true => exact False.elim (hnu ((hT u).mpr ⟨hc,he⟩))
    have orth (i j : V) (hij : i ≠ j) (hc : c i = c j) : ⟪x i,x j⟫_ℂ=0 := by
      apply excl i j hij
      cases he : adj i j with
      | false => rfl
      | true => exact False.elim (proper v r i j he hc)
    rw [← inner_sum (fiber c s) x (x v), context_sum ψ x c unit born orth sat s, born] at hsum
    obtain ⟨e01,e02,e12⟩ := triple_nodup v r
    simpa [p, T, e01,e02,e12,add_assoc] using hsum
  have hp (u : V) : ‖x u‖^2 = ‖x 0‖^2 := by
    apply eq_of_edge_eq (f:=fun v => ‖x v‖^2) _ u
    intro i j hij
    have hji : adj j i = true := by rw [adjacent_symm, hij]
    have h1 := congrArg Complex.re (hedges i j hij)
    have h2 := congrArg Complex.re (hedges j i hji)
    have hs := @inner_re_symm ℂ E _ _ _ (x i) (x j)
    change (⟪x i,x j⟫_ℂ).re = (⟪x j,x i⟫_ℂ).re at hs
    simp only [p, self_complex, Complex.ofReal_re, Complex.mul_re] at h1 h2
    norm_num at h1 h2
    linarith
  have m0 : (57:ℝ)*‖x 0‖^2 = 3 := by simpa [hp] using sat
  have pval (v : V) : (57:ℂ) * p v = 3 := by
    have hr : (57:ℝ) * ‖x v‖^2 = 3 := by rw [hp v]; exact m0
    change (57:ℂ)*⟪x v,x v⟫_ℂ=3
    rw [self_complex]
    exact_mod_cast hr
  intro v w
  by_cases he : v=w
  · subst w; simpa only [if_pos rfl] using pval v
  · simp only [if_neg he]
    cases ha : adj v w with
    | false => simp [excl v w he ha]
    | true =>
      simp only [if_true]
      have hh := hedges v w ha
      have hd := pval v
      linear_combination 19 * hh + (1/3 : ℂ) * hd

#print axioms gram_rigidity
end PerkelRigidity
