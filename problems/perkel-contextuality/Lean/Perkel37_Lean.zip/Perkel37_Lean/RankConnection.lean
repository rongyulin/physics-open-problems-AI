import RankCertificate
import PerkelGraph

namespace PerkelDimension
open PerkelRank
set_option maxHeartbeats 10000000
set_option maxRecDepth 100000

def site (i : Fin 37) : Fin 57 := ⟨i.val, by omega⟩

theorem block_entries : ∀ i j : Fin 37,
    G i j = if site i = site j then 3 else if PerkelGraph.adj (site i) (site j) then 1 else 0 := by
  decide +kernel

#print axioms block_entries
end PerkelDimension
