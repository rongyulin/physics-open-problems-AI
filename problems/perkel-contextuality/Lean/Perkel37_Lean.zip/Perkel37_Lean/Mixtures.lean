import Projectors
import Mathlib.Algebra.Order.BigOperators.Group.Finset

/-! Any finite probabilistic mixture of normalized states obeys the same
exact witness. The measurements are fixed across the ensemble. -/
open scoped BigOperators InnerProductSpace
open PerkelGraph PerkelRigidity

namespace PerkelModel
variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E]

theorem score_upper (M : Measurements E) (ψ : E) (unit : ‖ψ‖ = 1) : score M ψ ≤ 3 := by
  classical
  let c := col (0 : V) 0
  let x := fun i => M.P i ψ
  have born (i : V) : ⟪x i, ψ⟫_ℂ = ⟪x i, x i⟫_ℂ := by
    change ⟪M.P i ψ, ψ⟫_ℂ = ⟪M.P i ψ, M.P i ψ⟫_ℂ
    rw [← M.selfAdj, M.idem]
  have orth (z : Fin 3) (i : V) (hi : i ∈ fiber c z) (j : V)
      (hj : j ∈ fiber c z) (ne : i ≠ j) : ⟪x i,x j⟫_ℂ = 0 := by
    have hc : c i = c j := (Finset.mem_filter.mp hi).2.trans (Finset.mem_filter.mp hj).2.symm
    have he : adj i j = false := by
      cases e : adj i j with
      | false => rfl
      | true => exact False.elim (proper 0 0 i j e hc)
    change ⟪M.P i ψ, M.P j ψ⟫_ℂ = 0
    rw [M.selfAdj, M.exclusive _ _ ne he, inner_zero_right]
  have hctx (z : Fin 3) : ∑ i ∈ fiber c z, ‖x i‖^2 ≤ 1 := by
    have hd := deficit ψ x (fiber c z) unit born (orth z)
    linarith only [hd, sq_nonneg ‖(∑ i ∈ fiber c z, x i) - ψ‖]
  calc
    score M ψ = ∑ z : Fin 3, ∑ i ∈ fiber c z, ‖x i‖^2 := by
      simp only [fiber, Finset.sum_filter]
      rw [Finset.sum_comm]
      simp [score, x]
    _ ≤ ∑ _ : Fin 3, (1:ℝ) := Finset.sum_le_sum fun z _ => hctx z
    _ = 3 := by simp

/-- For an ensemble reaching the ideal score, each component with positive
weight reaches the same score using the very same measurements. -/
theorem component_saturates {ι : Type*} [Fintype ι] (M : Measurements E)
    (ψ : ι → E) (w : ι → ℝ) (unit : ∀ i, ‖ψ i‖ = 1)
    (wpos : ∀ i, 0 ≤ w i) (normalized : ∑ i, w i = 1)
    (sat : ∑ i, w i * score M (ψ i) = 3) (i : ι) (hi : 0 < w i) :
    score M (ψ i) = 3 := by
  have hnon (j : ι) : 0 ≤ w j * (3 - score M (ψ j)) :=
    mul_nonneg (wpos j) (sub_nonneg.mpr (score_upper M _ (unit j)))
  have htotal : ∑ j, w j * (3 - score M (ψ j)) = 0 := by
    simp_rw [mul_sub]
    rw [Finset.sum_sub_distrib, ← Finset.sum_mul, normalized, sat]
    norm_num
  have hzero := (Finset.sum_eq_zero_iff_of_nonneg (fun j _ => hnon j)).mp htotal i (Finset.mem_univ i)
  rcases mul_eq_zero.mp hzero with h | h
  · exact False.elim (hi.ne' h)
  · linarith

/-- The same 37-dimensional lower bound for every saturating finite convex
mixture of pure states, including spectral ensembles of density operators. -/
theorem mixed_minimum_dimension [Module.Finite ℂ E] {ι : Type*} [Fintype ι]
    (M : Measurements E) (ψ : ι → E) (w : ι → ℝ) (unit : ∀ i, ‖ψ i‖ = 1)
    (wpos : ∀ i, 0 ≤ w i) (normalized : ∑ i, w i = 1)
    (sat : ∑ i, w i * score M (ψ i) = 3) : 37 ≤ Module.finrank ℂ E := by
  classical
  have h : ∃ i, 0 < w i := by
    by_contra! h
    have hzero : ∀ j, w j = 0 := fun j => le_antisymm (h j) (wpos j)
    simp [hzero] at normalized
  obtain ⟨i,hi⟩ := h
  exact minimum_dimension M _ (unit i) (component_saturates M ψ w unit wpos normalized sat i hi)

#print axioms mixed_minimum_dimension
end PerkelModel
