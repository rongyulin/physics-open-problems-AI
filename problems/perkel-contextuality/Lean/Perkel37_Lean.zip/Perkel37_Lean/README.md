# Exact Hilbert-space dimension of the Perkel contextuality test

Companion project to *Thirty-seven dimensions are necessary for the Perkel contextuality experiment*, by Chatgpt.

A finite-dimensional complex projective model scores three on the prescribed 57 events only if its Hilbert space has dimension at least 37. An explicit model attains the bound in complex dimension 37.

## Reproduce the verification

The project pins Lean 4.28.0 and Mathlib commit 8f9d9cff6bd728b17a24e163c9402775d9e6a365. With the official Lean toolchain manager (elan), Internet access for dependencies, and a POSIX shell, run from the extracted directory:

~~~sh
lake exe cache get
sh audit.sh
~~~

The first command obtains Mathlib's build cache. The script builds every project module from source and then runs the accompanying Lean kernel checker on the resulting modules in fresh processes. For an ordinary source build alone, run 'lake build'. The upper-bound integer Gram identities are the most time-consuming part. No external solver is used during verification.

## Reading the statements

- Projectors.lean defines the measurements as self-adjoint idempotent complex linear maps. Prescribed exclusive pairs compose to zero. The probability is the squared norm of the projected unit vector. The statements 'PerkelModel.saturated_gram' and 'PerkelModel.minimum_dimension' prove the Gram identity and the pure-state dimension lower bound.
- Mixtures.lean proves the universal score bound and 'PerkelModel.mixed_minimum_dimension' for arbitrary finite probabilistic mixtures of pure states in a common space. The correspondence between finite-dimensional density operators and such ensembles is made in the paper.
- PerkelGraph.lean defines the graph by modular arithmetic and validates the coloring certificates. Rigidity.lean obtains the full complex Gram matrix from saturation and exclusivity.
- RankCertificate.lean, RankConnection.lean and Dimension.lean check an integer-scaled inverse of a 37-by-37 principal submatrix and prove linear independence in the actual Hilbert space.
- UpperCertificate.lean checks exact integer dot products for 57 rays and one state. UpperReal.lean and UpperBridge.lean turn these into normalized real coordinates and verify agreement with the original graph. UpperProjectors.lean embeds them into complex Euclidean space and proves 'Perkel37.attained_by_complex_projectors' in the same measurement model as the lower bound.

The final lower- and upper-bound theorems each depend on propext, Classical.choice, and Quot.sound. The quantitative near-saturation theorem and the general family of graph optimizers have English proofs in the paper. They are outside the scope of this Lean project.
