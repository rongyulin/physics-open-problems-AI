import IsoBell
import Mathlib.Analysis.Matrix.Spectrum
import Mathlib.LinearAlgebra.Matrix.Charpoly.Coeff

namespace IsoProjection
open Matrix IsoBell
open scoped Matrix ComplexConjugate BigOperators
noncomputable section
abbrev Vec := Fin 3 → ℂ
def ray (u : Vec) : Mat 3 := Matrix.vecMulVec u (star u)
def bracket (u v : Vec) : ℂ := star u ⬝ᵥ v
def model (r : Fin 4) (E : Mat 3) : Mat 3 := ![0,E,1-E,1] r

theorem col_unit (U : unitaryGroup (Fin 3) ℂ) (j : Fin 3) :
    bracket (U.val.col j) (U.val.col j) = 1 := by
  have h := congrFun (congrFun (Unitary.coe_star_mul_self U) j) j
  simpa [bracket, dotProduct, Matrix.mul_apply, Matrix.star_eq_conjTranspose] using h

private theorem conjugated_single (U : unitaryGroup (Fin 3) ℂ) (j : Fin 3) :
    Unitary.conjStarAlgAut ℂ _ U (Matrix.single j j (1 : ℂ)) = ray (U.val.col j) := by
  ext i k
  fin_cases j <;> simp [Fin.sum_univ_three,Unitary.conjStarAlgAut_apply,Matrix.star_eq_conjTranspose,ray, Matrix.mul_apply,
    Matrix.vecMulVec,Matrix.single, Matrix.col]

private theorem idempotent_bits (P : Mat 3) (h : Projector P) (i : Fin 3) :
    h.1.eigenvalues i = 0 ∨ h.1.eigenvalues i = 1 := by
  let φ := Unitary.conjStarAlgAut ℂ _ (star h.1.eigenvectorUnitary)
  have hd : φ P = diagonal (fun i => (h.1.eigenvalues i : ℂ)) :=
    h.1.conjStarAlgAut_star_eigenvectorUnitary
  have hsq := congrArg φ h.2
  rw [map_mul, hd,diagonal_mul_diagonal] at hsq
  have he := congrArg (fun (M : Mat 3) => (M i i).re) hsq
  simp at he
  exact (mul_eq_zero.mp (show h.1.eigenvalues i*(h.1.eigenvalues i-1)=0 by linarith)).imp id sub_eq_zero.mp

theorem projector_ray (P : Mat 3) (h : Projector P) :
    ∃ (r : Fin 4) (u : Vec), bracket u u=1 ∧ P = model r (ray u) := by
  let U := h.1.eigenvectorUnitary
  let φ := Unitary.conjStarAlgAut ℂ _ U
  have hs : P = φ (diagonal (fun i => (h.1.eigenvalues i : ℂ))) := h.1.spectral_theorem
  rcases idempotent_bits P h 0 with h0|h0 <;>
    rcases idempotent_bits P h 1 with h1|h1 <;>
    rcases idempotent_bits P h 2 with h2|h2
  · refine ⟨0, U.val.col 0, col_unit U 0, ?_⟩
    have he : diagonal (fun i => (h.1.eigenvalues i : ℂ)) = (0 : Mat 3) := by
      ext i j
      fin_cases i <;> fin_cases j <;> simp [Matrix.single, h0,h1,h2, Matrix.one_apply]
    rw [hs,he]
    exact map_zero _
  · refine ⟨1, U.val.col 2, col_unit U 2, ?_⟩
    have he : diagonal (fun i => (h.1.eigenvalues i : ℂ)) = (Matrix.single 2 2 1 : Mat 3) := by
      ext i j
      fin_cases i <;> fin_cases j <;> simp [Matrix.single, h0,h1,h2, Matrix.one_apply]
    rw [hs,he]
    exact conjugated_single _ _
  · refine ⟨1, U.val.col 1, col_unit U 1, ?_⟩
    have he : diagonal (fun i => (h.1.eigenvalues i : ℂ)) = (Matrix.single 1 1 1 : Mat 3) := by
      ext i j
      fin_cases i <;> fin_cases j <;> simp [Matrix.single, h0,h1,h2, Matrix.one_apply]
    rw [hs,he]
    exact conjugated_single _ _
  · refine ⟨2, U.val.col 0, col_unit U 0, ?_⟩
    have he : diagonal (fun i => (h.1.eigenvalues i : ℂ)) = (1 - Matrix.single 0 0 1 : Mat 3) := by
      ext i j
      fin_cases i <;> fin_cases j <;> simp [Matrix.single, h0,h1,h2, Matrix.one_apply]
    rw [hs,he]
    simpa [map_sub, map_one, φ, model] using congrArg (fun V : Mat 3 => 1-V) (conjugated_single U 0)
  · refine ⟨1, U.val.col 0, col_unit U 0, ?_⟩
    have he : diagonal (fun i => (h.1.eigenvalues i : ℂ)) = (Matrix.single 0 0 1 : Mat 3) := by
      ext i j
      fin_cases i <;> fin_cases j <;> simp [Matrix.single, h0,h1,h2, Matrix.one_apply]
    rw [hs,he]
    exact conjugated_single _ _
  · refine ⟨2, U.val.col 1, col_unit U 1, ?_⟩
    have he : diagonal (fun i => (h.1.eigenvalues i : ℂ)) = (1 - Matrix.single 1 1 1 : Mat 3) := by
      ext i j
      fin_cases i <;> fin_cases j <;> simp [Matrix.single, h0,h1,h2, Matrix.one_apply]
    rw [hs,he]
    simpa [map_sub, map_one, φ, model] using congrArg (fun V : Mat 3 => 1-V) (conjugated_single U 1)
  · refine ⟨2, U.val.col 2, col_unit U 2, ?_⟩
    have he : diagonal (fun i => (h.1.eigenvalues i : ℂ)) = (1 - Matrix.single 2 2 1 : Mat 3) := by
      ext i j
      fin_cases i <;> fin_cases j <;> simp [Matrix.single, h0,h1,h2, Matrix.one_apply]
    rw [hs,he]
    simpa [map_sub, map_one, φ, model] using congrArg (fun V : Mat 3 => 1-V) (conjugated_single U 2)
  · refine ⟨3, U.val.col 0, col_unit U 0, ?_⟩
    have he : diagonal (fun i => (h.1.eigenvalues i : ℂ)) = (1 : Mat 3) := by
      ext i j
      fin_cases i <;> fin_cases j <;> simp [Matrix.single, h0,h1,h2, Matrix.one_apply]
    rw [hs,he]
    exact map_one _

theorem bracket_conj (u v : Vec) : star (bracket u v) = bracket v u := by
  simp [bracket, dotProduct, mul_comm]

theorem overlap_parameters (u v : Vec) (hu : bracket u u = 1) (hv : bracket v v = 1) :
    ∃ t w : ℝ, 0 ≤ t ∧ 0 ≤ w ∧ t^2+w^2=1 ∧
      (t:ℂ)^2 = bracket u v * bracket v u := by
  have he (x y : Vec) : inner ℂ (WithLp.toLp 2 x) (WithLp.toLp 2 y) = bracket x y := by
    simp [EuclideanSpace.inner_eq_star_dotProduct,bracket,dotProduct,mul_comm]
  have norm_one (x : Vec) (hx : bracket x x = 1) : ‖WithLp.toLp 2 x‖=1 := by
    have hsq : ‖WithLp.toLp 2 x‖^2 = 1 := by
      have hr := congrArg Complex.re ((he x x).trans hx)
      rw [inner_self_eq_norm_sq_to_K] at hr
      change (((‖WithLp.toLp 2 x‖ : ℝ) : ℂ)^2).re = 1 at hr
      simpa only [← Complex.ofReal_pow, Complex.ofReal_re] using hr
    nlinarith [norm_nonneg (WithLp.toLp 2 x)]
  let t := ‖bracket u v‖
  have ht : t ≤ 1 := by
    change ‖bracket u v‖ ≤ 1
    rw [← he]
    simpa only [norm_one u hu,norm_one v hv,one_mul] using
      norm_inner_le_norm (𝕜 := ℂ) (WithLp.toLp 2 u) (WithLp.toLp 2 v)
  have hn : 0≤t := norm_nonneg _
  refine ⟨t,Real.sqrt (1-t^2),hn,Real.sqrt_nonneg _,?_,?_⟩
  · rw [Real.sq_sqrt (by nlinarith : 0 ≤ 1-t^2)]
    ring
  · calc
      (t:ℂ)^2 = (Complex.normSq (bracket u v) : ℂ) := by
        simp [t, Complex.normSq_eq_norm_sq]
      _ = bracket u v * star (bracket u v) := (Complex.mul_conj _).symm
      _ = _ := by rw [bracket_conj]

private theorem generic_det (u v : Vec) (l e f : ℂ) :
    (Matrix.scalar (Fin 3) l - (e • ray u + f • ray v)).det =
      l^3 - l^2*(e*bracket u u + f*bracket v v)
        + l*e*f*(bracket u u * bracket v v - bracket u v * bracket v u) := by
  simp [Matrix.det_fin_three, Matrix.scalar, Matrix.diagonal_apply, ray, vecMulVec,
    bracket,dotProduct, Fin.sum_univ_three]
  ring

theorem determinant_formula (u v : Vec) (hu : bracket u u=1) (hv : bracket v v=1)
    (l k e f : ℂ) :
    (Matrix.scalar (Fin 3) l - (k • 1 + e • ray u + f • ray v)).det =
     (l-k)*((l-k)^2-(l-k)*(e+f)+e*f*(1-bracket u v * bracket v u)) := by
  have he : Matrix.scalar (Fin 3) l - (k • 1 + e • ray u + f • ray v) =
      Matrix.scalar (Fin 3) (l-k) - (e • ray u + f • ray v) := by
    ext i j
    by_cases hij : i=j <;> simp [Matrix.scalar,Matrix.diagonal_apply, Matrix.one_apply, hij] <;> ring
  rw [he,generic_det,hu,hv]
  ring

end
end IsoProjection
