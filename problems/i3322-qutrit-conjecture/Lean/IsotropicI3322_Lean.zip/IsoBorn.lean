import IsoBell

namespace IsoBell
open Matrix
open scoped Matrix ComplexOrder BigOperators Kronecker
noncomputable section
abbrev Bip (d : ℕ) := Matrix (Fin d × Fin d) (Fin d × Fin d) ℂ

/-- Density matrix of the maximally entangled unit vector in the computational basis. -/
def bellPair (d : ℕ) : Bip d := fun u v =>
  if u.1=u.2 ∧ v.1=v.2 then (d:ℂ)⁻¹ else 0

def isotropic (d : ℕ) (α : ℝ) : Bip d :=
  α • bellPair d + ((1-α)/(d:ℝ)^2) • (1 : Bip d)

def born (d : ℕ) (ρ : Bip d) (A B : Mat d) : ℝ := ((A ⊗ₖ B) * ρ).trace.re

theorem bell_expect (d : ℕ) (A B : Mat d) :
    ((A ⊗ₖ B) * bellPair d).trace = (A*Bᵀ).trace * (d:ℂ)⁻¹ := by
  simp only [Matrix.trace,Matrix.diag,Matrix.mul_apply,Fintype.sum_prod_type,
    kronecker_apply,bellPair,Matrix.transpose_apply, Finset.sum_mul]
  simp [ite_and,mul_ite]

theorem born_joint (d : ℕ) (α : ℝ) (A B : Mat d)
    (ha : A.IsHermitian) (hb : B.IsHermitian) :
    born d (isotropic d α) A B = joint d α A B := by
  have ta : (A.trace.re:ℂ) = A.trace := by
    rw [Complex.re_eq_add_conj]
    have e : star A.trace=A.trace := by rw [← Matrix.trace_conjTranspose,ha.eq]
    change (A.trace + star A.trace)/2=A.trace
    rw [e]; ring
  have tb : (B.trace.re:ℂ) = B.trace := by
    rw [Complex.re_eq_add_conj]
    have e : star B.trace=B.trace := by rw [← Matrix.trace_conjTranspose,hb.eq]
    change (B.trace + star B.trace)/2=B.trace
    rw [e]; ring
  simp only [born,isotropic,Matrix.mul_add,Matrix.mul_smul,Matrix.mul_one,trace_add,
    trace_smul, bell_expect,trace_kronecker,Complex.add_re,Complex.real_smul,
    Complex.re_ofReal_mul,joint,overlap,tr]
  rw [← ta,← tb]
  simp only [← Complex.ofReal_natCast, ← Complex.ofReal_inv,Complex.mul_re,Complex.ofReal_im,mul_zero,sub_zero,
    ← Complex.ofReal_mul,Complex.ofReal_re,div_eq_mul_inv]
  ring

theorem joint_one_right (d : ℕ) (hd : 0<d) (α : ℝ) (A : Mat d) :
    joint d α A 1 = marginal d A := by
  have h : (d:ℝ)≠0 := by exact_mod_cast (Nat.ne_of_gt hd)
  simp [joint,overlap,tr,marginal,Matrix.trace_one]
  field_simp
  ring

theorem joint_one_left (d : ℕ) (hd : 0<d) (α : ℝ) (B : Mat d) :
    joint d α 1 B = marginal d B := by
  have h : (d:ℝ)≠0 := by exact_mod_cast (Nat.ne_of_gt hd)
  simp [joint,overlap,tr,marginal,Matrix.trace_one]
  field_simp
  ring

theorem bell_positive (d : ℕ) : (bellPair d).PosSemidef := by
  let v : Fin d × Fin d → ℂ := fun u => if u.1=u.2 then 1 else 0
  have e : bellPair d = (d:ℝ)⁻¹ • vecMulVec v (star v) := by
    ext u w
    by_cases a : u.1=u.2 <;> by_cases b : w.1=w.2 <;>
      simp [bellPair,v,a,b,vecMulVec,Complex.real_smul]
  rw [e]
  exact (posSemidef_vecMulVec_self_star v).smul (by positivity)

theorem isotropic_positive (d : ℕ) (α : ℝ) (ha : 0 ≤ α) (hb : α ≤ 1) :
    (isotropic d α).PosSemidef :=
  ((bell_positive d).smul ha).add (PosSemidef.one.smul
    (div_nonneg (sub_nonneg.mpr hb) (sq_nonneg (d:ℝ))))

theorem isotropic_trace (d : ℕ) (hd : 0<d) (α : ℝ) : (isotropic d α).trace=1 := by
  have hn : (d:ℂ)≠0 := by exact_mod_cast (Nat.ne_of_gt hd)
  have e : (bellPair d).trace=1 := by
    simpa [Matrix.trace_one,hn] using bell_expect d 1 1
  simp [isotropic,trace_smul,e,Complex.real_smul,Matrix.trace_one,Fintype.card_prod]
  field_simp
  ring

#print axioms born_joint
#print axioms isotropic_positive
#print axioms isotropic_trace
end
end IsoBell
