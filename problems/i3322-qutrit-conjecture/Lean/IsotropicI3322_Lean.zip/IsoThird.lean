import IsoWitness
namespace IsoWitness
open IsoBell Matrix
open scoped Matrix BigOperators
noncomputable section

/-- A two-dimensional projector on modes 0 and 2, with singleton value q. -/
def corner (x z q : ℝ) : Mat 3 :=
  !![((1+x)/2 : ℝ),0,(z/2 : ℝ); 0,(q:ℂ),0; (z/2 : ℝ),0,((1-x)/2 : ℝ)]

theorem corner_proj (x z q : ℝ) (h : x^2+z^2=1) (hq : q*q=q) :
    Projector (corner x z q) := by
  have hc : (x:ℂ)^2+(z:ℂ)^2=1 := by exact_mod_cast h
  have hqc : (q:ℂ)*(q:ℂ)=q := by exact_mod_cast hq
  constructor
  · ext i j; fin_cases i <;> fin_cases j <;> simp [corner, Matrix.conjTranspose_apply]
  · ext i j; fin_cases i <;> fin_cases j <;>
      simp [corner,Matrix.mul_apply,Fin.sum_univ_three,hqc] <;>
      first | linear_combination hc/4 | exact_mod_cast hq | ring

lemma tr_corner (x z q : ℝ) : tr (corner x z q)=1+q := by
  simp [tr,Matrix.trace,Fin.sum_univ_three,corner]; ring

lemma cc (x z q y w v : ℝ) :
    overlap (corner x z q) (corner y w v)=(1+x*y+z*w)/2+q*v := by
  rw [overlap,tr,Matrix.trace,Fin.sum_univ_three]
  simp only [Matrix.diag_apply,Matrix.mul_apply,Fin.sum_univ_three,Matrix.transpose_apply]
  simp [corner,Complex.mul_re]; ring

lemma cp (x z q y w : ℝ) :
    overlap (corner x z q) (plane y w)=(1+x)*(1+y)/4+q*(1-y)/2 := by
  rw [overlap,tr,Matrix.trace,Fin.sum_univ_three]
  simp only [Matrix.diag_apply,Matrix.mul_apply,Fin.sum_univ_three,Matrix.transpose_apply]
  simp [corner,plane,Complex.mul_re]; ring

def a3 (x z : ℝ) : Triple 3 := ![corner x z 0,corner x (-z) 1,plane 0 1]
def b3 (y w : ℝ) : Triple 3 := ![plane y w,plane y (-w),corner 0 1 0]

theorem a3_proj (x z : ℝ) (hx : x^2+z^2=1) (i : Fin 3) : Projector (a3 x z i) := by
  fin_cases i
  · exact corner_proj _ _ _ hx (by norm_num)
  · exact corner_proj _ _ _ (by simpa using hx) (by norm_num)
  · exact plane_proj _ _ (by norm_num)

theorem b3_proj (y w : ℝ) (hy : y^2+w^2=1) (i : Fin 3) : Projector (b3 y w i) := by
  fin_cases i
  · exact plane_proj _ _ hy
  · exact plane_proj _ _ (by simpa using hy)
  · exact corner_proj _ _ _ (by norm_num) (by norm_num)

theorem third_attained (α x y z w : ℝ) : score 3 α (a3 x z) (b3 y w) =
    α*(-2+x+x*y+z+w)/3 - 7*(1-α)/9 := by
  rw [score_explicit]
  simp [a3,b3,joint,marginal,tr_plane,tr_corner,overlap_plane,cp,cc]
  ring

#print axioms third_attained
end
end IsoWitness
