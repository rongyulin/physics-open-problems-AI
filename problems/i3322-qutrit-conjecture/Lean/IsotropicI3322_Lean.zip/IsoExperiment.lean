import IsoBorn
import IsoThird

/-! The observed score starts with a bipartite 9 by 9 density matrix,
product effects for each joint event, and a one-sided identity for a marginal. -/
namespace IsoExperiment
open IsoBell
open scoped ComplexOrder
noncomputable section

def observed (ρ : Bip 3) (A B : Triple 3) : ℝ :=
  (∑ i, ∑ j, coeff i j * born 3 ρ (A i) (B j)) +
  (∑ i, aliceCoeff i * born 3 ρ (A i) 1) +
   ∑ j, bobCoeff j * born 3 ρ 1 (B j)

def values (α : ℝ) : Set ℝ :=
  {s | ∃ A B : Triple 3, (∀ i, Effect (A i)) ∧ (∀ i, Effect (B i)) ∧
    observed (isotropic 3 α) A B = s}

theorem observed_eq (α : ℝ) (A B : Triple 3) (ha : ∀ i, Effect (A i))
    (hb : ∀ i, Effect (B i)) : observed (isotropic 3 α) A B = score 3 α A B := by
  have joint' (i j : Fin 3) := born_joint 3 α (A i) (B j) (ha i).1.isHermitian (hb j).1.isHermitian
  have left (i : Fin 3) : born 3 (isotropic 3 α) (A i) 1 = marginal 3 (A i) :=
    (born_joint 3 α (A i) 1 (ha i).1.isHermitian Matrix.isHermitian_one).trans
      (joint_one_right 3 (by decide) α (A i))
  have right (j : Fin 3) : born 3 (isotropic 3 α) 1 (B j) = marginal 3 (B j) :=
    (born_joint 3 α 1 (B j) Matrix.isHermitian_one (hb j).1.isHermitian).trans
      (joint_one_left 3 (by decide) α (B j))
  simp only [observed,score,joint',left,right]

theorem from_projectors (α : ℝ) (A B : Triple 3) (hA : ∀ i, Projector (A i))
    (hB : ∀ i, Projector (B i)) : score 3 α A B ∈ values α := by
  let ha := fun i => IsoWitness.projective_effect (hA i)
  let hb := fun i => IsoWitness.projective_effect (hB i)
  exact ⟨A,B,ha,hb,observed_eq α A B ha hb⟩

theorem zero_attained (α : ℝ) : 0 ∈ values α := by
  let Z : Triple 3 := fun _ => 0
  have hZ (i : Fin 3) : Projector (Z i) := ⟨Matrix.isHermitian_zero,by simp [Z]⟩
  have hz := from_projectors α Z Z hZ hZ
  simpa [score_explicit,joint,marginal,overlap,tr,Z] using hz

#print axioms observed_eq
end
end IsoExperiment
