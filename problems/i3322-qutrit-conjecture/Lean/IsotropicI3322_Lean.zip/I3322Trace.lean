import I3322Spectrum
import Mathlib.Analysis.Convex.Birkhoff
import Mathlib.Algebra.Order.Rearrangement
import Mathlib.LinearAlgebra.Matrix.Permutation

/-! The trace rearrangement inequality for Hermitian matrices. -/
namespace I3322Trace
open Matrix IsoBell
open scoped Matrix BigOperators ComplexConjugate
noncomputable section
variable {d : ℕ}

private def mixing (W : unitaryGroup (Fin d) ℂ) : Matrix (Fin d) (Fin d) ℝ :=
  fun i j => Complex.normSq (W.val i j)

private theorem mixing_stochastic (W : unitaryGroup (Fin d) ℂ) :
    mixing W ∈ doublyStochastic ℝ (Fin d) := by
  refine mem_doublyStochastic_iff_sum.mpr ⟨fun i j => Complex.normSq_nonneg _,?_,?_⟩
  · intro i
    have e := congrArg (fun H : Mat d => (H i i).re) (show W.val*W.valᴴ=1 from W.property.2)
    simpa [mixing,Matrix.mul_apply,Matrix.conjTranspose_apply,Complex.star_def,Complex.mul_conj] using e
  · intro j
    have e := congrArg (fun H : Mat d => (H j j).re) (show W.valᴴ*W.val=1 from W.property.1)
    simpa [mixing,Matrix.mul_apply,Matrix.conjTranspose_apply,Complex.star_def,
      ← Complex.normSq_eq_conj_mul_self] using e

private theorem trace_mixing (H K : Mat d) (a b : Fin d → ℝ)
    (hA : Spectrum H a) (hB : Spectrum K b) : ∃ W : unitaryGroup (Fin d) ℂ,
    (H*K).trace.re = a ⬝ᵥ (mixing W *ᵥ b) := by
  obtain ⟨U,hU⟩ := hA
  obtain ⟨V,hV⟩ := hB
  let W : unitaryGroup (Fin d) ℂ := star U * V
  let D (a : Fin d → ℝ) : Mat d := Matrix.diagonal (fun i => (a i:ℂ))
  have w : W.val=U.valᴴ*V.val := rfl
  have e : (H*K).trace = (D a * W.val * D b * W.valᴴ).trace := by
    rw [hU,hV]
    simp only [Matrix.mul_assoc]
    rw [Matrix.trace_mul_comm U.val]
    simp only [D,w,Matrix.conjTranspose_mul,Matrix.conjTranspose_conjTranspose,Matrix.mul_assoc]
  refine ⟨W,?_⟩
  rw [e]
  have scalar (i j : Fin d) : (((a i:ℂ)*W.val i j*(b j:ℂ))*star (W.val i j)).re =
      a i*(Complex.normSq (W.val i j)*b j) := by
    have eq : ((a i:ℂ)*W.val i j*(b j:ℂ))*star (W.val i j) =
        (a i:ℂ)*(W.val i j * conj (W.val i j))*(b j:ℂ) := by rw [Complex.star_def]; ring
    rw [eq,Complex.mul_conj]; norm_cast; ring
  simp only [Matrix.trace,Matrix.diag_apply,Complex.re_sum,dotProduct,Matrix.mulVec,
    D,Matrix.mul_apply (M := diagonal (fun i =>(a i:ℂ))*W.val*diagonal (fun i=>(b i:ℂ))) (N := W.valᴴ), Matrix.mul_diagonal,Matrix.diagonal_mul,
    Matrix.conjTranspose_apply,scalar,mixing,Finset.mul_sum]

/-- Bound against all rearrangements of arbitrary (possibly unsorted) real spectral lists. -/
theorem trace_le_of_permutations (H K : Mat d) (a b : Fin d → ℝ) (hA : Spectrum H a)
    (hB : Spectrum K b) (t : ℝ) (h : ∀ σ : Equiv.Perm (Fin d), (∑ i, a i*b (σ i)) ≤ t) :
    (H*K).trace.re ≤ t := by
  classical
  obtain ⟨W,e⟩ := trace_mixing H K a b hA hB
  obtain ⟨w,hn,hs,hm⟩ := exists_eq_sum_perm_of_mem_doublyStochastic (mixing_stochastic W)
  rw [e,← hm,Matrix.sum_mulVec,dotProduct_sum]
  simp only [Matrix.smul_mulVec,Matrix.permMatrix_mulVec,dotProduct_smul,smul_eq_mul]
  calc
    _ ≤ ∑ σ,w σ*t := Finset.sum_le_sum (fun σ _ => mul_le_mul_of_nonneg_left (h σ) (hn σ))
    _ = _ := by rw [← Finset.sum_mul,hs,one_mul]

/-- Hermitian von Neumann trace inequality, with eigenvalues sorted in decreasing order. -/
theorem trace_rearrange (H K : Mat d) (a b : Fin d → ℝ) (hA : Spectrum H a)
    (hB : Spectrum K b) (oa : Antitone a) (ob : Antitone b) :
    (H*K).trace.re ≤ ∑ i,a i*b i :=
  trace_le_of_permutations H K a b hA hB _ (fun _ => (oa.monovary ob).sum_mul_comp_perm_le_sum_mul)

theorem trace_rearrange_max (H K : Mat d) (a b : Fin d → ℝ) (hA : Spectrum H a)
    (hB : Spectrum K b) : ∃ σ : Equiv.Perm (Fin d), (H*K).trace.re ≤ ∑ i,a i*b (σ i) := by
  classical
  obtain ⟨σ,_,h⟩ := Finset.exists_max_image (Finset.univ : Finset (Equiv.Perm (Fin d)))
    (fun p => ∑ i,a i*b (p i)) Finset.univ_nonempty
  exact ⟨σ,trace_le_of_permutations H K a b hA hB _ (fun p => h p (Finset.mem_univ _))⟩

#print axioms trace_rearrange
end
end I3322Trace
