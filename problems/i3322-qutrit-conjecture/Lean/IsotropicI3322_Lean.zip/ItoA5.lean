import IsoEffects
namespace ItoA5
open IsoBell Matrix
open scoped Matrix BigOperators
noncomputable section
@[simp] private theorem v32 {T : Type*} (x : T) (v : Fin 2 → T) :
    Matrix.vecCons x v (2 : Fin 3) = v 1 := rfl
@[simp] private theorem v42 {T : Type*} (x : T) (v : Fin 3 → T) :
    Matrix.vecCons x v (2 : Fin 4) = v 1 := rfl
@[simp] private theorem v43 {T : Type*} (x : T) (v : Fin 3 → T) :
    Matrix.vecCons x v (3 : Fin 4) = v 2 := rfl

/-- The A5 coefficient table from Ito–Imai–Avis, arXiv:quant-ph/0508210,
Table I and the accompanying displayed inequality. Rows index Bob. -/
def c : Matrix (Fin 4) (Fin 4) ℝ := !![1,1,1,0; 1,-1,0,1; -1,1,1,1; 0,-1,1,0]
def score (α : ℝ) (A B : Fin 4 → Mat 3) : ℝ :=
  (∑ j, ∑ i, c j i * joint 3 α (A i) (B j)) - marginal 3 (A 2) -
    marginal 3 (A 3) - 2*marginal 3 (B 0) - marginal 3 (B 1) - marginal 3 (B 2)

private def A0 : Mat 3 := !![1, 0, 0; 0, 1, 0; 0, 0, 0]

private def A1 : Mat 3 := !![1/2, 0, 1/2; 0, 0, 0; 1/2, 0, 1/2]

private def A2 : Mat 3 := !![5/6, -1/3, -1/6; -1/3, 1/3, -1/3; -1/6, -1/3, 5/6]

private def A3 : Mat 3 := !![1/19, -3/19, 3/19; -3/19, 9/19, -9/19; 3/19, -9/19, 9/19]

def A : Fin 4 → Mat 3 := ![A0,A1,A2,A3]

private def B0 : Mat 3 := !![9/11, -3/11, 3/11; -3/11, 1/11, -1/11; 3/11, -1/11, 1/11]

private def B1 : Mat 3 := !![0, 0, 0; 0, 9/10, -3/10; 0, -3/10, 1/10]

private def B2 : Mat 3 := !![1/11, -1/11, 3/11; -1/11, 1/11, -3/11; 3/11, -3/11, 9/11]

private def B3 : Mat 3 := !![13/22, -3/11, -9/22; -3/11, 9/11, -3/11; -9/22, -3/11, 13/22]

def B : Fin 4 → Mat 3 := ![B0,B1,B2,B3]

set_option maxHeartbeats 5000000 in
theorem projections : (∀ i,Projector (A i)) ∧ (∀ j,Projector (B j)) := by
  constructor <;> intro k <;> fin_cases k <;> constructor
  all_goals
    apply Matrix.ext; intro i j; fin_cases i <;> fin_cases j <;>
      norm_num [A,B,A0,A1,A2,A3,B0,B1,B2,B3,Matrix.mul_apply,Fin.sum_univ_three,
        Matrix.conjTranspose_apply]

private theorem j00 : joint 3 (19/25) (A 0) (B 0) = 78/275 := by
  norm_num [A,B,A0,B0,joint,overlap,tr,Matrix.trace,Matrix.diag,Matrix.mul_apply,
    Matrix.transpose_apply,Fin.sum_univ_three,Complex.add_re,Complex.mul_re,Complex.div_re]
private theorem j01 : joint 3 (19/25) (A 1) (B 0) = 58/275 := by
  norm_num [A,B,A1,B0,joint,overlap,tr,Matrix.trace,Matrix.diag,Matrix.mul_apply,
    Matrix.transpose_apply,Fin.sum_univ_three,Complex.add_re,Complex.mul_re,Complex.div_re]
private theorem j02 : joint 3 (19/25) (A 2) (B 0) = 721/2475 := by
  norm_num [A,B,A2,B0,joint,overlap,tr,Matrix.trace,Matrix.diag,Matrix.mul_apply,
    Matrix.transpose_apply,Fin.sum_univ_three,Complex.add_re,Complex.mul_re,Complex.div_re]
private theorem j03 : joint 3 (19/25) (A 3) (B 0) = 103/825 := by
  norm_num [A,B,A3,B0,joint,overlap,tr,Matrix.trace,Matrix.diag,Matrix.mul_apply,
    Matrix.transpose_apply,Fin.sum_univ_three,Complex.add_re,Complex.mul_re,Complex.div_re]
private theorem j10 : joint 3 (19/25) (A 0) (B 1) = 211/750 := by
  norm_num [A,B,A0,B1,joint,overlap,tr,Matrix.trace,Matrix.diag,Matrix.mul_apply,
    Matrix.transpose_apply,Fin.sum_univ_three,Complex.add_re,Complex.mul_re,Complex.div_re]
private theorem j11 : joint 3 (19/25) (A 1) (B 1) = 59/1500 := by
  norm_num [A,B,A1,B1,joint,overlap,tr,Matrix.trace,Matrix.diag,Matrix.mul_apply,
    Matrix.transpose_apply,Fin.sum_univ_three,Complex.add_re,Complex.mul_re,Complex.div_re]
private theorem j12 : joint 3 (19/25) (A 2) (B 1) = 181/900 := by
  norm_num [A,B,A2,B1,joint,overlap,tr,Matrix.trace,Matrix.diag,Matrix.mul_apply,
    Matrix.transpose_apply,Fin.sum_univ_three,Complex.add_re,Complex.mul_re,Complex.div_re]
private theorem j13 : joint 3 (19/25) (A 3) (B 1) = 82/375 := by
  norm_num [A,B,A3,B1,joint,overlap,tr,Matrix.trace,Matrix.diag,Matrix.mul_apply,
    Matrix.transpose_apply,Fin.sum_univ_three,Complex.add_re,Complex.mul_re,Complex.div_re]
private theorem j20 : joint 3 (19/25) (A 0) (B 2) = 82/825 := by
  norm_num [A,B,A0,B2,joint,overlap,tr,Matrix.trace,Matrix.diag,Matrix.mul_apply,
    Matrix.transpose_apply,Fin.sum_univ_three,Complex.add_re,Complex.mul_re,Complex.div_re]
private theorem j21 : joint 3 (19/25) (A 1) (B 2) = 58/275 := by
  norm_num [A,B,A1,B2,joint,overlap,tr,Matrix.trace,Matrix.diag,Matrix.mul_apply,
    Matrix.transpose_apply,Fin.sum_univ_three,Complex.add_re,Complex.mul_re,Complex.div_re]
private theorem j22 : joint 3 (19/25) (A 2) (B 2) = 721/2475 := by
  norm_num [A,B,A2,B2,joint,overlap,tr,Matrix.trace,Matrix.diag,Matrix.mul_apply,
    Matrix.transpose_apply,Fin.sum_univ_three,Complex.add_re,Complex.mul_re,Complex.div_re]
private theorem j23 : joint 3 (19/25) (A 3) (B 2) = 191/825 := by
  norm_num [A,B,A3,B2,joint,overlap,tr,Matrix.trace,Matrix.diag,Matrix.mul_apply,
    Matrix.transpose_apply,Fin.sum_univ_three,Complex.add_re,Complex.mul_re,Complex.div_re]
private theorem j30 : joint 3 (19/25) (A 0) (B 3) = 51/110 := by
  norm_num [A,B,A0,B3,joint,overlap,tr,Matrix.trace,Matrix.diag,Matrix.mul_apply,
    Matrix.transpose_apply,Fin.sum_univ_three,Complex.add_re,Complex.mul_re,Complex.div_re]
private theorem j31 : joint 3 (19/25) (A 1) (B 3) = 82/825 := by
  norm_num [A,B,A1,B3,joint,overlap,tr,Matrix.trace,Matrix.diag,Matrix.mul_apply,
    Matrix.transpose_apply,Fin.sum_univ_three,Complex.add_re,Complex.mul_re,Complex.div_re]
private theorem j32 : joint 3 (19/25) (A 2) (B 3) = 1366/2475 := by
  norm_num [A,B,A2,B3,joint,overlap,tr,Matrix.trace,Matrix.diag,Matrix.mul_apply,
    Matrix.transpose_apply,Fin.sum_univ_three,Complex.add_re,Complex.mul_re,Complex.div_re]
private theorem j33 : joint 3 (19/25) (A 3) (B 3) = 47/165 := by
  norm_num [A,B,A3,B3,joint,overlap,tr,Matrix.trace,Matrix.diag,Matrix.mul_apply,
    Matrix.transpose_apply,Fin.sum_univ_three,Complex.add_re,Complex.mul_re,Complex.div_re]

/-- The four-by-four A5 experiment violates its local bound at visibility 19/25. -/
theorem score_exact : score (19/25) A B = 1/16500 := by
  unfold score
  simp only [Fin.sum_univ_four, j00, j01, j02, j03, j10, j11, j12, j13, j20, j21, j22, j23, j30, j31, j32, j33]
  norm_num [c,marginal,A,B,A0,A1,A2,A3,B0,B1,B2,B3,tr,Matrix.trace,Matrix.diag,
    Fin.sum_univ_three,Complex.add_re,Complex.div_re]

theorem thresholds : (19/25 : ℝ) < 4/(1+3*Real.sqrt 2) := by
  have hs := Real.sq_sqrt (by norm_num : 0≤(2:ℝ))
  apply (lt_div_iff₀ (by positivity)).mpr
  nlinarith [Real.sqrt_nonneg 2]

theorem effects : (∀ i, Effect (A i)) ∧ (∀ j, Effect (B j)) :=
  ⟨fun i => projector_effect (projections.1 i), fun j => projector_effect (projections.2 j)⟩

def cZ : Matrix (Fin 4) (Fin 4) ℤ := !![1,1,1,0; 1,-1,0,1; -1,1,1,1; 0,-1,1,0]
def bit (s : Fin 4 → Bool) (i : Fin 4) : ℤ := if s i then 1 else 0
def localScore (a b : Fin 4 → Bool) : ℤ :=
  (∑ j, ∑ i, cZ j i * bit a i * bit b j) - bit a 2 -
    bit a 3 - 2*bit b 0 - bit b 1 - bit b 2

theorem same_table (i j : Fin 4) : (cZ i j : ℝ)=c i j := by
  fin_cases i <;> fin_cases j <;> norm_num [cZ,c,Matrix.cons_val]

set_option maxRecDepth 10000 in
set_option maxHeartbeats 5000000 in
theorem local_bound : ∀ a b : Fin 4 → Bool, localScore a b ≤ 0 := by decide

#print axioms local_bound
#print axioms effects
#print axioms projections
#print axioms score_exact
#print axioms thresholds
end
end ItoA5
