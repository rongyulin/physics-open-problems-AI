import I3322ScalarDefs
import Mathlib.Tactic
namespace IsoScalar
open scoped BigOperators
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000

/-- Coefficients ordered as 1, x, y, xy, z, w, and the white-noise score. -/
structure Poly where
  c : ℤ
  x : ℤ
  y : ℤ
  xy : ℤ
  z : ℤ
  w : ℤ
  noise : ℤ
deriving DecidableEq

def Poly.val (p : Poly) (x y z w : ℝ) : ℝ :=
  p.c + p.x*x + p.y*y + p.xy*x*y + p.z*z + p.w*w

private def dot (a b : Fin 3 → ℤ) : ℤ := a 0*b 0 + a 1*b 1 + a 2*b 2
private def mi (r : Fin 4) (i : Fin 3) : ℤ := if i.val < r.val then 1 else 0

def rankPoly (r s u v j k : Fin 4) : Poly :=
  let m : ℤ := r.val+2*(u.val:ℤ)+v.val
  ⟨dot (sumBase r s) (sumBase u v) + dot (mi k) (diffBase r s) + dot (mi j) (diffBase u v) - m,
    dot (sumSlope r s) (sumBase u v), dot (sumBase r s) (sumSlope u v),
    dot (sumSlope r s) (sumSlope u v), dot (mi k) (diffSlope r s), dot (mi j) (diffSlope u v),
    ((r.val:ℤ)+s.val)*(u.val+v.val) + (r.val-(s.val:ℤ))*k.val + j.val*(u.val-(v.val:ℤ)) - 3*m⟩

theorem pure_val (r s u v j k : Fin 4) (x y z w : ℝ) :
    pure r s u v j k x y z w = (rankPoly r s u v j k).val x y z w := by
  have hm (q : Fin 4) (i : Fin 3) : ((mi q i : ℤ) : ℝ) = mask q i := by
    dsimp [mi,mask]; split_ifs <;> norm_num
  simp only [pure, sumSpec, diffSpec, Fin.sum_univ_three, Poly.val, rankPoly,dot]
  push_cast
  simp only [hm]
  ring

theorem white_val (r s u v j k : Fin 4) :
    white r s u v j k = ((rankPoly r s u v j k).noise:ℝ) := by
  simp [white,rankPoly]

def patterns : Fin 6 → Poly :=
  ![⟨0,0,0,0,0,0,0⟩, ⟨-1,1,0,0,1,0,-4⟩, ⟨-1,0,1,0,0,1,-4⟩,
    ⟨-2,1,0,1,1,1,-7⟩, ⟨-2,0,1,1,1,1,-7⟩, ⟨-2,1,1,-1,1,1,-7⟩]

/-- Upper bound on the difference at an xy corner, maximizing over z,w independently. -/
def corner (p q : Poly) (x y : ℤ) : ℤ := p.c-q.c+(p.x-q.x)*x+(p.y-q.y)*y+
 (p.xy-q.xy)*x*y+max 0 (p.z-q.z)+max 0 (p.w-q.w)

def covers (p q : Poly) : Bool := decide (p.noise ≤ q.noise ∧ corner p q 0 0 ≤ 0 ∧
  corner p q 0 1 ≤ 0 ∧ corner p q 1 0 ≤ 0 ∧ corner p q 1 1 ≤ 0)

/-- A kernel-reduced finite certificate for the six-tuples of projection ranks. -/
def tableOK (r s : Fin 4) : Bool :=
  (List.finRange 4).all fun u => (List.finRange 4).all fun v =>
    (List.finRange 4).all fun j => (List.finRange 4).all fun k =>
      (List.finRange 6).any fun l => covers (rankPoly r s u v j k) (patterns l)


end IsoScalar
