import I3322ScalarPoly
namespace IsoScalar
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000

theorem checked_30 : tableOK 3 0 = true := by rfl
theorem checked_31 : tableOK 3 1 = true := by rfl
theorem checked_32 : tableOK 3 2 = true := by rfl
theorem checked_33 : tableOK 3 3 = true := by rfl

end IsoScalar
