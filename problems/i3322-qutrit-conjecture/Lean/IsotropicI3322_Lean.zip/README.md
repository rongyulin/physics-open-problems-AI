# Exact I3322 violation for isotropic qutrit pairs

Ito, Imai and Avis asked whether I3322 ever detects nonlocality below the CHSH visibility threshold for a maximally entangled qutrit pair mixed with white noise. The public entry point `IsotropicI3322.lean` proves their Conjecture 1. Its theorem `violation_iff` says that some three-setting binary measurement violates I3322 exactly when the visibility exceeds **4/(1+3√2)**. The theorem `maximum` gives the entire curve, including measurements attaining it. [Ito, Imai and Avis, *Bell inequalities stronger than the CHSH inequality for 3-level isotropic states*, Conjecture 1](https://arxiv.org/abs/quant-ph/0508210).

For visibility α between 0 and 1, the maximum is the largest of

- 0,
- `((1+3√2)α−4)/9`,
- `(3αH−7(1−α))/9`.

Here `H = √[(1+y)²+1] + √(1−y²) − 2`, where y is the quartic root in [16/25,33/50] satisfying `(1+y)²(1−2y²)=y²`. The upper-envelope formula and its two transition points are in `IsoPhases.lean`.

## Physical and mathematical scope

| Modules | Theorem scope |
| --- | --- |
| `IsoBell`, `IsoBorn`, `IsoExperiment` | The input is the explicit 9×9 isotropic density matrix. It is positive and has trace one. Its joint and marginal probabilities are computed by the Born rule. |
| `IsoEffects`, `IsoReduction`, `IsoRank` | Each party may choose three arbitrary binary POVMs on the local qutrit. Increasing the Bell score by replacing all six effects with projections preserves local dimension. The trace of any orthogonal projection equals its rank. |
| `IsoProjection`, `I3322Spectrum`, `I3322Trace`, `IsoMatrixBound` | The ordered spectra of projection sums and differences and a trace inequality bound the physical Bell score by a function of the six ranks and two angular parameters. |
| `I3322Scalar`, `IsoOpt`, `IsoPhases`, `IsoWitness`, `IsoThird` | The finite rank reduction, continuous optimization and three measurement strategies give the attained envelope. |
| `ItoA5`, `IsoSeparation` | At α = 19/25 every three-setting I3322 score is at most zero. Eight rational projectors attain the four-setting A5 score 1/16500. Its deterministic local bound is checked for all 256 response pairs. |

The independent integer computation in `check_rank_cases.py` enumerates 4,096 rank tuples, 202 distinct polynomials, six maximal patterns and all 16 corners of their comparison domain. The Lean proof checks the rank reduction separately.

The [prior-art review](PRIORITY.md) compares the exact result with the original conjecture, subsequent publications and publicly indexed proof repositories.

## Reproduction

Use Lean 4.28.0 with mathlib at revision `8f9d9cff6bd728b17a24e163c9402775d9e6a365`. The included Lake manifest pins dependencies. From the directory containing `lakefile.toml`, run

```sh
lake exe cache get
sh audit.sh
python3 check_rank_cases.py
python3 check_a5.py
```

The audit script builds the project, then runs `leanchecker` separately on every module. The release archive includes the build log, source hashes and replay summary in `evidence/`.
