import Mathlib.LinearAlgebra.Matrix.Notation
import Mathlib.Data.Real.Sqrt
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Linarith

/-! Ordered spectra of two qutrit projections. Each entry is an affine function
of the relevant Jordan-block parameter. The ranks are 0, 1, 2 or 3. -/
namespace IsoScalar
open scoped BigOperators Matrix

def mask (r : Fin 4) (i : Fin 3) : ℝ := if i.val < r.val then 1 else 0

def sumBase : Fin 4 → Fin 4 → Fin 3 → ℤ :=
  ![![![0, 0, 0], ![1, 0, 0], ![1, 1, 0], ![1, 1, 1]],
    ![![1, 0, 0], ![1, 1, 0], ![1, 1, 1], ![2, 1, 1]],
    ![![1, 1, 0], ![1, 1, 1], ![2, 1, 1], ![2, 2, 1]],
    ![![1, 1, 1], ![2, 1, 1], ![2, 2, 1], ![2, 2, 2]]]

def sumSlope : Fin 4 → Fin 4 → Fin 3 → ℤ :=
  ![![![0, 0, 0], ![0, 0, 0], ![0, 0, 0], ![0, 0, 0]],
    ![![0, 0, 0], ![1, -1, 0], ![1, 0, -1], ![0, 0, 0]],
    ![![0, 0, 0], ![1, 0, -1], ![0, 1, -1], ![0, 0, 0]],
    ![![0, 0, 0], ![0, 0, 0], ![0, 0, 0], ![0, 0, 0]]]

def sumSpec (r s : Fin 4) (x : ℝ) (i : Fin 3) : ℝ := (sumBase r s i : ℝ) + (sumSlope r s i : ℝ)*x

def diffBase : Fin 4 → Fin 4 → Fin 3 → ℤ :=
  ![![![0, 0, 0], ![0, 0, -1], ![0, -1, -1], ![-1, -1, -1]],
    ![![1, 0, 0], ![0, 0, 0], ![0, 0, -1], ![0, -1, -1]],
    ![![1, 1, 0], ![1, 0, 0], ![0, 0, 0], ![0, 0, -1]],
    ![![1, 1, 1], ![1, 1, 0], ![1, 0, 0], ![0, 0, 0]]]

def diffSlope : Fin 4 → Fin 4 → Fin 3 → ℤ :=
  ![![![0, 0, 0], ![0, 0, 0], ![0, 0, 0], ![0, 0, 0]],
    ![![0, 0, 0], ![1, 0, -1], ![1, -1, 0], ![0, 0, 0]],
    ![![0, 0, 0], ![0, 1, -1], ![1, 0, -1], ![0, 0, 0]],
    ![![0, 0, 0], ![0, 0, 0], ![0, 0, 0], ![0, 0, 0]]]

def diffSpec (r s : Fin 4) (x : ℝ) (i : Fin 3) : ℝ := (diffBase r s i : ℝ) + (diffSlope r s i : ℝ)*x

def pure (r s u v j k : Fin 4) (x y z w : ℝ) : ℝ :=
  (∑ i, sumSpec r s x i * sumSpec u v y i) +
  (∑ i, mask k i * diffSpec r s z i) + (∑ i, mask j i * diffSpec u v w i) -
  ((r.val:ℝ)+2*u.val+v.val)

def white (r s u v j k : Fin 4) : ℝ :=
  ((r.val:ℝ)+s.val)*(u.val+v.val) + (r.val-(s.val:ℝ))*k.val + j.val*(u.val-(v.val:ℝ)) -
  3*(r.val+2*(u.val:ℝ)+v.val)

end IsoScalar
