import I3322ScalarPoly
namespace IsoScalar
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000

theorem checked_20 : tableOK 2 0 = true := by rfl
theorem checked_21 : tableOK 2 1 = true := by rfl
theorem checked_22 : tableOK 2 2 = true := by rfl
theorem checked_23 : tableOK 2 3 = true := by rfl

end IsoScalar
