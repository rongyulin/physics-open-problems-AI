import IsoBell
import Mathlib.Analysis.Matrix.Spectrum
import Mathlib.LinearAlgebra.Matrix.Trace

/-! Real eigenvalue lists, carried with their unitary diagonalizations. -/
namespace I3322Trace
open Matrix IsoBell
open scoped Matrix BigOperators
noncomputable section
variable {d : ℕ}

def Spectrum (H : Mat d) (a : Fin d → ℝ) : Prop :=
  ∃ U : Matrix.unitaryGroup (Fin d) ℂ, H = U.val * diagonal (fun i => (a i:ℂ)) * U.valᴴ

theorem sorted_spectrum {H : Mat d} (h : H.IsHermitian) :
    ∃ a : Fin d → ℝ, Antitone a ∧ Spectrum H a := by
  classical
  let hs := Matrix.isHermitian_iff_isSymmetric.mp h
  have card : Module.finrank ℂ (EuclideanSpace ℂ (Fin d)) = d := finrank_euclideanSpace_fin
  let b := hs.eigenvectorBasis card
  let a := hs.eigenvalues card
  let U : unitaryGroup (Fin d) ℂ := ⟨(EuclideanSpace.basisFun (Fin d) ℂ).toBasis.toMatrix b.toBasis,
    (EuclideanSpace.basisFun (Fin d) ℂ).toMatrix_orthonormalBasis_mem_unitary b⟩
  have prod : H*U.val = U.val * diagonal (fun i => (a i:ℂ)) := by
    ext i j
    rw [Matrix.mul_diagonal]
    have ev := congrArg (fun v : EuclideanSpace ℂ (Fin d) => v i) (hs.apply_eigenvectorBasis card j)
    change (∑ k, H i k * b j k) = b j i * (a j:ℂ)
    change (∑ k, H i k * b j k) = (a j:ℂ) * b j i at ev
    rw [mul_comm]; exact ev
  refine ⟨a,hs.eigenvalues_antitone card,U,?_⟩
  rw [← prod, Matrix.mul_assoc,show U.val*U.valᴴ=1 from U.property.2,Matrix.mul_one]

theorem Spectrum.trace_eq {H : Mat d} {a : Fin d → ℝ} (hs : Spectrum H a) :
    tr H = ∑ i,a i := by
  obtain ⟨U,h⟩ := hs
  simp only [IsoBell.tr,h,Matrix.trace_mul_cycle,show U.valᴴ*U.val=1 from U.property.1,
    Matrix.one_mul,Matrix.trace_diagonal,Complex.re_sum,Complex.ofReal_re]

private theorem diag_of_eq (U : unitaryGroup (Fin d) ℂ) (H D : Mat d)
    (h : H = U.val*D*U.valᴴ) : U.valᴴ*H*U.val = D := by
  rw [h]
  calc
    _ = (U.valᴴ*U.val)*D*(U.valᴴ*U.val) := by simp only [Matrix.mul_assoc]
    _ = _ := by rw [show U.valᴴ*U.val=1 from U.property.1, Matrix.one_mul,Matrix.mul_one]

theorem projector_spectrum (P : Mat 3) (hP : Projector P) : ∃ r : Fin 4,
    Spectrum P (fun i : Fin 3 => if i.val<r.val then (1:ℝ) else 0) ∧ tr P=(r.val:ℝ) := by
  obtain ⟨a,ha,h⟩ := sorted_spectrum hP.1
  have ht := h.trace_eq
  obtain ⟨U,hu⟩ := h
  let D := diagonal (fun i => (a i:ℂ))
  have hd : U.valᴴ*P*U.val = D := diag_of_eq U P D hu
  have sq : D*D=D := calc
    _ = (U.valᴴ*P*U.val)*(U.valᴴ*P*U.val) := by rw [hd]
    _ = U.valᴴ*P*(U.val*U.valᴴ)*P*U.val := by simp only [Matrix.mul_assoc]
    _ = U.valᴴ*(P*P)*U.val := by rw [show U.val*U.valᴴ=1 from U.property.2,Matrix.mul_one,Matrix.mul_assoc U.valᴴ]
    _ = _ := by rw [hP.2,hd]
  have bits (i : Fin 3) : a i=0 ∨ a i=1 := by
    have z := congrArg (fun M : Mat 3 => (M i i).re) sq
    have f : a i * a i = a i := by
      simpa [D,Matrix.diagonal_mul_diagonal] using z
    exact (mul_eq_zero.mp (show a i*(a i-1)=0 by linarith)).imp id sub_eq_zero.mp
  have h₁ := ha (by decide : (0:Fin 3) ≤ 1)
  have h₂ := ha (by decide : (1:Fin 3) ≤ 2)
  have mk (r : Fin 4) (e : a = fun i:Fin 3 => if i.val<r.val then (1:ℝ) else 0)
      (t : tr P = (r.val:ℝ)) : ∃ r : Fin 4,
      Spectrum P (fun i : Fin 3 => if i.val<r.val then (1:ℝ) else 0) ∧ tr P=(r.val:ℝ) :=
    ⟨r,⟨U,e ▸ hu⟩,t⟩
  rw [Fin.sum_univ_three] at ht
  rcases bits 0 with h0|h0 <;> rcases bits 1 with h1|h1 <;> rcases bits 2 with h2|h2
  all_goals try (exfalso; linarith)
  case inl.inl.inl => apply mk 0 <;> first | (funext i; fin_cases i <;> norm_num [h0,h1,h2] <;> first | exact h0 | exact h1 | exact h2) | (norm_num; linarith)
  case inr.inl.inl => apply mk 1 <;> first | (funext i; fin_cases i <;> norm_num [h0,h1,h2] <;> first | exact h0 | exact h1 | exact h2) | (norm_num; linarith)
  case inr.inr.inl => apply mk 2 <;> first | (funext i; fin_cases i <;> norm_num [h0,h1,h2] <;> first | exact h0 | exact h1 | exact h2) | (norm_num; linarith)
  case inr.inr.inr => apply mk 3 <;> first | (funext i; fin_cases i <;> norm_num [h0,h1,h2] <;> first | exact h0 | exact h1 | exact h2) | (norm_num; linarith)

theorem projector_spectrum_of_trace (P : Mat 3) (hP : Projector P) (r : Fin 4)
    (hr : tr P=(r.val:ℝ)) : Spectrum P (fun i : Fin 3 => if i.val<r.val then (1:ℝ) else 0) := by
  obtain ⟨s,h,htr⟩ := projector_spectrum P hP
  have hv : s.val=r.val := by exact_mod_cast htr.symm.trans hr
  exact Fin.ext hv ▸ h

#print axioms projector_spectrum
end
end I3322Trace
