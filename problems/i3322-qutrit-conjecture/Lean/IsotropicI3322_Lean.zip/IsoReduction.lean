import IsoEffects

namespace IsoBell
open Matrix
open scoped Matrix ComplexOrder BigOperators
noncomputable section
variable {d : ℕ}

private def marginalL : Mat d →ₗ[ℝ] ℝ where
  toFun := marginal d
  map_add' A C := by simp [marginal,tr,add_div]
  map_smul' r A := by simp [marginal,tr,Matrix.trace_smul,Complex.real_smul,mul_div_assoc]

private def jointL (α : ℝ) (B : Mat d) : Mat d →ₗ[ℝ] ℝ where
  toFun A := joint d α A B
  map_add' A C := by simp [joint,overlap,tr,mul_add,add_mul,add_div]; ring
  map_smul' r A := by
    simp [joint,overlap,tr,Matrix.trace_smul,Complex.real_smul]
    ring

private def jointR (α : ℝ) (A : Mat d) : Mat d →ₗ[ℝ] ℝ where
  toFun B := joint d α A B
  map_add' B C := by simp [joint,overlap,tr,mul_add,add_div]; ring
  map_smul' r B := by
    simp [joint,overlap,tr,Matrix.trace_smul,Complex.real_smul]
    ring

/-- For all six binary POVMs there are six projective binary measurements,
on the same two local Hilbert spaces, with at least the original I3322 score. -/
theorem projectivize (d : ℕ) (α : ℝ) (A B : Triple d)
    (ha : ∀ i, Effect (A i)) (hb : ∀ j, Effect (B j)) :
    ∃ P Q : Triple d, (∀ i, Projector (P i)) ∧ (∀ j, Projector (Q j)) ∧
      score d α A B ≤ score d α P Q := by
  let L (i : Fin 3) : Mat d →ₗ[ℝ] ℝ :=
    (∑ j, coeff i j • jointL α (B j)) + aliceCoeff i • marginalL
  choose P hp hle using fun i => maximize_effect (ha i) (L i)
  let R (j : Fin 3) : Mat d →ₗ[ℝ] ℝ :=
    (∑ i, coeff i j • jointR α (P i)) + bobCoeff j • marginalL
  choose Q hq hge using fun j => maximize_effect (hb j) (R j)
  refine ⟨P,Q,hp,hq,?_⟩
  have l := Finset.sum_le_sum (s:=Finset.univ) (fun i _ => hle i)
  have r := Finset.sum_le_sum (s:=Finset.univ) (fun j _ => hge j)
  simp only [L,R, LinearMap.add_apply,LinearMap.sum_apply,LinearMap.smul_apply,
    jointL,jointR,marginalL,LinearMap.coe_mk, AddHom.coe_mk, smul_eq_mul,
    Finset.sum_add_distrib] at l r
  rw [Finset.sum_comm (f := fun j i => coeff i j*joint d α (P i) (B j)),
      Finset.sum_comm (f := fun j i => coeff i j*joint d α (P i) (Q j))] at r
  unfold score
  linarith only [l,r]

#print axioms projectivize
end
end IsoBell
