import I3322ScalarPoly
namespace IsoScalar
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000

theorem checked_00 : tableOK 0 0 = true := by rfl
theorem checked_01 : tableOK 0 1 = true := by rfl
theorem checked_02 : tableOK 0 2 = true := by rfl
theorem checked_03 : tableOK 0 3 = true := by rfl

end IsoScalar
