import Mathlib.Topology.Order.IntermediateValue
import Mathlib.Data.Real.Sqrt
import Mathlib.Tactic

/-! Exact algebraic maximum of the two-angle branch of the I3322 optimization. -/
namespace BellIsoOpt
noncomputable section

def feasible (x y z w : ℝ) : Prop :=
  0 ≤ x ∧ 0 ≤ y ∧ 0 ≤ z ∧ 0 ≤ w ∧ x^2+z^2=1 ∧ y^2+w^2=1

def value (x y z w : ℝ) : ℝ := -2+x+x*y+z+w

def polynomial (y : ℝ) : ℝ := (1+y)^2*(1-2*y^2)-y^2

private theorem root_exists :
    ∃ y : ℝ, y ∈ Set.Icc (16/25:ℝ) (33/50) ∧ polynomial y = 0 := by
  apply intermediate_value_Icc' (show (16/25:ℝ) ≤ 33/50 by norm_num)
    (f:=polynomial) (by unfold polynomial; fun_prop)
  norm_num [polynomial, Set.mem_Icc]

def root : ℝ := Classical.choose root_exists
theorem root_interval : root ∈ Set.Icc (16/25:ℝ) (33/50) :=
  (Classical.choose_spec root_exists).1
theorem root_polynomial : polynomial root = 0 :=
  (Classical.choose_spec root_exists).2

private theorem root_fraction {a : ℝ} (ha : 0 ≤ a) (h : polynomial a=0) :
    (a/(1+a))^2=1-2*a^2 := by
  have hpos : 0 < 1+a := by linarith
  unfold polynomial at h
  field_simp
  linarith only [h]

private theorem no_larger_root {a b : ℝ} (ha : 0≤a) (hab : a<b)
    (h₁ : polynomial a=0) (h₂ : polynomial b=0) : False := by
  have hb : 0≤b := ha.trans hab.le
  have fa := root_fraction ha h₁
  have fb := root_fraction hb h₂
  have hg : a/(1+a)<b/(1+b) := by
    apply (div_lt_div_iff₀ (by linarith) (by linarith)).mpr
    nlinarith only [hab]
  have han : 0≤a/(1+a) := by positivity
  have h₃ : (a/(1+a))^2<(b/(1+b))^2 := by
    nlinarith only [mul_pos (sub_pos.mpr hg) (show 0 < b/(1+b)+a/(1+a) by linarith only [han,hg])]
  nlinarith only [fa,fb,h₃,mul_nonneg (sub_nonneg.mpr hab.le) (show 0≤b+a by linarith)]

theorem root_unique {y : ℝ} (hy : 0 ≤ y) (h : polynomial y=0) : y=root := by
  have hroot : 0 ≤ root := (by norm_num : (0:ℝ) ≤16/25).trans root_interval.1
  rcases lt_trichotomy y root with hl|he|hg
  · exact False.elim (no_larger_root hy hl h root_polynomial)
  · exact he
  · exact False.elim (no_larger_root hroot hg root_polynomial h)

/-- The largest value is an explicitly specified real algebraic number. -/
def H : ℝ := Real.sqrt ((1+root)^2+1) + Real.sqrt (1-root^2) - 2

private def D := Real.sqrt ((1+root)^2+1)
private def W := Real.sqrt (1-root^2)
private def X := (1+root)/D
private def Z := 1/D

private theorem parameters :
    feasible X root Z W ∧ 0 < Z ∧ Z ≤ 1 ∧ 0 < W ∧ W ≤ 1 ∧
      X = (1+root)*Z ∧ root=X*W ∧ value X root Z W=H := by
  have hl := root_interval.1
  have hu := root_interval.2
  have hy : 0<root := by linarith
  have hy' : root<1 := by linarith
  have hd : 0<D := Real.sqrt_pos.mpr (by positivity)
  have hd2 : D^2 = (1+root)^2+1 := Real.sq_sqrt (by positivity)
  have hdiff : 0<1-root^2 := by nlinarith [mul_pos (sub_pos.mpr hy') (show 0<1+root by linarith)]
  have hw : 0<W := Real.sqrt_pos.mpr hdiff
  have hw2 : W^2=1-root^2 := Real.sq_sqrt hdiff.le
  have hz : 0<Z := by dsimp [Z]; positivity
  have hxeq : X=(1+root)*Z := by unfold X Z; ring
  have hxeq' : X^2+Z^2=1 := by unfold X Z; field_simp; nlinarith only [hd2]
  have stat : ((1+root)*W)^2=(root*D)^2 := by
    have hr := root_polynomial
    unfold polynomial at hr
    linear_combination (1+root)^2 * hw2 - root^2 * hd2 + hr
  have stat' : (1+root)*W=root*D := by
    apply (sq_eq_sq₀ (by positivity) (by positivity)).mp stat
  have v : value X root Z W=H := by
    change -2+(1+root)/D+((1+root)/D)*root+1/D+W=D+W-2
    field_simp
    nlinarith only [hd2]
  refine ⟨⟨?_,hy.le,hz.le,hw.le,hxeq',by linarith only [hw2]⟩,hz,?_,hw,?_,hxeq,?_,v⟩
  · dsimp [X]; positivity
  · nlinarith only [hxeq',sq_nonneg X, sq_nonneg (Z-1)]
  · nlinarith only [hw2,sq_nonneg root,sq_nonneg (W-1)]
  · unfold X
    field_simp
    linarith only [stat']

/-- A unit circle's supporting-line deficit dominates half the squared chord
when the positive multiplier connecting the gradient to the radius is at least one. -/
private theorem chord {a b A B g : ℝ} (h : a^2+b^2=1) (h' : A^2+B^2=1)
    (hB : 0<B) (hB' : B≤1) (hA : A=g*B) :
    2*(g*(a-A)+(b-B)) ≤ -((a-A)^2+(b-B)^2) := by
  have hid : 2*(g*(a-A)+(b-B))*B = -((a-A)^2+(b-B)^2) := by
    calc
      _ = 2*(A*(a-A)+B*(b-B)) := by rw [hA]; ring
      _ = _ := by nlinarith only [h,h']
  have neg : 2*(g*(a-A)+(b-B)) ≤ 0 := by
    apply nonpos_of_mul_nonpos_left (b:=B) _ hB
    rw [hid]
    nlinarith only [sq_nonneg (a-A), sq_nonneg (b-B)]
  have hmul := mul_nonpos_of_nonpos_of_nonneg neg (sub_nonneg.mpr hB')
  linarith only [hid,hmul]

theorem upper (x y z w : ℝ) (h : feasible x y z w) : value x y z w ≤ H := by
  obtain ⟨hf,hz,hz1,hw,hw1,hx,hy,hm⟩ := parameters
  obtain ⟨_,_,_,_,h1,h2⟩ := h
  obtain ⟨_,_,_,_,h3,h4⟩ := hf
  have a := chord h1 h3 hz hz1 hx
  have b := chord h2 h4 hw hw1 hy
  rw [←hm]
  unfold value
  nlinarith only [a,b,sq_nonneg ((x-X)-(y-root)),sq_nonneg (z-Z),sq_nonneg (w-W)]

theorem attain : ∃ x y z w, feasible x y z w ∧ value x y z w = H :=
  ⟨X, root, Z, W, parameters.1, parameters.2.2.2.2.2.2.2⟩

theorem maximum : IsGreatest {h | ∃ x y z w, feasible x y z w ∧ h=value x y z w} H := by
  obtain ⟨x,y,z,w,hf,hh⟩ := attain
  refine ⟨⟨x,y,z,w,hf,hh.symm⟩, ?_⟩
  intro a ha
  obtain ⟨x,y,z,w,h,hv⟩ := ha
  rw [hv]
  exact upper x y z w h

theorem half_le : (1:ℝ)/2 ≤ H := by
  have h := upper (4/5) (3/5) (3/5) (4/5) (by norm_num [feasible])
  norm_num [value] at h
  linarith only [h]

theorem le_thirteen : H ≤ 13/18 := by
  have hl := root_interval.1
  have hu := root_interval.2
  have hd : D^2=(1+root)^2+1 := Real.sq_sqrt (by positivity)
  have hw : W^2 = 1-root^2 := Real.sq_sqrt (by
    nlinarith [mul_nonneg (show 0≤1-root by linarith) (show 0≤1+root by linarith)])
  have ha : D ≤ 97/50 := by
    nlinarith [mul_nonneg (sub_nonneg.mpr hu) (show 0≤33/50+root+2 by linarith)]
  have hb : W ≤ 77/100 := by
    nlinarith [mul_nonneg (sub_nonneg.mpr hl) (show 0≤root+16/25 by linarith)]
  change D+W-2 ≤ 13/18
  linarith only [ha,hb]

#print axioms maximum
end
end BellIsoOpt
