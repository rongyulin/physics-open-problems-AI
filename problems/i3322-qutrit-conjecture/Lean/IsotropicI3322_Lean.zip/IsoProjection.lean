import IsoProjectionRays
import IsoProjectionTables
import I3322Spectrum

/-! Simultaneous ordered spectral data for P+Q and P-Q. The diagonalizing
unitaries can differ. Both eigenvalue lists use the same overlap angle. -/
namespace IsoProjection
open IsoBell IsoScalar I3322Trace Matrix
open scoped Matrix BigOperators
noncomputable section

private theorem model_linear (r : Fin 4) (E : Mat 3) :
    model r E = origin r • (1 : Mat 3) + direction r • E := by
  fin_cases r <;> simp [model,origin,direction,sub_eq_add_neg]

private theorem tr_model (r : Fin 4) (u : Vec) (hu : bracket u u=1) :
    tr (model r (ray u)) = (r.val:ℝ) := by
  have he : (ray u).trace = 1 := by
    simpa [ray,Matrix.trace,Matrix.diag,Matrix.vecMulVec,bracket,dotProduct,mul_comm] using hu
  fin_cases r <;> norm_num [tr,model,he,Matrix.trace_sub,Matrix.trace_one,Finset.card_univ]

set_option maxHeartbeats 800000 in
private theorem spectrum_of_det (H : Mat 3) (hH : H.IsHermitian) (a : Fin 3 → ℝ)
    (h : ∀ l : ℂ, (Matrix.scalar (Fin 3) l - H).det = ∏ i, (l-(a i:ℂ))) :
    Spectrum H a := by
  let D : Mat 3 := diagonal (fun i => (a i:ℂ))
  have hd : D.IsHermitian := by
    apply Matrix.isHermitian_diagonal_iff.mpr
    intro i
    change star (a i:ℂ) = _
    simp
  have hc : H.charpoly = D.charpoly := by
    apply Polynomial.funext
    intro l
    rw [Matrix.eval_charpoly, h]
    simp [D,Matrix.charpoly_diagonal,Polynomial.eval_prod]
  have he := (hH.eigenvalues_eq_eigenvalues_iff hd).mpr hc
  let W : unitaryGroup (Fin 3) ℂ := hH.eigenvectorUnitary * star hd.eigenvectorUnitary
  refine ⟨W,?_⟩
  change H = Unitary.conjStarAlgAut ℂ _ W D
  calc
    H = Unitary.conjStarAlgAut ℂ _ hH.eigenvectorUnitary
        (diagonal ((↑) ∘ hH.eigenvalues)) := hH.spectral_theorem
    _ = Unitary.conjStarAlgAut ℂ _ hH.eigenvectorUnitary
        (diagonal ((↑) ∘ hd.eigenvalues)) := by rw [he]
    _ = Unitary.conjStarAlgAut ℂ _ W D := by
      rw [show W=hH.eigenvectorUnitary * star hd.eigenvectorUnitary by rfl,
        Unitary.conjStarAlgAut_mul_apply,hd.conjStarAlgAut_star_eigenvectorUnitary]
      rfl

/-- All projection ranks, including zero and the identity. -/
theorem pair_spectra (P Q : Mat 3) (hP : Projector P) (hQ : Projector Q) :
    ∃ (r s : Fin 4) (x z : ℝ), tr P=(r.val:ℝ) ∧ tr Q=(s.val:ℝ) ∧
      0≤x ∧ 0≤z ∧ x^2+z^2=1 ∧ Spectrum (P+Q) (sumSpec r s x) ∧
      Spectrum (P-Q) (diffSpec r s z) := by
  obtain ⟨r,u,hu,hp⟩ := projector_ray P hP
  obtain ⟨s,v,hv,hq⟩ := projector_ray Q hQ
  obtain ⟨t,w,ht,hw,htw,hc⟩ := overlap_parameters u v hu hv
  refine ⟨r,s,angle r s t w,angle r s w t,hp ▸ tr_model r u hu,hq ▸ tr_model s v hv,?_,?_,?_,?_,?_⟩
  · unfold angle; split <;> assumption
  · unfold angle; split <;> assumption
  · unfold angle; split <;> linarith
  · apply spectrum_of_det _ (hP.1.add hQ.1)
    intro l
    have he : P+Q = (origin r+origin s) • (1:Mat 3) + direction r • ray u + direction s • ray v := by
      rw [hp,hq,model_linear,model_linear,add_smul]
      abel
    rw [he,determinant_formula u v hu hv,← hc]
    exact table_plus r s t w htw l
  · apply spectrum_of_det _ (hP.1.sub hQ.1)
    intro l
    have he : P-Q = (origin r-origin s) • (1:Mat 3) + direction r • ray u + (-direction s) • ray v := by
      rw [hp,hq,model_linear,model_linear,sub_smul,neg_smul]
      abel
    rw [he,determinant_formula u v hu hv,← hc]
    exact table_minus r s t w htw l

#print axioms pair_spectra
end
end IsoProjection
