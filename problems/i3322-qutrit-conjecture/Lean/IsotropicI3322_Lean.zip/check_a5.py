#!/usr/bin/env python3
"""Check the rational A5 witness at visibility 19/25 with exact probabilities."""

from fractions import Fraction
from itertools import product

# Each outcome-one projector is P(v)=vvᵀ/(vᵀv) or, when flagged, I-P(v).
ALICE = ((True, (0, 0, 1)), (False, (1, 0, 1)),
         (True, (1, 2, 1)), (False, (1, -3, 3)))
BOB = ((False, (3, -1, 1)), (False, (0, 3, -1)),
       (False, (1, -1, 3)), (True, (3, 2, 3)))
COEFF = ((1, 1, 1, 0), (1, -1, 0, 1), (-1, 1, 1, 1), (0, -1, 1, 0))


def rank(measurement):
    return 2 if measurement[0] else 1


def dot(u, v):
    return sum(x*y for x, y in zip(u, v))


def trace_product(a, b):
    ca, u = a
    cb, v = b
    sa, sb = 1 - 2*ca, 1 - 2*cb
    return 3*ca*cb + ca*sb + cb*sa + sa*sb*Fraction(dot(u, v)**2, dot(u, u)*dot(v, v))


def score(marg_a, marg_b, joint):
    return (sum(c*joint(i, j) for j, row in enumerate(COEFF) for i, c in enumerate(row))
            - marg_a[2] - marg_a[3] - 2*marg_b[0] - marg_b[1] - marg_b[2])


def main():
    local = max(score(a, b, lambda i, j: a[i]*b[j])
                for a in product(range(2), repeat=4) for b in product(range(2), repeat=4))
    alpha = Fraction(19, 25)
    marg_a = [Fraction(rank(a), 3) for a in ALICE]
    marg_b = [Fraction(rank(b), 3) for b in BOB]

    def joint(i, j):
        return alpha*trace_product(ALICE[i], BOB[j])/3 + (1-alpha)*marg_a[i]*marg_b[j]

    quantum = score(marg_a, marg_b, joint)
    if local != 0 or quantum != Fraction(1, 16500):
        raise ValueError(f"Unexpected local or quantum value: {local}, {quantum}")
    if not (100-19)**2 > 2*(3*19)**2:
        raise ValueError("Visibility is not below the I3322 threshold")
    print(f"A5 local maximum {local} over 256 deterministic strategies; "
          f"qutrit score {quantum} at visibility {alpha}.")


if __name__ == "__main__":
    main()
