import I3322ScalarPoly
namespace IsoScalar
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000

theorem checked_10 : tableOK 1 0 = true := by rfl
theorem checked_11 : tableOK 1 1 = true := by rfl
theorem checked_12 : tableOK 1 2 = true := by rfl
theorem checked_13 : tableOK 1 3 = true := by rfl

end IsoScalar
