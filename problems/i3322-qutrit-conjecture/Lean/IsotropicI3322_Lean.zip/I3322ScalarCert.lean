import I3322Rank0
import I3322Rank1
import I3322Rank2
import I3322Rank3
namespace IsoScalar
theorem pattern_cover (r s u v j k : Fin 4) : ∃ l : Fin 6, covers (rankPoly r s u v j k) (patterns l) = true := by
  have hr : tableOK r s = true := by
    fin_cases r <;> fin_cases s
    · exact checked_00
    · exact checked_01
    · exact checked_02
    · exact checked_03
    · exact checked_10
    · exact checked_11
    · exact checked_12
    · exact checked_13
    · exact checked_20
    · exact checked_21
    · exact checked_22
    · exact checked_23
    · exact checked_30
    · exact checked_31
    · exact checked_32
    · exact checked_33

  simp only [tableOK, List.all_eq_true, List.any_eq_true, List.mem_finRange, forall_const,
    true_and] at hr
  exact hr u v j k

end IsoScalar
