import IsoBell

namespace IsoBell
open Matrix
open scoped Matrix ComplexOrder BigOperators
noncomputable section
variable {d : ℕ}

theorem projector_effect {P : Mat d} (h : Projector P) : Effect P := by
  have hp : Pᴴ*P=P := by rw [h.1.eq,h.2]
  have hq : (1-P)ᴴ*(1-P)=1-P := by
    rw [conjTranspose_sub,conjTranspose_one,h.1.eq]
    noncomm_ring [h.2]
  exact ⟨hp ▸ posSemidef_conjTranspose_mul_self P,
    hq ▸ posSemidef_conjTranspose_mul_self (1-P)⟩

private theorem spectral_score (U : Matrix.unitaryGroup (Fin d) ℂ)
    (L : Mat d →ₗ[ℝ] ℝ) (x : Fin d → ℝ) :
    L ((Unitary.conjStarAlgAut ℂ _ U) (diagonal fun i => (x i : ℂ))) =
      ∑ i, x i * L ((Unitary.conjStarAlgAut ℂ _ U) (Matrix.single i i 1)) := by
  have decomp : diagonal (fun i => (x i : ℂ)) =
      ∑ i, x i • (Matrix.single i i (1 : ℂ)) := by
    simpa [Matrix.smul_single, Complex.real_smul] using
      (Matrix.sum_single_eq_diagonal (fun i => (x i : ℂ))).symm
  rw [decomp, Unitary.conjStarAlgAut_apply, Matrix.mul_sum, Matrix.sum_mul, map_sum]
  simp only [Matrix.mul_smul, Matrix.smul_mul, map_smul, smul_eq_mul, Unitary.conjStarAlgAut_apply]

theorem effect_eigenvalue_le_one {A : Mat d} (hA : Effect A) (i : Fin d) :
    hA.1.isHermitian.eigenvalues i ≤ 1 := by
  let v := ⇑(hA.1.isHermitian.eigenvectorBasis i)
  have hv : RCLike.re (star v ⬝ᵥ v) = 1 := by
    dsimp [v]
    rw [dotProduct_comm, ← EuclideanSpace.inner_eq_star_dotProduct, inner_self_eq_norm_sq_to_K,
      hA.1.isHermitian.eigenvectorBasis.orthonormal.1 i]
    norm_num
  have he : RCLike.re (star v ⬝ᵥ (A *ᵥ v)) = hA.1.isHermitian.eigenvalues i :=
    (hA.1.isHermitian.eigenvalues_eq i).symm
  have h := hA.2.re_dotProduct_nonneg v
  rw [Matrix.sub_mulVec, Matrix.one_mulVec, dotProduct_sub, map_sub, hv, he] at h
  linarith

/-- A projection maximizes each real-linear functional at least as well
as any specified positive effect, in the same local Hilbert space. -/
theorem maximize_effect {A : Mat d} (hA : Effect A) (L : Mat d →ₗ[ℝ] ℝ) :
    ∃ P : Mat d, Projector P ∧ L A ≤ L P := by
  let U := hA.1.isHermitian.eigenvectorUnitary
  let φ := Unitary.conjStarAlgAut ℂ _ U
  let t (i : Fin d) := L (φ (Matrix.single i i 1))
  let s (i : Fin d) : ℝ := if 0≤t i then 1 else 0
  let D := diagonal (fun i => (s i : ℂ))
  have hs (i : Fin d) : s i * s i = s i := by dsimp [s]; split <;> norm_num
  have hH : D.IsHermitian := by
    apply Matrix.isHermitian_diagonal_iff.mpr
    intro i
    change star (s i : ℂ) = _
    simp
  have he : D*D=D := by
    change diagonal _ * diagonal _ = _
    rw [Matrix.diagonal_mul_diagonal]
    congr 1; funext i; exact_mod_cast hs i
  refine ⟨φ D, ⟨?_,?_⟩,?_⟩
  · change star (φ D) = φ D
    rw [← map_star]; exact congrArg φ hH
  · rw [← map_mul,he]
  · calc
      L A = ∑ i, hA.1.isHermitian.eigenvalues i * t i := by
        conv_lhs => rw [hA.1.isHermitian.spectral_theorem]
        exact spectral_score U L _
      _ ≤ ∑ i, s i * t i := by
        apply Finset.sum_le_sum; intro i _
        by_cases h : 0≤t i
        · simpa [s,h] using mul_le_mul_of_nonneg_right (effect_eigenvalue_le_one hA i) h
        · simpa [s,h] using mul_nonpos_of_nonneg_of_nonpos (hA.1.eigenvalues_nonneg i) (le_of_not_ge h)
      _ = L (φ D) := (spectral_score U L s).symm
end
end IsoBell
