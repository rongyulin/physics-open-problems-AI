import IsoBell

namespace IsoBell
open Matrix
open scoped Matrix ComplexOrder BigOperators
noncomputable section
variable {d : ℕ}

theorem projector_eigenvalue {P : Mat d} (h : Projector P) (i : Fin d) :
    h.1.eigenvalues i = 0 ∨ h.1.eigenvalues i = 1 := by
  let φ := Unitary.conjStarAlgAut ℂ _ (star h.1.eigenvectorUnitary)
  have hd : φ P = diagonal (fun i => (h.1.eigenvalues i : ℂ)) :=
    h.1.conjStarAlgAut_star_eigenvectorUnitary
  have hsq := congrArg φ h.2
  rw [map_mul,hd,diagonal_mul_diagonal] at hsq
  have he := congrArg (fun (M : Mat d) => (M i i).re) hsq
  simp at he
  rcases mul_eq_zero.mp (show h.1.eigenvalues i * (h.1.eigenvalues i-1)=0 by nlinarith [he]) with h0|h1
  · exact Or.inl h0
  · exact Or.inr (by linarith)

theorem projector_trace_rank {P : Mat d} (h : Projector P) : tr P=(P.rank:ℝ) := by
  classical
  have eig (i : Fin d) : h.1.eigenvalues i =
      if h.1.eigenvalues i≠0 then (1:ℝ) else 0 := by
    rcases projector_eigenvalue h i with hi|hi <;> simp [hi]
  rw [tr,h.1.trace_eq_sum_eigenvalues,Complex.re_sum,h.1.rank_eq_card_non_zero_eigs]
  change (∑ i, h.1.eigenvalues i) = _
  calc
    _ = ∑ i, if h.1.eigenvalues i≠0 then (1:ℝ) else 0 := Finset.sum_congr rfl fun i _ => eig i
    _ = _ := by rw [Fintype.card_subtype, Finset.sum_boole]

#print axioms projector_trace_rank
end
end IsoBell
