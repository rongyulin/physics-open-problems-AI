import IsotropicI3322
import ItoA5

namespace IsoSeparation
open IsoBell
open scoped Matrix BigOperators ComplexOrder
noncomputable section

/-- The A5 functional on actual Born probabilities of the isotropic density matrix. -/
def observedA5 (α : ℝ) (A B : Fin 4 → Mat 3) : ℝ :=
  let p := born 3 (isotropic 3 α)
  (∑ j, ∑ i, ItoA5.c j i * p (A i) (B j)) - p (A 2) 1 -
    p (A 3) 1 - 2*p 1 (B 0) - p 1 (B 1) - p 1 (B 2)

theorem A5_born (α : ℝ) (A B : Fin 4 → Mat 3)
    (ha : ∀ i, Effect (A i)) (hb : ∀ j, Effect (B j)) :
    observedA5 α A B = ItoA5.score α A B := by
  have pair (i j : Fin 4) := born_joint 3 α (A i) (B j) (ha i).1.isHermitian (hb j).1.isHermitian
  have left (i : Fin 4) := (born_joint 3 α (A i) 1 (ha i).1.isHermitian Matrix.isHermitian_one).trans
    (joint_one_right 3 (by decide) α (A i))
  have right (j : Fin 4) := (born_joint 3 α 1 (B j) Matrix.isHermitian_one (hb j).1.isHermitian).trans
    (joint_one_left 3 (by decide) α (B j))
  simp only [observedA5,ItoA5.score,pair,left,right]

/-- The same physical state violates the four-setting A5 inequality and
satisfies the three-setting I3322 inequality for all binary POVMs. -/
theorem strict_separation :
    (∀ a b, ItoA5.localScore a b ≤ 0) ∧
    (∀ s ∈ IsoExperiment.values (19/25), s ≤ 0) ∧
    (∀ i, Effect (ItoA5.A i)) ∧ (∀ j, Effect (ItoA5.B j)) ∧
    observedA5 (19/25) ItoA5.A ItoA5.B = 1/16500 := by
  refine ⟨ItoA5.local_bound,?_,ItoA5.effects.1,ItoA5.effects.2,?_⟩
  · intro s hm
    by_contra! h
    have e := (IsotropicI3322.violation_iff (19/25) (by norm_num) (by norm_num)).mp ⟨s,hm,h⟩
    linarith only [e,ItoA5.thresholds]
  · rw [A5_born _ _ _ ItoA5.effects.1 ItoA5.effects.2,ItoA5.score_exact]

#print axioms strict_separation
end
end IsoSeparation
