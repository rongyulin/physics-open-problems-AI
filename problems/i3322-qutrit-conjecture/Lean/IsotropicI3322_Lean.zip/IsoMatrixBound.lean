import I3322Trace
import I3322ScalarDefs
import IsoCollect
import IsoProjection

/-! Reduction of the six arbitrary complex projectors in I3322 to two
principal-angle circles and six discrete ranks, at nonnegative visibility. -/
namespace IsoMatrixBound
open IsoBell IsoScalar I3322Trace IsoCollect Matrix
open scoped Matrix BigOperators
noncomputable section

private theorem mask_sorted (r : Fin 4) : Antitone (mask r) := by
  intro i j hij
  change i.val ≤ j.val at hij
  unfold mask
  split_ifs <;> norm_num <;> omega

private theorem sum_sorted (r s : Fin 4) {x : ℝ} (h0 : 0≤x) (h1 : x≤1) :
    Antitone (sumSpec r s x) := by
  rw [Fin.antitone_iff_succ_le]
  intro i
  fin_cases i
  · change sumSpec r s x 1 ≤ sumSpec r s x 0
    fin_cases r <;> fin_cases s <;> norm_num [sumSpec,sumBase,sumSlope,Matrix.cons_val_two,Matrix.cons_val_three] <;> linarith
  · change sumSpec r s x 2 ≤ sumSpec r s x 1
    fin_cases r <;> fin_cases s <;> norm_num [sumSpec,sumBase,sumSlope,Matrix.cons_val_two,Matrix.cons_val_three] <;> linarith

private theorem diff_sorted (r s : Fin 4) {z : ℝ} (h0 : 0≤z) (h1 : z≤1) :
    Antitone (diffSpec r s z) := by
  rw [Fin.antitone_iff_succ_le]
  intro i
  fin_cases i
  · change diffSpec r s z 1 ≤ diffSpec r s z 0
    fin_cases r <;> fin_cases s <;> norm_num [diffSpec,diffBase,diffSlope,Matrix.cons_val_two,Matrix.cons_val_three] <;> linarith
  · change diffSpec r s z 2 ≤ diffSpec r s z 1
    fin_cases r <;> fin_cases s <;> norm_num [diffSpec,diffBase,diffSlope,Matrix.cons_val_two,Matrix.cons_val_three] <;> linarith

/-- Matrix upper bound for the actual isotropic-state Bell score. -/
theorem projector_bound (α : ℝ) (ha : 0≤α) (A B : Triple 3)
    (hA : ∀i,Projector (A i)) (hB : ∀i,Projector (B i)) :
    ∃ (r s u v j k : Fin 4) (x y z w : ℝ), 0≤x ∧ 0≤y ∧ 0≤z ∧ 0≤w ∧
      x^2+z^2=1 ∧ y^2+w^2=1 ∧ 9*score 3 α A B ≤
      3*α*pure r s u v j k x y z w + (1-α)*white r s u v j k := by
  let C := transposed B
  have hC (i : Fin 3) : Projector (C i) := transpose_proj (hB i)
  obtain ⟨r,s,x,z,hr,hs,hx,hz,hxz,sa,da⟩ :=
    IsoProjection.pair_spectra (A 0) (A 1) (hA 0) (hA 1)
  obtain ⟨u,v,y,w,hu,hv,hy,hw,hyw,sb,db⟩ :=
    IsoProjection.pair_spectra (C 0) (C 1) (hC 0) (hC 1)
  obtain ⟨j,aj,hj⟩ := projector_spectrum (A 2) (hA 2)
  obtain ⟨k,bk,hk⟩ := projector_spectrum (C 2) (hC 2)
  have x1 : x≤1 := by nlinarith [sq_nonneg (x-1),sq_nonneg z,mul_self_nonneg (x+1)]
  have y1 : y≤1 := by nlinarith [sq_nonneg (y-1),sq_nonneg w,mul_self_nonneg (y+1)]
  have z1 : z≤1 := by nlinarith [sq_nonneg (z-1),sq_nonneg x,mul_self_nonneg (z+1)]
  have w1 : w≤1 := by nlinarith [sq_nonneg (w-1),sq_nonneg y,mul_self_nonneg (w+1)]
  have s1 := trace_rearrange _ _ _ _ sa sb (sum_sorted r s hx x1) (sum_sorted u v hy y1)
  have s2 := trace_rearrange _ _ _ _ bk da (mask_sorted k) (diff_sorted r s hz z1)
  have s3 := trace_rearrange _ _ _ _ aj db (mask_sorted j) (diff_sorted u v hw w1)
  rw [Matrix.trace_mul_comm (C 2)] at s2
  have g : G A C ≤ pure r s u v j k x y z w := by
    unfold G IsoScalar.pure mask
    rw [hr,hu,hv]
    unfold IsoBell.tr
    linarith only [s1,s2,s3]
  have wh : W A C = white r s u v j k := by
    simp only [W,white,hr,hs,hu,hv,hj,hk]
  refine ⟨r,s,u,v,j,k,x,y,z,w,hx,hy,hz,hw,hxz,hyw,?_⟩
  rw [score_collect]
  change 3*α*G A C + (1-α)*W A C ≤ _
  rw [wh]
  exact add_le_add (mul_le_mul_of_nonneg_left g (show 0≤3*α by positivity)) le_rfl
#print axioms projector_bound
end
end IsoMatrixBound
