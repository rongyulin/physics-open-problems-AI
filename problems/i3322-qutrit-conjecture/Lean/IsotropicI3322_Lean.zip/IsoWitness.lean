import IsoBell

/-! A fixed projective strategy witnesses the transition. Only the first
two basis vectors occur in its nonzero effects. No trial is discarded. -/
namespace IsoWitness
open IsoBell Matrix
open scoped Matrix BigOperators ComplexOrder
noncomputable section

def plane (x y : ℝ) : Mat 3 :=
  !![((1+x)/2 : ℝ), (y/2 : ℝ), 0; (y/2 : ℝ), ((1-x)/2 : ℝ), 0; 0,0,0]

theorem plane_proj (x y : ℝ) (h : x^2+y^2=1) : Projector (plane x y) := by
  have hc : (x:ℂ)^2+(y:ℂ)^2=1 := by exact_mod_cast h
  constructor
  · ext i j
    fin_cases i <;> fin_cases j <;> simp [plane, Matrix.conjTranspose_apply]
  · ext i j
    fin_cases i <;> fin_cases j <;> simp [plane, Matrix.mul_apply, Fin.sum_univ_three] <;>
      push_cast <;> first | linear_combination hc/4 | ring

theorem projective_effect {A : Mat 3} (h : Projector A) : Effect A := by
  obtain ⟨hh,hi⟩ := h
  constructor
  · have z := Matrix.posSemidef_conjTranspose_mul_self A
    rwa [hh.eq,hi] at z
  · have z := Matrix.posSemidef_conjTranspose_mul_self (1-A)
    rwa [(Matrix.isHermitian_one.sub hh).eq,Matrix.sub_mul,Matrix.one_mul,Matrix.mul_sub,Matrix.mul_one,
      hi,sub_self,sub_zero] at z

def t : ℝ := Real.sqrt 2/2
theorem tsq : t^2+t^2=1 := by
  dsimp [t]; nlinarith [Real.sq_sqrt (show 0 ≤ (2:ℝ) by norm_num)]

def alice : Triple 3 := ![plane 1 0, plane 0 1, 0]
def bob : Triple 3 := ![0, plane t t, plane t (-t)]

theorem alice_proj (i : Fin 3) : Projector (alice i) := by
  fin_cases i
  · exact plane_proj _ _ (by norm_num)
  · exact plane_proj _ _ (by norm_num)
  · exact (show Projector (0:Mat 3) from ⟨Matrix.isHermitian_zero,by simp⟩)

theorem bob_proj (i : Fin 3) : Projector (bob i) := by
  fin_cases i
  · exact (show Projector (0:Mat 3) from ⟨Matrix.isHermitian_zero,by simp⟩)
  · exact plane_proj _ _ tsq
  · exact plane_proj _ _ (by simpa using tsq)

lemma tr_plane (x y : ℝ) : tr (plane x y)=1 := by
  simp [tr,Matrix.trace, Fin.sum_univ_three,plane]; ring
lemma overlap_plane (x y u v : ℝ) : overlap (plane x y) (plane u v)=(1+x*u+y*v)/2 := by
  rw [overlap,tr,Matrix.trace,Fin.sum_univ_three]
  simp only [Matrix.diag_apply,Matrix.mul_apply,Fin.sum_univ_three,Matrix.transpose_apply]
  simp [plane,Complex.mul_re]; ring

theorem attained (α : ℝ) : score 3 α alice bob = ((1+3*Real.sqrt 2)*α-4)/9 := by
  rw [score_explicit]
  simp [alice,bob,joint,marginal,tr_plane,overlap_plane,
    show ∀ A : Mat 3, overlap A 0=0 by simp [overlap,tr],
    show ∀ A : Mat 3, overlap 0 A=0 by simp [overlap,tr],show tr (0:Mat 3)=0 by simp [tr],t]
  ring

#print axioms attained
end
end IsoWitness
