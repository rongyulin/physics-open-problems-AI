import IsoBell
import I3322ScalarDefs

namespace IsoProjection
open Matrix IsoBell IsoScalar
open scoped Matrix BigOperators
noncomputable section

def origin (r : Fin 4) : ℂ := ![0,0,1,1] r
def direction (r : Fin 4) : ℂ := ![0,1,-1,0] r

/-- Complementing exactly one nontrivial rank interchanges the two circle coordinates. -/
def angle (r s : Fin 4) (t w : ℝ) : ℝ :=
  if (r.val=1 ∧ s.val=2) ∨ (r.val=2 ∧ s.val=1) then w else t

private def spec (diff : Bool) (r s : Fin 4) (t w : ℝ) :=
  if diff then diffSpec r s (angle r s w t) else sumSpec r s (angle r s t w)

def determinantPolynomial (k e f tq l : ℂ) :=
  (l-k)*((l-k)^2-(l-k)*(e+f)+e*f*(1-tq))

set_option maxHeartbeats 4000000 in
theorem table (diff : Bool) (r s : Fin 4) (t w : ℝ) (h : t^2+w^2=1) (l : ℂ) :
    let sg : ℂ := if diff then -1 else 1
    determinantPolynomial (origin r+sg*origin s) (direction r) (sg*direction s) ((t:ℂ)^2) l =
      ∏ i, (l - (spec diff r s t w i : ℂ)) := by
  have hw : (w:ℂ)^2 = 1-(t:ℂ)^2 := by exact_mod_cast (show w^2=1-t^2 by linarith)
  cases diff <;> fin_cases r <;> fin_cases s <;>
    norm_num [determinantPolynomial, origin,direction,spec,angle, sumSpec,sumBase,sumSlope,
      diffSpec,diffBase,diffSlope,Fin.prod_univ_three,Matrix.cons_val_two,Matrix.cons_val_three] <;>
    ring_nf <;> rw [hw] <;> ring

theorem table_plus (r s : Fin 4) (t w : ℝ) (h : t^2+w^2=1) (l : ℂ) :
    determinantPolynomial (origin r+origin s) (direction r) (direction s) ((t:ℂ)^2) l =
      ∏ i, (l - (sumSpec r s (angle r s t w) i : ℂ)) := by
  simpa [spec] using table false r s t w h l

theorem table_minus (r s : Fin 4) (t w : ℝ) (h : t^2+w^2=1) (l : ℂ) :
    determinantPolynomial (origin r-origin s) (direction r) (-direction s) ((t:ℂ)^2) l =
      ∏ i, (l - (diffSpec r s (angle r s w t) i : ℂ)) := by
  simpa [spec,sub_eq_add_neg] using table true r s t w h l

end
end IsoProjection
