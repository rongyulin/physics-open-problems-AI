import I3322ScalarCert
namespace IsoScalar
open scoped BigOperators

private theorem mul_le_max_zero {a x : ℝ} (h₀ : 0 ≤ x) (h₁ : x ≤ 1) : a*x ≤ max 0 a := by
  by_cases h : a ≤ 0
  · exact le_trans (mul_nonpos_of_nonpos_of_nonneg h h₀) (le_max_left _ _)
  · simpa using (mul_le_mul_of_nonneg_left h₁ (le_of_not_ge h)).trans
      (show a*1 ≤ max 0 a by simp)

private theorem blend {a b t : ℝ} (h₀ : a≤0) (h₁ : a+b≤0) (ht₀ : 0≤t) (ht₁ : t≤1) :
    a+b*t≤0 := by
  nlinarith only [mul_nonpos_of_nonneg_of_nonpos (sub_nonneg.mpr ht₁) h₀,
    mul_nonpos_of_nonneg_of_nonpos ht₀ h₁]

private theorem covers_sound {p q : Poly} (h : covers p q=true)
    {x y z w : ℝ} (hx : x∈Set.Icc 0 1) (hy : y∈Set.Icc 0 1)
    (hz : z∈Set.Icc 0 1) (hw : w∈Set.Icc 0 1) :
    p.val x y z w ≤ q.val x y z w ∧ (p.noise:ℝ) ≤ (q.noise:ℝ) := by
  simp only [covers,decide_eq_true_eq] at h
  obtain ⟨hn,h00,h01,h10,h11⟩ := h
  let a : ℝ := (p.c-q.c:ℤ)+max 0 (p.z-q.z:ℤ)+max 0 (p.w-q.w:ℤ)
  let b : ℝ := (p.x-q.x:ℤ)
  let c : ℝ := (p.y-q.y:ℤ)
  let d : ℝ := (p.xy-q.xy:ℤ)
  have h0 : a ≤ 0 := by
    have ht : ((corner p q 0 0:ℤ):ℝ) ≤ 0 := by exact_mod_cast h00
    simpa [a,corner] using ht
  have h1 : a+c ≤ 0 := by
    dsimp [a,c]
    push_cast
    have ht : ((corner p q 0 1:ℤ):ℝ) ≤ 0 := by exact_mod_cast h01
    simp [corner] at ht
    linarith
  have h2 : a+b ≤ 0 := by
    dsimp [a,b]
    push_cast
    have ht : ((corner p q 1 0:ℤ):ℝ) ≤ 0 := by exact_mod_cast h10
    simp [corner] at ht
    linarith
  have h3 : a+b+(c+d) ≤ 0 := by
    dsimp [a,b,c,d]
    push_cast
    have ht : ((corner p q 1 1:ℤ):ℝ) ≤ 0 := by exact_mod_cast h11
    simp [corner] at ht
    linarith
  have y0 := blend h0 h1 hy.1 hy.2
  have y1 := blend h2 h3 hy.1 hy.2
  have xy := blend y0 (show a+c*y+(b+d*y)≤0 by linarith) hx.1 hx.2
  have z' := mul_le_max_zero (a:=(p.z:ℝ)-q.z) hz.1 hz.2
  have w' := mul_le_max_zero (a:=(p.w:ℝ)-q.w) hw.1 hw.2
  dsimp [a,b,c,d] at xy
  push_cast at xy
  constructor
  · unfold Poly.val
    linarith
  · exact_mod_cast hn

private theorem unit_sum {x z : ℝ} (hu : x^2+z^2=1) : x+z ≤ Real.sqrt 2 := by
  apply Real.le_sqrt_of_sq_le
  nlinarith [sq_nonneg (x-z)]

private theorem exceptional {x y z w : ℝ} (ha : x^2+z^2=1) (hb : y^2+w^2=1) :
    -2+x+y-x*y+z+w ≤ 1/2 := by
  nlinarith only [sq_nonneg (1-z), sq_nonneg (1-w), sq_nonneg (x+y-1), ha,hb]

private theorem unit_box {x z : ℝ} (hx : 0≤x) (h : x^2+z^2=1) : x∈Set.Icc 0 1 :=
  ⟨hx, by nlinarith [sq_nonneg z]⟩

/-- A weighted form separates the pure and white-noise parts of the rank table. -/
private theorem weighted (r s u v j k : Fin 4) (x y z w : ℝ)
    (hx : 0≤x) (hy : 0≤y) (hz : 0≤z) (hw : 0≤w) (ha : x^2+z^2=1) (hb : y^2+w^2=1)
    (a b H : ℝ) (h₁ : 0≤a) (h₂ : 0≤b) (hH₀ : 1/2≤H)
    (hH : ∀ X Y Z W : ℝ, 0≤X → 0≤Y → 0≤Z → 0≤W →
      X^2+Z^2=1 → Y^2+W^2=1 → -2+X+X*Y+Z+W≤H) :
    a*pure r s u v j k x y z w+b*white r s u v j k ≤
      max 0 (max (a*(Real.sqrt 2-1)-4*b) (a*H-7*b)) := by
  obtain ⟨l,hl⟩ := pattern_cover r s u v j k
  have hza : z^2+x^2=1 := by linarith
  have hwb : w^2+y^2=1 := by linarith
  obtain ⟨hp,hn⟩ := covers_sound hl (unit_box hx ha) (unit_box hy hb) (unit_box hz hza) (unit_box hw hwb)
  calc
    _ ≤ a*(patterns l).val x y z w + b*((patterns l).noise:ℝ) := by
      rw [pure_val, white_val]
      exact add_le_add (mul_le_mul_of_nonneg_left hp h₁) (mul_le_mul_of_nonneg_left hn h₂)
    _ ≤ _ := by
      have hleft := (le_max_left (a*(Real.sqrt 2-1)-4*b) (a*H-7*b)).trans (le_max_right 0 _)
      have hright := (le_max_right (a*(Real.sqrt 2-1)-4*b) (a*H-7*b)).trans (le_max_right 0 _)
      fin_cases l
      · apply le_trans _ (le_max_left (0:ℝ) _)
        norm_num [patterns,Poly.val]
      · apply le_trans _ hleft
        norm_num [patterns,Poly.val]
        nlinarith only [mul_le_mul_of_nonneg_left (unit_sum ha) h₁]
      · apply le_trans _ hleft
        norm_num [patterns,Poly.val]
        nlinarith only [mul_le_mul_of_nonneg_left (unit_sum hb) h₁]
      · apply le_trans _ hright
        norm_num [patterns,Poly.val]
        nlinarith only [mul_le_mul_of_nonneg_left (hH x y z w hx hy hz hw ha hb) h₁]
      · apply le_trans _ hright
        norm_num [patterns,Poly.val]
        nlinarith only [mul_le_mul_of_nonneg_left (hH y x w z hy hx hw hz hb ha) h₁]
      · apply le_trans _ hright
        norm_num [patterns,Poly.val]
        nlinarith only [mul_le_mul_of_nonneg_left ((exceptional ha hb).trans hH₀) h₁]

/-- Multiaffine domination of the physical score by the three candidate straight lines. -/
theorem envelope (r s u v j k : Fin 4) (x y z w : ℝ)
    (hx : 0≤x) (hy : 0≤y) (hz : 0≤z) (hw : 0≤w) (ha : x^2+z^2=1) (hb : y^2+w^2=1)
    (α H : ℝ) (hα₀ : 0≤α) (hα₁ : α≤1) (hH₀ : 1/2≤H)
    (hH : ∀ X Y Z W : ℝ, 0≤X → 0≤Y → 0≤Z → 0≤W →
       X^2+Z^2=1 → Y^2+W^2=1 → -2+X+X*Y+Z+W≤H) :
    3*α*pure r s u v j k x y z w+(1-α)*white r s u v j k ≤
      max 0 (max (3*α*(Real.sqrt 2-1)-4*(1-α)) (3*α*H-7*(1-α))) :=
  weighted r s u v j k x y z w hx hy hz hw ha hb _ _ _ (by positivity) (sub_nonneg.mpr hα₁) hH₀ hH

/-- A rational upper bound suffices to decide the conjectured visibility exactly. -/
theorem critical_bound (x y z w : ℝ) (_hx : 0≤x) (hy : 0≤y) (_hz : 0≤z) (_hw : 0≤w)
    (ha : x^2+z^2=1) (hb : y^2+w^2=1) : -2+x+x*y+z+w ≤ 13/18 := by
  have hy1 := (unit_box hy hb).2
  have h17 : x+z≤17/12 := by
    nlinarith only [ha,sq_nonneg (x-z), sq_nonneg (x+z-17/12)]
  have h9 : 2*x+z≤9/4 := by
    nlinarith only [ha,sq_nonneg (x-2*z), sq_nonneg (2*x+z-9/4)]
  have h47 : 10*y+12*w ≤ 47/3 := by
    nlinarith only [hb,sq_nonneg (12*y-10*w),sq_nonneg (10*y+12*w-47/3)]
  nlinarith only [mul_le_mul_of_nonneg_left h17 (sub_nonneg.mpr hy1),
    mul_le_mul_of_nonneg_left h9 hy,h47]

theorem threshold (r s u v j k : Fin 4) (x y z w : ℝ)
    (hx : 0≤x) (hy : 0≤y) (hz : 0≤z) (hw : 0≤w) (ha : x^2+z^2=1) (hb : y^2+w^2=1) :
    4*pure r s u v j k x y z w + (Real.sqrt 2-1)*white r s u v j k ≤ 0 := by
  have hs : 89/63 ≤ Real.sqrt 2 := by
    apply Real.le_sqrt_of_sq_le
    norm_num
  have h := weighted r s u v j k x y z w hx hy hz hw ha hb 4 (Real.sqrt 2-1) (13/18)
    (by norm_num) (by linarith) (by norm_num) critical_bound
  exact h.trans (max_le le_rfl (max_le (by ring_nf; rfl) (by linarith)))

#print axioms envelope
#print axioms threshold
end IsoScalar
