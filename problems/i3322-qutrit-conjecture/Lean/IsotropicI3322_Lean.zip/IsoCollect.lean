import IsoBell

/-! Trace and white-noise contributions in the coefficient convention of
Ito, Imai and Avis, equation (2). Bob's transpose is explicit. -/
namespace IsoCollect
open IsoBell Matrix
open scoped Matrix BigOperators
noncomputable section

def transposed (B : Triple 3) : Triple 3 := fun i => (B i)ᵀ

theorem transpose_proj {B : Mat 3} (h : Projector B) : Projector Bᵀ := by
  refine ⟨?_,?_⟩
  · exact h.1.transpose
  · simpa only [Matrix.transpose_mul] using congrArg Matrix.transpose h.2

def G (A C : Triple 3) : ℝ :=
  tr ((A 0+A 1)*(C 0+C 1)) + tr ((A 0-A 1)*C 2) + tr (A 2*(C 0-C 1)) -
    tr (A 0) - 2*tr (C 0) - tr (C 1)

def W (A C : Triple 3) : ℝ :=
  (tr (A 0)+tr (A 1))*(tr (C 0)+tr (C 1)) + (tr (A 0)-tr (A 1))*tr (C 2) +
    tr (A 2)*(tr (C 0)-tr (C 1))-3*(tr (A 0)+2*tr (C 0)+tr (C 1))

theorem score_collect (α : ℝ) (A B : Triple 3) :
    9*score 3 α A B = 3*α*G A (transposed B)+(1-α)*W A (transposed B) := by
  rw [score_explicit]
  simp only [joint,marginal,overlap,IsoBell.tr,G,W,transposed,Matrix.add_mul,
    Matrix.mul_add,Matrix.sub_mul,Matrix.mul_sub,Matrix.trace_add,Matrix.trace_sub,
    Matrix.trace_transpose,Complex.add_re,Complex.sub_re,Nat.cast_ofNat]
  ring

#print axioms score_collect
end
end IsoCollect
