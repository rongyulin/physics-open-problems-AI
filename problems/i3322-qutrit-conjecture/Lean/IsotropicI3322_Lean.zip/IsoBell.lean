import Mathlib.Analysis.Matrix.PosDef
import Mathlib.Data.Matrix.Basis
import Mathlib.LinearAlgebra.Matrix.Kronecker
import Mathlib.Tactic

/-! The six positive effects are the outcome-one operators of the
Ito–Imai–Avis three-setting Bell experiment. -/
namespace IsoBell
open Matrix
open scoped Matrix ComplexOrder BigOperators
noncomputable section
abbrev Mat (d : ℕ) := Matrix (Fin d) (Fin d) ℂ
abbrev Triple (d : ℕ) := Fin 3 → Mat d

def Effect {d : ℕ} (A : Mat d) : Prop := A.PosSemidef ∧ (1-A).PosSemidef
def Projector {d : ℕ} (A : Mat d) : Prop := A.IsHermitian ∧ A*A=A
def tr {d : ℕ} (A : Mat d) : ℝ := A.trace.re
def marginal (d : ℕ) (A : Mat d) : ℝ := tr A / d
def overlap {d : ℕ} (A B : Mat d) : ℝ := tr (A * Bᵀ)
def joint (d : ℕ) (α : ℝ) (A B : Mat d) : ℝ :=
  α * overlap A B / d + (1-α) * tr A * tr B / (d:ℝ)^2

def coeff : Matrix (Fin 3) (Fin 3) ℝ := !![1,1,1;1,1,-1;1,-1,0]
def aliceCoeff : Fin 3 → ℝ := ![-1,0,0]
def bobCoeff : Fin 3 → ℝ := ![-2,-1,0]
def score (d : ℕ) (α : ℝ) (A B : Triple d) : ℝ :=
  (∑ i, ∑ j, coeff i j * joint d α (A i) (B j)) +
    (∑ i, aliceCoeff i * marginal d (A i)) + ∑ j, bobCoeff j * marginal d (B j)

theorem score_explicit (d : ℕ) (α : ℝ) (A B : Triple d) :
    score d α A B =
      joint d α (A 0) (B 0) + joint d α (A 0) (B 1) + joint d α (A 0) (B 2) +
      joint d α (A 1) (B 0) + joint d α (A 1) (B 1) - joint d α (A 1) (B 2) +
      joint d α (A 2) (B 0) - joint d α (A 2) (B 1) -
      marginal d (A 0) - 2*marginal d (B 0) - marginal d (B 1) := by
  simp [score,coeff,aliceCoeff,bobCoeff,Fin.sum_univ_three]
  ring
end
end IsoBell
