import IsoOpt

/-! Visibility thresholds separating the three optimal measurement strategies. -/
namespace BellIsoPhases
noncomputable section
open BellIsoOpt

def c (a : ℝ) : ℝ := ((1+3*Real.sqrt 2)*a-4)/9
def d (a : ℝ) : ℝ := (3*a*H-7*(1-a))/9
def V (a : ℝ) : ℝ := max 0 (max (c a) (d a))
def α0 : ℝ := 4/(1+3*Real.sqrt 2)
def α1 : ℝ := 1/(H+2-Real.sqrt 2)

private theorem sqrt_bounds : 41/29 < Real.sqrt 2 ∧ Real.sqrt 2 < 3/2 := by
  have hs := Real.sqrt_nonneg (2:ℝ)
  have hq := Real.sq_sqrt (show (0:ℝ) ≤ 2 by norm_num)
  constructor <;> nlinarith

private theorem den0 : 0 < 1+3*Real.sqrt 2 := by positivity
private theorem den1 : 0 < H+2-Real.sqrt 2 := by linarith only [half_le,sqrt_bounds.2]

theorem ordered : 0 < α0 ∧ α0 < α1 ∧ α1 < 1 := by
  refine ⟨div_pos (by norm_num) den0,(div_lt_div_iff₀ den0 den1).mpr ?_,
    (div_lt_iff₀ den1).mpr ?_⟩
  · linarith only [le_thirteen,sqrt_bounds.1]
  · linarith only [half_le,sqrt_bounds.2]

theorem c_nonpos_iff (a : ℝ) : c a ≤ 0 ↔ a ≤ α0 := by
  rw [α0,le_div_iff₀ den0]
  unfold c
  constructor <;> intro h <;> linarith only [h]

theorem c_nonneg_iff (a : ℝ) : 0 ≤ c a ↔ α0 ≤ a := by
  rw [α0,div_le_iff₀ den0]
  unfold c
  constructor <;> intro h <;> linarith only [h]

theorem d_le_c_iff (a : ℝ) : d a ≤ c a ↔ a ≤ α1 := by
  rw [α1,le_div_iff₀ den1]
  unfold c d
  constructor <;> intro h <;> linarith only [h]

theorem c_le_d_iff (a : ℝ) : c a ≤ d a ↔ α1 ≤ a := by
  rw [α1,div_le_iff₀ den1]
  unfold c d
  constructor <;> intro h <;> linarith only [h]

theorem low {a : ℝ} (h : a ≤ α0) : V a = 0 := by
  have hc := (c_nonpos_iff a).mpr h
  have hd := (d_le_c_iff a).mpr (h.trans ordered.2.1.le)
  simp [V, max_eq_left hd,max_eq_left hc]

theorem middle {a : ℝ} (h0 : α0 ≤ a) (h1 : a ≤ α1) : V a = c a := by
  simp [V,max_eq_left ((d_le_c_iff a).mpr h1),max_eq_right ((c_nonneg_iff a).mpr h0)]

theorem high {a : ℝ} (h : α1 ≤ a) : V a = d a := by
  have hc := (c_le_d_iff a).mpr h
  have hn := (c_nonneg_iff a).mpr (ordered.2.1.le.trans h)
  simp [V,max_eq_right hc,max_eq_right (hn.trans hc)]

theorem V_eq_zero_all (a : ℝ) : V a = 0 ↔ a ≤ α0 := by
  refine ⟨fun h => (c_nonpos_iff a).mp ?_, low⟩
  rw [←h]
  exact (le_max_left (c a) (d a)).trans (le_max_right _ _)

theorem V_eq_zero_iff (a : ℝ) (_ha : 0 ≤ a) (_ha' : a ≤ 1) : V a = 0 ↔ a ≤ α0 :=
  V_eq_zero_all a

theorem V_pos_iff (a : ℝ) : 0 < V a ↔ α0 < a := by
  have h : 0 ≤ V a := le_max_left _ _
  constructor
  · intro hv
    exact lt_of_not_ge (fun ha => (ne_of_gt hv) (low ha))
  · intro ha
    exact lt_of_le_of_ne h (fun hv => (not_le_of_gt ha) ((V_eq_zero_all a).mp hv.symm))

#print axioms V_eq_zero_iff
#print axioms high
end
end BellIsoPhases
