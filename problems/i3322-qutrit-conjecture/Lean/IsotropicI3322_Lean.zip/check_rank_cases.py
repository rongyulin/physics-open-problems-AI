#!/usr/bin/env python3
"""Verify the rank-envelope step with integer arithmetic. Run with Python 3."""

from collections import Counter
from itertools import product

RANKS = range(4)
CORNERS = tuple(product(range(2), repeat=4))
# Coefficients of 1,x,y,xy,z,w in the pure expression, then the white-noise value.
PATTERNS = (
    (0, 0, 0, 0, 0, 0, 0),
    (-1, 1, 0, 0, 1, 0, -4),
    (-1, 0, 1, 0, 0, 1, -4),
    (-2, 1, 0, 1, 1, 1, -7),
    (-2, 0, 1, 1, 1, 1, -7),
    (-2, 1, 1, -1, 1, 1, -7),
)


def mask(r):
    return [int(i < r) for i in range(3)]


def spectra(r, s, x, z):
    if r in (1, 2) and s in (1, 2):
        sums = [1 + x, 1 - x, r + s - 2]
        diffs = [z, -z, r - s]
    else:
        sums = [a + b for a, b in zip(mask(r), mask(s))]
        diffs = [a - b for a, b in zip(mask(r), mask(s))]
    return sorted(sums, reverse=True), sorted(diffs, reverse=True)


def dot(a, b):
    return sum(i * j for i, j in zip(a, b))


def value(poly, x, y, z, w):
    c, a, b, ab, d, e, _ = poly
    return c + a * x + b * y + ab * x * y + d * z + e * w


def rank_polynomial(r, s, u, v, j, k):
    offset = r + 2 * u + v
    white = (r + s) * (u + v) + (r - s) * k + j * (u - v) - 3 * offset
    samples = {}
    for x, y, z, w in CORNERS:
        a_sum, a_diff = spectra(r, s, x, z)
        b_sum, b_diff = spectra(u, v, y, w)
        samples[x, y, z, w] = (
            dot(a_sum, b_sum) + dot(mask(k), a_diff) + dot(mask(j), b_diff) - offset
        )
    c = samples[0, 0, 0, 0]
    a = samples[1, 0, 0, 0] - c
    b = samples[0, 1, 0, 0] - c
    ab = samples[1, 1, 0, 0] - c - a - b
    d = samples[0, 0, 1, 0] - c
    e = samples[0, 0, 0, 1] - c
    poly = c, a, b, ab, d, e, white
    if any(value(poly, *p) != raw for p, raw in samples.items()):
        raise ValueError(f"Unexpected mixed term for ranks {(r, s, u, v, j, k)}")
    return poly


def covers(upper, lower):
    # A separately affine difference is the multilinear interpolant of its corners.
    return upper[-1] >= lower[-1] and all(
        value(upper, *p) >= value(lower, *p) for p in CORNERS
    )


def main():
    counts = Counter(rank_polynomial(*ranks) for ranks in product(RANKS, repeat=6))
    if (sum(counts.values()), len(counts)) != (4096, 202):
        raise ValueError("Unexpected numbers of rank cases or distinct polynomials")
    if not all(pattern in counts for pattern in PATTERNS):
        raise ValueError("A proposed upper pattern is absent from the rank cases")
    for poly in counts:
        if not any(covers(upper, poly) for upper in PATTERNS):
            raise ValueError(f"Uncovered rank polynomial {poly}")
    maximal = {poly for poly in counts if not any(
        other != poly and covers(other, poly) for other in counts
    )}
    if maximal != set(PATTERNS):
        raise ValueError("Listed patterns differ from the maximal rank polynomials")
    print(f"{sum(counts.values())} rank tuples, {len(counts)} distinct polynomials, "
          f"{len(maximal)} maximal patterns. All bounds verified at all 16 corners.")


if __name__ == "__main__":
    main()
