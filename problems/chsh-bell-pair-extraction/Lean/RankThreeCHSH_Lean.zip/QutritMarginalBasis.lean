import QutritPartialTrace
import QutritMixedSharp
namespace CHSHMixed
open CHSH Matrix QutritCHSH
open scoped Matrix MatrixOrder ComplexOrder BigOperators Kronecker
noncomputable section
variable {n : Type*} [Fintype n] [DecidableEq n]

private theorem binary_rotate (U : unitaryGroup (Fin 3) ℂ) (A : Mat (Fin 3))
    (ha : Binary A) : Binary (U.valᴴ*A*U.val) := by
  have huu : U.valᴴ*U.val=1 := U.property.1
  constructor
  · simpa only [Matrix.mul_add,Matrix.add_mul,Matrix.mul_one,huu]
      using ha.1.conjTranspose_mul_mul_same U.val
  · simpa only [Matrix.mul_sub,Matrix.sub_mul,Matrix.mul_one,huu]
      using ha.2.conjTranspose_mul_mul_same U.val

/-- Spectral form of the mixed-state bound, in the laboratory basis of Alice.
The unitary U diagonalizes her one-qutrit marginal. -/
theorem mixed_upper_spectral (c : Fin 3 → ℝ) (hc : Antitone c) (hn : ∀ i, 0 ≤ c i)
    (U : unitaryGroup (Fin 3) ℂ) (R : Mat (Fin 3 × n)) (hR : R.PosSemidef)
    (hm : U.valᴴ * marginal R * U.val = diagonal (fun i => (c i:ℂ)^2))
    (A X : Mat (Fin 3)) (B Y : Mat n)
    (hA : Binary A) (hX : Binary X) (hB : Binary B) (hY : Binary Y) :
    mixedCHSH R A X B Y ≤ value c := by
  let E := U.val ⊗ₖ (1 : Mat n)
  let R' := Eᴴ*R*E
  have hr : R'.PosSemidef := hR.conjTranspose_mul_mul_same E
  have hd : marginal R' = diagonal (fun i => (c i:ℂ)^2) := by
    simp only [R',E,conjTranspose_kronecker,conjTranspose_one,marginal_right,marginal_left,hm]
  have hh := mixed_upper c hc hn R' hr hd _ _ B Y (binary_rotate U A hA)
    (binary_rotate U X hX) hB hY
  simpa only [mixedCHSH,R',E,corr_rotate] using hh

/-- A fixed marginal in an arbitrary laboratory basis. -/
def extensionScoresAt (M : Mat (Fin 3)) : Set ℝ := {z | ∃ (n : ℕ) (R : Mat (Fin 3 × Fin n)),
  R.PosSemidef ∧ marginal R = M ∧ ∃ (A X : Mat (Fin 3)) (B Y : Mat (Fin n)),
    Binary A ∧ Binary X ∧ Binary B ∧ Binary Y ∧ mixedCHSH R A X B Y = z}

/-- Sharp fixed-marginal CHSH maximum, independent of the marginal eigenbasis. -/
theorem exact_extensions_spectral (c : Fin 3 → ℝ) (hc : Antitone c) (hn : ∀ i, 0 ≤ c i)
    (U : unitaryGroup (Fin 3) ℂ) (M : Mat (Fin 3))
    (hm : U.valᴴ*M*U.val = diagonal (fun i => (c i:ℂ)^2)) :
    IsGreatest (extensionScoresAt M) (value c) := by
  constructor
  · let T := rankOne (state c)
    let E := U.val ⊗ₖ (1 : Mat (Fin 3))
    let S := E*T*Eᴴ
    have hS : S.PosSemidef := (rankOne_positive _).mul_mul_conjTranspose_same E
    have hu : U.val*U.valᴴ=1 := U.property.2
    have hM : marginal S = M := by
      rw [show marginal S=U.val*marginal T*U.valᴴ by
        simp only [S,E,conjTranspose_kronecker,conjTranspose_one,marginal_right,marginal_left]]
      rw [show marginal T=diagonal (fun i => (c i:ℂ)^2) from marginal_schmidt c,← hm]
      calc
        _ = (U.val*U.valᴴ)*M*(U.val*U.valᴴ) := by simp only [Matrix.mul_assoc]
        _ = _ := by rw [hu,one_mul,mul_one]
    obtain ⟨A,X,B,Y,ha,hx,hb,hy,hs⟩ := state_attained c
    let W : unitaryGroup (Fin 3) ℂ := star U
    have we : W.val = U.valᴴ := rfl
    refine ⟨3,S,hS,hM,U.val*A*U.valᴴ,U.val*X*U.valᴴ,B,Y,?_,?_,
      binary_of_observable hb,binary_of_observable hy,?_⟩
    · simpa only [we,conjTranspose_conjTranspose] using binary_rotate W A (binary_of_observable ha)
    · simpa only [we,conjTranspose_conjTranspose] using binary_rotate W X (binary_of_observable hx)
    have rot (D H : Mat (Fin 3)) : mixedCorr S (U.val*D*U.valᴴ) H = corr (state c) D H := by
      have h := corr_rotate W T D H
      simpa only [S,E,T,we,conjTranspose_kronecker,conjTranspose_one,
        conjTranspose_conjTranspose,rankOne_corr] using h
    simpa only [mixedCHSH,rot,CHSH.chsh] using hs
  · rintro z ⟨n,R,hR,hmR,A,X,B,Y,hA,hX,hB,hY,rfl⟩
    exact mixed_upper_spectral c hc hn U R hR (by rw [hmR]; exact hm) A X B Y hA hX hB hY

#print axioms exact_extensions_spectral
#print axioms mixed_upper_spectral
end
end CHSHMixed
