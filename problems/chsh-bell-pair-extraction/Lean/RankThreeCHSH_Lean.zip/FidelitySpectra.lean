import FidelityFrontier
import QutritCHSH

/-! Conversion between normalized Schmidt amplitudes, actual maximal CHSH
in Schmidt coordinates, and the three ordered probabilities in the frontier. -/
namespace CHSHFrontier
open QutritCHSH
noncomputable section

private theorem antitone_three {f : Fin 3 → ℝ} (h₀ : f 1 ≤ f 0) (h₁ : f 2 ≤ f 1) :
    Antitone f := by
  have absurd_order {i j : Fin 3} (h : i ≤ j) (bad : ¬ i ≤ j) : False := bad h
  intro i j hij
  fin_cases i <;> fin_cases j <;>
    first | exact le_rfl | exact h₀ | exact h₁ | exact h₁.trans h₀ | exact False.elim (absurd_order hij (by decide))

theorem of_schmidt {s : ℝ} (c : Fin 3 → ℝ) (hc : Antitone c) (hn : ∀ i, 0 ≤ c i)
    (hw : (c 0)^2+(c 1)^2+(c 2)^2=1) (hs : 2*s ≤ value c) :
    Compatible s (2*c 0*c 1) ((c 0)^2) ((c 1)^2) ((c 2)^2) := by
  have h01 : c 1 ≤ c 0 := hc (by decide : (0 : Fin 3) ≤ 1)
  have h12 : c 2 ≤ c 1 := hc (by decide : (1 : Fin 3) ≤ 2)
  refine ⟨sq_nonneg _, (sq_le_sq₀ (hn 2) (hn 1)).mpr h12,
    (sq_le_sq₀ (hn 1) (hn 0)).mpr h01, hw, ?_, ?_⟩
  · rw [← mul_pow, Real.sqrt_sq (mul_nonneg (hn 0) (hn 1))]
    ring
  · rw [show 1-(c 2)^2 = (c 0)^2+(c 1)^2 by linarith,
      show (2*c 0*c 1)^2 = 4*(c 0)^2*(c 1)^2 by ring]
    dsimp [value] at hs
    linarith

theorem to_schmidt {s w a b p : ℝ} (h : Compatible s w a b p) :
    ∃ c : Fin 3 → ℝ, Antitone c ∧ (∀ i, 0 ≤ c i) ∧
      (c 0)^2+(c 1)^2+(c 2)^2=1 ∧ 2*s ≤ value c ∧ 2*c 0*c 1 = w := by
  obtain ⟨hp,hpb,hba,hn,hw,hs⟩ := h
  have hb := hp.trans hpb
  have ha := hb.trans hba
  let c : Fin 3 → ℝ := ![Real.sqrt a, Real.sqrt b, Real.sqrt p]
  have h0 : c 0 = Real.sqrt a := rfl
  have h1 : c 1 = Real.sqrt b := rfl
  have h2 : c 2 = Real.sqrt p := rfl
  have h01 : c 1 ≤ c 0 := Real.sqrt_le_sqrt hba
  have h12 : c 2 ≤ c 1 := Real.sqrt_le_sqrt hpb
  have hs0 : (c 0)^2=a := Real.sq_sqrt ha
  have hs1 : (c 1)^2=b := Real.sq_sqrt hb
  have hs2 : (c 2)^2=p := Real.sq_sqrt hp
  have hprod : 2*c 0*c 1=w := by rw [h0, h1, hw, Real.sqrt_mul ha]; ring
  refine ⟨c, ?_, ?_, by rwa [hs0,hs1,hs2], ?_, hprod⟩
  · exact antitone_three h01 h12
  · intro i
    fin_cases i <;> apply Real.sqrt_nonneg
  · have hw2 : w^2=4*a*b := by rw [hw,mul_pow,Real.sq_sqrt (mul_nonneg ha hb)]; ring
    dsimp [value]
    rw [hs0,hs1,hs2]
    rw [show 1-p=a+b by linarith, hw2] at hs
    linarith
end
end CHSHFrontier
