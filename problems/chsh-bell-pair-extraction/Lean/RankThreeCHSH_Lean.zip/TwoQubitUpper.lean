import TwoQubitCoordinates
import TwoQubitVectors
import CHSHClassical

/-! The pure two-qubit CHSH bound applies to arbitrary, potentially
unnormalized, complex two-by-two amplitude matrices. -/
namespace TwoQubit
open CHSH
open scoped BigOperators Matrix
noncomputable section

theorem upper (F A0 A1 B0 B1 : Q) (hA0 : Observable A0) (hA1 : Observable A1)
    (hB0 : Observable B0) (hB1 : Observable B1) :
    chsh F A0 A1 B0 B1 ≤ 2 * Real.sqrt ((weight F)^2 + 4*Complex.normSq F.det) := by
  let k := 4*Complex.normSq F.det
  have hk : 0≤k := mul_nonneg (by norm_num) (Complex.normSq_nonneg _)
  by_cases h : A0=1 ∨ A0= -1 ∨ A1=1 ∨ A1= -1 ∨ B0=1 ∨ B0= -1 ∨ B1=1 ∨ B1= -1
  · have hh := CHSHClassical.degenerate F A0 A1 B0 B1 hA0 hA1 hB0 hB1 h
    have hm : weight F ≤ Real.sqrt ((weight F)^2+k) := by
      have hroot := Real.sq_sqrt (show 0 ≤ (weight F)^2+k by positivity)
      have hpos := Real.sqrt_nonneg ((weight F)^2+k)
      nlinarith [sq_nonneg (weight F - Real.sqrt ((weight F)^2+k))]
    simpa only [k] using hh.trans (by linarith : 2*weight F ≤ 2*Real.sqrt ((weight F)^2+k))
  simp only [not_or] at h
  obtain ⟨a,ha,rfl⟩ := ((pauli_or_scalar hA0).resolve_left h.1).resolve_left h.2.1
  obtain ⟨b,hb,rfl⟩ := ((pauli_or_scalar hA1).resolve_left h.2.2.1).resolve_left h.2.2.2.1
  obtain ⟨c,hc,rfl⟩ := ((pauli_or_scalar hB0).resolve_left h.2.2.2.2.1).resolve_left h.2.2.2.2.2.1
  obtain ⟨d,hd,rfl⟩ := ((pauli_or_scalar hB1).resolve_left h.2.2.2.2.2.2.1).resolve_left h.2.2.2.2.2.2.2
  rw [chsh,corr_pauli,corr_pauli,corr_pauli,corr_pauli]
  have had : imageVec F (c+d) = imageVec F c + imageVec F d := by
    funext i; simp [imageVec, mul_add, Finset.sum_add_distrib]
  have hsu : imageVec F (c-d) = imageVec F c - imageVec F d := by
    funext i; simp [imageVec, mul_sub, Finset.sum_sub_distrib]
  have H := directions_bound (imageVec F) (bobVector F) a b c d k hk ha hb hc hd had hsu (image_sq F)
  rw [bob_sq] at H
  have hh : 2*k+((weight F)^2 -4*Complex.normSq F.det) = (weight F)^2+4*Complex.normSq F.det := by dsimp [k]; ring
  rwa [hh] at H

#print axioms upper
end
end TwoQubit
