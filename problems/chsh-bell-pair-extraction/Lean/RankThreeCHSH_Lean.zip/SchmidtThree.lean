import CHSHDefs
import Mathlib.Analysis.Matrix.Spectrum
import Mathlib.Analysis.Matrix.PosDef
import Mathlib.Tactic

/-! Singular-value decomposition as a Schmidt decomposition of a complex
three-by-three amplitude matrix. The proof completes only the left singular
vectors belonging to nonzero singular values, so repeated and zero Schmidt
coefficients need no special conventions. -/
namespace CHSHSchmidt
open scoped BigOperators Matrix InnerProductSpace ComplexConjugate
open CHSH Matrix
noncomputable section
private abbrev I := Fin 3
private abbrev E := EuclideanSpace ℂ I

private def columns (b : OrthonormalBasis I ℂ E) : Matrix.unitaryGroup I ℂ :=
  ⟨(EuclideanSpace.basisFun I ℂ).toBasis.toMatrix b.toBasis,
    (EuclideanSpace.basisFun I ℂ).toMatrix_orthonormalBasis_mem_unitary b⟩

private theorem columns_apply (b : OrthonormalBasis I ℂ E) (i j : I) :
    (columns b).val i j = b j i := rfl

private def transposeU (V : Matrix.unitaryGroup I ℂ) : Matrix.unitaryGroup I ℂ := by
  refine ⟨V.valᵀ, ?_, ?_⟩
  · have h := congrArg Matrix.transpose (show V.val * V.valᴴ = 1 from V.property.2)
    simpa only [Matrix.transpose_mul,Matrix.transpose_one,Matrix.transpose_conjTranspose,
      Matrix.star_eq_conjTranspose,Matrix.conjTranspose_transpose] using h
  · have h := congrArg Matrix.transpose (show V.valᴴ * V.val = 1 from V.property.1)
    simpa only [Matrix.transpose_mul,Matrix.transpose_one,Matrix.transpose_conjTranspose,
      Matrix.star_eq_conjTranspose,Matrix.conjTranspose_transpose] using h

private theorem inner_gram (F : Mat I) (x y : E) :
    ⟪F.toEuclideanLin x, F.toEuclideanLin y⟫_ℂ = ⟪x, (Fᴴ*F).toEuclideanLin y⟫_ℂ := by
  simp only [EuclideanSpace.inner_eq_star_dotProduct, Matrix.ofLp_toLpLin,Matrix.toLin'_apply]
  rw [dotProduct_comm, star_mulVec, ← dotProduct_mulVec, mulVec_mulVec, dotProduct_comm]

/-- Every amplitude matrix has nonnegative Schmidt coefficients in
decreasing order. The right basis acts by transpose in this convention. -/
theorem factor (F : Mat (Fin 3)) :
    ∃ (U V : Matrix.unitaryGroup (Fin 3) ℂ) (c : Fin 3 → ℝ),
      Antitone c ∧ (∀ i, 0 ≤ c i) ∧
      F = U.val * Matrix.diagonal (fun i => (c i:ℂ)) * V.valᵀ := by
  classical
  let hp := (Matrix.isHermitian_conjTranspose_mul_self F)
  let hs := Matrix.isHermitian_iff_isSymmetric.mp hp
  have card : Module.finrank ℂ E = 3 := finrank_euclideanSpace_fin
  let b := hs.eigenvectorBasis card
  let l := hs.eigenvalues card
  let u (i : I) : E := F.toEuclideanLin (b i)
  have inn (i j : I) : ⟪u i,u j⟫_ℂ = (l j:ℂ) * (if i=j then 1 else 0) := by
    rw [show ⟪u i, u j⟫_ℂ = ⟪b i, (Fᴴ*F).toEuclideanLin (b j)⟫_ℂ from inner_gram _ _ _]
    rw [show (Fᴴ*F).toEuclideanLin (b j) = (l j:ℂ) • b j from hs.apply_eigenvectorBasis card j]
    rw [inner_smul_right,orthonormal_iff_ite.mp b.orthonormal]
  have normu (i:I) : ‖u i‖^2 = l i := by
    rw [← @inner_self_eq_norm_sq ℂ E _ _ _ (u i),inn]; simp
  have ln (i:I) : 0 ≤ l i := by rw [← normu]; positivity
  let c i := Real.sqrt (l i)
  have cs (i:I) : (c i)^2 = l i := Real.sq_sqrt (ln i)
  have cn (i:I) : 0≤c i := Real.sqrt_nonneg _
  let v (i:I) : E := (c i:ℂ)⁻¹ • u i
  let S : Set I := {i | c i ≠ 0}
  have ortho : Orthonormal ℂ (S.restrict v) := by
    rw [orthonormal_iff_ite]; intro i j
    change ⟪(c i:ℂ)⁻¹ • u i, (c j:ℂ)⁻¹ • u j⟫_ℂ = _
    rw [inner_smul_left,inner_smul_right,inn]
    simp only [map_inv₀, Complex.conj_ofReal]
    by_cases e : i=j
    · subst j
      rw [← cs]
      have ne : (c i : ℂ) ≠ 0 := by exact_mod_cast (show c i ≠ 0 from i.property)
      push_cast
      field_simp
    · have e' : (i:I) ≠ (j:I) := fun h => e (Subtype.ext h)
      simp [e,e']
  obtain ⟨a,ha⟩ := Orthonormal.exists_orthonormalBasis_extension_of_card_eq (by simp [card]) ortho
  have col (j:I) : u j = (c j:ℂ) • a j := by
    by_cases hj : c j = 0
    · have hz : ‖u j‖=0 := by nlinarith [normu j,cs j,norm_nonneg (u j)]
      simp [norm_eq_zero.mp hz,hj]
    · rw [ha j hj]; simp [v,smul_smul,hj]
  let U := columns a
  let W := columns b
  let V := transposeU (star W)
  have vt : V.valᵀ = W.valᴴ := by change (W.valᴴᵀ)ᵀ=W.valᴴ; rw [Matrix.transpose_transpose]
  have prod : F * W.val = U.val * diagonal (fun i => (c i:ℂ)) := by
    apply Matrix.ext; intro i j
    rw [Matrix.mul_diagonal]
    change (∑ k, F i k * columns b k j) = columns a i j * (c j:ℂ)
    simp only [columns_apply]
    have h := congrArg (fun z:E => z i) (col j)
    change (∑ k, F i k * b j k) = (c j:ℂ) * (a j i) at h
    rw [mul_comm]; exact h
  refine ⟨U,V,c,fun i j hij => Real.sqrt_le_sqrt (hs.eigenvalues_antitone card hij),cn, ?_⟩
  rw [vt,← prod,Matrix.mul_assoc,show W.val*W.valᴴ=1 from W.property.2,Matrix.mul_one]

#print axioms factor
end
end CHSHSchmidt
