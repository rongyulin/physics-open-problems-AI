import CHSHDefs
import Mathlib.Analysis.Matrix.Order
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

/-! A deterministic measurement on either party enforces the usual classical CHSH bound.
The input amplitudes are unnormalized and all four correlations are unconditional. -/
namespace CHSHClassical
open CHSH Matrix
open scoped Matrix BigOperators Kronecker ComplexOrder
noncomputable section
variable {m n : Type*} [Fintype m] [Fintype n] [DecidableEq m] [DecidableEq n]

theorem neg_observable {A : Mat m} (h : Observable A) : Observable (-A) :=
  ⟨h.1.neg, by simpa using h.2⟩

theorem plus_pos {A : Mat m} (h : Observable A) : (1+A).PosSemidef := by
  have hh := Matrix.posSemidef_conjTranspose_mul_self (1+A)
  simp only [Matrix.conjTranspose_add, Matrix.conjTranspose_one, h.1.eq,
    add_mul, mul_add, mul_one, one_mul, h.2] at hh
  have hs := hh.smul (a := (1/2:ℝ)) (by norm_num)
  convert hs using 1
  ext i j
  simp only [Matrix.smul_apply, Matrix.add_apply, Complex.real_smul]
  push_cast
  ring

omit [DecidableEq m] [DecidableEq n] in
/-- The correlation of two positive observables is nonnegative in any bipartite state. -/
private theorem corr_pos (F : Matrix m n ℂ) {A : Mat m} {B : Mat n}
    (ha : A.PosSemidef) (hb : B.PosSemidef) : 0 ≤ corr F A B := by
  let v : m × n → ℂ := fun p => F p.1 p.2
  have h := (ha.kronecker hb).dotProduct_mulVec_nonneg v
  have hr := (Complex.nonneg_iff.mp h).1
  simpa [corr, dotProduct, mulVec, v, Fintype.sum_prod_type, Finset.mul_sum,
    Matrix.kronecker_apply, mul_assoc] using hr

omit [DecidableEq m] [DecidableEq n] in
private theorem corr_add_l (F : Matrix m n ℂ) (A C : Mat m) (B : Mat n) :
    corr F (A+C) B = corr F A B + corr F C B := by
  simp [corr, add_mul, mul_add, Finset.sum_add_distrib]

omit [DecidableEq m] [DecidableEq n] in
private theorem corr_add_r (F : Matrix m n ℂ) (A : Mat m) (B D : Mat n) :
    corr F A (B+D) = corr F A B + corr F A D := by
  simp [corr, add_mul, mul_add, Finset.sum_add_distrib]

omit [DecidableEq m] [DecidableEq n] in
private theorem corr_neg_l (F : Matrix m n ℂ) (A : Mat m) (B : Mat n) :
    corr F (-A) B = -corr F A B := by simp [corr, Finset.sum_neg_distrib]

omit [DecidableEq m] [DecidableEq n] in
private theorem corr_neg_r (F : Matrix m n ℂ) (A : Mat m) (B : Mat n) :
    corr F A (-B) = -corr F A B := by simp [corr, Finset.sum_neg_distrib]

private theorem corr_one (F : Matrix m n ℂ) : corr F 1 1 = weight F := by
  simp [corr, weight, Matrix.one_apply, mul_ite, ite_mul, Complex.normSq_apply]

private theorem signs (F : Matrix m n ℂ) {A : Mat m} {B : Mat n}
    (ha : Observable A) (hb : Observable B) :
    0 ≤ weight F + corr F A 1 + corr F 1 B + corr F A B ∧
    0 ≤ weight F + corr F A 1 - corr F 1 B - corr F A B ∧
    0 ≤ weight F - corr F A 1 + corr F 1 B - corr F A B ∧
    0 ≤ weight F - corr F A 1 - corr F 1 B + corr F A B := by
  have hpp := corr_pos F (plus_pos ha) (plus_pos hb)
  have hpm := corr_pos F (plus_pos ha) (plus_pos (neg_observable hb))
  have hmp := corr_pos F (plus_pos (neg_observable ha)) (plus_pos hb)
  have hmm := corr_pos F (plus_pos (neg_observable ha)) (plus_pos (neg_observable hb))
  simp only [corr_add_l, corr_add_r, corr_neg_l, corr_neg_r, corr_one] at *
  exact ⟨by linarith, by linarith, by linarith, by linarith⟩

/-- A deterministic dichotomic observable forces the unconditional classical bound, for
arbitrary local finite dimensions and without any normalization of the coefficient matrix. -/
theorem degenerate (F : Matrix m n ℂ) (A₀ A₁ : Mat m) (B₀ B₁ : Mat n)
    (ha₀ : Observable A₀) (ha₁ : Observable A₁)
    (hb₀ : Observable B₀) (hb₁ : Observable B₁)
    (h : A₀=1 ∨ A₀=-1 ∨ A₁=1 ∨ A₁=-1 ∨ B₀=1 ∨ B₀=-1 ∨ B₁=1 ∨ B₁=-1) :
    chsh F A₀ A₁ B₀ B₁ ≤ 2 * weight F := by
  obtain ⟨p₀₀,q₀₀,r₀₀,s₀₀⟩ := signs F ha₀ hb₀
  obtain ⟨p₀₁,q₀₁,r₀₁,s₀₁⟩ := signs F ha₀ hb₁
  obtain ⟨p₁₀,q₁₀,r₁₀,s₁₀⟩ := signs F ha₁ hb₀
  obtain ⟨p₁₁,q₁₁,r₁₁,s₁₁⟩ := signs F ha₁ hb₁
  rcases h with h|h|h|h|h|h|h|h <;> subst_vars <;>
    simp only [chsh, corr_neg_l, corr_neg_r, corr_one] at * <;> linarith

end
end CHSHClassical
