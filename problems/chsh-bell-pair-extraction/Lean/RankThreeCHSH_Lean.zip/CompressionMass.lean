import Mathlib.Analysis.Matrix.PosDef
import Mathlib.Tactic
namespace CHSHCompression
open Matrix
open scoped Matrix BigOperators ComplexConjugate ComplexOrder
noncomputable section

def mass {n : Type*} [Fintype n] (v : n → ℂ) : ℝ := ∑ i, Complex.normSq (v i)

theorem mass_complex {n : Type*} [Fintype n] (v : n → ℂ) :
    (mass v : ℂ) = star v ⬝ᵥ v := by
  simp only [mass, Complex.ofReal_sum, Complex.normSq_eq_conj_mul_self, dotProduct]
  rfl

theorem mass_unitary {n : Type*} [Fintype n] [DecidableEq n]
    (U : unitary (Matrix n n ℂ)) (v : n → ℂ) :
    mass ((U : Matrix n n ℂ) *ᵥ v) = mass v := by
  apply Complex.ofReal_injective
  rw [mass_complex, mass_complex, star_mulVec, dotProduct_mulVec, vecMul_vecMul,
    ← Matrix.star_eq_conjTranspose, Unitary.coe_star_mul_self, vecMul_one]

end
end CHSHCompression
