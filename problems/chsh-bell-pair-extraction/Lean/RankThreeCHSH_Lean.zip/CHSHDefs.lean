import Mathlib.LinearAlgebra.Matrix.Hermitian
import Mathlib.LinearAlgebra.Matrix.Notation
import Mathlib.Analysis.Complex.Norm
import Mathlib.Data.Complex.BigOperators

/-! Unnormalized bipartite pure-state amplitudes and their CHSH correlation.
All matrices and amplitudes use the ordinary computational basis. -/
namespace CHSH
open scoped Matrix BigOperators
noncomputable section

abbrev Qutrit := Fin 3
abbrev Mat (n : Type*) := Matrix n n ℂ

def Observable {n : Type*} [Fintype n] [DecidableEq n] (A : Mat n) : Prop :=
  A.IsHermitian ∧ A * A = 1

def weight {m n : Type*} [Fintype m] [Fintype n] (F : Matrix m n ℂ) : ℝ :=
  ∑ i, ∑ j, Complex.normSq (F i j)

/-- Real part of the expectation of A ⊗ B in the bipartite vector F. -/
def corr {m n : Type*} [Fintype m] [Fintype n]
    (F : Matrix m n ℂ) (A : Mat m) (B : Mat n) : ℝ :=
  (∑ i, ∑ j, ∑ k, ∑ l, star (F i j) * A i k * B j l * F k l).re

def chsh {m n : Type*} [Fintype m] [Fintype n]
    (F : Matrix m n ℂ) (A₀ A₁ : Mat m) (B₀ B₁ : Mat n) : ℝ :=
  corr F A₀ B₀ + corr F A₀ B₁ + corr F A₁ B₀ - corr F A₁ B₁

def block (A : Mat (Fin 2)) (a : ℝ) : Mat Qutrit :=
  !![A 0 0, A 0 1, 0; A 1 0, A 1 1, 0; 0, 0, (a : ℂ)]

def top (F : Mat Qutrit) : Mat (Fin 2) := F.submatrix Fin.castSucc Fin.castSucc

end
end CHSH
