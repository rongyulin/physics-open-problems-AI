import QutritMixedBound
import CHSHClassical
namespace CHSHMixed
open CHSH QutritCHSH Matrix
open scoped BigOperators Matrix ComplexOrder
noncomputable section

theorem binary_of_observable {n : Type*} [Fintype n] [DecidableEq n] {A : Mat n}
    (h : Observable A) : Binary A := by
  refine ⟨CHSHClassical.plus_pos h,?_⟩
  simpa only [sub_eq_add_neg] using CHSHClassical.plus_pos (CHSHClassical.neg_observable h)

/-- All CHSH scores of all mixed extensions on a finite Bob system of the
specified qutrit marginal, in its eigenbasis. -/
def extensionScores (c : Fin 3 → ℝ) : Set ℝ := {z | ∃ (n : ℕ) (R : Mat (Fin 3 × Fin n)),
  R.PosSemidef ∧ marginal R = diagonal (fun i => (c i:ℂ)^2) ∧
    ∃ (A X : Mat (Fin 3)) (B Y : Mat (Fin n)),
      Binary A ∧ Binary X ∧ Binary B ∧ Binary Y ∧ mixedCHSH R A X B Y = z}

/-- The best score over all mixed extensions and all binary POVMs is attained
on a purification with Bob a qutrit. Subnormalized marginals are also allowed. -/
theorem exact_extensions (c : Fin 3 → ℝ) (hc : Antitone c) (hn : ∀ i, 0 ≤ c i) :
    IsGreatest (extensionScores c) (value c) := by
  constructor
  · obtain ⟨A,X,B,Y,ha,hx,hb,hy,hh⟩ := state_attained c
    refine ⟨3,rankOne (state c),rankOne_positive _,marginal_schmidt c,A,X,B,Y,
      binary_of_observable ha,binary_of_observable hx,binary_of_observable hb,binary_of_observable hy,?_⟩
    simpa only [mixedCHSH,rankOne_corr,CHSH.chsh] using hh
  · rintro z ⟨n,R,hR,hm,A,X,B,Y,ha,hx,hb,hy,rfl⟩
    exact mixed_upper c hc hn R hR hm A X B Y ha hx hb hy

#print axioms exact_extensions
end
end CHSHMixed
