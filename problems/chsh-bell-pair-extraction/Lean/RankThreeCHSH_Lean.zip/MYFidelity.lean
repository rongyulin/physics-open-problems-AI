import CHSHDefs
import Mathlib.Analysis.Matrix.PosDef
import Mathlib.Tactic

/-! Singlet extraction for a pure state of Schmidt rank at most three.
The output coordinates are (ancilla Schmidt index, extracted qubit).
A reference singlet times a pure ancillary state has two equal Schmidt
amplitudes d j for every ancillary Schmidt index j. -/
namespace MYFidelity
open Matrix CHSH
open scoped BigOperators Matrix ComplexOrder
noncomputable section

abbrev Site (n : ℕ) := Fin (n+2) × Fin 2
abbrev Embed (n : ℕ) := Matrix (Site n) (Fin 3) ℂ

/-- The row index is an output basis vector and the column index an input
basis vector. The equality expresses preservation of the inner product. -/
def IsEmbedding {n : ℕ} (U : Embed n) := Uᴴ * U = 1

private def weight {n : ℕ} (U : Embed n) (j : Fin (n+2)) (i : Fin 3) : ℝ :=
  ∑ k : Fin 2, Complex.normSq (U (j,k) i)

private theorem col_mass {n : ℕ} {U : Embed n} (h : IsEmbedding U) (i : Fin 3) :
    ∑ j, weight U j i = 1 := by
  have e := congrArg (fun M : Mat (Fin 3) => (M i i).re) h
  simpa [weight, Matrix.mul_apply, Matrix.conjTranspose_apply, Fintype.sum_prod_type,
    Complex.star_def, Complex.mul_re, Complex.normSq_apply] using e

private theorem row_mass {n : ℕ} {U : Embed n} (h : IsEmbedding U) (j : Site n) :
    ∑ i, Complex.normSq (U j i) ≤ 1 := by
  let P := U * Uᴴ
  have hP : P * P = P := by
    change (U * Uᴴ) * (U * Uᴴ) = _
    rw [← Matrix.mul_assoc, Matrix.mul_assoc U Uᴴ, h, Matrix.mul_one]
  have hPs : Pᴴ = P := by simp [P]
  have hn := Matrix.posSemidef_conjTranspose_mul_self (1-P)
  have e : (1-P)ᴴ*(1-P) = 1-P := by
    rw [Matrix.conjTranspose_sub, Matrix.conjTranspose_one, hPs,
      Matrix.mul_sub, Matrix.sub_mul, Matrix.sub_mul, Matrix.one_mul,
      Matrix.one_mul, Matrix.mul_one, hP]
    abel
  rw [e] at hn
  have hz := (Complex.nonneg_iff.mp (show 0 ≤ (1-P) j j from hn.diag_nonneg)).1
  simp [P, Matrix.mul_apply, Matrix.conjTranspose_apply, Complex.mul_re,
    Complex.normSq_apply, Finset.sum_add_distrib] at hz ⊢
  linarith

private theorem oneSide {n : ℕ} {U : Embed n} (h : IsEmbedding U)
    (a b c : ℝ) (hab : b ≤ a) (hbc : c ≤ b) (hc : 0 ≤ c)
    (d : Fin (n+2) → ℝ) (hd : Antitone d) :
    (∑ i : Fin 3, ![a,b,c] i * ∑ j, d j * weight U j i) ≤
      (a+b)*d 0 + c*d 1 := by
  have hw (j i) : 0 ≤ weight U j i := Finset.sum_nonneg fun _ _ => Complex.normSq_nonneg _
  have h0 (i : Fin 3) : weight U 0 i ≤ 1 := by
    rw [← col_mass h i]
    exact Finset.single_le_sum (fun j _ => hw j i) (Finset.mem_univ _)
  have htotal : ∑ i, weight U 0 i ≤ 2 := by
    simp only [weight, Fin.sum_univ_two, Finset.sum_add_distrib]
    linarith [row_mass h (0,0), row_mass h (0,1)]
  have hcol (i : Fin 3) : (∑ j, d j * weight U j i) ≤
      d 1 + (d 0 - d 1) * weight U 0 i := by
    have tail : (∑ j : Fin (n+1), d j.succ * weight U j.succ i) ≤
        ∑ j : Fin (n+1), d 1 * weight U j.succ i := by
      apply Finset.sum_le_sum
      intro j _
      exact mul_le_mul_of_nonneg_right (hd (by change 1 ≤ j.val+1; omega)) (hw _ _)
    have H := col_mass h i
    rw [Fin.sum_univ_succ] at H ⊢
    rw [← Finset.mul_sum] at tail
    rw [show (∑ j : Fin (n+1), weight U j.succ i) = 1 - weight U 0 i by linarith] at tail
    linarith
  have hw3 : 0 ≤ ![a,b,c] := by
    intro i
    fin_cases i <;> simp <;> linarith
  have first : (∑ i : Fin 3, ![a,b,c] i * weight U 0 i) ≤ a+b := by
    simp [Fin.sum_univ_three] at htotal ⊢
    nlinarith [mul_nonneg (sub_nonneg.mpr (le_trans hbc hab)) (sub_nonneg.mpr (h0 0)),
      mul_nonneg (sub_nonneg.mpr hbc) (sub_nonneg.mpr (h0 1)),
      mul_nonneg hc (sub_nonneg.mpr htotal)]
  calc
    _ ≤ ∑ i : Fin 3, ![a,b,c] i * (d 1 + (d 0 - d 1) * weight U 0 i) :=
      Finset.sum_le_sum fun i _ => mul_le_mul_of_nonneg_left (hcol i) (hw3 i)
    _ = (a+b+c)*d 1 + (d 0 - d 1) * ∑ i : Fin 3, ![a,b,c] i * weight U 0 i := by
      simp [Fin.sum_univ_three]; ring
    _ ≤ _ := by nlinarith [mul_le_mul_of_nonneg_left first (sub_nonneg.mpr (hd (Fin.zero_le (1 : Fin (n+2)))))]

/-- Inner product of the paired-Schmidt target with the locally embedded
input, in the Schmidt bases of the input and pure ancillary target.
Here 2 * ∑ j, (d j)^2 = 1 normalizes the reference state. -/
def overlap {n : ℕ} (a b c : ℝ) (d : Fin (n+2) → ℝ) (U V : Embed n) : ℂ :=
  ∑ i : Fin 3, ∑ j, ∑ k : Fin 2,
    ((![a,b,c] i * d j : ℝ) : ℂ) * U (j,k) i * V (j,k) i


theorem overlap_upper {n : ℕ} (a b c : ℝ) (hab : b ≤ a) (hbc : c ≤ b) (hc : 0 ≤ c)
    (d : Fin (n+2) → ℝ) (hd : Antitone d) (hn : ∀ j, 0 ≤ d j)
    (hs : 2 * ∑ j, (d j)^2 = 1) (U V : Embed n) (hU : IsEmbedding U) (hV : IsEmbedding V) :
    Complex.normSq (overlap a b c d U V) ≤ ((a+b)^2+c^2)/2 := by
  let s : Fin 3 → ℝ := ![a,b,c]
  have hsi (i : Fin 3) : 0 ≤ s i := by fin_cases i <;> simp [s] <;> linarith
  have hterm (i : Fin 3) (j : Fin (n+2)) (k : Fin 2) :
      ‖((s i * d j : ℝ) : ℂ) * U (j,k) i * V (j,k) i‖ ≤
        s i * d j * ((Complex.normSq (U (j,k) i) + Complex.normSq (V (j,k) i))/2) := by
    simp only [norm_mul, Complex.norm_real, Real.norm_eq_abs,
      abs_of_nonneg (hsi i), abs_of_nonneg (hn j), Complex.normSq_eq_norm_sq]
    rw [mul_assoc]
    exact mul_le_mul_of_nonneg_left (by nlinarith [sq_nonneg (‖U (j,k) i‖ - ‖V (j,k) i‖)])
      (mul_nonneg (hsi i) (hn j))
  have hnorm : ‖overlap a b c d U V‖ ≤ (a+b)*d 0 + c*d 1 := by
    calc
      _ ≤ ∑ i : Fin 3, ∑ j, ∑ k : Fin 2,
          s i * d j * ((Complex.normSq (U (j,k) i) + Complex.normSq (V (j,k) i))/2) := by
        apply (norm_sum_le _ _).trans
        apply Finset.sum_le_sum
        intro i _
        apply (norm_sum_le _ _).trans
        apply Finset.sum_le_sum
        intro j _
        apply (norm_sum_le _ _).trans
        exact Finset.sum_le_sum fun k _ => hterm i j k
      _ = ((∑ i : Fin 3, s i * ∑ j, d j * weight U j i) +
        (∑ i : Fin 3, s i * ∑ j, d j * weight V j i))/2 := by
        simp only [weight, Fin.sum_univ_two, Finset.mul_sum, ← Finset.sum_add_distrib,
          Finset.sum_div]
        apply Finset.sum_congr rfl
        intro i _
        apply Finset.sum_congr rfl
        intro j _
        ring
      _ ≤ _ := by
        have hu := oneSide hU a b c hab hbc hc d hd
        have hv := oneSide hV a b c hab hbc hc d hd
        dsimp [s]
        linarith
  have h01 : (d 0)^2+(d 1)^2 ≤ 1/2 := by
    rw [Fin.sum_univ_succ, Fin.sum_univ_succ] at hs
    have ht : 0 ≤ ∑ j : Fin n, (d j.succ.succ)^2 := Finset.sum_nonneg fun _ _ => sq_nonneg _
    change 2 * (d 0 ^ 2 + (d 1 ^ 2 + ∑ j : Fin n, (d j.succ.succ)^2)) = 1 at hs
    linarith
  have hpow := pow_le_pow_left₀ (norm_nonneg _) hnorm 2
  rw [Complex.normSq_eq_norm_sq]
  nlinarith [sq_nonneg ((a+b)*d 1-c*d 0), mul_le_mul_of_nonneg_left h01
    (add_nonneg (sq_nonneg (a+b)) (sq_nonneg c))]

/-- Isometrically label the first Schmidt pair by the first ancillary
coordinate, and the third occupied Schmidt coordinate by the second one. -/
private def canonical : Embed 0 := fun jk i =>
  if (jk = (0,0) ∧ i=0) ∨ (jk = (0,1) ∧ i=1) ∨ (jk = (1,0) ∧ i=2) then 1 else 0

private theorem canonical_isEmbedding : IsEmbedding canonical := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    norm_num [IsEmbedding, canonical, Matrix.mul_apply, Matrix.conjTranspose_apply,
      Fintype.sum_prod_type, Nat.zero_add, Fin.sum_univ_two, Matrix.one_apply] <;>
    norm_num [Fin.sum_univ_succ, show (0 : Fin 3) ≠ 2 by decide,
      show (1 : Fin 3) ≠ 2 by decide, show (⟨2,by decide⟩ : Fin 3) = 2 by decide]

private theorem canonical_overlap (a b c x y : ℝ) :
    overlap a b c ![x,y] canonical canonical = (((a+b)*x+c*y : ℝ) : ℂ) := by
  simp [overlap, canonical, Fin.sum_univ_three, Fin.sum_univ_two]
  ring

theorem overlap_attained (a b c : ℝ) (hab : b ≤ a) (hbc : c ≤ b) (hc : 0 ≤ c)
    (hs : a^2+b^2+c^2=1) :
    ∃ (d : Fin 2 → ℝ) (U V : Embed 0), Antitone d ∧ (∀ j, 0 ≤ d j) ∧
      (2 * ∑ j, (d j)^2 = 1) ∧ IsEmbedding U ∧ IsEmbedding V ∧
      Complex.normSq (overlap a b c d U V) = (1+2*a*b)/2 := by
  have hden : 0 < 2*((a+b)^2+c^2) := by
    nlinarith [mul_nonneg (show 0 ≤ a by linarith) (show 0 ≤ b by linarith)]
  let t := Real.sqrt (2*((a+b)^2+c^2))
  have ht : 0 < t := Real.sqrt_pos.mpr hden
  have htsq : t^2 = 2*((a+b)^2+c^2) := Real.sq_sqrt hden.le
  let x := (a+b)/t
  let y := c/t
  have hxy : y ≤ x := (div_le_div_iff_of_pos_right ht).mpr (by linarith)
  have hy : 0 ≤ y := div_nonneg hc ht.le
  refine ⟨![x,y], canonical, canonical, ?_, ?_, ?_, canonical_isEmbedding, canonical_isEmbedding, ?_⟩
  · intro i j hij
    fin_cases i <;> fin_cases j <;> simp_all
  · intro i
    fin_cases i <;> simp <;> linarith
  · simp [Fin.sum_univ_two,x,y]
    field_simp
    nlinarith
  · rw [canonical_overlap, Complex.normSq_ofReal]
    dsimp [x,y]
    field_simp
    nlinarith [show (a+b)^2+c^2 = 1+2*a*b by linarith only [hs],
      htsq]

/-- Squared overlaps with a singlet times an arbitrary finite pure
ancilla, after local isometries. Zero-padding allows at least two ancillary
Schmidt positions without restricting any reference or isometry. -/
def scores (a b c : ℝ) : Set ℝ :=
  {r | ∃ (n : ℕ) (d : Fin (n+2) → ℝ) (U V : Embed n),
    Antitone d ∧ (∀ j, 0 ≤ d j) ∧ (2 * ∑ j, (d j)^2 = 1) ∧
      IsEmbedding U ∧ IsEmbedding V ∧ Complex.normSq (overlap a b c d U V) = r}

theorem operational (a b c : ℝ) (hab : b ≤ a) (hbc : c ≤ b) (hc : 0 ≤ c)
    (hs : a^2+b^2+c^2=1) : IsGreatest (scores a b c) ((1+2*a*b)/2) := by
  constructor
  · obtain ⟨d,U,V,hd,hn,hp,hu,hv,hm⟩ := overlap_attained a b c hab hbc hc hs
    exact ⟨0,d,U,V,hd,hn,hp,hu,hv,hm⟩
  · rintro r ⟨n,d,U,V,hd,hn,hp,hu,hv,rfl⟩
    have H := overlap_upper a b c hab hbc hc d hd hn hp U V hu hv
    linarith only [H, hs]

end
end MYFidelity
