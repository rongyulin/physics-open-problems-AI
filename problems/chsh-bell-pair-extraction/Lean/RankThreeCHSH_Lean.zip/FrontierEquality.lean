import FidelityFrontier

namespace CHSHFrontier
noncomputable section

/-- On the open plateau, a small squared-overlap excess forces the
smallest Schmidt probability close to 1/3. Written without divisions to
include endpoints and the region in which this certificate is vacuous. -/
theorem rigidity_margin {s w a b p : ℝ} (h : Compatible s w a b p) (hs : 1 ≤ s) :
    (1/3-p)*((s-1)*(s+2/3)-w^2) ≤ (s-1)*(w^2-4/9)/4 := by
  obtain ⟨hp,hpb,hba,hn,hw,hscore⟩ := h
  have hp3 : p ≤ 1/3 := by linarith
  have ha : 0 ≤ a := hp.trans (hpb.trans hba)
  have hb : 0 ≤ b := hp.trans hpb
  have hw2 : w^2=4*(a*b) := by rw [hw, mul_pow, Real.sq_sqrt (mul_nonneg ha hb)]; ring
  have hquad : 4*p*(1-2*p) ≤ w^2 := by
    nlinarith [mul_nonneg (sub_nonneg.mpr (hpb.trans hba)) (sub_nonneg.mpr hpb),
      congrArg (fun x : ℝ => p*x) hn]
  have hroot : s-p ≤ Real.sqrt ((1-p)^2+w^2) := by linarith
  have hscore' := (Real.le_sqrt (show 0 ≤ s-p by linarith) (by positivity)).mp hroot
  have hlow : (s-1)*(s+2/3)-w^2 ≤ 2*(s-1)*(p-1/6) := by linarith only [hscore']
  have hhigh : 8*(1/3-p)*(p-1/6) ≤ w^2-4/9 := by linarith only [hquad]
  nlinarith only [mul_le_mul_of_nonneg_right hlow (sub_nonneg.mpr hp3),
    mul_le_mul_of_nonneg_right hhigh (sub_nonneg.mpr hs)]

theorem plateau_unique {s a b p : ℝ} (h : Compatible s (2/3) a b p)
    (hs : switchA < s) : a=1/3 ∧ b=1/3 ∧ p=1/3 := by
  have h41 : (Real.sqrt 41)^2=41 := Real.sq_sqrt (by norm_num)
  have h1 : 1 ≤ switchA := by dsimp [switchA]; nlinarith [Real.sqrt_nonneg 41]
  have he : (switchA-1)*(switchA+2/3)=(2/3:ℝ)^2 := by
    dsimp [switchA]; nlinarith only [h41]
  have hpos : 0 < (s-1)*(s+2/3)-(2/3:ℝ)^2 := by
    nlinarith only [he, mul_pos (sub_pos.mpr hs) (show 0 < s+switchA-1/3 by linarith)]
  have H := rigidity_margin h (h1.trans hs.le)
  have hzero : 1/3-p ≤ 0 := by
    by_contra! hq
    nlinarith only [H,mul_pos hq hpos]
  have hh := h.normalized
  have h2 := h.order₂
  have h3 := h.order₁
  exact ⟨by linarith, by linarith, by linarith⟩

private theorem switch_order : switchA ≤ switchB := by
  have e41 := Real.sq_sqrt (show (0:ℝ) ≤ 41 by norm_num)
  have e2 := Real.sq_sqrt (show (0:ℝ) ≤ 2 by norm_num)
  have upper : Real.sqrt 41 ≤ 13/2 := by nlinarith [Real.sqrt_nonneg 41]
  have lower : 11/8 ≤ Real.sqrt 2 := by nlinarith [Real.sqrt_nonneg 2]
  dsimp [switchA,switchB]
  linarith

private theorem left_witness : Compatible switchA (2/3) (2/3) (1/6) (1/6) := by
  refine ⟨by norm_num, le_rfl, by norm_num, by norm_num, ?_, ?_⟩
  · rw [show (2/3:ℝ)*(1/6)=(1/3)^2 by norm_num, Real.sqrt_sq (by norm_num)]
    norm_num
  · have sq : (1-(1/6:ℝ))^2+(2/3)^2 = (Real.sqrt 41/6)^2 := by
      nlinarith only [Real.sq_sqrt (by norm_num : 0 ≤ (41:ℝ))]
    rw [sq, Real.sqrt_sq (by positivity)]
    dsimp [switchA]
    linarith

theorem plateau_endpoint_iff {a b p : ℝ} : Compatible switchA (2/3) a b p ↔
    (a=1/3 ∧ b=1/3 ∧ p=1/3) ∨ (a=2/3 ∧ b=1/6 ∧ p=1/6) := by
  constructor
  · rintro ⟨hp,hpb,hba,hn,hw,hscore⟩
    have h41 : (Real.sqrt 41)^2=41 := Real.sq_sqrt (by norm_num)
    have h1 : 1 < switchA := by dsimp [switchA]; nlinarith [Real.sqrt_nonneg 41]
    have he : (switchA-1)*(switchA+2/3)=(2/3:ℝ)^2 := by
      dsimp [switchA]; nlinarith only [h41]
    have ha : 0 ≤ a := hp.trans (hpb.trans hba)
    have hb : 0 ≤ b := hp.trans hpb
    have hab : a*b=1/9 := by nlinarith [Real.sq_sqrt (mul_nonneg ha hb)]
    have hp3 : p ≤ 1/3 := by linarith
    have hroot : switchA-p ≤ Real.sqrt ((1-p)^2+(2/3:ℝ)^2) := by linarith
    have hscore' := (Real.le_sqrt (show 0 ≤ switchA-p by linarith) (by positivity)).mp hroot
    have h6 : 1/6 ≤ p := by
      by_contra! hneg
      nlinarith only [he, hscore', mul_pos (sub_pos.mpr h1) (sub_pos.mpr hneg)]
    have hquad : 4*p*(1-2*p) ≤ (2/3:ℝ)^2 := by
      nlinarith [mul_nonneg (sub_nonneg.mpr (hpb.trans hba)) (sub_nonneg.mpr hpb),
        congrArg (fun x : ℝ => p*x) hn]
    have hfac : (1/3-p)*(p-1/6)=0 :=
      le_antisymm (by linarith only [hquad]) (mul_nonneg (by linarith) (by linarith))
    rcases mul_eq_zero.mp hfac with hu | hl
    · left; exact ⟨by linarith,by linarith,by linarith⟩
    · right
      have heq : p=1/6 := sub_eq_zero.mp hl
      have hf : (a-p)*(b-p)=0 := by
        rw [heq]
        linarith only [hab,hn,heq]
      rcases mul_eq_zero.mp hf with ha | hb <;> exact ⟨by linarith,by linarith,by linarith⟩
  · rintro (⟨rfl,rfl,rfl⟩ | ⟨rfl,rfl,rfl⟩)
    · exact middle_witness switchA switch_order
    · exact left_witness

#print axioms plateau_endpoint_iff
#print axioms plateau_unique
#print axioms rigidity_margin
end
end CHSHFrontier
