import QutritCHSH
import CHSHPOVM
import MYFidelity

/-! The state in McKague's 2010 thesis, Eq. (5.59), at flag probability
p=2/3. The product-flag term has amplitude sqrt(2/3), and the Bell-flag
term splits into two Schmidt amplitudes sqrt(1/6). Thus it suffices to
use three dimensions on each Schmidt support. -/
namespace ThesisWitness
open CHSH QutritCHSH
noncomputable section

def t : ℝ := Real.sqrt (1/6)
def coeff : Fin 3 → ℝ := ![2*t,t,t]
def best : ℝ := (1+Real.sqrt 41)/3

private theorem t_sq : t^2=1/6 := Real.sq_sqrt (by norm_num)
private theorem t_nn : 0 ≤ t := Real.sqrt_nonneg _

theorem probabilities : (coeff 0)^2=2/3 ∧ (coeff 1)^2=1/6 ∧ (coeff 2)^2=1/6 := by
  change (2*t)^2=2/3 ∧ t^2=1/6 ∧ t^2=1/6
  exact ⟨by nlinarith only [t_sq],t_sq,t_sq⟩

private theorem ordered : Antitone coeff := by
  intro i j hij
  fin_cases i <;> fin_cases j <;> simp_all [coeff] <;> linarith [t_nn]

private theorem nonnegative (i : Fin 3) : 0 ≤ coeff i := by
  fin_cases i <;> simp [coeff] <;> linarith [t_nn]

theorem actual_value : value coeff = best := by
  obtain ⟨h0,h1,h2⟩ := probabilities
  rw [value,h0,h1,h2]
  have e : ((2/3:ℝ)+1/6)^2+4*(2/3)*(1/6) = (Real.sqrt 41/6)^2 := by
    nlinarith only [Real.sq_sqrt (by norm_num : 0 ≤ (41:ℝ))]
  rw [e, Real.sqrt_sq (by positivity)]
  dsimp [best]; ring

theorem score : IsGreatest (projectiveScores (state coeff)) best := by
  rw [← actual_value]
  exact exact_projective coeff ordered nonnegative

theorem povm_upper (A X B Y : M) (ha : CHSHPOVM.Contraction A)
    (hx : CHSHPOVM.Contraction X) (hb : CHSHPOVM.Contraction B)
    (hy : CHSHPOVM.Contraction Y) : chsh (state coeff) A X B Y ≤ best := by
  obtain ⟨P,Q,R,T,hP,hQ,hR,hT,h⟩ := CHSHPOVM.projectivize (state coeff) A X B Y ha hx hb hy
  exact h.trans (score.2 ⟨P,Q,R,T,hP,hQ,hR,hT,rfl⟩)

theorem fidelity : IsGreatest (MYFidelity.scores (coeff 0) (coeff 1) (coeff 2)) (5/6) := by
  obtain ⟨h0,h1,h2⟩ := probabilities
  have eqv : (1+2*coeff 0*coeff 1)/2=5/6 := by
    change (1+2*(2*t)*t)/2=5/6
    nlinarith only [t_sq]
  rw [← eqv]
  exact MYFidelity.operational _ _ _ (ordered (by decide : (0:Fin 3) ≤ 1))
    (ordered (by decide : (1:Fin 3) ≤ 2)) (nonnegative 2) (by linarith)

theorem proposed_values_are_smaller :
    (1-(2/3:ℝ)/2 = 2/3) ∧ (2/3:ℝ)<5/6 ∧
    2*(2/3)+(1-2/3)*2*Real.sqrt 2 < best := by
  have e41 := Real.sq_sqrt (by norm_num : 0 ≤ (41:ℝ))
  have e2 := Real.sq_sqrt (by norm_num : 0 ≤ (2:ℝ))
  have lo : 6 < Real.sqrt 41 := by nlinarith [Real.sqrt_nonneg 41]
  have hi : Real.sqrt 2 < 3/2 := by nlinarith [Real.sqrt_nonneg 2]
  dsimp [best]
  exact ⟨by norm_num, by norm_num, by linarith⟩

#print axioms score
#print axioms povm_upper
#print axioms fidelity
#print axioms proposed_values_are_smaller
end
end ThesisWitness
