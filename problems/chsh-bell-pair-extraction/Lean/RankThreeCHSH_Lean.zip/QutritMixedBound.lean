import QutritPurification
import QutritCHSH
import CHSHPOVM
namespace CHSHMixed
open CHSH QutritCHSH CHSHPOVM Matrix
open scoped BigOperators Matrix ComplexOrder
noncomputable section
variable {n : Type*} [Fintype n] [DecidableEq n]

/-- The effects (I ± A)/2 of a dichotomic measurement are positive. -/
def Binary (A : Mat n) : Prop := (1+A).PosSemidef ∧ (1-A).PosSemidef

theorem Binary.contraction {A : Mat n} (h : Binary A) : Contraction A := by
  have ha : A.IsHermitian := by
    simpa using h.1.isHermitian.sub (isHermitian_one : (1 : Mat n).IsHermitian)
  exact contraction_of_posSemidef ha h.1 h.2

theorem mixed_upper (c : Fin 3 → ℝ) (hc : Antitone c) (hn : ∀ i, 0 ≤ c i)
    (R : Mat (Fin 3 × n)) (hR : R.PosSemidef)
    (hm : marginal R = diagonal (fun i => (c i : ℂ)^2))
    (A X : Mat (Fin 3)) (B Y : Mat n)
    (hA : Binary A) (hX : Binary X) (hB : Binary B) (hY : Binary Y) :
    mixedCHSH R A X B Y ≤ value c := by
  obtain ⟨f,hf,he⟩ := mixed_reduction R hR c hm
  have hb : Binary (f B) := hf _ hB.1 hB.2
  have hy : Binary (f Y) := hf _ hY.1 hY.2
  obtain ⟨A',X',B',Y',hA',hX',hB',hY',score⟩ :=
    projectivize (state c) A X (f B) (f Y) hA.contraction hX.contraction hb.contraction hy.contraction
  apply le_trans _ (QutritCHSH.upper c hc hn _ _ _ _ hA' hX' hB' hY')
  simpa only [mixedCHSH,he,CHSH.chsh,QutritCHSH.state] using score

/-- Rank-one density matrix of an arbitrary rectangular coefficient matrix. -/
def rankOne (F : Matrix (Fin 3) n ℂ) : Mat (Fin 3 × n) :=
  fun i j => F i.1 i.2 * star (F j.1 j.2)

omit [DecidableEq n] in
theorem rankOne_positive (F : Matrix (Fin 3) n ℂ) : (rankOne F).PosSemidef := by
  let v : Matrix (Fin 3 × n) Unit ℂ := fun i _ => F i.1 i.2
  have h : rankOne F = v*vᴴ := by ext i j; simp [rankOne,v,Matrix.mul_apply]
  rw [h]
  exact posSemidef_self_mul_conjTranspose _

theorem marginal_schmidt (c : Fin 3 → ℝ) :
    marginal (rankOne (state c)) = diagonal (fun i => (c i:ℂ)^2) := by
  ext i k
  fin_cases i <;> fin_cases k <;>
    simp [marginal,rankOne,state,Matrix.diagonal,pow_two]

omit [DecidableEq n] in
theorem rankOne_corr (F : Matrix (Fin 3) n ℂ) (A : Mat (Fin 3)) (B : Mat n) :
    mixedCorr (rankOne F) A B = corr F A B := by
  simp only [mixedCorr,rankOne,corr]
  congr 1
  apply Finset.sum_congr rfl
  intro i _
  apply Finset.sum_congr rfl
  intro j _
  apply Finset.sum_congr rfl
  intro k _
  apply Finset.sum_congr rfl
  intro l _
  ring

#print axioms mixed_upper
end
end CHSHMixed
