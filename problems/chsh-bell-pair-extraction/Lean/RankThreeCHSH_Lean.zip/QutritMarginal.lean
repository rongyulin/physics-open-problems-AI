import QutritMarginalBasis
import SchmidtThree

namespace CHSHMixed
open CHSH Matrix QutritCHSH
open scoped Matrix MatrixOrder ComplexOrder
noncomputable section

/-- For any positive qutrit marginal, its decreasing eigenvalues are the
squares of three nonnegative amplitudes. Its exact extension optimum is
attained on a qutrit purification. No eigenbasis is supplied as input. -/
theorem fixed_marginal_maximum (M : Mat (Fin 3)) (hM : M.PosSemidef) :
    ∃ (U : unitaryGroup (Fin 3) ℂ) (c : Fin 3 → ℝ),
      Antitone c ∧ (∀ i, 0 ≤ c i) ∧
      U.valᴴ*M*U.val = diagonal (fun i => (c i:ℂ)^2) ∧
      IsGreatest (extensionScoresAt M) (value c) := by
  obtain ⟨K,hK⟩ := CStarAlgebra.nonneg_iff_eq_star_mul_self.mp hM.nonneg
  have fac : M = Kᴴ*(Kᴴ)ᴴ := by simpa only [conjTranspose_conjTranspose] using hK
  obtain ⟨U,V,c,hc,hn,hF⟩ := CHSHSchmidt.factor Kᴴ
  change Kᴴ = U.val*state c*V.valᵀ at hF
  have hu : U.valᴴ*U.val=1 := U.property.1
  have hv : V.valᴴ*V.val=1 := V.property.1
  have ht : V.valᵀ*(V.valᵀ)ᴴ=1 := by
    simpa only [transpose_mul,transpose_conjTranspose,conjTranspose_transpose,transpose_one]
      using congrArg Matrix.transpose hv
  have hdiag : U.valᴴ*M*U.val=diagonal (fun i => (c i:ℂ)^2) := by
    rw [fac,hF,conjTranspose_mul,conjTranspose_mul]
    calc
      _ = (U.valᴴ*U.val)*(state c)*(V.valᵀ*(V.valᵀ)ᴴ)*(state c)ᴴ*(U.valᴴ*U.val) := by
        simp only [Matrix.mul_assoc]
      _ = _ := by
        rw [hu,ht,Matrix.one_mul,Matrix.mul_one,Matrix.mul_one]
        simp [state,diagonal_mul_diagonal,pow_two]
  exact ⟨U,c,hc,hn,hdiag,exact_extensions_spectral c hc hn U M hdiag⟩

#print axioms fixed_marginal_maximum
end
end CHSHMixed
