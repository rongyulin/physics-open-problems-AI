import CHSHDefs
import Mathlib.Data.Matrix.Block
import Mathlib.Tactic

/-! Equal Schmidt amplitudes in each of any finite number of pairs, plus one
unpaired amplitude. All paired blocks use the same four projective measurements. -/
namespace CHSHOddAttain
open CHSH Matrix
open scoped Matrix BigOperators
noncomputable section

abbrev Blocks (ι : Type*) := (Fin 2 × ι) ⊕ Unit

/-- The two vectors of each pair have amplitude `c i`, the singleton has amplitude `t`. -/
def amplitude {ι : Type*} (c : ι → ℝ) (t : ℝ) : Blocks ι → ℝ :=
  Sum.elim (fun p => c p.2) (fun _ => t)

private def spin (x y : ℝ) : Mat (Fin 2) :=
  !![(x : ℂ), (y : ℂ); (y : ℂ), -(x : ℂ)]

private theorem spin_reflect (x y : ℝ) (h : x^2+y^2=1) : Observable (spin x y) := by
  have hc : (x : ℂ)^2+(y : ℂ)^2=1 := by exact_mod_cast h
  constructor
  · ext i j
    fin_cases i <;> fin_cases j <;> simp [spin, Matrix.conjTranspose_apply]
  · ext i j
    fin_cases i <;> fin_cases j <;> simp [spin, Matrix.mul_apply, Fin.sum_univ_two] <;>
      first | linear_combination hc | ring

private def extend {ι : Type*} [DecidableEq ι] (A : Mat (Fin 2)) : Mat (Blocks ι) :=
  fromBlocks (blockDiagonal fun _ : ι => A) 0 0 1

private theorem extend_reflect {ι : Type*} [DecidableEq ι] [Fintype ι] {A : Mat (Fin 2)}
    (ha : Observable A) : Observable (extend (ι := ι) A) := by
  constructor
  · simp only [IsHermitian, extend, fromBlocks_conjTranspose, blockDiagonal_conjTranspose,
      Matrix.conjTranspose_zero, Matrix.conjTranspose_one, ha.1.eq]
  · simp only [extend, fromBlocks_multiply, ← blockDiagonal_mul, ha.2, Matrix.zero_mul, Matrix.mul_zero,
      add_zero, zero_add, one_mul]
    change fromBlocks (blockDiagonal (1 : ι → Mat (Fin 2))) 0 0 (1 : Mat Unit) = _
    rw [blockDiagonal_one, fromBlocks_one]

private theorem diagonal_corr {N : Type*} [Fintype N] [DecidableEq N]
    (f : N → ℝ) (A B : Mat N) :
    corr (diagonal fun i => (f i : ℂ)) A B =
      (∑ i, ∑ k, (f i : ℂ) * A i k * B i k * (f k : ℂ)).re := by
  simp [corr, Matrix.diagonal_apply, apply_ite, ite_mul]

private theorem pair_corr {ι : Type*} [Fintype ι] [DecidableEq ι] (c : ι → ℝ)
    (t x y u v : ℝ) :
    corr (diagonal fun i => (amplitude c t i : ℂ))
      (extend (spin x y)) (extend (spin u v)) =
      2 * (∑ i, c i ^ 2) * (x*u+y*v) + t^2 := by
  rw [diagonal_corr]
  simp [amplitude, extend, Fintype.sum_sum_type, Fintype.sum_prod_type,
    Matrix.blockDiagonal_apply, mul_ite, ite_mul, spin, Fin.sum_univ_two,
    Complex.mul_re, Complex.mul_im]
  ring_nf
  simp only [Finset.sum_add_distrib, ← Finset.sum_mul, ← Finset.mul_sum]
  ring

/-- The specified Bell-pair blocks and the classical leftover attain the odd-dimensional
ceiling; the construction requires neither normalization nor any ordering hypotheses. -/
theorem paired_attained {ι : Type*} [Fintype ι] [DecidableEq ι] (c : ι → ℝ) (t : ℝ) :
    ∃ A₀ A₁ B₀ B₁ : Mat (Blocks ι),
      Observable A₀ ∧ Observable A₁ ∧ Observable B₀ ∧ Observable B₁ ∧
      chsh (diagonal fun i => (amplitude c t i : ℂ)) A₀ A₁ B₀ B₁ =
        2 * Real.sqrt 2 * (2 * ∑ i, c i ^ 2) + 2 * t^2 := by
  let s := Real.sqrt 2 / 2
  have hs : s^2 + s^2 = 1 := by
    dsimp [s]
    nlinarith [Real.sq_sqrt (show (0:ℝ) ≤ 2 by norm_num)]
  refine ⟨extend (spin 1 0), extend (spin 0 1), extend (spin s s), extend (spin s (-s)),
    extend_reflect (spin_reflect _ _ (by norm_num)), extend_reflect (spin_reflect _ _ (by norm_num)),
    extend_reflect (spin_reflect _ _ hs), extend_reflect (spin_reflect _ _ (by simpa using hs)), ?_⟩
  simp only [chsh, pair_corr, s]
  ring


/-- Reindexing the paired construction is allowed in any orthonormal Schmidt basis. -/
theorem labelled_attained {ι N : Type*} [Fintype ι] [DecidableEq ι] [Fintype N] [DecidableEq N]
    (e : N ≃ Blocks ι) (c : ι → ℝ) (t : ℝ) :
    ∃ A₀ A₁ B₀ B₁ : Mat N,
      Observable A₀ ∧ Observable A₁ ∧ Observable B₀ ∧ Observable B₁ ∧
      chsh (diagonal fun i => (amplitude c t (e i) : ℂ)) A₀ A₁ B₀ B₁ =
        2 * Real.sqrt 2 * (2 * ∑ i, c i ^ 2) + 2 * t^2 := by
  obtain ⟨A,C,B,D,hA,hC,hB,hD,h⟩ := paired_attained c t
  have ho (M : Mat (Blocks ι)) (hM : Observable M) : Observable (M.submatrix e e) :=
    ⟨hM.1.submatrix e, by rw [submatrix_mul_equiv, hM.2, submatrix_one_equiv]⟩
  refine ⟨_,_,_,_,ho A hA,ho C hC,ho B hB,ho D hD,?_⟩
  have hsum (f : Blocks ι → Blocks ι → ℂ) :
      (∑ i, ∑ j, f (e i) (e j)) = ∑ i, ∑ j, f i j := by
    calc
      _ = ∑ i : N, ∑ j : Blocks ι, f (e i) j := by
        exact Finset.sum_congr rfl fun i _ => e.sum_comp _
      _ = _ := e.sum_comp (fun i => ∑ j, f i j)
  have hc (M P : Mat (Blocks ι)) :
      corr (diagonal fun i => (amplitude c t (e i) : ℂ)) (M.submatrix e e) (P.submatrix e e) =
      corr (diagonal fun i => (amplitude c t i : ℂ)) M P := by
    rw [diagonal_corr, diagonal_corr]
    exact congrArg Complex.re (hsum (fun i j => (amplitude c t i : ℂ) * M i j * P i j *
      (amplitude c t j : ℂ)))
  simpa only [chsh, hc] using h

/-- A standard finite-dimensional space of odd dimension has such a block indexing. -/
def oddLabelling (k : ℕ) : Fin (2*k+1) ≃ Blocks (Fin k) :=
  (Fintype.equivFinOfCardEq (α := Blocks (Fin k)) (by simp [Blocks])).symm

theorem amplitude_mass {ι N : Type*} [Fintype ι] [Fintype N]
    (e : N ≃ Blocks ι) (c : ι → ℝ) (t : ℝ) :
    (∑ i, amplitude c t (e i) ^ 2) = 2*(∑ i, c i ^ 2) + t^2 := by
  rw [e.sum_comp (fun i => amplitude c t i ^ 2)]
  simp [amplitude, Fintype.sum_sum_type, Fintype.sum_prod_type, two_mul]

theorem tail_smallest {ι N : Type*} (e : N ≃ Blocks ι) (c : ι → ℝ) (t : ℝ)
    (h : ∀ i, t^2 ≤ c i^2) (j : N) : t^2 ≤ amplitude c t (e j)^2 := by
  cases hh : e j with
  | inl ij => exact h ij.2
  | inr u => exact le_rfl

end
end CHSHOddAttain
