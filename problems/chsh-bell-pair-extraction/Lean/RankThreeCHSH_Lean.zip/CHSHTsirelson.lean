import CHSHDefs
import Mathlib.Analysis.Matrix.Order
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

/-! The sum-of-squares proof of the Tsirelson bound for arbitrary finite
local dimensions and unnormalized bipartite amplitude matrices. -/
namespace CHSHTsirelson
open CHSH Matrix
open scoped Matrix Kronecker BigOperators ComplexOrder
noncomputable section
variable {m n : Type*} [Fintype m] [Fintype n]

private def expectation (F : Matrix m n ℂ) : Mat (m × n) →ₗ[ℝ] ℝ where
  toFun M := (∑ i, ∑ j, ∑ k, ∑ l, star (F i j) * M (i,j) (k,l) * F k l).re
  map_add' X Y := by simp [mul_add, add_mul, Finset.sum_add_distrib]
  map_smul' r X := by
    simp only [Matrix.smul_apply, Complex.real_smul, RingHom.id_apply, smul_eq_mul]
    simp_rw [show ∀ a b c : ℂ, a * ((r:ℂ)*b) * c = r * (a*b*c) by intros; ring]
    simp [← Finset.mul_sum]

private theorem expectation_kron (F : Matrix m n ℂ) (A : Mat m) (B : Mat n) :
    expectation F (A ⊗ₖ B) = corr F A B := by
  change (∑ i, ∑ j, ∑ k, ∑ l, star (F i j) * (A i k * B j l) * F k l).re = _
  simp only [corr, mul_assoc]

private theorem expectation_pos (F : Matrix m n ℂ) {M : Mat (m × n)} (h : M.PosSemidef) :
    0 ≤ expectation F M := by
  let v : m × n → ℂ := fun ij => F ij.1 ij.2
  have hr := (Complex.nonneg_iff.mp (h.dotProduct_mulVec_nonneg v)).1
  simpa [expectation, dotProduct, mulVec, v, Fintype.sum_prod_type, Finset.mul_sum,
    mul_assoc] using hr

variable [DecidableEq m] [DecidableEq n]

private theorem expectation_one (F : Matrix m n ℂ) : expectation F 1 = weight F := by
  rw [← Matrix.one_kronecker_one (m := m) (n := n), expectation_kron]
  simp [corr, weight, Matrix.one_apply, mul_ite, ite_mul, Complex.normSq_apply]

/-- Tsirelson's bound with arbitrary finite local alphabets and unnormalized amplitudes. -/
theorem upper (F : Matrix m n ℂ) (A₀ A₁ : Mat m) (B₀ B₁ : Mat n)
    (ha₀ : Observable A₀) (ha₁ : Observable A₁)
    (hb₀ : Observable B₀) (hb₁ : Observable B₁) :
    chsh F A₀ A₁ B₀ B₁ ≤ 2 * Real.sqrt 2 * weight F := by
  let X := Real.sqrt 2 • (A₀ ⊗ₖ (1 : Mat n)) -
    ((1 : Mat m) ⊗ₖ B₀) - ((1 : Mat m) ⊗ₖ B₁)
  let Y := Real.sqrt 2 • (A₁ ⊗ₖ (1 : Mat n)) -
    ((1 : Mat m) ⊗ₖ B₀) + ((1 : Mat m) ⊗ₖ B₁)
  have hx := expectation_pos F (Matrix.posSemidef_conjTranspose_mul_self X)
  have hy := expectation_pos F (Matrix.posSemidef_conjTranspose_mul_self Y)
  have sq : Real.sqrt 2 * Real.sqrt 2 = 2 := Real.mul_self_sqrt (by norm_num)
  simp only [X,Y, Matrix.conjTranspose_add, Matrix.conjTranspose_sub, Matrix.conjTranspose_smul,
    Matrix.conjTranspose_kronecker, star_trivial, Matrix.conjTranspose_one,
    ha₀.1.eq, ha₁.1.eq, hb₀.1.eq, hb₁.1.eq, add_mul, sub_mul, mul_add, mul_sub,
    smul_mul_assoc, mul_smul_comm, ← Matrix.mul_kronecker_mul, mul_one, one_mul,
    ha₀.2, ha₁.2, hb₀.2, hb₁.2, Matrix.one_kronecker_one, map_add, map_sub, map_smul,
    smul_eq_mul, expectation_one, expectation_kron] at hx hy
  rw [← mul_assoc (Real.sqrt 2) (Real.sqrt 2), sq] at hx hy
  apply le_of_mul_le_mul_left (a := Real.sqrt 2) _ (by positivity)
  rw [show Real.sqrt 2 * (2 * Real.sqrt 2 * weight F) = 4 * weight F by
    calc
      _ = 2 * (Real.sqrt 2 * Real.sqrt 2) * weight F := by ring
      _ = _ := by rw [sq]; ring]
  simp only [chsh, mul_add, mul_sub]
  linarith

end
end CHSHTsirelson
