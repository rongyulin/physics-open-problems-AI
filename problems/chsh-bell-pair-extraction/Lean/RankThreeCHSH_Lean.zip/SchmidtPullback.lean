import CHSHDefs
import Mathlib.Analysis.Matrix.PosDef
import Mathlib.Tactic

/-! Compress an arbitrary second subsystem to the Schmidt support of a qutrit.
The construction includes zero Schmidt coefficients. -/
namespace CHSHMixed
open CHSH Matrix
open scoped Matrix BigOperators ComplexOrder
noncomputable section
variable {n : Type*} [Fintype n] [DecidableEq n]

def SchmidtRows (c : Fin 3 → ℝ) (F : Matrix (Fin 3) n ℂ) : Prop :=
  ∀ i k, (∑ j, star (F i j) * F k j) = if i=k then (c i : ℂ)^2 else 0

private def W (c : Fin 3 → ℝ) (F : Matrix (Fin 3) n ℂ) : Matrix n (Fin 3) ℂ :=
  fun j i => F i j / (c i : ℂ)

/-- Pull a Bob measurement back from his entire subsystem to the at-most-three
Schmidt directions. The pulled observable acts as zero on absent directions. -/
def pull (c : Fin 3 → ℝ) (F : Matrix (Fin 3) n ℂ) (B : Mat n) : Mat (Fin 3) :=
  (W c F)ᴴ * B * W c F

omit [DecidableEq n] in
private theorem zero_row (c : Fin 3 → ℝ) (F : Matrix (Fin 3) n ℂ) (hs : SchmidtRows c F)
    (i : Fin 3) (h : c i=0) (j : n) : F i j = 0 := by
  have hx := congrArg Complex.re (hs i i)
  have hz : ∑ k, Complex.normSq (F i k) = 0 := by
    simpa [h,Complex.star_def,Complex.mul_re,Complex.normSq_apply] using hx
  exact Complex.normSq_eq_zero.mp ((Finset.sum_eq_zero_iff_of_nonneg
    (fun k _ => Complex.normSq_nonneg (F i k))).mp hz j (Finset.mem_univ _))

omit [DecidableEq n] in
private theorem reconstruct (c : Fin 3 → ℝ) (F : Matrix (Fin 3) n ℂ) (hs : SchmidtRows c F)
    (i : Fin 3) (j : n) : F i j = (c i:ℂ) * W c F j i := by
  by_cases h : c i=0
  · simp [h,zero_row c F hs i h j]
  · have hc : (c i:ℂ) ≠ 0 := by exact_mod_cast h
    unfold W
    field_simp

omit [DecidableEq n] in
private theorem W_gram (c : Fin 3 → ℝ) (F : Matrix (Fin 3) n ℂ) (hs : SchmidtRows c F) :
    (W c F)ᴴ * W c F = diagonal (fun i => if c i=0 then (0:ℂ) else 1) := by
  ext i k
  simp only [Matrix.mul_apply, Matrix.conjTranspose_apply, W, star_div₀, Complex.star_def,
    Complex.conj_ofReal]
  have fac (j : n) :
      (starRingEnd ℂ) (F i j) / ↑(c i) * (F k j / ↑(c k)) =
      (star (F i j) * F k j) / ((c i : ℂ) * (c k:ℂ)) := by
    rw [div_mul_div_comm]; rfl
  simp_rw [fac]
  rw [← Finset.sum_div, hs]
  by_cases e : i=k
  · subst k; simp only [if_true, diagonal_apply_eq]
    by_cases z : c i=0
    · simp [z]
    · have hc : (c i:ℂ) ≠ 0 := by exact_mod_cast z
      simp [z,pow_two,hc]
  · simp [e]

omit [DecidableEq n] in
private theorem defect_psd (c : Fin 3 → ℝ) (F : Matrix (Fin 3) n ℂ) (hs : SchmidtRows c F) :
    (1 - (W c F)ᴴ * W c F).PosSemidef := by
  rw [W_gram c F hs, ← diagonal_one, diagonal_sub]
  apply PosSemidef.diagonal
  intro i
  by_cases h : c i=0 <;> simp [h]

/-- Positivity of the two binary effects is preserved by the compression. -/
theorem pull_effects (c : Fin 3 → ℝ) (F : Matrix (Fin 3) n ℂ) (hs : SchmidtRows c F)
    (B : Mat n) (hp : (1+B).PosSemidef) (hm : (1-B).PosSemidef) :
    (1+pull c F B).PosSemidef ∧ (1-pull c F B).PosSemidef := by
  have d := defect_psd c F hs
  constructor
  · convert d.add (hp.conjTranspose_mul_mul_same (W c F)) using 1
    simp only [pull,Matrix.mul_add,Matrix.add_mul,Matrix.mul_one]
    abel
  · convert d.add (hm.conjTranspose_mul_mul_same (W c F)) using 1
    simp only [pull,Matrix.mul_sub,Matrix.sub_mul,Matrix.mul_one]
    abel

omit [DecidableEq n] in
theorem corr_pull (c : Fin 3 → ℝ) (F : Matrix (Fin 3) n ℂ) (hs : SchmidtRows c F)
    (A : Mat (Fin 3)) (B : Mat n) :
    corr F A B = corr (diagonal fun i => (c i:ℂ)) A (pull c F B) := by
  unfold corr
  congr 1
  have right : (∑ i, ∑ j, ∑ k, ∑ l, star ((diagonal fun i => (c i:ℂ)) i j) *
      A i k * (pull c F B) j l * (diagonal fun i => (c i:ℂ)) k l) =
      ∑ i, ∑ k, (c i:ℂ) * A i k * (pull c F B) i k * (c k:ℂ) := by
    classical
    simp [Fin.sum_univ_three, Matrix.diagonal]
  rw [right]
  apply Finset.sum_congr rfl
  intro i _
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro k _
  simp only [pull,Matrix.mul_apply,Matrix.conjTranspose_apply, Finset.sum_mul, Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro j _
  apply Finset.sum_congr rfl
  intro l _
  rw [reconstruct c F hs i l, reconstruct c F hs k j, StarMul.star_mul]
  simp only [Complex.star_def, Complex.conj_ofReal]
  ring

end
end CHSHMixed
