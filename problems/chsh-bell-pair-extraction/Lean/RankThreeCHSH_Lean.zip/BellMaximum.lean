import QutritCHSH
import CHSHPOVM
import SchmidtThree

/-! The main theorem starts with an arbitrary complex amplitude matrix.
A binary measurement is represented both by its pair of positive effects
and by the difference of those effects. -/
namespace BellMaximum
open CHSH QutritCHSH CHSHPOVM Matrix
open scoped Matrix BigOperators
noncomputable section

def Scores (F : M) : Set ℝ := {s | ∃ A₀ A₁ B₀ B₁ : M,
  Contraction A₀ ∧ Contraction A₁ ∧ Contraction B₀ ∧ Contraction B₁ ∧
  chsh F A₀ A₁ B₀ B₁ = s}

lemma observable_contraction {A : M} (h : Observable A) : Contraction A :=
  contraction_of_posSemidef h.1 (CHSHClassical.plus_pos h)
    (by simpa [sub_eq_add_neg] using CHSHClassical.plus_pos (CHSHClassical.neg_observable h))

lemma rotated_observable {A : M} (h : Observable A) (U : U3) :
    Observable (U.valᴴ*A*U.val) := by
  refine ⟨Matrix.isHermitian_conjTranspose_mul_mul _ h.1,?_⟩
  have hu : U.val*U.valᴴ=1 := U.property.2
  have hi : U.valᴴ*U.val=1 := U.property.1
  calc
    _ = U.valᴴ * (A * (U.val*U.valᴴ) * A) * U.val := by simp only [Matrix.mul_assoc]
    _ = 1 := by rw [hu,Matrix.mul_one,h.2,Matrix.mul_one,hi]

private lemma projective_pull (D : M) (U V : U3) :
    projectiveScores (U.val*D*V.valᵀ) ⊆ projectiveScores D := by
  rintro _ ⟨A,X,B,Y,hA,hX,hB,hY,rfl⟩
  refine ⟨U.valᴴ*A*U.val,U.valᴴ*X*U.val,V.valᴴ*B*V.val,V.valᴴ*Y*V.val,
    rotated_observable hA U,rotated_observable hX U,
    rotated_observable hB V,rotated_observable hY V,?_⟩
  exact (CHSHBasis.chsh_basis D A X B Y U V).symm

lemma projective_invariant (D : M) (U V : U3) :
    projectiveScores (U.val*D*V.valᵀ) = projectiveScores D := by
  apply Set.Subset.antisymm (projective_pull D U V)
  have hu : U.valᴴ*U.val=1 := U.property.1
  have hv : V.valᵀ*V.valᴴᵀ=1 := by
    simpa only [Matrix.transpose_mul,Matrix.transpose_one] using
      congrArg Matrix.transpose (show V.valᴴ*V.val=1 from V.property.1)
  have back : (star U).val*(U.val*D*V.valᵀ)*(star V).valᵀ=D := by
    change U.valᴴ*(U.val*D*V.valᵀ)*V.valᴴᵀ=D
    calc
      _ = (U.valᴴ*U.val)*D*(V.valᵀ*V.valᴴᵀ) := by simp only [Matrix.mul_assoc]
      _ = D := by rw [hu,hv,Matrix.one_mul,Matrix.mul_one]
  have hh := projective_pull (U.val*D*V.valᵀ) (star U) (star V)
  exact (congrArg (fun E : M => projectiveScores E ⊆ projectiveScores (U.val*D*V.valᵀ)) back).mp hh

theorem general_maximum (F : M) :
    ∃ (U V : U3) (c : Fin 3 → ℝ),
      Antitone c ∧ (∀ i, 0 ≤ c i) ∧ F=U.val*state c*V.valᵀ ∧
      IsGreatest (Scores F) (value c) := by
  obtain ⟨U,V,c,hc,hn,hF⟩ := CHSHSchmidt.factor F
  refine ⟨U,V,c,hc,hn,hF,?_⟩
  have he : F=U.val*state c*V.valᵀ := hF
  have hsets : projectiveScores F=projectiveScores (state c) :=
    (congrArg projectiveScores he).trans (projective_invariant (state c) U V)
  have hproj : IsGreatest (projectiveScores F) (value c) :=
    (congrArg (fun X : Set ℝ => IsGreatest X (value c)) hsets).mpr (exact_projective c hc hn)
  constructor
  · obtain ⟨A,X,B,Y,hA,hX,hB,hY,hs⟩ := hproj.1
    exact ⟨A,X,B,Y,observable_contraction hA,observable_contraction hX,
      observable_contraction hB,observable_contraction hY,hs⟩
  · rintro _ ⟨A,X,B,Y,hA,hX,hB,hY,rfl⟩
    obtain ⟨P,Q,R,T,hP,hQ,hR,hT,hh⟩ := projectivize F A X B Y hA hX hB hY
    exact hh.trans (hproj.2 ⟨P,Q,R,T,hP,hQ,hR,hT,rfl⟩)

#print axioms general_maximum
end
end BellMaximum
