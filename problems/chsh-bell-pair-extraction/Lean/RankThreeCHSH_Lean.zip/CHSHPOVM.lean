import CHSHDefs
import Mathlib.Analysis.Matrix.PosDef
import Mathlib.Data.Matrix.Basis
import Mathlib.Tactic

/-! A binary POVM gives a Hermitian contraction. Every real-linear objective
on such a contraction can be increased by independently rounding its
eigenvalues to signs. Applying this to each measurement leaves the local
dimensions unchanged. -/
namespace CHSHPOVM
open Matrix CHSH
open scoped BigOperators Matrix ComplexOrder
noncomputable section
variable {m n : Type*} [Fintype m] [Fintype n] [DecidableEq m] [DecidableEq n]

def Contraction (A : Mat n) : Prop :=
  ∃ hA : A.IsHermitian, ∀ i, |hA.eigenvalues i| ≤ 1

theorem contraction_of_posSemidef {A : Mat n} (hA : A.IsHermitian)
    (hp : (1 + A).PosSemidef) (hm : (1 - A).PosSemidef) : Contraction A := by
  refine ⟨hA, fun i => abs_le.mpr ⟨?_, ?_⟩⟩
  all_goals
    let v := ⇑(hA.eigenvectorBasis i)
    have hv : RCLike.re (star v ⬝ᵥ v) = 1 := by
      dsimp [v]
      rw [dotProduct_comm, ← EuclideanSpace.inner_eq_star_dotProduct, inner_self_eq_norm_sq_to_K,
        hA.eigenvectorBasis.orthonormal.1 i]
      norm_num
    have he : RCLike.re (star v ⬝ᵥ (A *ᵥ v)) = hA.eigenvalues i :=
      (hA.eigenvalues_eq i).symm
  · have h := hp.re_dotProduct_nonneg v
    rw [Matrix.add_mulVec, Matrix.one_mulVec, dotProduct_add, map_add, hv, he] at h
    linarith
  · have h := hm.re_dotProduct_nonneg v
    rw [Matrix.sub_mulVec, Matrix.one_mulVec, dotProduct_sub, map_sub, hv, he] at h
    linarith

/-- The signed observable of two positive effects summing to the identity. -/
theorem contraction_of_effects {P Q : Mat n} (hP : P.PosSemidef) (hQ : Q.PosSemidef)
    (hsum : P + Q = 1) : Contraction (P - Q) := by
  apply contraction_of_posSemidef (hP.isHermitian.sub hQ.isHermitian)
  · have e : 1 + (P - Q) = P + P := by rw [← hsum]; abel
    rw [e]
    exact hP.add hP
  · have e : 1 - (P - Q) = Q + Q := by rw [← hsum]; abel
    rw [e]
    exact hQ.add hQ

private theorem spectral_score (U : Matrix.unitaryGroup n ℂ)
    (L : Mat n →ₗ[ℝ] ℝ) (x : n → ℝ) :
    L ((Unitary.conjStarAlgAut ℂ _ U) (diagonal fun i => (x i : ℂ))) =
      ∑ i, x i * L ((Unitary.conjStarAlgAut ℂ _ U) (Matrix.single i i 1)) := by
  have decomp : diagonal (fun i => (x i : ℂ)) =
      ∑ i, x i • (Matrix.single i i (1 : ℂ)) := by
    simpa [Matrix.smul_single, Complex.real_smul] using
      (Matrix.sum_single_eq_diagonal (fun i => (x i : ℂ))).symm
  rw [decomp, Unitary.conjStarAlgAut_apply, Matrix.mul_sum, Matrix.sum_mul, map_sum]
  simp only [Matrix.mul_smul, Matrix.smul_mul, map_smul, smul_eq_mul,
    Unitary.conjStarAlgAut_apply]

theorem maximize_reflection {A : Mat n} (hA : Contraction A) (L : Mat n →ₗ[ℝ] ℝ) :
    ∃ R : Mat n, Observable R ∧ L A ≤ L R := by
  rcases hA with ⟨hA, hbound⟩
  let U := hA.eigenvectorUnitary
  let φ := Unitary.conjStarAlgAut ℂ _ U
  let t (i : n) := L (φ (Matrix.single i i 1))
  let s (i : n) : ℝ := if 0 ≤ t i then 1 else -1
  let D := diagonal (fun i => (s i : ℂ))
  have hs (i : n) : s i * s i = 1 := by
    dsimp [s]; split <;> norm_num
  have hD : D.IsHermitian := by
    apply Matrix.isHermitian_diagonal_iff.mpr
    intro i
    change star (s i : ℂ) = _
    simp
  have hDsq : D * D = 1 := by
    change diagonal _ * diagonal _ = _
    rw [Matrix.diagonal_mul_diagonal, ← Matrix.diagonal_one]
    congr 1
    funext i
    exact_mod_cast hs i
  refine ⟨φ D, ⟨?_, ?_⟩, ?_⟩
  · change star (φ D) = φ D
    rw [← map_star]
    exact congrArg φ hD
  · rw [← map_mul, hDsq, map_one]
  · calc
      L A = ∑ i, hA.eigenvalues i * t i := by
        conv_lhs => rw [hA.spectral_theorem]
        exact spectral_score U L hA.eigenvalues
      _ ≤ ∑ i, s i * t i := by
        apply Finset.sum_le_sum
        intro i _
        rcases abs_le.mp (hbound i) with ⟨hi, hj⟩
        by_cases h : 0 ≤ t i
        · exact_mod_cast (show hA.eigenvalues i * t i ≤ s i * t i by
            simpa [s, h] using mul_le_mul_of_nonneg_right hj h)
        · simpa [s, h] using mul_le_mul_of_nonpos_right hi (le_of_not_ge h)
      _ = L (φ D) := (spectral_score U L s).symm

variable (F : Matrix m n ℂ)

omit [DecidableEq m] [DecidableEq n] in
def corrLeft (B : Mat n) : Mat m →ₗ[ℝ] ℝ where
  toFun := fun A => corr F A B
  map_add' A C := by simp [corr, mul_add, add_mul, Finset.sum_add_distrib]
  map_smul' r A := by
    have hr (i j k l) : star (F i j) * (r • A i k) * B j l * F k l =
        (r : ℂ) * (star (F i j) * A i k * B j l * F k l) := by
      rw [Complex.real_smul]; ring
    simp only [corr, Matrix.smul_apply, hr, ← Finset.mul_sum, Complex.re_ofReal_mul,
      RingHom.id_apply, smul_eq_mul]

omit [DecidableEq m] [DecidableEq n] in
def corrRight (A : Mat m) : Mat n →ₗ[ℝ] ℝ where
  toFun := fun B => corr F A B
  map_add' B C := by simp [corr, mul_add, add_mul, Finset.sum_add_distrib]
  map_smul' r B := by
    have hr (i j k l) : star (F i j) * A i k * (r • B j l) * F k l =
        (r : ℂ) * (star (F i j) * A i k * B j l * F k l) := by
      rw [Complex.real_smul]; ring
    simp only [corr, Matrix.smul_apply, hr, ← Finset.mul_sum, Complex.re_ofReal_mul,
      RingHom.id_apply, smul_eq_mul]

theorem projectivize (A₀ A₁ : Mat m) (B₀ B₁ : Mat n)
    (ha : Contraction A₀) (hc : Contraction A₁)
    (hb : Contraction B₀) (hd : Contraction B₁) :
    ∃ A₀' A₁' B₀' B₁', Observable A₀' ∧ Observable A₁' ∧
      Observable B₀' ∧ Observable B₁' ∧
      chsh F A₀ A₁ B₀ B₁ ≤ chsh F A₀' A₁' B₀' B₁' := by
  obtain ⟨P, hP, hp⟩ := maximize_reflection ha (corrLeft F B₀ + corrLeft F B₁)
  obtain ⟨Q, hQ, hq⟩ := maximize_reflection hc (corrLeft F B₀ - corrLeft F B₁)
  obtain ⟨R, hR, hr⟩ := maximize_reflection hb (corrRight F P + corrRight F Q)
  obtain ⟨S, hS, hs⟩ := maximize_reflection hd (corrRight F P - corrRight F Q)
  refine ⟨P, Q, R, S, hP, hQ, hR, hS, ?_⟩
  simp only [LinearMap.add_apply, LinearMap.sub_apply] at hp hq hr hs
  change corr F A₀ B₀ + corr F A₀ B₁ ≤ corr F P B₀ + corr F P B₁ at hp
  change corr F A₁ B₀ - corr F A₁ B₁ ≤ corr F Q B₀ - corr F Q B₁ at hq
  change corr F P B₀ + corr F Q B₀ ≤ corr F P R + corr F Q R at hr
  change corr F P B₁ - corr F Q B₁ ≤ corr F P S - corr F Q S at hs
  unfold chsh
  linarith only [hp, hq, hr, hs]

end
end CHSHPOVM
