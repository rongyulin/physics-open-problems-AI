import OddCHSH
import QutritMixedBound

/-! The odd-dimensional CHSH deficit for arbitrary positive mixed states,
with unrestricted local binary effects and Alice's actual partial trace. -/
namespace CHSHOddMixed
open CHSH Matrix CHSHMixed
open scoped BigOperators Matrix Kronecker MatrixOrder ComplexOrder
noncomputable section
variable {d : ℕ} {n : Type*} [Fintype n] [DecidableEq n]

/-- Partial trace over Bob in the laboratory basis. -/
def partialTrace (R : Mat (Fin d × n)) : Mat (Fin d) := fun i k => ∑ j, R (i,j) (k,j)

/-- Mixed-state expectation of the usual CHSH operator, with the physical trace rule. -/
def score (R : Mat (Fin d × n)) (A C : Mat (Fin d)) (B D : Mat n) : ℝ :=
  ((A⊗ₖ B)*R).trace.re + ((A⊗ₖ D)*R).trace.re + ((C⊗ₖ B)*R).trace.re - ((C⊗ₖ D)*R).trace.re

omit [DecidableEq n] in
private theorem trace_partial (R : Mat (Fin d × n)) : (partialTrace R).trace = R.trace := by
  simp only [Matrix.trace, Matrix.diag, partialTrace, Fintype.sum_prod_type]

omit [DecidableEq n] in
theorem partial_hermitian {R : Mat (Fin d × n)} (hR : R.IsHermitian) : (partialTrace R).IsHermitian := by
  ext i k
  simp only [conjTranspose_apply, partialTrace, star_sum]
  exact Finset.sum_congr rfl fun j _ => hR.apply (i,j) (k,j)

def leastEigen (hd : 0<d) (M : Mat (Fin d)) (hm : M.IsHermitian) : ℝ :=
  (Finset.univ : Finset (Fin d)).inf' ⟨⟨0,hd⟩,Finset.mem_univ _⟩ hm.eigenvalues

private def unpack {e : Type*} (P : Matrix (Fin d × n) e ℂ) : Matrix (Fin d) (n × e) ℂ :=
  fun i u => P (i,u.1) u.2

omit [DecidableEq n] in
private theorem purified_corr {e : Type*} [Fintype e] [DecidableEq e] (P : Matrix (Fin d × n) e ℂ)
    (A : Mat (Fin d)) (B : Mat n) :
    ((A ⊗ₖ B)*(P*Pᴴ)).trace.re = corr (unpack P) A (B ⊗ₖ (1 : Mat e)) := by
  unfold Matrix.trace Matrix.diag corr
  congr 1
  simp only [Matrix.mul_apply,Matrix.conjTranspose_apply,Fintype.sum_prod_type,
    unpack,Matrix.kronecker_apply,Matrix.one_apply,mul_ite,mul_one,mul_zero,ite_mul,
    zero_mul,Finset.sum_ite_eq,Finset.mem_univ,if_true,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i _
  apply Finset.sum_congr rfl
  intro j _
  conv_rhs => rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro k _
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro l _
  apply Finset.sum_congr rfl
  intro a _
  ring

omit [DecidableEq n] in
private theorem purified_marginal {e : Type*} [Fintype e] (P : Matrix (Fin d × n) e ℂ) :
    unpack P * (unpack P)ᴴ = partialTrace (P*Pᴴ) := by
  ext i k
  simp only [Matrix.mul_apply,Matrix.conjTranspose_apply,Fintype.sum_prod_type,unpack,partialTrace]

private theorem extend_binary {e : Type*} [Fintype e] [DecidableEq e] {B : Mat n} (h : Binary B) :
    Binary (B ⊗ₖ (1 : Mat e)) := by
  constructor
  · simpa only [Matrix.add_kronecker,Matrix.one_kronecker_one] using
      h.1.kronecker (Matrix.PosSemidef.one : (1 : Mat e).PosSemidef)
  · have he : ((1-B) ⊗ₖ (1 : Mat e)) = 1 - (B ⊗ₖ (1 : Mat e)) := by
      calc
        _ = (1 : Mat n) ⊗ₖ (1 : Mat e) - B ⊗ₖ (1 : Mat e) := by
          ext i j
          exact sub_mul _ _ _
        _ = _ := by rw [Matrix.one_kronecker_one]
    rw [← he]
    exact h.2.kronecker Matrix.PosSemidef.one

/-- Purification on Bob's side preserves the physical score, partial trace and trace mass,
even when the original density matrix is not normalized. -/
private theorem purify (R : Mat (Fin d × n)) (hR : R.PosSemidef)
    (A C : Mat (Fin d)) (B D : Mat n) :
    ∃ F : Matrix (Fin d) (n × (Fin d × n)) ℂ,
      F*Fᴴ = partialTrace R ∧ weight F = R.trace.re ∧
      score R A C B D = chsh F A C (B ⊗ₖ (1 : Mat (Fin d × n))) (D ⊗ₖ (1 : Mat (Fin d × n))) := by
  obtain ⟨X,hX⟩ := CStarAlgebra.nonneg_iff_eq_star_mul_self.mp hR.nonneg
  let P := Xᴴ
  have hp : R=P*Pᴴ := by simpa [P] using hX
  refine ⟨unpack P,?_,?_,?_⟩
  · rw [hp]; exact purified_marginal P
  · rw [CHSHBasis.weight_trace,Matrix.trace_mul_comm,purified_marginal,trace_partial,← hp]
  · simp only [score,chsh,hp,purified_corr]

/-- Upper bound expressed directly using the smallest eigenvalue of Alice's actual
reduced density operator, and the trace of the joint mixed state. -/
theorem upper {k : ℕ} (hd : d = 2*k+1) (R : Mat (Fin d × n)) (hR : R.PosSemidef)
    (A C : Mat (Fin d)) (B D : Mat n)
    (hA : Binary A) (hC : Binary C) (hB : Binary B) (hD : Binary D) :
    score R A C B D ≤ 2*Real.sqrt 2*R.trace.re -
      (2*Real.sqrt 2-2)*leastEigen (by omega) (partialTrace R) (partial_hermitian hR.1) := by
  obtain ⟨F,hm,hw,hs⟩ := purify R hR A C B D
  obtain ⟨A',C',B',D',ha,hc,hb,he,hs'⟩ := CHSHPOVM.projectivize F A C
    (B ⊗ₖ (1 : Mat (Fin d × n))) (D ⊗ₖ (1 : Mat (Fin d × n))) hA.contraction hC.contraction
    (extend_binary hB).contraction (extend_binary hD).contraction
  rw [hs]
  apply hs'.trans
  have hh := CHSHOdd.upper_least hd F A' C' B' D' ha hc hb he
  rw [hw] at hh
  convert hh using 1
  have eig (M : Mat (Fin d)) (hM : M.IsHermitian) (hm' : F*Fᴴ=M) :
      leastEigen (by omega) M hM = CHSHOdd.leastAliceProbability (by omega) F := by
    subst M
    rfl
  rw [eig (partialTrace R) (partial_hermitian hR.1) hm]

#print axioms upper
end
end CHSHOddMixed
