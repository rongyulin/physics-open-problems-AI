# Sharp singlet-extraction fidelity from an observed CHSH score at Schmidt rank three

For a normalized pure two-qutrit state, let `S = 2s` be the CHSH score observed with four binary measurements, and let `F` be the largest squared overlap with a singlet times an ancillary pure state after finite local isometries. For each `1 ≤ s ≤ √2`, the minimum possible `F` is attained. It equals `(1+w)/2`, where the three branches are

| Range of the half-score | Value of w |
| --- | --- |
| `1 ≤ s ≤ (1+√41)/6` | `2√[p(1−2p)]`, with `p = (s+1−√(−7s²+2s+9))/8` |
| `(1+√41)/6 ≤ s ≤ (1+2√2)/3` | `2/3` |
| `(1+2√2)/3 ≤ s ≤ √2` | `(s−1)/(√2−1)` |

The middle interval gives a constant fidelity of 5/6. The public entry points `RankThreeCHSH.sharp` and `RankThreeCHSH.plateau` in `RankThreeCHSH.lean` give the piecewise formula and its flat interval. The full operational statement is `CHSHFrontier.sharp_observed_fidelity` in `FidelityObserved.lean`. It minimizes over all normalized 3×3 complex pure-state amplitude matrices and all measurements compatible with the specified score. The binary effects in each measurement are positive and add to the identity.

The proof also formalizes the fixed-state maximum at Schmidt rank three, previously obtained by Lance Pollard. For ordered Schmidt coefficients a ≥ b ≥ c ≥ 0 the value is `2c² + 2√[(a²+b²)²+4a²b²]`. [Pollard, experiment E-QTM-0132, proof in lines 4–17](https://github.com/cluesurf/vibe/blob/6f3d9c6e2e069f0296ab6f84a62fc857da19293f/test/experiment/quantum/tsirelson-closed-form.ts#L4-L17).

McKague's thesis discusses the straight-line fidelity bound and gives a state family in Eq. (5.59). For p > 1/3 the Schmidt amplitudes in that expression change order. Its extraction fidelity then exceeds the proposed line for interior parameters, as the exact p = 2/3 example in `ThesisWitness` illustrates. [Matthew McKague, *Quantum Information Processing with Adversarial Devices*, Chapter 5 (2010)](https://arxiv.org/abs/1006.2352).

The [supplemental prior-art search](PRIORITY.md) records the GitHub experiments and literature checked, their overlap with these theorems, and the limits of the search.

## Reproduction

Install elan, change into this directory, then run

```sh
lake exe cache get
sh audit.sh
```

The checked project uses Lean 4.28.0 and mathlib revision `8f9d9cff6bd728b17a24e163c9402775d9e6a365`. The manifest pins transitive dependencies. Lake elaborates the source files. A separate `leanchecker` process then replays the declarations in each project module using the same Lean kernel. The final line of the script reports the number of successful module replays.

## Main theorems

| Source | Statement |
| --- | --- |
| `QutritCHSH`, `BellMaximum`, `BellExperiment`, `SchmidtThree` | The upper bound and explicit attainability for Schmidt-diagonal states, and the maximum over all binary positive effects for an arbitrary complex 3×3 amplitude matrix using its Schmidt decomposition. |
| `CompressionCoefficients` | Both singular values of the 2×2 block are bounded by the two largest Schmidt coefficients. |
| `CHSHPOVM`, `CHSHScoreInterval` | Binary POVMs can be replaced by projective measurements when maximizing a CHSH score. The score-interval theorem constructs binary effects reaching intermediate scores. |
| `SchmidtPullback`, `QutritPurification`, `QutritMixedBound`, `QutritMixedSharp`, `QutritMarginalBasis`, `QutritMarginal` | For any positive qutrit marginal in any basis, the greatest score over positive density matrices extending it, arbitrary finite Bob dimension, and binary effects is attained by the qutrit purification and equals the same formula. The theorem constructs its ordered marginal spectrum and includes zero eigenvalues. |
| `OddCHSH`, `OddOptimum` | An upper bound using the smallest marginal eigenvalue in odd dimension, and its attainment for the stated family with paired coefficients. |
| `CHSHCopy` | A joint measurement on two copies of an entangled pure two-qutrit state of full Schmidt rank yields a strict improvement under the hypotheses of `two_copy_strict`. |
| `FidelityObserved`, `RawExtraction`, `MYFidelity` | For normalized pure two-qutrit amplitudes and each exactly observed CHSH score from 2 to 2√2, the smallest achievable optimal singlet-extraction fidelity is attained. The middle branch has fidelity 5/6. The score uses four binary POVMs and the extraction uses finite local isometries and an ancillary pure state. |
| `FrontierEquality` | Equality and stability properties of the Schmidt parameters in the middle branch of the fidelity frontier. |
| `MeasurementRigidity` | For projective settings and a positive gap between the second and third Schmidt coefficients, a quantitative score deficit controls the tilt of the singleton Jordan lines. At optimality both lines coincide with the smallest Schmidt line. |
| `OddCopies` | For a normalized odd-dimensional Schmidt spectrum with equal pairs and one remaining smallest coefficient, the collective maximum for any number of copies is attained. This includes maximally entangled qutrits. |
| `OddMixed` | For any positive bipartite density matrix with an odd-dimensional Alice, the least eigenvalue of her actual partial trace gives an upper bound for every binary CHSH measurement. |
| `SupportReduction` | Isometric embeddings of a state into two larger finite local systems preserve the entire set of achievable binary-POVM CHSH scores. Any rectangular state supplied with a rank-three Schmidt factorization has the same fixed-state maximum. Finite supports of local dimension one or two are included through zero-padding. |
