import CompressionMass
namespace CHSHCompression
open Matrix
open scoped Matrix BigOperators ComplexConjugate ComplexOrder
noncomputable section

private theorem mass_gram {n : Type*} [Fintype n] (C : Matrix n n ℂ) (v : n → ℂ) :
    (mass (C *ᵥ v) : ℂ) = star v ⬝ᵥ ((Cᴴ * C) *ᵥ v) := by
  rw [mass_complex, star_mulVec, ← mulVec_mulVec, dotProduct_mulVec]
  simp only [dotProduct_mulVec]

private theorem mass_gram_weight {n : Type*} [Fintype n] [DecidableEq n]
    (C : Matrix n n ℂ) (v : n → ℂ) :
    let h := (posSemidef_conjTranspose_mul_self C).isHermitian
    ∃ w : n → ℂ, mass w = mass v ∧ mass (C *ᵥ v) =
        ∑ i, h.eigenvalues i * Complex.normSq (w i) := by
  let h := (posSemidef_conjTranspose_mul_self C).isHermitian
  let U := h.eigenvectorUnitary
  let w := ((star U : unitary (Matrix n n ℂ)) : Matrix n n ℂ) *ᵥ v
  refine ⟨w, mass_unitary (star U) v, ?_⟩
  have hdiag : (Cᴴ*C) *ᵥ v =
      (U : Matrix n n ℂ) *ᵥ (diagonal (fun i => (h.eigenvalues i : ℂ)) *ᵥ w) := by
    conv_lhs => rw [h.spectral_theorem, Unitary.conjStarAlgAut_apply]
    simp only [← Matrix.mulVec_mulVec]
    rfl
  have hwstar : star w = star v ᵥ* (U : Matrix n n ℂ) := by
    simp [w, star_mulVec, ← Matrix.star_eq_conjTranspose]
  apply Complex.ofReal_injective
  rw [mass_gram, hdiag, dotProduct_mulVec, ← hwstar]
  simp only [dotProduct, Matrix.mulVec_diagonal, Complex.ofReal_sum, Complex.ofReal_mul,
    Complex.normSq_eq_conj_mul_self, Pi.star_apply]
  apply Finset.sum_congr rfl
  intro i _
  change star (w i) * ((h.eigenvalues i : ℂ) * w i) = (h.eigenvalues i : ℂ) * (star (w i) * w i)
  ring

private theorem gram_eigenvalue_mass {n : Type*} [Fintype n] [DecidableEq n] (C : Matrix n n ℂ)
    (i : n) :
    let h := (posSemidef_conjTranspose_mul_self C).isHermitian
    ∃ v : n → ℂ, mass v = 1 ∧ mass (C *ᵥ v) = h.eigenvalues i := by
  let h := (posSemidef_conjTranspose_mul_self C).isHermitian
  let v := ⇑(h.eigenvectorBasis i)
  refine ⟨v, ?_, ?_⟩
  · unfold mass v
    simp_rw [Complex.normSq_eq_norm_sq]
    rw [← EuclideanSpace.norm_sq_eq, OrthonormalBasis.norm_eq_one, one_pow]
  · have he := h.eigenvalues_eq i
    have hx := congrArg Complex.re (mass_gram C v)
    exact hx.trans he.symm

theorem two_gram_spectrum (C : Matrix (Fin 2) (Fin 2) ℂ) :
    ∃ a b : ℝ, 0 ≤ b ∧ b ≤ a ∧
      (∑ i, ∑ j, Complex.normSq (C i j)) = a+b ∧ ‖C.det‖^2 = a*b ∧
      (∃ v : Fin 2 → ℂ, mass v = 1 ∧ mass (C *ᵥ v) = a) ∧
      (∀ v : Fin 2 → ℂ, b*mass v ≤ mass (C *ᵥ v)) := by
  let h := (posSemidef_conjTranspose_mul_self C).isHermitian
  let e := h.eigenvalues
  refine ⟨max (e 0) (e 1), min (e 0) (e 1), ?_, min_le_max, ?_, ?_, ?_, ?_⟩
  · exact le_min ((posSemidef_conjTranspose_mul_self C).eigenvalues_nonneg 0)
      ((posSemidef_conjTranspose_mul_self C).eigenvalues_nonneg 1)
  · have ht := congrArg Complex.re h.trace_eq_sum_eigenvalues
    have ht' : (∑ i, ∑ j, Complex.normSq (C i j)) = (Cᴴ*C).trace.re := by
      rw [Finset.sum_comm]
      simp only [Matrix.trace, Matrix.diag, Matrix.mul_apply, Matrix.conjTranspose_apply,
        Complex.re_sum]
      simp [Complex.normSq_apply]
    rw [ht', ht]
    simp only [Fin.sum_univ_two, Complex.add_re]
    exact (max_add_min _ _).symm
  · have hd := congrArg Complex.re h.det_eq_prod_eigenvalues
    rw [Matrix.det_mul, Matrix.det_conjTranspose] at hd
    simp only [Fin.prod_univ_two] at hd
    have hd' : ‖C.det‖^2 = e 0 * e 1 := by
      rw [← Complex.normSq_eq_norm_sq]
      simpa [e, Complex.star_def, Complex.mul_re, Complex.normSq_apply] using hd
    rcases le_total (e 0) (e 1) with hl | hl
    · rw [max_eq_right hl,min_eq_left hl,mul_comm]; exact hd'
    · rw [max_eq_left hl,min_eq_right hl]; exact hd'
  · rcases le_total (e 0) (e 1) with hl | hl
    · rw [max_eq_right hl]; exact gram_eigenvalue_mass C 1
    · rw [max_eq_left hl]; exact gram_eigenvalue_mass C 0
  · intro v
    obtain ⟨w,hw,hm⟩ := mass_gram_weight C v
    rw [← hw, hm]
    unfold mass
    rw [Finset.mul_sum]
    refine Finset.sum_le_sum fun i _ => mul_le_mul_of_nonneg_right ?_ (Complex.normSq_nonneg _)
    fin_cases i
    · exact min_le_left _ _
    · exact min_le_right _ _
end
end CHSHCompression
