import BellExperiment

/-! Local isometric embeddings do not change any attainable binary-POVM CHSH
scores, even if the measurements couple the state support to its complement. -/
namespace CHSHSupport
open CHSH CHSHScoreInterval Matrix
open scoped Matrix BigOperators ComplexOrder
noncomputable section

variable {m n k l : Type*} [Fintype m] [Fintype n] [Fintype k] [Fintype l]
  [DecidableEq m] [DecidableEq n] [DecidableEq k] [DecidableEq l]

theorem rectangular_corr (D : Matrix k l ℂ) (U : Matrix m k ℂ) (V : Matrix n l ℂ)
    (A : Mat m) (B : Mat n) :
    corr (U*D*Vᵀ) A B = corr D (Uᴴ*A*U) (Vᴴ*B*V) := by
  rw [CHSHBasis.corr_trace,CHSHBasis.corr_trace]
  congr 1
  simp only [Matrix.conjTranspose_mul,Matrix.transpose_mul,Matrix.mul_assoc]
  rw [Matrix.trace_mul_comm (Vᵀᴴ) _]
  simp only [Matrix.mul_assoc, Matrix.conjTranspose_transpose, Matrix.transpose_conjTranspose]

theorem rectangular_chsh (D : Matrix k l ℂ) (U : Matrix m k ℂ) (V : Matrix n l ℂ)
    (A X : Mat m) (B Y : Mat n) :
    chsh (U*D*Vᵀ) A X B Y = chsh D (Uᴴ*A*U) (Uᴴ*X*U) (Vᴴ*B*V) (Vᴴ*Y*V) := by
  simp only [chsh,rectangular_corr]

def compress (U : Matrix m k ℂ) (hu : Uᴴ*U=1) (A : Binary m) : Binary k where
  plus := Uᴴ*A.plus*U
  minus := Uᴴ*A.minus*U
  plus_pos := A.plus_pos.conjTranspose_mul_mul_same U
  minus_pos := A.minus_pos.conjTranspose_mul_mul_same U
  complete := by rw [← Matrix.add_mul,← Matrix.mul_add,A.complete,Matrix.mul_one,hu]

theorem compress_diff (U : Matrix m k ℂ) (hu : Uᴴ*U=1) (A : Binary m) :
    (compress U hu A).diff = Uᴴ * A.diff * U := by
  simp only [compress,Binary.diff,Matrix.mul_sub,Matrix.sub_mul]

private theorem support_complement (U : Matrix m k ℂ) (hu : Uᴴ*U=1) :
    (1-U*Uᴴ).PosSemidef := by
  let P := U*Uᴴ
  have hh : Pᴴ=P := by simp only [P,Matrix.conjTranspose_mul,Matrix.conjTranspose_conjTranspose]
  have hp : P*P=P := by
    change (U*Uᴴ)*(U*Uᴴ)=U*Uᴴ
    rw [Matrix.mul_assoc,← Matrix.mul_assoc Uᴴ,hu,Matrix.one_mul]
  have h := Matrix.posSemidef_conjTranspose_mul_self (1-P)
  simpa only [Matrix.conjTranspose_sub,Matrix.conjTranspose_one,hh,Matrix.sub_mul,
    Matrix.mul_sub,Matrix.one_mul,Matrix.mul_one,hp,sub_self,sub_zero] using h

/-- The plus outcome is certain on the orthogonal complement of the support. -/
def extend (U : Matrix m k ℂ) (hu : Uᴴ*U=1) (A : Binary k) : Binary m where
  plus := U*A.plus*Uᴴ + (1-U*Uᴴ)
  minus := U*A.minus*Uᴴ
  plus_pos := (A.plus_pos.mul_mul_conjTranspose_same U).add (support_complement U hu)
  minus_pos := A.minus_pos.mul_mul_conjTranspose_same U
  complete := by
    rw [add_right_comm,← Matrix.add_mul,← Matrix.mul_add,A.complete,Matrix.mul_one]
    abel

omit [DecidableEq m] in
private theorem sandwich (U : Matrix m k ℂ) (hu : Uᴴ*U=1) (T : Mat k) :
    Uᴴ*(U*T*Uᴴ)*U=T := by
  calc
    _ = (Uᴴ*U)*T*(Uᴴ*U) := by simp only [Matrix.mul_assoc]
    _ = _ := by rw [hu,Matrix.one_mul,Matrix.mul_one]

private theorem sandwich_complement (U : Matrix m k ℂ) (hu : Uᴴ*U=1) :
    Uᴴ*(1-U*Uᴴ)*U=0 := by
  have h : Uᴴ*(U*Uᴴ)*U = 1 := by
    simpa only [Matrix.mul_one] using sandwich U hu (1:Mat k)
  rw [Matrix.mul_sub,Matrix.sub_mul,Matrix.mul_one,hu,h,sub_self]

theorem extend_diff (U : Matrix m k ℂ) (hu : Uᴴ*U=1) (A : Binary k) :
    Uᴴ*(extend U hu A).diff*U=A.diff := by
  change Uᴴ * (U*A.plus*Uᴴ+(1-U*Uᴴ)-U*A.minus*Uᴴ) * U = A.plus-A.minus
  rw [Matrix.mul_sub,Matrix.sub_mul,Matrix.mul_add,Matrix.add_mul,
    sandwich U hu,sandwich_complement U hu,sandwich U hu,add_zero]

/-- Equality of the entire score sets, in arbitrary finite input and output dimensions. -/
theorem score_set (D : Matrix k l ℂ) (U : Matrix m k ℂ) (V : Matrix n l ℂ)
    (hu : Uᴴ*U=1) (hv : Vᴴ*V=1) :
    effectScores (U*D*Vᵀ) = effectScores D := by
  ext s
  constructor
  · rintro ⟨A,X,B,Y,h⟩
    refine ⟨compress U hu A, compress U hu X, compress V hv B, compress V hv Y, ?_⟩
    simpa only [compress_diff,rectangular_chsh] using h
  · rintro ⟨A,X,B,Y,h⟩
    refine ⟨extend U hu A, extend U hu X, extend V hv B, extend V hv Y, ?_⟩
    simpa only [rectangular_chsh,extend_diff] using h

/-- The two-qutrit maximum in an arbitrary finite-dimensional laboratory, for
a pure state presented by three ordered nonnegative Schmidt amplitudes and
orthonormal triples of Schmidt vectors on each side. -/
theorem schmidt_three_maximum (c : Fin 3 → ℝ) (hc : Antitone c) (hn : ∀i,0 ≤ c i)
    (U : Matrix m (Fin 3) ℂ) (V : Matrix n (Fin 3) ℂ) (hu : Uᴴ*U=1) (hv : Vᴴ*V=1) :
    IsGreatest (effectScores (U*QutritCHSH.state c*Vᵀ)) (QutritCHSH.value c) := by
  rw [score_set _ _ _ hu hv]
  constructor
  · obtain ⟨A,X,B,Y,hA,hX,hB,hY,hs⟩ := QutritCHSH.state_attained c
    exact exact_score _ A X B Y hA hX hB hY _ _ hs (by unfold QutritCHSH.value; positivity) le_rfl
  · intro s hs
    obtain ⟨A,X,B,Y,hA,hX,hB,hY,rfl⟩ := effect_to_contractions hs
    obtain ⟨P,Q,R,T,hP,hQ,hR,hT,hle⟩ := CHSHPOVM.projectivize _ _ _ _ _ hA hX hB hY
    exact hle.trans (QutritCHSH.upper c hc hn P Q R T hP hQ hR hT)

/-- The coordinate embedding that pads an amplitude matrix by zero rows or columns. -/
def coordinate (e : k ↪ Qutrit) : Matrix Qutrit k ℂ := (1 : Mat Qutrit).submatrix id e

omit [Fintype k] in
theorem coordinate_isometry (e : k ↪ Qutrit) : (coordinate e)ᴴ * coordinate e = 1 := by
  rw [coordinate,Matrix.conjTranspose_submatrix,Matrix.conjTranspose_one,
    ← Matrix.submatrix_mul _ _ _ id _ Function.bijective_id,Matrix.one_mul,
    Matrix.submatrix_one _ e.injective]

/-- A rectangular laboratory state on two local supports of dimensions at most
three has exactly the CHSH maximum of its zero-padded two-qutrit amplitude. -/
theorem small_support_maximum (D : Matrix k l ℂ) (a : k ↪ Qutrit) (b : l ↪ Qutrit)
    (U : Matrix m k ℂ) (V : Matrix n l ℂ) (hu : Uᴴ*U=1) (hv : Vᴴ*V=1) :
    ∃ (R S : QutritCHSH.U3) (c : Fin 3 → ℝ), Antitone c ∧ (∀i,0 ≤ c i) ∧
       coordinate a * D * (coordinate b)ᵀ = R.val*QutritCHSH.state c*S.valᵀ ∧
       IsGreatest (effectScores (U*D*Vᵀ)) (QutritCHSH.value c) := by
  obtain ⟨R,S,c,hc,hn,he,hm⟩ := BellExperiment.maximum_CHSH (coordinate a * D * (coordinate b)ᵀ)
  rw [score_set _ _ _ (coordinate_isometry a) (coordinate_isometry b)] at hm
  exact ⟨R,S,c,hc,hn,he,by rwa [score_set _ _ _ hu hv]⟩
#print axioms small_support_maximum
#print axioms score_set
#print axioms schmidt_three_maximum
end
end CHSHSupport
