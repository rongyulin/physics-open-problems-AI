import BellMaximum
import CHSHScoreInterval

/-! A directly inspectable entry point with honest binary POVMs. Each
measurement has two positive semidefinite effects whose sum is the identity. -/
namespace BellExperiment
open CHSH QutritCHSH BellMaximum CHSHScoreInterval CHSHPOVM
open scoped Matrix

/-- The optimizing value is attained over all honest binary measurements
for every 3×3 complex amplitude matrix, without assuming a Schmidt basis.
For a normalized state the squared Schmidt amplitudes sum to one. -/
theorem maximum_CHSH (F : M) :
    ∃ (U V : U3) (c : Fin 3 → ℝ),
      Antitone c ∧ (∀ i, 0 ≤ c i) ∧ F=U.val*state c*V.valᵀ ∧
      IsGreatest (effectScores F) (value c) := by
  obtain ⟨U,V,c,hc,hn,hF,hs⟩ := general_maximum F
  refine ⟨U,V,c,hc,hn,hF,?_,?_⟩
  · have hp : value c ∈ projectiveScores F := by
      have hsets := (congrArg projectiveScores hF).trans (projective_invariant (state c) U V)
      exact (congrArg (fun X : Set ℝ => value c ∈ X) hsets).mpr (state_attained c)
    obtain ⟨A,X,B,Y,hA,hX,hB,hY,he⟩ := hp
    exact exact_score F A X B Y hA hX hB hY _ _ he
      (by unfold value; positivity) (le_refl _)
  · rintro _ ⟨A,X,B,Y,rfl⟩
    have phys (Z : Binary Qutrit) : Contraction Z.diff :=
      contraction_of_effects Z.plus_pos Z.minus_pos Z.complete
    exact hs.2 ⟨A.diff,X.diff,B.diff,Y.diff,phys A,phys X,phys B,phys Y,rfl⟩

#print axioms maximum_CHSH
end BellExperiment
