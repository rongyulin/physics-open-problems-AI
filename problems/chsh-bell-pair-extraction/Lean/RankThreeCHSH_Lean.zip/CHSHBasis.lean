import CHSHDefs
import Mathlib.LinearAlgebra.Matrix.Trace
import Mathlib.LinearAlgebra.UnitaryGroup
import Mathlib.Tactic

namespace CHSHBasis
open CHSH Matrix
open scoped Matrix BigOperators ComplexConjugate
noncomputable section

variable {m n : Type*} [Fintype m] [Fintype n] [DecidableEq m] [DecidableEq n]

/-- Matrix form of the computational-basis expectation, retaining the Bob transpose. -/
theorem corr_trace (F : Matrix m n ℂ) (A : Mat m) (B : Mat n) :
    corr F A B = ((Fᴴ * (A * F * Bᵀ)).trace).re := by
  unfold corr
  congr 1
  unfold Matrix.trace
  simp only [Matrix.diag_apply, Matrix.mul_apply, Matrix.conjTranspose_apply, Matrix.transpose_apply,
    Finset.sum_mul, Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro _ _
  apply Finset.sum_congr rfl
  intro _ _
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro _ _
  apply Finset.sum_congr rfl
  intro _ _
  ring

theorem weight_trace (F : Matrix m n ℂ) :
    weight F = ((Fᴴ * F).trace).re := by
  unfold weight Matrix.trace
  simp only [Matrix.diag_apply, Matrix.mul_apply, Matrix.conjTranspose_apply, Complex.re_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro _ _
  apply Finset.sum_congr rfl
  intro _ _
  simp [Complex.star_def, Complex.mul_re, Complex.normSq_apply]

/-- Write the old amplitudes as U F Vᵀ. Both observables then change by U† A U or V† B V. -/
theorem corr_basis (F : Matrix m n ℂ) (A : Mat m) (B : Mat n)
    (U : Matrix.unitaryGroup m ℂ) (V : Matrix.unitaryGroup n ℂ) :
    corr (U.val * F * V.valᵀ) A B = corr F (U.valᴴ*A*U.val) (V.valᴴ*B*V.val) := by
  rw [corr_trace, corr_trace]
  congr 1
  simp only [Matrix.conjTranspose_mul, Matrix.transpose_mul, Matrix.mul_assoc]
  rw [Matrix.trace_mul_comm (V.valᵀᴴ) _]
  simp only [Matrix.mul_assoc, Matrix.conjTranspose_transpose, Matrix.transpose_conjTranspose]

theorem weight_basis (F : Matrix m n ℂ) (U : Matrix.unitaryGroup m ℂ)
    (V : Matrix.unitaryGroup n ℂ) : weight (U.val * F * V.valᵀ) = weight F := by
  rw [weight_trace, weight_trace]
  congr 1
  have hu : U.valᴴ * U.val = 1 := U.property.1
  have hv : V.valᵀ * V.valᵀᴴ = 1 := by
    have hh := congrArg Matrix.transpose (show V.valᴴ * V.val = 1 from V.property.1)
    simpa only [Matrix.transpose_mul,Matrix.transpose_one,Matrix.transpose_conjTranspose,
      Matrix.conjTranspose_transpose] using hh
  simp only [Matrix.conjTranspose_mul, Matrix.mul_assoc]
  rw [← Matrix.mul_assoc U.valᴴ, hu, Matrix.one_mul, Matrix.trace_mul_comm]
  simp only [Matrix.mul_assoc, hv, Matrix.mul_one]

theorem chsh_basis (F : Matrix m n ℂ) (A₀ A₁ : Mat m) (B₀ B₁ : Mat n)
    (U : Matrix.unitaryGroup m ℂ) (V : Matrix.unitaryGroup n ℂ) :
    chsh (U.val * F * V.valᵀ) A₀ A₁ B₀ B₁ =
    chsh F (U.valᴴ*A₀*U.val) (U.valᴴ*A₁*U.val)
      (V.valᴴ*B₀*V.val) (V.valᴴ*B₁*V.val) := by
  simp only [chsh,corr_basis]

end
end CHSHBasis
