import CHSHBasis
import CHSHBlocks
import CHSHAttain
import JordanThree
import TwoQubitUpper
import CompressionCoefficients
import PairGain

/-! Exact projective CHSH value of a pure state of Schmidt rank at most three.
The optimization is over all four complex Hermitian reflections. -/
namespace QutritCHSH
open CHSH CHSHAttain Matrix
open scoped Matrix BigOperators
noncomputable section

abbrev M := Mat Qutrit
abbrev U3 := Matrix.unitaryGroup Qutrit ℂ
def state (c : Fin 3 → ℝ) : M := diagonal (fun i => (c i : ℂ))
def value (c : Fin 3 → ℝ) : ℝ :=
  2*(c 2)^2 + 2*Real.sqrt (((c 0)^2+(c 1)^2)^2+4*(c 0)^2*(c 1)^2)

def projectiveScores (F : M) : Set ℝ :=
  {s | ∃ A₀ A₁ B₀ B₁ : M, Observable A₀ ∧ Observable A₁ ∧
    Observable B₀ ∧ Observable B₁ ∧ chsh F A₀ A₁ B₀ B₁ = s}

lemma state_weight (c : Fin 3 → ℝ) : weight (state c) = (c 0)^2+(c 1)^2+(c 2)^2 := by
  simp [weight,state,Matrix.diagonal,Fin.sum_univ_three,Complex.normSq_apply,pow_two,add_assoc]

lemma state_attained (c : Fin 3 → ℝ) : value c ∈ projectiveScores (state c) := by
  have he : state c = schmidtState (c 0) (c 1) (c 2) := by
    unfold state schmidtState
    congr 1
    funext i
    fin_cases i <;> rfl
  rw [he]
  exact qutrit_attained _ _ _

def conjugateU (V : U3) : U3 :=
  ⟨(V.valᵀ)ᴴ, by
    constructor
    · change (V.valᵀᴴ)ᴴ * V.valᵀᴴ = 1
      rw [Matrix.conjTranspose_conjTranspose]
      have h := congrArg Matrix.transpose (show V.valᴴ * V.val = 1 from V.property.1)
      simpa only [Matrix.star_eq_conjTranspose,Matrix.conjTranspose_conjTranspose,
        Matrix.transpose_mul,Matrix.transpose_one,Matrix.transpose_conjTranspose,
        Matrix.conjTranspose_transpose,Matrix.transpose_map] using h
    · change V.valᵀᴴ * (V.valᵀᴴ)ᴴ = 1
      rw [Matrix.conjTranspose_conjTranspose]
      have h := congrArg Matrix.transpose (show V.val * V.valᴴ = 1 from V.property.2)
      simpa only [Matrix.star_eq_conjTranspose,Matrix.conjTranspose_conjTranspose,
        Matrix.transpose_mul,Matrix.transpose_one,Matrix.transpose_conjTranspose,
        Matrix.conjTranspose_transpose,Matrix.transpose_map] using h⟩

lemma restore (D : M) (U V : U3) :
    U.val * (U.valᴴ * D * (conjugateU V).val) * V.valᵀ = D := by
  have hu : U.val * U.valᴴ = 1 := U.property.2
  have hv : (conjugateU V).val * V.valᵀ = 1 := by
    have h := congrArg Matrix.transpose (show V.val * V.valᴴ = 1 from V.property.2)
    simpa only [conjugateU,Matrix.transpose_mul,Matrix.transpose_one,
      Matrix.transpose_conjTranspose,Matrix.conjTranspose_transpose] using h
  rw [Matrix.mul_assoc U.valᴴ, ← Matrix.mul_assoc U.val, hu, Matrix.one_mul,
    Matrix.mul_assoc,hv,Matrix.mul_one]

/-- Unrestricted Hermitian-involution upper bound in Schmidt coordinates. -/
theorem upper (c : Fin 3 → ℝ) (hc : Antitone c) (hn : ∀i, 0 ≤ c i)
    (A₀ A₁ B₀ B₁ : M) (hA₀ : Observable A₀) (hA₁ : Observable A₁)
    (hB₀ : Observable B₀) (hB₁ : Observable B₁) :
    chsh (state c) A₀ A₁ B₀ B₁ ≤ value c := by
  obtain ⟨U,A,A',a,a',hA,hA',ha,ha',eA,eA'⟩ :=
    CHSHJordan.simultaneous_observable_blocks _ _ hA₀ hA₁
  obtain ⟨V,B,B',b,b',hB,hB',hb,hb',eB,eB'⟩ :=
    CHSHJordan.simultaneous_observable_blocks _ _ hB₀ hB₁
  let F := U.valᴴ * state c * (conjugateU V).val
  have back : U.val * F * V.valᵀ = state c := restore _ U V
  have hw : weight F = (c 0)^2+(c 1)^2+(c 2)^2 := by
    rw [← CHSHBasis.weight_basis F U V, back, state_weight]
  have he : chsh (state c) A₀ A₁ B₀ B₁ =
      chsh F (block A a) (block A' a') (block B b) (block B' b') := by
    rw [← back, CHSHBasis.chsh_basis, eA,eA',eB,eB']
  obtain ⟨x,y,hy,hyx,hxa,hyb,hweight,hdet⟩ :=
    CHSHCompression.compression_singular_bounds (star U) (conjugateU V) c hc hn
  change weight (top F) = x^2+y^2 at hweight
  change ‖(top F).det‖ = x*y at hdet
  apply CHSHPair.envelope (hy.trans hyx) hy hxa hyb hw
  rw [he]
  have ht := TwoQubit.upper (top F) A A' B B' hA hA' hB hB'
  rw [Complex.normSq_eq_norm_sq,hdet,hweight] at ht
  have hh := CHSH.block_bound F A A' B B' a a' b b' hA hA' hB hB' ha ha' hb hb'
  rw [hweight] at hh
  linarith

theorem exact_projective (c : Fin 3 → ℝ) (hc : Antitone c) (hn : ∀i, 0 ≤ c i) :
    IsGreatest (projectiveScores (state c)) (value c) := by
  refine ⟨state_attained c,?_⟩
  rintro _ ⟨A,X,B,Y,hA,hX,hB,hY,rfl⟩
  exact upper c hc hn _ _ _ _ hA hX hB hY

#print axioms exact_projective
end
end QutritCHSH
