import OddSplit
import CHSHTsirelson
import Mathlib.Analysis.Matrix.PosDef

/-! A Pauli-independent CHSH deficit in every odd local dimension.
Here m is any lower bound on Alice's unnormalized reduced density matrix. -/
namespace CHSHOdd
open Matrix CHSH CHSHOddJordan CHSHBasis
open scoped Matrix BigOperators ComplexOrder
noncomputable section
variable {d : ℕ} {n : Type*} [Fintype n] [DecidableEq n]
local notation "GMat" => Matrix (Fin d) n ℂ
local notation "AMat" => Mat (Fin d)

omit [DecidableEq n] in
private theorem row_density (l : Fin d) (G : GMat) :
    (G*Gᴴ) l l = (weight (singleRow l G) : ℂ) := by
  rw [weight_single,Complex.ofReal_sum]
  simp only [Matrix.mul_apply,Matrix.conjTranspose_apply,Complex.normSq_eq_conj_mul_self]
  apply Finset.sum_congr rfl
  intro i _
  rw [mul_comm]
  rfl

omit [DecidableEq n] in
theorem marginal_floor (l : Fin d) (F : GMat) (U : unitaryGroup (Fin d) ℂ) (m : ℝ)
    (hm : (F*Fᴴ - (m:ℂ) • (1:AMat)).PosSemidef) :
    m ≤ weight (singleRow l (U.valᴴ * F)) := by
  have h := hm.conjTranspose_mul_mul_same U.val
  have hi : U.valᴴ * U.val = 1 := U.property.1
  have eq : U.valᴴ * (F*Fᴴ - (m:ℂ) • (1:AMat)) * U.val =
      (U.valᴴ*F)*(U.valᴴ*F)ᴴ - (m:ℂ) • (1:AMat) := by
    simp only [Matrix.mul_sub,Matrix.sub_mul,Matrix.mul_smul,Matrix.smul_mul,
      Matrix.mul_one,hi,Matrix.conjTranspose_mul,Matrix.conjTranspose_conjTranspose,Matrix.mul_assoc]
  rw [eq] at h
  let G := U.valᴴ * F
  change (G*Gᴴ - (m:ℂ) • (1:AMat)).PosSemidef at h
  have hg : 0 ≤ (G*Gᴴ - (m:ℂ) • (1:AMat)) l l := by
    simpa [dotProduct,Pi.single_apply] using h.dotProduct_mulVec_nonneg (Pi.single l 1)
  rw [Matrix.sub_apply, row_density] at hg
  simpa using (Complex.nonneg_iff.mp hg).1

/-- The full odd-dimensional CHSH bound for arbitrary finite Bob dimension,
arbitrary pure amplitudes (without normalization), and four dichotomic observables. -/
theorem upper {k : ℕ} (hd : d=2*k+1) (F : GMat)
    (A C : AMat) (B D : Mat n) (hA : Observable A) (hC : Observable C)
    (hB : Observable B) (hD : Observable D) (m : ℝ)
    (hm : (F*Fᴴ - (m:ℂ) • (1:AMat)).PosSemidef) :
    chsh F A C B D ≤ 2*Real.sqrt 2*weight F - (2*Real.sqrt 2-2)*m := by
  let l : Fin d := ⟨0,by omega⟩
  obtain ⟨U,a,c,ha,hc,hAU,hCU⟩ := simultaneous_blocks k hd l A C hA.1 hC.1 hA.2 hC.2
  let G := U.valᴴ*F
  have left := chsh_basis G A C B D U (1:unitaryGroup n ℂ)
  have w := weight_basis G U (1:unitaryGroup n ℂ)
  have un : U.val*U.valᴴ=1 := U.property.2
  have old : U.val*G=F := by dsimp [G]; rw [←Matrix.mul_assoc,un,Matrix.one_mul]
  have hone : (1:unitaryGroup n ℂ).val = (1:Mat n) := rfl
  simp only [hone,Matrix.transpose_one,Matrix.conjTranspose_one,Matrix.mul_one,
    Matrix.one_mul,old] at left w
  rw [left, chsh_split l G _ _ B D a c hAU hCU]
  have hrest := CHSHTsirelson.upper (otherRows l G) _ _ B D
    (conjugated_observable A hA U) (conjugated_observable C hC U) hB hD
  have hlast := isolated_classical l G a c B D ha hc hB hD
  have hfloor := marginal_floor l F U m hm
  change m ≤ weight (singleRow l G) at hfloor
  have hs := weight_split l G
  have h2 : 1 ≤ Real.sqrt 2 := by norm_num
  nlinarith only [hrest,hlast, hs, w, mul_nonneg (show 0 ≤ 2*Real.sqrt 2-2 by linarith) (sub_nonneg.mpr hfloor),
    congrArg ((2*Real.sqrt 2) * ·) hs, congrArg ((2*Real.sqrt 2) * ·) w]

/-- In a Schmidt basis the matrix lower bound is the smallest Schmidt probability. -/
theorem schmidt_upper {k : ℕ} (hd : d=2*k+1) (r : Fin d → ℝ)
    (A C B D : AMat) (hA : Observable A) (hC : Observable C)
    (hB : Observable B) (hD : Observable D) (m : ℝ) (hm : ∀ i, m ≤ (r i)^2) :
    chsh (diagonal fun i => (r i:ℂ)) A C B D ≤
      2*Real.sqrt 2*weight (diagonal fun i => (r i:ℂ)) - (2*Real.sqrt 2-2)*m := by
  apply upper hd _ A C B D hA hC hB hD m
  convert Matrix.PosSemidef.diagonal (d:=fun i => (((r i)^2-m:ℝ):ℂ))
      (show ∀ i, 0 ≤ (((r i)^2-m:ℝ):ℂ) by intro i; exact_mod_cast sub_nonneg.mpr (hm i)) using 1
  ext i j
  by_cases hij : i=j
  · subst j; simp [pow_two]
  · simp [hij]

/-- Least eigenvalue of Alice's unnormalized reduced density matrix. -/
def leastAliceProbability (hd : 0<d) (F : GMat) : ℝ :=
  (Finset.univ : Finset (Fin d)).inf' ⟨⟨0,hd⟩,Finset.mem_univ _⟩
    (Matrix.isHermitian_mul_conjTranspose_self F).eigenvalues

private theorem density_floor_of_spectrum (A : AMat) (hA : A.IsHermitian) {m : ℝ}
    (hm : ∀ i, m ≤ hA.eigenvalues i) : (A - (m:ℂ) • (1:AMat)).PosSemidef := by
  let U := hA.eigenvectorUnitary
  let D := diagonal fun i => (hA.eigenvalues i : ℂ)
  have diag : A = U.val * D * U.valᴴ := hA.spectral_theorem
  have hdiff : (D-(m:ℂ) • (1:AMat)).PosSemidef := by
    convert Matrix.PosSemidef.diagonal (d:=fun i => (((hA.eigenvalues i)-m:ℝ):ℂ))
      (show ∀ i, 0 ≤ (((hA.eigenvalues i)-m:ℝ):ℂ) by
        intro i; exact_mod_cast sub_nonneg.mpr (hm i)) using 1
    ext i j
    by_cases h:i=j
    · subst j; simp [D]
    · simp [D, h]
  have hp := hdiff.mul_mul_conjTranspose_same U.val
  have hi : U.val*U.valᴴ=1 := U.property.2
  rwa [Matrix.mul_sub, Matrix.sub_mul, Matrix.mul_smul, Matrix.mul_one, Matrix.smul_mul,
    hi, ←diag] at hp

/-- State-dependent Tsirelson deficit, with the smallest marginal eigenvalue
computed from the actual arbitrary pure-state amplitude matrix. -/
theorem upper_least {k : ℕ} (hd : d=2*k+1) (F : GMat)
    (A C : AMat) (B D : Mat n) (hA : Observable A) (hC : Observable C)
    (hB : Observable B) (hD : Observable D) :
    chsh F A C B D ≤ 2*Real.sqrt 2*weight F -
      (2*Real.sqrt 2-2)*leastAliceProbability (by omega) F := by
  apply upper hd F A C B D hA hC hB hD
  apply density_floor_of_spectrum _ (Matrix.isHermitian_mul_conjTranspose_self F)
  intro i
  exact Finset.inf'_le _ (Finset.mem_univ i)

#print axioms upper_least
#print axioms upper
#print axioms schmidt_upper
end
end CHSHOdd
