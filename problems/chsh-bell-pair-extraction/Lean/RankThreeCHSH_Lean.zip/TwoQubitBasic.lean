import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Data.Real.Sqrt

namespace TwoQubit
noncomputable section
open scoped BigOperators
abbrev V := Fin 3 → ℝ

def dot (a b : V) : ℝ := ∑ i, a i * b i
def sq (a : V) : ℝ := dot a a
end
end TwoQubit
