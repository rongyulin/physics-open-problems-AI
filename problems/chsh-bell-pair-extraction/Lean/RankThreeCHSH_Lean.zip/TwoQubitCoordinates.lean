import TwoQubitBasic
import CHSHDefs
import Mathlib.Tactic
import Mathlib.Algebra.BigOperators.Fin

/-! The real correlation tensor of a pure two-qubit state. The three
axes are X, Y and Z; the state need not be normalized. -/
namespace TwoQubit
noncomputable section
open scoped BigOperators Matrix
open CHSH
abbrev Q := Mat (Fin 2)

def pauli (v : V) : Q := !![(v 2:ℂ), ⟨v 0, -v 1⟩; ⟨v 0,v 1⟩, -(v 2:ℂ)]

private def tensor (F : Q) : Matrix (Fin 3) (Fin 3) ℝ := !![
2*(F 0 0).re*(F 1 1).re + 2*(F 0 0).im*(F 1 1).im + 2*(F 0 1).re*(F 1 0).re + 2*(F 0 1).im*(F 1 0).im, 2*(F 0 0).re*(F 1 1).im - 2*(F 0 0).im*(F 1 1).re - 2*(F 0 1).re*(F 1 0).im + 2*(F 0 1).im*(F 1 0).re, 2*(F 0 0).re*(F 1 0).re + 2*(F 0 0).im*(F 1 0).im - 2*(F 0 1).re*(F 1 1).re - 2*(F 0 1).im*(F 1 1).im;
2*(F 0 0).re*(F 1 1).im - 2*(F 0 0).im*(F 1 1).re + 2*(F 0 1).re*(F 1 0).im - 2*(F 0 1).im*(F 1 0).re, -2*(F 0 0).re*(F 1 1).re - 2*(F 0 0).im*(F 1 1).im + 2*(F 0 1).re*(F 1 0).re + 2*(F 0 1).im*(F 1 0).im, 2*(F 0 0).re*(F 1 0).im - 2*(F 0 0).im*(F 1 0).re - 2*(F 0 1).re*(F 1 1).im + 2*(F 0 1).im*(F 1 1).re;
2*(F 0 0).re*(F 0 1).re + 2*(F 0 0).im*(F 0 1).im - 2*(F 1 0).re*(F 1 1).re - 2*(F 1 0).im*(F 1 1).im, 2*(F 0 0).re*(F 0 1).im - 2*(F 0 0).im*(F 0 1).re - 2*(F 1 0).re*(F 1 1).im + 2*(F 1 0).im*(F 1 1).re, (F 0 0).re^2 + (F 0 0).im^2 - (F 0 1).re^2 - (F 0 1).im^2 - (F 1 0).re^2 - (F 1 0).im^2 + (F 1 1).re^2 + (F 1 1).im^2]

def bobVector (F : Q) : V := ![2*(F 0 0).re*(F 0 1).re + 2*(F 0 0).im*(F 0 1).im + 2*(F 1 0).re*(F 1 1).re + 2*(F 1 0).im*(F 1 1).im,
2*(F 0 0).re*(F 0 1).im - 2*(F 0 0).im*(F 0 1).re + 2*(F 1 0).re*(F 1 1).im - 2*(F 1 0).im*(F 1 1).re,
(F 0 0).re^2 + (F 0 0).im^2 - (F 0 1).re^2 - (F 0 1).im^2 + (F 1 0).re^2 + (F 1 0).im^2 - (F 1 1).re^2 - (F 1 1).im^2]

def imageVec (F : Q) (v : V) : V := fun j => ∑ k, tensor F j k * v k

set_option linter.unusedSimpArgs false
set_option maxHeartbeats 3000000
set_option maxRecDepth 12000

/-- Pauli coordinates reproduce the CHSH correlation in the computational basis. -/
theorem corr_pauli (F:Q) (u v:V) : corr F (pauli u) (pauli v) = dot u (imageVec F v) := by
  simp [corr, pauli, dot, imageVec, tensor, Fin.sum_univ_two, Fin.sum_univ_three, Complex.star_def,
    Complex.mul_re, Complex.mul_im, Complex.add_re, Complex.add_im] <;> ring

/-- The pure-state correlation tensor obeys TᵀT = 4|det F|² I + rrᵀ. -/
theorem image_sq (F : Q) (v : V) : sq (imageVec F v) =
    (4*Complex.normSq F.det)*sq v + (dot (bobVector F) v)^2 := by
  simp [sq,dot,imageVec,tensor,bobVector, Matrix.det_fin_two, Complex.normSq_apply,
    Complex.sub_re, Complex.sub_im, Complex.mul_re, Complex.mul_im, Fin.sum_univ_three] <;> ring

theorem bob_sq (F:Q) : sq (bobVector F) = (weight F)^2 - 4*Complex.normSq F.det := by
  simp [sq,dot,bobVector,weight, Matrix.det_fin_two, Complex.normSq_apply,
    Complex.sub_re, Complex.sub_im, Complex.mul_re, Complex.mul_im,
    Fin.sum_univ_three, Fin.sum_univ_two] <;> ring

/-- A nonconstant binary qubit observable is a Pauli direction of unit length. -/
theorem pauli_or_scalar {A:Q} (h : Observable A) :
    A=1 ∨ A= -1 ∨ ∃ v:V, sq v = 1 ∧ A=pauli v := by
  obtain ⟨ha, hprod⟩ := h
  have h00 := congrArg (fun M:Q => (M 0 0).im) ha.eq
  have h11 := congrArg (fun M:Q => (M 1 1).im) ha.eq
  have h01 := congrArg (fun M:Q => M 1 0) ha.eq
  simp [Matrix.conjTranspose_apply,Complex.star_def] at h00 h11 h01
  have a0 : (A 0 0).im = 0 := by linarith
  have a1 : (A 1 1).im = 0 := by linarith
  have a01 := congrArg Complex.re h01
  have b01 := congrArg Complex.im h01
  simp at a01 b01
  have eq00 := congrArg (fun M:Q => (M 0 0).re) hprod
  have eq11 := congrArg (fun M:Q => (M 1 1).re) hprod
  have eq01r := congrArg (fun M:Q => (M 0 1).re) hprod
  have eq01i := congrArg (fun M:Q => (M 0 1).im) hprod
  simp [Matrix.mul_apply,Matrix.one_apply,Fin.sum_univ_two,Complex.mul_re,Complex.mul_im,a0,a1] at eq00 eq11 eq01r eq01i
  rw [← a01, ← b01] at eq00 eq11
  by_cases ht : (A 0 0).re + (A 1 1).re = 0
  · right; right
    refine ⟨![(A 0 1).re, -(A 0 1).im, (A 0 0).re], ?_, ?_⟩
    · simp [sq,dot,Fin.sum_univ_three]; nlinarith
    · apply Matrix.ext; intro i j
      fin_cases i <;> fin_cases j <;> apply Complex.ext <;> simp [pauli] <;> linarith
  · have z0 : (A 0 1).re=0 := by
      apply (mul_eq_zero.mp (show ((A 0 0).re+(A 1 1).re) * (A 0 1).re=0 by linarith [eq01r])).resolve_left ht
    have z1 : (A 0 1).im=0 := by
      apply (mul_eq_zero.mp (show ((A 0 0).re+(A 1 1).re) * (A 0 1).im=0 by linarith [eq01i])).resolve_left ht
    have t0 : (A 0 0).re = 1 ∨ (A 0 0).re = -1 := by
      apply or_iff_not_imp_left.mpr; intro h; exact (mul_eq_zero.mp (show ((A 0 0).re-1)*((A 0 0).re+1)=0 by rw [z0,z1] at eq00; nlinarith)).resolve_left (sub_ne_zero.mpr h) |> fun hi => by linarith
    have t1 : (A 1 1).re = 1 ∨ (A 1 1).re = -1 := by
      apply or_iff_not_imp_left.mpr; intro h; exact (mul_eq_zero.mp (show ((A 1 1).re-1)*((A 1 1).re+1)=0 by rw [z0,z1] at eq11; nlinarith)).resolve_left (sub_ne_zero.mpr h) |> fun hi => by linarith
    rcases t0 with h0|h0 <;> rcases t1 with h1|h1
    · left; apply Matrix.ext; intro i j; fin_cases i <;> fin_cases j <;> apply Complex.ext <;> simp [Matrix.one_apply] <;> linarith
    · exact False.elim (ht (by linarith))
    · exact False.elim (ht (by linarith))
    · right; left; apply Matrix.ext; intro i j; fin_cases i <;> fin_cases j <;> apply Complex.ext <;> simp [Matrix.one_apply] <;> linarith
end
end TwoQubit
