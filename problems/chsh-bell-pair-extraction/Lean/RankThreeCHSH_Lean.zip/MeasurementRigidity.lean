import RigidityLeak
import RigidityGain
import QutritCHSH

/-! Stability of the singleton sectors of arbitrary Jordan decompositions of
near-optimal projective measurements on a pure Schmidt-diagonal qutrit pair. -/
namespace CHSHRigidity
open scoped Matrix BigOperators
open CHSH QutritCHSH
noncomputable section

/-- The last column of U is the common singleton of the two measurements. -/
def JordanBasis (U : U3) (A A' : M) : Prop :=
  ∃ (X X' : Mat (Fin 2)) (a a' : ℝ), Observable X ∧ Observable X' ∧
    (a=1 ∨ a= -1) ∧ (a'=1 ∨ a'= -1) ∧
    U.valᴴ * A * U.val = block X a ∧ U.valᴴ * A' * U.val = block X' a'

theorem exists_jordanBasis {A A' : M} (h : Observable A) (h' : Observable A') :
    ∃ U : U3, JordanBasis U A A' := CHSHJordan.simultaneous_observable_blocks _ _ h h'

/-- The score deficit controls the squared projections of both common
singletons away from their least-weight Schmidt line. The claim holds for
every Jordan basis realizing the indicated physical measurements. -/
theorem measurement_stability (c : Fin 3 → ℝ) (hc : Antitone c) (hn : ∀ i, 0 ≤ c i)
    (hb : 0<c 1) (A A' B B' : M) (U V : U3)
    (hu : JordanBasis U A A') (hv : JordanBasis V B B') :
    2 * slope ((c 0)^2) ((c 1)^2) * ((c 1)^2-(c 2)^2) * max (leak U) (leak V) ≤
      value c - chsh (state c) A A' B B' := by
  obtain ⟨X,X',a,a',hX,hX',ha,ha',eA,eA'⟩ := hu
  obtain ⟨Y,Y',b,b',hY,hY',hb',hb'',eB,eB'⟩ := hv
  let F := U.valᴴ * state c * (conjugateU V).val
  have back : U.val * F * V.valᵀ = state c := restore _ U V
  have hw : weight F = (c 0)^2+(c 1)^2+(c 2)^2 := by
    rw [← CHSHBasis.weight_basis F U V,back,state_weight]
  have he : chsh (state c) A A' B B' =
      chsh F (block X a) (block X' a') (block Y b) (block Y' b') := by
    rw [← back, CHSHBasis.chsh_basis, eA,eA',eB,eB']
  obtain ⟨x,y,hy,hyx,hxa,hyb,hweight,hdet⟩ :=
    CHSHCompression.compression_singular_bounds (star U) (conjugateU V) c hc hn
  change weight (top F)=x^2+y^2 at hweight
  change ‖(top F).det‖=x*y at hdet
  have ht := TwoQubit.upper (top F) X X' Y Y' hX hX' hY hY'
  rw [Complex.normSq_eq_norm_sq,hdet,hweight,mul_pow] at ht
  have hbl := CHSH.block_bound F X X' Y Y' a a' b b' hX hX' hY hY' ha ha' hb' hb''
  rw [hw,hweight,← he] at hbl
  have hba : (c 1)^2 ≤ (c 0)^2 := pow_le_pow_left₀ (hn 1) (hc (by decide : (0:Fin 3)≤1)) 2
  have hbp : 0 < (c 1)^2 := sq_pos_of_pos hb
  have hgain := gain_loss hbp hba (sq_nonneg x) (sq_nonneg y) (pow_le_pow_left₀ hy hyb 2)
  have hleak := leak_bound c hc hn U V
  change ((c 1)^2-(c 2)^2)*max (leak U) (leak V) ≤ (c 0)^2+(c 1)^2-weight (top F) at hleak
  rw [hweight] at hleak
  have hm := mul_le_mul_of_nonneg_left hleak (slope_pos hbp hba).le
  unfold CHSHPair.gain at hgain
  unfold value
  rw [← mul_assoc (4:ℝ) (x^2) (y^2)] at ht
  linarith only [ht,hbl,hgain,hm]

/-- When the second Schmidt coefficient is separated from the third, exact
maximizers have the smallest Schmidt line as their common singleton on both sides. -/
theorem exact_singletons (c : Fin 3 → ℝ) (hc : Antitone c) (hn : ∀ i, 0 ≤ c i)
    (gap : c 2<c 1) (A A' B B' : M) (U V : U3)
    (hu : JordanBasis U A A') (hv : JordanBasis V B B')
    (exactScore : chsh (state c) A A' B B' = value c) :
    U.val 0 2=0 ∧ U.val 1 2=0 ∧ V.val 0 2=0 ∧ V.val 1 2=0 := by
  have hb := (hn 2).trans_lt gap
  have h := measurement_stability c hc hn hb A A' B B' U V hu hv
  rw [exactScore,sub_self] at h
  have hba : (c 1)^2 ≤ (c 0)^2 := pow_le_pow_left₀ (hn 1) (hc (by decide : (0:Fin 3)≤1)) 2
  have hs := slope_pos (sq_pos_of_pos hb) hba
  have diff : 0 < (c 1)^2-(c 2)^2 := by nlinarith [mul_pos (sub_pos.mpr gap) (show 0<c 1+c 2 by linarith [hn 2])]
  have hz : max (leak U) (leak V) ≤ 0 :=
    nonpos_of_mul_nonpos_right h (show 0<2*slope ((c 0)^2) ((c 1)^2) * ((c 1)^2-(c 2)^2) by positivity)
  have hu' := (le_max_left (leak U) (leak V)).trans hz
  have hv' := (le_max_right (leak U) (leak V)).trans hz
  unfold leak at hu' hv'
  exact ⟨Complex.normSq_eq_zero.mp (by linarith [Complex.normSq_nonneg (U.val 1 2),Complex.normSq_nonneg (U.val 0 2)]),
    Complex.normSq_eq_zero.mp (by linarith [Complex.normSq_nonneg (U.val 1 2),Complex.normSq_nonneg (U.val 0 2)]),
    Complex.normSq_eq_zero.mp (by linarith [Complex.normSq_nonneg (V.val 1 2),Complex.normSq_nonneg (V.val 0 2)]),
    Complex.normSq_eq_zero.mp (by linarith [Complex.normSq_nonneg (V.val 1 2),Complex.normSq_nonneg (V.val 0 2)])⟩

private lemma change_jordanBasis (R U : U3) {A A' : M} (h : JordanBasis U A A') :
    JordanBasis (star R * U) (R.valᴴ * A * R.val) (R.valᴴ * A' * R.val) := by
  obtain ⟨X,X',a,a',hX,hX',ha,ha',eA,eA'⟩ := h
  have cancel (T : M) : (R.valᴴ*U.val)ᴴ*(R.valᴴ*T*R.val)*(R.valᴴ*U.val) =
      U.valᴴ*T*U.val := by
    calc
      _ = (U.valᴴ*(R.val*R.valᴴ))*T*((R.val*R.valᴴ)*U.val) := by
        simp only [Matrix.conjTranspose_mul, Matrix.conjTranspose_conjTranspose, Matrix.mul_assoc]
      _ = _ := by rw [show R.val*R.valᴴ=1 from R.property.2, Matrix.mul_one, Matrix.one_mul]
  exact ⟨X,X',a,a',hX,hX',ha,ha',(cancel A).trans eA,(cancel A').trans eA'⟩

/-- Lab-frame version. R and S contain the ordered Schmidt vectors and U and V
contain the physical measurement singletons in their last columns. -/
theorem physical_stability (F : M) (c : Fin 3 → ℝ) (hc : Antitone c) (hn : ∀ i, 0 ≤ c i)
    (hb : 0<c 1) (R S : U3) (hF : F = R.val*state c*S.valᵀ)
    (A A' B B' : M) (U V : U3) (hu : JordanBasis U A A') (hv : JordanBasis V B B') :
    2*slope ((c 0)^2) ((c 1)^2)*((c 1)^2-(c 2)^2)*max (leak (star R*U)) (leak (star S*V))
      ≤ value c - chsh F A A' B B' := by
  rw [hF,CHSHBasis.chsh_basis]
  exact measurement_stability c hc hn hb _ _ _ _ _ _ (change_jordanBasis R U hu) (change_jordanBasis S V hv)

#print axioms physical_stability
#print axioms measurement_stability
#print axioms exact_singletons
end
end CHSHRigidity
