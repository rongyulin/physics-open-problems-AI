import CHSHDefs
import CHSHBasis
import CHSHClassical
import OddJordan
namespace CHSHOdd
open CHSH Matrix CHSHOddJordan
open scoped Matrix BigOperators
noncomputable section
variable {d : ℕ} {n : Type*} [Fintype n] [DecidableEq n]
local notation "GMat" => Matrix (Fin d) n ℂ
local notation "AMat" => Mat (Fin d)
def singleRow (l : Fin d) (F : GMat) : GMat := fun i j => if i=l then F i j else 0
def otherRows (l : Fin d) (F : GMat) : GMat := fun i j => if i=l then 0 else F i j

omit [DecidableEq n] in
theorem weight_split (l : Fin d) (F : GMat) :
    weight F = weight (otherRows l F) + weight (singleRow l F) := by
  unfold weight
  simp only [←Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro i _
  by_cases h : i=l <;> simp [otherRows,singleRow,h]

omit [DecidableEq n] in
theorem weight_single (l : Fin d) (F : GMat) :
    weight (singleRow l F) = ∑ j, Complex.normSq (F l j) := by
  simp [weight,singleRow, apply_ite, Finset.sum_ite_irrel, Finset.sum_ite_eq']

omit [DecidableEq n] in
theorem corr_split (l : Fin d) (F : GMat) (A : AMat) (B : Mat n) (a : ℂ)
    (ha : LastBlock l A a) :
    corr F A B = corr (otherRows l F) A B + corr (singleRow l F) (a • (1:AMat)) B := by
  unfold corr
  rw [←Complex.add_re]
  congr 1
  simp only [←Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro i _
  apply Finset.sum_congr rfl
  intro j _
  apply Finset.sum_congr rfl
  intro k _
  apply Finset.sum_congr rfl
  intro t _
  by_cases hi : i=l <;> by_cases hk : k=l
  · subst i; subst k; simp [otherRows,singleRow,ha.1]
  · subst i; simp [otherRows,singleRow,hk,ha.2]
  · subst k; simp [otherRows,singleRow,hi,ha.1]
  · simp [otherRows,singleRow,hi,hk]

omit [DecidableEq n] in
theorem chsh_split (l : Fin d) (F : GMat) (A C : AMat) (B D : Mat n) (a c : ℂ)
    (ha : LastBlock l A a) (hc : LastBlock l C c) :
    chsh F A C B D =
      chsh (otherRows l F) A C B D + chsh (singleRow l F)
        (a • (1:AMat)) (c • (1:AMat)) B D := by
  unfold chsh
  rw [corr_split l F A B a ha, corr_split l F A D a ha,
    corr_split l F C B c hc, corr_split l F C D c hc]
  ring

theorem isolated_classical (l : Fin d) (F : GMat) (a c : ℂ) (B D : Mat n)
    (ha : a=1 ∨ a= -1) (hc : c=1 ∨ c= -1) (hb : Observable B) (hd : Observable D) :
    chsh (singleRow l F) (a • (1:AMat)) (c • (1:AMat)) B D ≤ 2*weight (singleRow l F) := by
  rcases ha with rfl|rfl <;> rcases hc with rfl|rfl <;> simp only [one_smul,neg_one_smul]
  all_goals
    apply CHSHClassical.degenerate _ _ _ _ _ _ _ hb hd
  all_goals simp [Observable]

theorem conjugated_observable (A : AMat) (h : Observable A) (U : unitaryGroup (Fin d) ℂ) :
    Observable (U.valᴴ * A * U.val) := by
  refine ⟨Matrix.isHermitian_conjTranspose_mul_mul _ h.1, ?_⟩
  have hi : U.val*U.valᴴ=1 := U.property.2
  have hj : U.valᴴ*U.val=1 := U.property.1
  calc
    _ = U.valᴴ * (A * (U.val * U.valᴴ) * A) * U.val := by simp only [Matrix.mul_assoc]
    _ = 1 := by rw [hi,Matrix.mul_one,h.2,Matrix.mul_one,hj]

end
end CHSHOdd
