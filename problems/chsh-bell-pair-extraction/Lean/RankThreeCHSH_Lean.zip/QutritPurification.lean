import SchmidtPullback
import Mathlib.Analysis.Matrix.Order
import Mathlib.LinearAlgebra.Matrix.Kronecker

/-! Purification of a positive density matrix, and the equality of correlations
when Bob's measurement is extended by the identity on the environment. -/
namespace CHSHMixed
open CHSH Matrix
open scoped BigOperators Matrix Kronecker ComplexOrder MatrixOrder
noncomputable section
variable {n : Type*} [Fintype n] [DecidableEq n]

def marginal (R : Mat (Fin 3 × n)) : Mat (Fin 3) := fun i k => ∑ j, R (i,j) (k,j)

def mixedCorr (R : Mat (Fin 3 × n)) (A : Mat (Fin 3)) (B : Mat n) : ℝ :=
  (∑ i, ∑ j, ∑ k, ∑ l, R (k,l) (i,j) * A i k * B j l).re

def mixedCHSH (R : Mat (Fin 3 × n)) (A₀ A₁ : Mat (Fin 3)) (B₀ B₁ : Mat n) : ℝ :=
  mixedCorr R A₀ B₀ + mixedCorr R A₀ B₁ + mixedCorr R A₁ B₀ - mixedCorr R A₁ B₁

private def purified {e : Type*} (P : Matrix (Fin 3 × n) e ℂ) : Matrix (Fin 3) (n × e) ℂ :=
  fun i u => P (i,u.1) u.2

omit [DecidableEq n] in
private theorem purification_rows {e : Type*} [Fintype e] (R : Mat (Fin 3 × n)) (P : Matrix (Fin 3 × n) e ℂ) (fac : R=P*Pᴴ)
    (c : Fin 3 → ℝ) (hm : marginal R = diagonal (fun i => (c i : ℂ)^2)) :
    SchmidtRows c (purified P) := by
  intro i k
  have h := congrFun (congrFun hm k) i
  change (∑ j, R (k,j) (i,j)) = _ at h
  rw [fac] at h
  simp only [purified, Fintype.sum_prod_type]
  convert h using 1
  · simp [Matrix.mul_apply,Matrix.conjTranspose_apply,mul_comm]
  · by_cases he : i=k
    · simp [he]
    · simp [he,Ne.symm he]

omit [DecidableEq n] in
private theorem mixedCorr_purified {e : Type*} [Fintype e] [DecidableEq e] (R : Mat (Fin 3 × n)) (P : Matrix (Fin 3 × n) e ℂ) (fac : R=P*Pᴴ)
    (A : Mat (Fin 3)) (B : Mat n) :
    mixedCorr R A B = corr (purified P) A (B ⊗ₖ (1 : Mat e)) := by
  unfold mixedCorr corr
  congr 1
  simp only [fac,Matrix.mul_apply,Matrix.conjTranspose_apply, Fintype.sum_prod_type,
    purified, Matrix.kronecker_apply,Matrix.one_apply, mul_ite, mul_one, mul_zero, ite_mul,
    zero_mul, Finset.sum_ite_eq, Finset.mem_univ, if_true,Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro i _
  apply Finset.sum_congr rfl
  intro j _
  conv_rhs => rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro k _
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro l _
  apply Finset.sum_congr rfl
  intro a _
  ring

theorem mixed_reduction (R : Mat (Fin 3 × n)) (hR : R.PosSemidef) (c : Fin 3 → ℝ)
    (hm : marginal R = diagonal (fun i => (c i : ℂ)^2)) :
    ∃ mapB : Mat n → Mat (Fin 3),
      (∀ B, (1+B).PosSemidef → (1-B).PosSemidef →
        (1+mapB B).PosSemidef ∧ (1-mapB B).PosSemidef) ∧
      (∀ A B, mixedCorr R A B = corr (diagonal fun i => (c i:ℂ)) A (mapB B)) := by
  classical
  obtain ⟨X,hX⟩ := CStarAlgebra.nonneg_iff_eq_star_mul_self.mp hR.nonneg
  let P := Xᴴ
  have fac : R=P*Pᴴ := by simpa [P] using hX
  have hs := purification_rows R P fac c hm
  refine ⟨fun B => pull c (purified P) (B ⊗ₖ (1 : Mat (Fin 3 × n))),?_,?_⟩
  · intro B hp hn
    apply pull_effects c (purified P) hs
    · simpa only [Matrix.add_kronecker, Matrix.one_kronecker_one] using
        hp.kronecker (Matrix.PosSemidef.one : (1 : Mat (Fin 3 × n)).PosSemidef)
    · have he : ((1-B) ⊗ₖ (1 : Mat (Fin 3 × n))) =
            1 - (B ⊗ₖ (1 : Mat (Fin 3 × n))) := by
        calc
          _ = (1 : Mat n) ⊗ₖ (1 : Mat (Fin 3 × n)) - B ⊗ₖ (1 : Mat (Fin 3 × n)) := by
            ext i j
            exact sub_mul _ _ _
          _ = _ := by rw [Matrix.one_kronecker_one]
      rw [← he]
      exact hn.kronecker Matrix.PosSemidef.one
  · intro A B
    exact (mixedCorr_purified R P fac A B).trans (corr_pull c _ hs A _)

#print axioms mixed_reduction
end
end CHSHMixed
