import FidelitySpectra
import CHSHScoreInterval
import RawExtraction
import BellMaximum

/-! The rank-three singlet-fidelity frontier for *an exactly observed* CHSH
value. Both settings on either side are arbitrary positive binary effects.
The extraction score optimizes over arbitrary finite local isometries and
ancillary Schmidt amplitudes in the state's local Schmidt bases. -/
namespace CHSHFrontier
open CHSH QutritCHSH CHSHPOVM CHSHScoreInterval Matrix
open scoped Matrix BigOperators
noncomputable section

/-- The state F has a genuine locally rotated Schmidt decomposition. The
scores of both experiments are operational: four binary POVMs realize
exactly 2s, and the extraction squared overlap is maximized at f. -/
def observedFidelities (s : ℝ) : Set ℝ :=
  {f | ∃ F : M, weight F = 1 ∧ 2*s ∈ effectScores F ∧ IsGreatest (RawExtraction.scores F) f}

/-- With a specified Schmidt basis, the complete nonnegative score interval
is obtained using positive effects. -/
theorem compatible_effect_iff (F : M) (U V : U3) (c : Fin 3 → ℝ)
    (hc : Antitone c) (hn : ∀ i, 0 ≤ c i) (he : F = U.val * state c * V.valᵀ)
    (S : ℝ) (hS : 0 ≤ S) : S ∈ effectScores F ↔ S ≤ value c := by
  have hproj : IsGreatest (projectiveScores F) (value c) := by
    rw [he, BellMaximum.projective_invariant]
    exact exact_projective c hc hn
  constructor
  · intro h
    obtain ⟨A,X,B,Y,hA,hX,hB,hY,hs⟩ := effect_to_contractions h
    obtain ⟨P,Q,R,T,hP,hQ,hR,hT,hu⟩ := projectivize F A X B Y hA hX hB hY
    rw [← hs]
    exact hu.trans (hproj.2 ⟨_,_,_,_,hP,hQ,hR,hT,rfl⟩)
  · intro h
    obtain ⟨P,Q,R,T,hP,hQ,hR,hT,hs⟩ := hproj.1
    exact exact_score F P Q R T hP hQ hR hT S (value c) hs hS h

theorem observed_iff_scalar (s f : ℝ) (hs : 0 ≤ s) :
    f ∈ observedFidelities s ↔ ∃ w, feasible s w ∧ f = (1+w)/2 := by
  constructor
  · rintro ⟨F,hwt,hS,hf⟩
    obtain ⟨U,V,c,hc,hn,he⟩ := CHSHSchmidt.factor F
    change F = U.val * state c * V.valᵀ at he
    rw [he, RawExtraction.scores_basis, RawExtraction.scores_diagonal] at hf
    have hnorm : (c 0)^2+(c 1)^2+(c 2)^2=1 := by
      rw [← state_weight, ← CHSHBasis.weight_basis (state c) U V, ← he, hwt]
    have hmax := MYFidelity.operational (c 0) (c 1) (c 2)
      (hc (by decide : (0:Fin 3)≤1)) (hc (by decide : (1:Fin 3)≤2)) (hn 2) hnorm
    have hval := (compatible_effect_iff F U V c hc hn he (2*s) (by positivity)).mp hS
    exact ⟨_,⟨_,_,_,of_schmidt c hc hn hnorm hval⟩,hf.unique hmax⟩
  · rintro ⟨w,⟨a,b,p,h⟩,rfl⟩
    obtain ⟨c,hc,hn,hnorm,hval,hw⟩ := to_schmidt h
    have he : state c = (1:U3).val * state c * (1:U3).valᵀ := by simp
    refine ⟨state c,?_,?_,?_⟩
    · rwa [state_weight]
    · exact (compatible_effect_iff _ 1 1 c hc hn he _ (by positivity)).mpr hval
    · rw [RawExtraction.scores_diagonal, ← hw]
      exact MYFidelity.operational (c 0) (c 1) (c 2)
        (hc (by decide : (0:Fin 3)≤1)) (hc (by decide : (1:Fin 3)≤2)) (hn 2) hnorm

/-- Exact global physical minimum, attained for every allowed observed CHSH. -/
theorem sharp_observed_fidelity (s : ℝ) (hl : 1 ≤ s) (hu : s ≤ Real.sqrt 2) :
    IsLeast (observedFidelities s) ((1+minimumW s)/2) := by
  have e : observedFidelities s = {f : ℝ | ∃ w, feasible s w ∧ f=(1+w)/2} := by
    ext f
    exact observed_iff_scalar s f (by linarith)
  rw [e]
  exact optimal_fidelity s hl hu

/-- The middle branch, including both endpoints, has constant fidelity 5/6. -/
theorem plateau_observed (s : ℝ) (hl : switchA ≤ s) (hu : s ≤ switchB) :
    IsLeast (observedFidelities s) (5/6) := by
  have h0 : 0 ≤ s := by
    apply le_trans _ hl
    dsimp [switchA]
    positivity
  constructor
  · apply (observed_iff_scalar s _ h0).mpr
    exact ⟨2/3,⟨_,_,_,middle_witness s hu⟩,by norm_num⟩
  · intro f hf
    obtain ⟨w,⟨a,b,p,h⟩,rfl⟩ := (observed_iff_scalar s f h0).mp hf
    linarith only [middle_le h hl]

#print axioms sharp_observed_fidelity
#print axioms plateau_observed
end
end CHSHFrontier
