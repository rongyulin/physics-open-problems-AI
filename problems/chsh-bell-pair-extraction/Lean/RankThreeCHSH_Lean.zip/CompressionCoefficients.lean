import CompressionCut
import CompressionGram
namespace CHSHCompression
open Matrix
open scoped Matrix BigOperators
noncomputable section

theorem compression_singular_bounds (U V : unitary (Matrix (Fin 3) (Fin 3) ℂ))
    (c : Fin 3 → ℝ) (hc : Antitone c) (hn : ∀ i, 0 ≤ c i) :
    let C := qubitBlock ((U : Matrix (Fin 3) (Fin 3) ℂ) *
      diagonal (fun i => (c i : ℂ)) * V)
    ∃ x y : ℝ, 0 ≤ y ∧ y ≤ x ∧ x ≤ c 0 ∧ y ≤ c 1 ∧
      (∑ i, ∑ j, Complex.normSq (C i j)) = x^2+y^2 ∧ ‖C.det‖ = x*y := by
  let C := qubitBlock ((U : Matrix (Fin 3) (Fin 3) ℂ) *
      diagonal (fun i => (c i : ℂ)) * V)
  obtain ⟨a,b,hb,hba,htr,hd,⟨u,hu,hmax⟩,hmin⟩ := two_gram_spectrum C
  obtain ⟨hupper, v, hv, hlower⟩ := three_bounds U V c hc hn
  have hab : 0 ≤ a := hb.trans hba
  have ha' : a ≤ (c 0)^2 := by
    calc
      a = mass (C *ᵥ u) := hmax.symm
      _ ≤ _ := by simpa only [hu, mul_one] using hupper u
  have hb' : b ≤ (c 1)^2 := (le_of_mul_le_mul_right (hmin v |>.trans hlower) hv)
  refine ⟨√a,√b,Real.sqrt_nonneg _,Real.sqrt_le_sqrt hba,?_,?_,?_,?_⟩
  · exact (Real.sqrt_le_iff).mpr ⟨hn 0,ha'⟩
  · exact (Real.sqrt_le_iff).mpr ⟨hn 1,hb'⟩
  · rwa [Real.sq_sqrt hab, Real.sq_sqrt hb]
  · apply (sq_eq_sq₀ (norm_nonneg _) (mul_nonneg (Real.sqrt_nonneg _) (Real.sqrt_nonneg _))).mp
    rwa [mul_pow,Real.sq_sqrt hab,Real.sq_sqrt hb]

#print axioms compression_singular_bounds
end
end CHSHCompression
