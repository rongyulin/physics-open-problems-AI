import TwoQubitBasic
import Mathlib.Tactic
import Mathlib.Algebra.BigOperators.Fin

/-! Euclidean three-vector bounds and the two orthogonal directions
arising from Bob's sum and difference of Bloch directions. -/
namespace TwoQubit
noncomputable section
open scoped BigOperators

theorem sq_nonnegative (v:V) : 0 ≤ sq v := by
  unfold sq dot
  exact Finset.sum_nonneg (fun i _ => mul_self_nonneg (v i))

private theorem cauchy (a b : V) : (dot a b)^2 ≤ sq a * sq b := by
  simpa [sq,dot,pow_two] using Finset.sum_mul_sq_le_sq_mul_sq Finset.univ a b

/-- Bessel's inequality for two orthogonal real three-vectors, without division. -/
private theorem bessel (r u v : V) (orth : dot u v = 0) :
    (dot r u)^2*sq v + (dot r v)^2*sq u ≤ sq r*sq u*sq v := by
  let vol := r 0*(u 1*v 2-u 2*v 1) - r 1*(u 0*v 2-u 2*v 0) + r 2*(u 0*v 1-u 1*v 0)
  have ident : sq r*sq u*sq v - (dot r u)^2*sq v - (dot r v)^2*sq u - sq r*(dot u v)^2
      + 2*dot r u*dot r v*dot u v = vol^2 := by simp [sq,dot,Fin.sum_univ_three,vol]; ring
  rw [orth] at ident
  nlinarith [sq_nonneg vol]

private theorem weighted {k r p q x y a b : ℝ}
    (hk : 0≤k) (hr : 0≤r) (hp : 0≤p) (hq : 0≤q) (hpq:p+q=4)
    (hx : x^2=k*p+a^2) (hy : y^2=k*q+b^2)
    (ha : a^2 ≤ r*p) (hb : b^2 ≤ r*q) (hh : a^2*q+b^2*p ≤ r*p*q) :
    (x+y)^2 ≤ 4*(2*k+r) := by
  rcases hp.eq_or_lt with h0 | ppos
  · have hz : p=0 := h0.symm
    subst p; have ax : a=0 := by nlinarith [sq_nonneg a]
    subst a; have xx : x=0 := by nlinarith [sq_nonneg x]
    subst x; obtain rfl : q=4 := by linarith
    nlinarith
  rcases hq.eq_or_lt with h0 | qpos
  · have hz : q=0 := h0.symm
    subst q; have bx : b=0 := by nlinarith [sq_nonneg b]
    subst b; have yy : y=0 := by nlinarith [sq_nonneg y]
    subst y; obtain rfl : p=4 := by linarith
    nlinarith
  have alg : p*q*(x+y)^2 + (q*x-p*y)^2 = (p+q)*(x^2*q+y^2*p) := by ring
  have terms : x^2*q+y^2*p ≤ (2*k+r)*p*q := by rw [hx,hy]; linarith only [hh]
  have total := mul_le_mul_of_nonneg_left terms (show 0 ≤ p+q by linarith)
  rw [← alg, hpq] at total
  apply le_of_mul_le_mul_left (a:=p*q) _ (mul_pos ppos qpos)
  nlinarith only [total,sq_nonneg (q*x-p*y)]

/-- A correlation tensor with TᵀT = kI + rrᵀ obeys the CHSH sphere bound. -/
theorem directions_bound (J : V → V) (r a b c d : V) (k : ℝ) (hk : 0≤k)
    (ha : sq a=1) (hb : sq b=1) (hc : sq c=1) (hd : sq d=1)
    (add : J (c+d)=J c+J d) (sub : J (c-d)=J c-J d)
    (hs : ∀ v, sq (J v) = k*sq v+(dot r v)^2) :
    dot a (J c) + dot a (J d) + dot b (J c) - dot b (J d) ≤
    2*Real.sqrt (2*k+sq r) := by
  let u := c+d
  let v := c-d
  let x := Real.sqrt (sq (J u))
  let y := Real.sqrt (sq (J v))
  have sx : x^2=sq (J u) := Real.sq_sqrt (sq_nonnegative _)
  have sy : y^2=sq (J v) := Real.sq_sqrt (sq_nonnegative _)
  have xx : 0≤x := Real.sqrt_nonneg _
  have yy : 0≤y := Real.sqrt_nonneg _
  have uv : dot u v=0 := by
    have hh : dot u v = sq c-sq d := by simp [u,v,dot,sq,Fin.sum_univ_three]; ring
    linarith
  have uv4 : sq u+sq v=4 := by
    have hh : sq u + sq v = 2*(sq c+sq d) := by simp [u,v,sq,dot,Fin.sum_univ_three]; ring
    linarith
  have wt := weighted hk (sq_nonnegative r) (sq_nonnegative u) (sq_nonnegative v) uv4
    (sx.trans (hs u)) (sy.trans (hs v)) (cauchy r u) (cauchy r v) (bessel r u v uv)
  have hax : dot a (J u) ≤ x := by
    have h := cauchy a (J u); rw [ha,one_mul,← sx] at h
    nlinarith [sq_nonneg (dot a (J u) - x)]
  have hby : dot b (J v) ≤ y := by
    have h := cauchy b (J v); rw [hb,one_mul,← sy] at h
    nlinarith [sq_nonneg (dot b (J v) - y)]
  have hplus : dot a (J u) = dot a (J c)+dot a (J d) := by
    dsimp [u]; rw [add]; simp [dot, Finset.sum_add_distrib, mul_add]
  have hminus : dot b (J v) = dot b (J c)-dot b (J d) := by
    dsimp [v]; rw [sub]; simp [dot, Finset.sum_sub_distrib, mul_sub]
  have hn : 0 ≤ 2*k+sq r := by linarith [sq_nonnegative r]
  have ht := Real.sq_sqrt hn
  have ht' := Real.sqrt_nonneg (2*k+sq r)
  nlinarith [sq_nonneg (x+y-2*Real.sqrt (2*k+sq r))]
end
end TwoQubit
