import OddAttain
import OddCHSH
import CHSHPOVM

/-! The exact binary-measurement maximum on every odd-dimensional pure state
with equal Schmidt amplitudes inside each pair and a smallest singleton. -/
namespace CHSHOddOptimum
open CHSH CHSHOddAttain CHSHPOVM Matrix
open scoped Matrix BigOperators
noncomputable section

def scores {N : Type*} [Fintype N] [DecidableEq N] (F : Mat N) : Set ℝ :=
  {s | ∃ A C B D : Mat N, Contraction A ∧ Contraction C ∧ Contraction B ∧ Contraction D ∧
    chsh F A C B D = s}

private theorem reflection_contraction {N : Type*} [Fintype N] [DecidableEq N] {A : Mat N}
    (h : Observable A) : Contraction A :=
  contraction_of_posSemidef h.1 (CHSHClassical.plus_pos h)
    (by simpa [sub_eq_add_neg] using CHSHClassical.plus_pos (CHSHClassical.neg_observable h))

/-- The expression is a genuine maximum over binary Hermitian contractions. The labels
are arbitrary, the pair weights may all differ, and the state can be unnormalized. -/
theorem paired_maximum {k : ℕ} (e : Fin (2*k+1) ≃ Blocks (Fin k))
    (c : Fin k → ℝ) (t : ℝ) (hmin : ∀ i, t^2 ≤ c i^2) :
    IsGreatest (scores (diagonal fun i => (amplitude c t (e i) : ℂ)))
      (2 * Real.sqrt 2 * (2 * ∑ i, c i ^ 2) + 2*t^2) := by
  constructor
  · obtain ⟨A,C,B,D,hA,hC,hB,hD,h⟩ := labelled_attained e c t
    exact ⟨A,C,B,D,reflection_contraction hA,reflection_contraction hC,
      reflection_contraction hB,reflection_contraction hD,h⟩
  · rintro _ ⟨A,C,B,D,hA,hC,hB,hD,rfl⟩
    obtain ⟨P,Q,R,S,hP,hQ,hR,hS,h⟩ := projectivize _ A C B D hA hC hB hD
    refine h.trans ?_
    have hu := CHSHOdd.schmidt_upper (k:=k) rfl (fun i => amplitude c t (e i))
      P Q R S hP hQ hR hS (t^2) (tail_smallest e c t hmin)
    have hw : weight (diagonal fun i => (amplitude c t (e i) : ℂ)) =
        2*(∑ i, c i^2)+t^2 := by
      rw [← amplitude_mass e c t]
      simp [weight, Matrix.diagonal_apply, apply_ite, Complex.normSq_apply, pow_two]
    rw [hw] at hu
    linarith

#print axioms paired_maximum
end
end CHSHOddOptimum
