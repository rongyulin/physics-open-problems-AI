import CompressionMass
import CHSHDefs
namespace CHSHCompression
open Matrix
open scoped Matrix BigOperators
noncomputable section

abbrev qubitBlock := CHSH.top

private def extend (v : Fin 2 → ℂ) : Fin 3 → ℂ := ![v 0,v 1,0]

private theorem extend_mass (v : Fin 2 → ℂ) : mass (extend v) = mass v := by
  simp [mass, Fin.sum_univ_three, Fin.sum_univ_two, extend]

private theorem cut_mass (F : Matrix (Fin 3) (Fin 3) ℂ) (v : Fin 2 → ℂ) :
    mass (qubitBlock F *ᵥ v) ≤ mass (F *ᵥ extend v) := by
  simp only [mass, Fin.sum_univ_three, Fin.sum_univ_two, Matrix.mulVec, dotProduct,
    qubitBlock, CHSH.top, Matrix.submatrix_apply]
  simpa [extend] using (Complex.normSq_nonneg (F 2 0 * v 0 + F 2 1 * v 1))

private theorem cancel_first (V : Matrix (Fin 3) (Fin 3) ℂ) :
    ∃ v : Fin 2 → ℂ, 0 < mass v ∧ (V *ᵥ extend v) 0 = 0 := by
  by_cases h : V 0 0 = 0
  · refine ⟨![1,0], ?_, ?_⟩
    · norm_num [mass, Fin.sum_univ_two]
    · simp [Matrix.mulVec, dotProduct, Fin.sum_univ_three, extend, h]
  · refine ⟨![V 0 1,-V 0 0], ?_, ?_⟩
    · simp only [mass, Fin.sum_univ_two, Matrix.cons_val_zero, Matrix.cons_val_one,
        Matrix.cons_val_fin_one, Complex.normSq_neg]
      exact add_pos_of_nonneg_of_pos (Complex.normSq_nonneg _) (Complex.normSq_pos.mpr h)
    · simp [Matrix.mulVec, dotProduct, Fin.sum_univ_three, extend, mul_comm]

theorem three_bounds (U V : unitary (Matrix (Fin 3) (Fin 3) ℂ))
    (c : Fin 3 → ℝ) (hc : Antitone c) (hn : ∀ i, 0 ≤ c i) :
    let F := (U : Matrix (Fin 3) (Fin 3) ℂ) * diagonal (fun i => (c i:ℂ)) * V
    (∀ v, mass (qubitBlock F *ᵥ v) ≤ (c 0)^2 * mass v) ∧
    ∃ v, 0 < mass v ∧ mass (qubitBlock F *ᵥ v) ≤ (c 1)^2 * mass v := by
  let F := (U : Matrix (Fin 3) (Fin 3) ℂ) * diagonal (fun i => (c i:ℂ)) * V
  have eqmass (v : Fin 2 → ℂ) :
      mass (F *ᵥ extend v) = ∑ i, (c i)^2 * Complex.normSq ((V.1 *ᵥ extend v) i) := by
    dsimp [F]
    rw [← mulVec_mulVec, ← mulVec_mulVec, mass_unitary]
    simp [mass, Matrix.mulVec_diagonal, map_mul, pow_two]
  have htotal (v : Fin 2 → ℂ) : mass v = ∑ i, Complex.normSq ((V.1 *ᵥ extend v) i) := by
    exact (mass_unitary V (extend v) |>.trans (extend_mass v)).symm
  constructor
  · intro v
    apply (cut_mass F v).trans
    rw [eqmass, htotal, Finset.mul_sum]
    exact Finset.sum_le_sum fun i _ => mul_le_mul_of_nonneg_right
      (pow_le_pow_left₀ (hn i) (hc (Fin.zero_le _)) 2) (Complex.normSq_nonneg _)
  · obtain ⟨v,hv,hfirst⟩ := cancel_first V.1
    refine ⟨v,hv,(cut_mass F v).trans ?_⟩
    rw [eqmass, htotal, Finset.mul_sum]
    apply Finset.sum_le_sum
    intro i _
    by_cases hi : i=0
    · simp [hi,hfirst]
    · apply mul_le_mul_of_nonneg_right _ (Complex.normSq_nonneg _)
      apply pow_le_pow_left₀ (hn i) _ 2
      apply hc
      omega

end
end CHSHCompression
