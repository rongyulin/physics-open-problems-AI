import PairGain

/-! Supporting-plane inequality for the two-qubit CHSH advantage,
including a lower bound on the loss when either squared singular value falls. -/
namespace CHSHRigidity
open CHSHPair
noncomputable section

def pairNorm (a b : ℝ) := Real.sqrt ((a+b)^2+4*a*b)

def slope (a b : ℝ) := (a+3*b-pairNorm a b)/pairNorm a b

private theorem norm_sq {a b : ℝ} (ha : 0 ≤ a) (hb : 0 ≤ b) :
    (pairNorm a b)^2 = (a+b)^2+4*a*b := Real.sq_sqrt (by positivity)

theorem slope_pos {a b : ℝ} (hb : 0 < b) (hba : b ≤ a) : 0 < slope a b := by
  have ha : 0<a := hb.trans_le hba
  have hn : 0 < pairNorm a b := by unfold pairNorm; positivity
  have hh := norm_sq ha.le hb.le
  have hm : 0 < a+3*b-pairNorm a b := by
    nlinarith [sq_pos_of_pos hb, mul_nonneg (show 0 ≤ a+3*b by positivity) hn.le,
      sq_nonneg (a+3*b-pairNorm a b)]
  exact div_pos hm hn

/-- The smallest supporting-plane coefficient is the slope in the larger
Schmidt weight. We retain a modulus that remains positive down to u=v=0. -/
theorem gain_loss {a b u v : ℝ} (hb : 0 < b) (hba : b ≤ a)
    (hu : 0 ≤ u) (hv : 0 ≤ v) (hvb : v ≤ b) :
    slope a b * (a+b-u-v) ≤ gain a b - gain u v := by
  let f := pairNorm a b
  let g := pairNorm u v
  have ha : 0<a := hb.trans_le hba
  have hf : 0 < f := by dsimp [f,pairNorm]; positivity
  have hg : 0 ≤ g := Real.sqrt_nonneg _
  have hf2 : f^2=(a+b)^2+4*a*b := norm_sq ha.le hb.le
  have hg2 : g^2=(u+v)^2+4*u*v := norm_sq hu hv
  let m := (a+3*b)*u+(3*a+b)*v
  have hm : 0 ≤ m := by dsimp [m]; positivity
  have id : m^2-(f*g)^2=8*(b*u-a*v)^2 := by rw [mul_pow,hf2,hg2]; dsimp [m]; ring
  have ht : f*g ≤ m := by
    nlinarith [sq_nonneg (b*u-a*v), mul_nonneg hf.le hg, sq_nonneg (m-f*g)]
  change ((a+3*b-f)/f)*(a+b-u-v) ≤ (f-(a+b))-(g-(u+v))
  rw [div_mul_eq_mul_div,div_le_iff₀ hf]
  dsimp [m] at ht
  nlinarith only [hf2,ht,mul_nonneg (sub_nonneg.mpr hba) (sub_nonneg.mpr hvb)]

#print axioms gain_loss
end
end CHSHRigidity
