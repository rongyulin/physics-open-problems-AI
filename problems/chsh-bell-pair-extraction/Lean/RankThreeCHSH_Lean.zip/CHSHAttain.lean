import CHSHDefs
import Mathlib.Tactic

/-! An explicit, normalized pair of measurement directions attains the
Schmidt-pair value. The three state amplitudes may be unnormalized and no
nonzero denominator is required. -/
namespace CHSHAttain
open CHSH Matrix
open scoped BigOperators Matrix
noncomputable section

def schmidtState (a b c : ℝ) : Mat Qutrit :=
  diagonal ![(a : ℂ), (b : ℂ), (c : ℂ)]

/-- A qubit reflection in the real XZ plane, extended with eigenvalue +1
on the unused qutrit coordinate. -/
def reflection (x y : ℝ) : Mat Qutrit :=
  !![(x : ℂ), (y : ℂ), 0; (y : ℂ), -(x : ℂ), 0; 0, 0, 1]

theorem reflection_observable (x y : ℝ) (h : x^2+y^2=1) :
    Observable (reflection x y) := by
  have hc : (x : ℂ)^2 + (y : ℂ)^2 = 1 := by exact_mod_cast h
  constructor
  · ext i j
    fin_cases i <;> fin_cases j <;>
      simp [reflection, Matrix.conjTranspose_apply]
  · ext i j
    fin_cases i <;> fin_cases j <;>
      simp [reflection, Matrix.mul_apply, Fin.sum_univ_three, Matrix.one_apply] <;>
      first | linear_combination hc | linear_combination -hc | ring

theorem reflection_corr (a b c x y u v : ℝ) :
    corr (schmidtState a b c) (reflection x y) (reflection u v) =
      (a^2+b^2)*x*u+2*a*b*y*v+c^2 := by
  simp [corr, schmidtState, Matrix.diagonal, reflection, Fin.sum_univ_three,
    Complex.mul_re, Complex.mul_im]
  ring

theorem maximizing_direction (u v : ℝ) :
    ∃ x y : ℝ, x^2+y^2=1 ∧ u*x+v*y=Real.sqrt (u^2+v^2) := by
  let t := Real.sqrt (u^2+v^2)
  have ht : t^2=u^2+v^2 := Real.sq_sqrt (by positivity)
  by_cases hz : t=0
  · have hu : u=0 := by nlinarith [sq_nonneg v, sq_nonneg (u-0)]
    have hv : v=0 := by nlinarith [sq_nonneg u, sq_nonneg (v-0)]
    exact ⟨1,0,by norm_num,by simp [hu,hv]⟩
  · refine ⟨u/t,v/t,?_,?_⟩
    · field_simp
      nlinarith [ht]
    · change u*(u/t)+v*(v/t)=t
      field_simp
      nlinarith [ht]

/-- Binary projective measurements attaining the paired two-qutrit value. -/
theorem qutrit_attained (a b c : ℝ) :
    ∃ A₀ A₁ B₀ B₁ : Mat Qutrit,
      Observable A₀ ∧ Observable A₁ ∧ Observable B₀ ∧ Observable B₁ ∧
      chsh (schmidtState a b c) A₀ A₁ B₀ B₁ =
        2*c^2 + 2*Real.sqrt ((a^2+b^2)^2+4*a^2*b^2) := by
  obtain ⟨x,y,hxy,hangle⟩ := maximizing_direction (a^2+b^2) (2*a*b)
  refine ⟨reflection 1 0, reflection 0 1, reflection x y, reflection x (-y),
    reflection_observable _ _ (by norm_num), reflection_observable _ _ (by norm_num),
    reflection_observable _ _ hxy, reflection_observable _ _ (by simpa using hxy), ?_⟩
  simp only [chsh, reflection_corr]
  rw [show 4*a^2*b^2 = (2*a*b)^2 by ring, ← hangle]
  ring

end
end CHSHAttain
