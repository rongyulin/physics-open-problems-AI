import CHSHDefs
import Mathlib.LinearAlgebra.Matrix.DotProduct
import Mathlib.Analysis.Complex.Order
import Mathlib.Tactic

/-! The three sectors with a one-dimensional measurement block contribute
at most the classical value times their total squared-amplitude weight. -/
namespace CHSH
open scoped Matrix BigOperators ComplexOrder
open Matrix
noncomputable section

def sliceA (F : Mat Qutrit) (i : Fin 2) : ℂ := F i.castSucc 2
def sliceB (F : Mat Qutrit) (j : Fin 2) : ℂ := F 2 j.castSucc

def vectorWeight {n : Type*} [Fintype n] (v : n → ℂ) : ℝ := ∑ i, Complex.normSq (v i)

def form {n : Type*} [Fintype n] (v : n → ℂ) (A : Mat n) : ℝ :=
  (star v ⬝ᵥ (A *ᵥ v)).re

private theorem dot_weight {n : Type*} [Fintype n] (v : n → ℂ) :
    (star v ⬝ᵥ v).re = vectorWeight v := by
  simp only [dotProduct, Complex.re_sum, Pi.star_apply, Complex.star_def,
    ← Complex.normSq_eq_conj_mul_self, Complex.ofReal_re, vectorWeight]

theorem form_bounds {n : Type*} [Fintype n] [DecidableEq n] (v : n → ℂ) (A : Mat n)
    (ha : Observable A) : -vectorWeight v ≤ form v A ∧ form v A ≤ vectorWeight v := by
  have heq : star (A *ᵥ v) ⬝ᵥ (A *ᵥ v) = star v ⬝ᵥ v := by
    rw [star_mulVec, ha.1.eq, ← dotProduct_mulVec, mulVec_mulVec, ha.2, one_mulVec]
  have hcross : star (A *ᵥ v) ⬝ᵥ v = star v ⬝ᵥ (A *ᵥ v) := by
    rw [star_mulVec, ha.1.eq, ← dotProduct_mulVec]
  have hp := (Complex.nonneg_iff.mp (dotProduct_star_self_nonneg (v + A *ᵥ v))).1
  have hn := (Complex.nonneg_iff.mp (dotProduct_star_self_nonneg (v - A *ᵥ v))).1
  simp only [star_add, add_dotProduct, dotProduct_add, heq, hcross, Complex.add_re,
    dot_weight] at hp
  simp only [star_sub, sub_dotProduct, dotProduct_sub, heq, hcross, Complex.sub_re,
    dot_weight] at hn
  unfold form
  constructor <;> linarith

theorem weight_blocks (F : Mat Qutrit) :
    weight F = weight (top F) + vectorWeight (sliceA F) + vectorWeight (sliceB F) +
      Complex.normSq (F 2 2) := by
  simp [weight, top, vectorWeight, sliceA, sliceB, Fin.sum_univ_three, Fin.sum_univ_two,
    Matrix.submatrix_apply]
  ring

set_option maxRecDepth 8192 in
set_option maxHeartbeats 1000000 in
theorem corr_blocks (F : Mat Qutrit) (A B : Mat (Fin 2)) (a b : ℝ) :
    corr F (block A a) (block B b) =
      corr (top F) A B + b * form (sliceA F) A + a * form (sliceB F) B +
      (a * b) * Complex.normSq (F 2 2) := by
  let quad (G : Mat (Fin 2)) : ℂ :=
    ∑ i, ∑ j, ∑ k, ∑ l, star (G i j) * A i k * B j l * G k l
  have hc : (∑ i, ∑ j, ∑ k, ∑ l, star (F i j) * block A a i k * block B b j l * F k l) =
      quad (top F) + (b : ℂ) * (star (sliceA F) ⬝ᵥ (A *ᵥ sliceA F)) +
        (a : ℂ) * (star (sliceB F) ⬝ᵥ (B *ᵥ sliceB F)) +
        ((a * b : ℝ) : ℂ) * (Complex.normSq (F 2 2) : ℂ) := by
    simp [quad, block, top, sliceA, sliceB, Matrix.submatrix_apply, Matrix.mulVec, dotProduct,
      Fin.sum_univ_three, Fin.sum_univ_two, Complex.normSq_eq_conj_mul_self]
    ring
  simpa [corr, quad, form, Complex.mul_re] using congrArg Complex.re hc

/-- Each sign-pair selects one of two bounded expectations. -/
private theorem scalar_CHSH (x y m s t : ℝ) (hx : -m ≤ x ∧ x ≤ m)
    (hy : -m ≤ y ∧ y ≤ m) (hs : s = 1 ∨ s = -1) (ht : t = 1 ∨ t = -1) :
    (s+t)*x + (s-t)*y ≤ 2*m := by
  rcases hs with rfl | rfl <;> rcases ht with rfl | rfl <;> linarith

theorem block_bound (F : Mat Qutrit) (A₀ A₁ B₀ B₁ : Mat (Fin 2)) (a₀ a₁ b₀ b₁ : ℝ)
    (hA₀ : Observable A₀) (hA₁ : Observable A₁) (hB₀ : Observable B₀) (hB₁ : Observable B₁)
    (ha₀ : a₀ = 1 ∨ a₀ = -1) (ha₁ : a₁ = 1 ∨ a₁ = -1)
    (hb₀ : b₀ = 1 ∨ b₀ = -1) (hb₁ : b₁ = 1 ∨ b₁ = -1) :
    chsh F (block A₀ a₀) (block A₁ a₁) (block B₀ b₀) (block B₁ b₁) ≤
      chsh (top F) A₀ A₁ B₀ B₁ + 2 * (weight F - weight (top F)) := by
  have hA := scalar_CHSH _ _ _ _ _ (form_bounds (sliceA F) A₀ hA₀)
    (form_bounds (sliceA F) A₁ hA₁) hb₀ hb₁
  have hB := scalar_CHSH _ _ _ _ _ (form_bounds (sliceB F) B₀ hB₀)
    (form_bounds (sliceB F) B₁ hB₁) ha₀ ha₁
  have has : (-1 : ℝ) ≤ a₀ ∧ a₀ ≤ 1 := by rcases ha₀ with rfl | rfl <;> norm_num
  have hat : (-1 : ℝ) ≤ a₁ ∧ a₁ ≤ 1 := by rcases ha₁ with rfl | rfl <;> norm_num
  have hs := mul_le_mul_of_nonneg_right (scalar_CHSH _ _ _ _ _ has hat hb₀ hb₁)
    (Complex.normSq_nonneg (F 2 2))
  rw [weight_blocks F]
  simp only [chsh, corr_blocks]
  linarith only [hA, hB, hs]

#print axioms block_bound
end
end CHSH
