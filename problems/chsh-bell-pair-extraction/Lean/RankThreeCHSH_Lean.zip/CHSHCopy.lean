import CHSHAttain
import Mathlib.LinearAlgebra.Matrix.Kronecker

/-! A local two-copy protocol. Each party coherently controls on the
Schmidt singleton of its first qutrit. No message or postselection is used. -/
namespace CHSHCopy
open CHSH CHSHAttain Matrix
open scoped Matrix BigOperators Kronecker
noncomputable section

private def pass (x y : ℝ) : Mat Qutrit :=
  !![(x:ℂ),(y:ℂ),0; (y:ℂ),-(x:ℂ),0; 0,0,0]
private def fail : Mat Qutrit := !![0,0,0; 0,0,0; 0,0,1]

def controlled (x y : ℝ) (R : Mat Qutrit) : Mat (Qutrit × Qutrit) :=
  pass x y ⊗ₖ (1 : Mat Qutrit) + fail ⊗ₖ R

theorem controlled_observable (x y : ℝ) (R : Mat Qutrit) (h : x^2 + y^2 = 1)
    (hR : Observable R) : Observable (controlled x y R) := by
  have hxy : (x : ℂ)^2 + (y : ℂ)^2 = 1 := by exact_mod_cast h
  have hp : (pass x y).IsHermitian := by
    ext i j
    fin_cases i <;> fin_cases j <;> simp [pass, Matrix.conjTranspose_apply]
  have hf : fail.IsHermitian := by
    ext i j
    fin_cases i <;> fin_cases j <;> simp [fail, Matrix.conjTranspose_apply]
  have hp2 : pass x y * pass x y + fail = 1 := by
    ext i j
    fin_cases i <;> fin_cases j <;>
      simp [pass, fail] <;>
      first | linear_combination hxy | ring
  have hf2 : fail * fail = fail := by
    ext i j
    fin_cases i <;> fin_cases j <;> simp [fail, Matrix.mul_apply, Fin.sum_univ_three]
  have hpf : pass x y * fail = 0 := by
    ext i j
    fin_cases i <;> fin_cases j <;> simp [pass, fail, Matrix.mul_apply, Fin.sum_univ_three]
  have hfp : fail * pass x y = 0 := by
    ext i j
    fin_cases i <;> fin_cases j <;> simp [pass, fail, Matrix.mul_apply, Fin.sum_univ_three]
  constructor
  · unfold Observable at hR
    simp only [Matrix.IsHermitian, controlled, Matrix.conjTranspose_add,
      Matrix.conjTranspose_kronecker, hp.eq, hf.eq, hR.1.eq, Matrix.conjTranspose_one]
  · simp only [controlled, add_mul, mul_add, ← Matrix.mul_kronecker_mul, hpf, hfp,
      Matrix.zero_kronecker, zero_add, add_zero, one_mul, hR.2, hf2, ← Matrix.add_kronecker,
      hp2, Matrix.one_kronecker_one]

/-- A Cartesian pair of local computational-basis indices for Alice and for Bob. -/
def copies (a b c : ℝ) : Mat (Qutrit × Qutrit) :=
  schmidtState a b c ⊗ₖ schmidtState a b c

private theorem corr_diagonal {n : Type*} [Fintype n] [DecidableEq n]
    (z : n → ℂ) (A B : Mat n) :
    corr (diagonal z) A B = (∑ i, ∑ k, star (z i) * A i k * B i k * z k).re := by
  classical
  simp [corr, Matrix.diagonal, ite_mul, apply_ite]

set_option maxRecDepth 10000 in
set_option maxHeartbeats 4000000 in
theorem controlled_corr (a b c x y u v : ℝ) (R S : Mat Qutrit) :
    corr (copies a b c) (controlled x y R) (controlled u v S) =
      (a^2+b^2+c^2)*((a^2+b^2)*x*u+2*a*b*y*v) + c^2*corr (schmidtState a b c) R S := by
  simp only [copies, schmidtState, Matrix.diagonal_kronecker_diagonal, corr_diagonal]
  simp [Fintype.sum_prod_type, Fin.sum_univ_three, controlled, pass, fail,
    Matrix.one_apply, Complex.add_re, Complex.mul_re, Complex.mul_im]
  ring

def singleValue (a b c : ℝ) := 2*c^2 + 2*Real.sqrt ((a^2+b^2)^2+4*a^2*b^2)

/-- The two-copy value is attained by four explicit local Hermitian involutions. -/
theorem two_copy_attained (a b c : ℝ) (hn : a^2+b^2+c^2=1) :
    ∃ A₀ A₁ B₀ B₁ : Mat (Qutrit × Qutrit),
      Observable A₀ ∧ Observable A₁ ∧ Observable B₀ ∧ Observable B₁ ∧
      chsh (copies a b c) A₀ A₁ B₀ B₁ =
        singleValue a b c + c^2*(singleValue a b c-2) := by
  obtain ⟨R₀,R₁,S₀,S₁,hR₀,hR₁,hS₀,hS₁,hs⟩ := qutrit_attained a b c
  obtain ⟨x,y,hxy,hang⟩ := maximizing_direction (a^2+b^2) (2*a*b)
  refine ⟨controlled 1 0 R₀, controlled 0 1 R₁, controlled x y S₀, controlled x (-y) S₁,
    controlled_observable _ _ _ (by norm_num) hR₀, controlled_observable _ _ _ (by norm_num) hR₁,
    controlled_observable _ _ _ hxy hS₀, controlled_observable _ _ _ (by simpa using hxy) hS₁, ?_⟩
  simp only [chsh, controlled_corr, hn, one_mul]
  simp only [chsh] at hs
  dsimp [singleValue]
  rw [show 4*a^2*b^2=(2*a*b)^2 by ring, ← hang] at hs ⊢
  linear_combination c^2 * hs

theorem two_copy_strict (a b c : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c)
    (hn : a^2+b^2+c^2=1) :
    ∃ A₀ A₁ B₀ B₁ : Mat (Qutrit × Qutrit),
      Observable A₀ ∧ Observable A₁ ∧ Observable B₀ ∧ Observable B₁ ∧
      singleValue a b c < chsh (copies a b c) A₀ A₁ B₀ B₁ := by
  obtain ⟨A₀,A₁,B₀,B₁,hA₀,hA₁,hB₀,hB₁,he⟩ := two_copy_attained a b c hn
  refine ⟨A₀,A₁,B₀,B₁,hA₀,hA₁,hB₀,hB₁,?_⟩
  rw [he]
  have hv : a^2+b^2 < Real.sqrt ((a^2+b^2)^2+4*a^2*b^2) := by
    apply Real.lt_sqrt_of_sq_lt
    nlinarith [show 0 < 4*a^2*b^2 by positivity]
  have hs : 0 < singleValue a b c - 2 := by dsimp [singleValue]; linarith
  linarith only [mul_pos (sq_pos_of_pos hc) hs]

#print axioms two_copy_strict
end
end CHSHCopy
