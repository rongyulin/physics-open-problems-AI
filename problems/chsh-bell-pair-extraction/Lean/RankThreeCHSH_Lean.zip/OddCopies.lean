import OddOptimum
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Data.Fin.Tuple.Basic

/-! The exact CHSH value of every tensor power of a paired odd-dimensional
Schmidt state. A basis word consists of one local Schmidt label from each copy. -/
namespace CHSHOddCopies
open CHSH CHSHOddAttain CHSHOddOptimum Matrix
open scoped BigOperators
noncomputable section

/-- Two product basis labels form a pair at the first non-singleton factor. -/
private def blocksProduct {I J : Type} :
    Blocks I × Blocks J ≃ Blocks ((I × Blocks J) ⊕ J) where
  toFun
    | (.inl (a,i),v) => .inl (a,.inl (i,v))
    | (.inr _,.inl (b,j)) => .inl (b,.inr j)
    | (.inr _,.inr _) => .inr ()
  invFun
    | .inl (a,.inl (i,v)) => (.inl (a,i),v)
    | .inl (b,.inr j) => (.inr (),.inl (b,j))
    | .inr _ => (.inr (),.inr ())
  left_inv := by rintro ⟨⟨a,i⟩|⟨⟩, ⟨b,j⟩|⟨⟩⟩ <;> rfl
  right_inv := by
    intro z
    rcases z with ⟨a,ix⟩|⟨⟩
    · rcases ix with ⟨i,v⟩|j
      · rcases v with ⟨b,j⟩|⟨⟩ <;> rfl
      · rfl
    · rfl

private def pairProduct {I J : Type} (c : I → ℝ) (t : ℝ) (d : J → ℝ) (s : ℝ) :
    (I × Blocks J) ⊕ J → ℝ :=
  Sum.elim (fun p => c p.1 * amplitude d s p.2) (fun j => t * d j)

private theorem product_amplitude {I J : Type} (c : I → ℝ) (t : ℝ) (d : J → ℝ) (s : ℝ)
    (v : Blocks I) (w : Blocks J) :
    amplitude c t v * amplitude d s w =
      amplitude (pairProduct c t d s) (t*s) (blocksProduct (v,w)) := by
  rcases v with ⟨a,i⟩|⟨⟩ <;> rcases w with ⟨b,j⟩|⟨⟩ <;> rfl

private def relabel {I J : Type} (e : I ≃ J) : Blocks I ≃ Blocks J :=
  (Equiv.prodCongr (Equiv.refl (Fin 2)) e).sumCongr (Equiv.refl Unit)

private theorem relabel_amplitude {I J : Type} (e : I ≃ J) (d : I → ℝ) (s : ℝ) (w : Blocks I) :
    amplitude d s w = amplitude (d ∘ e.symm) s (relabel e w) := by
  rcases w with ⟨a,i⟩|u
  · change d i = d (e.symm (e i))
    rw [e.symm_apply_apply]
  · rfl

def wordAmplitude {k n : ℕ} (c : Fin k → ℝ) (t : ℝ)
    (w : Fin n → Blocks (Fin k)) : ℝ := ∏ i, amplitude c t (w i)

/-- The tensor product spectrum pairs all words except the all-singleton word. -/
theorem pair_words {k : ℕ} (n : ℕ) (c : Fin k → ℝ) (t : ℝ) :
    ∃ j : ℕ, ∃ (e : (Fin n → Blocks (Fin k)) ≃ Blocks (Fin j)) (d : Fin j → ℝ),
      ∀ w, wordAmplitude c t w = amplitude d (t^n) (e w) := by
  induction n with
  | zero =>
    have hcard : Fintype.card (Fin 0 → Blocks (Fin k)) = Fintype.card (Blocks (Fin 0)) := by
      simp [Blocks]
    let e := Fintype.equivOfCardEq hcard
    refine ⟨0,e,(fun _ => 0),fun w => ?_⟩
    rcases h : e w with ⟨a,i⟩|u
    · exact Fin.elim0 i
    · simp [wordAmplitude, amplitude]
  | succ n ih =>
    obtain ⟨j,e,d,hd⟩ := ih
    let I := (Fin k × Blocks (Fin j)) ⊕ Fin j
    let u := Fintype.equivFin I
    let f : (Fin (n+1) → Blocks (Fin k)) ≃ Blocks I :=
      (Fin.consEquiv (fun _ : Fin (n+1) => Blocks (Fin k))).symm.trans
        ((Equiv.prodCongr (Equiv.refl _) e).trans blocksProduct)
    refine ⟨Fintype.card I, f.trans (relabel u), pairProduct c t d (t^n) ∘ u.symm, fun w => ?_⟩
    calc
      wordAmplitude c t w = amplitude c t (w 0) * wordAmplitude c t (fun i => w i.succ) :=
        Fin.prod_univ_succ _
      _ = amplitude (pairProduct c t d (t^n)) (t*(t^n)) (f w) := by
        rw [hd]; exact product_amplitude _ _ _ _ _ _
      _ = _ := by rw [pow_succ', relabel_amplitude u]; rfl

private theorem word_floor {k n : ℕ} (c : Fin k → ℝ) (t : ℝ)
    (hmin : ∀ i, t^2 ≤ c i^2) (w : Fin n → Blocks (Fin k)) :
    (t^n)^2 ≤ wordAmplitude c t w ^ 2 := by
  calc
    (t^n)^2 = ∏ _ : Fin n, t^2 := by simp [← pow_mul, Nat.mul_comm]
    _ ≤ ∏ i, amplitude c t (w i)^2 := Finset.prod_le_prod (fun _ _ => sq_nonneg _) (fun i _ => by
      rcases hh : w i with ⟨a,j⟩|u
      · exact hmin j
      · exact le_rfl)
    _ = _ := by rw [wordAmplitude, Finset.prod_pow]

private theorem word_mass {k n : ℕ} (c : Fin k → ℝ) (t : ℝ)
    (hn : 2*(∑ i, c i^2)+t^2 = 1) :
    (∑ w : Fin n → Blocks (Fin k), wordAmplitude c t w ^ 2) = 1 := by
  have h1 : (∑ i : Blocks (Fin k), amplitude c t i ^ 2) = 1 := (amplitude_mass (Equiv.refl _) c t).trans hn
  simp only [wordAmplitude, ← Finset.prod_pow]
  rw [← Fintype.sum_pow (fun i : Blocks (Fin k) => amplitude c t i ^ 2) n, h1, one_pow]

/-- Label the product basis by ordinary finite matrix indices. -/
def wordLabels (k n : ℕ) : Fin ((2*k+1)^n) ≃ (Fin n → Blocks (Fin k)) :=
  (Fintype.equivFinOfCardEq (α := Fin n → Blocks (Fin k)) (by simp [Blocks])).symm

/-- This diagonal matrix contains exactly the amplitudes of the tensor power in its
product Schmidt basis. The entry associated with `w` is the product of the amplitudes. -/
def state {k : ℕ} (n : ℕ) (c : Fin k → ℝ) (t : ℝ) : Mat (Fin ((2*k+1)^n)) :=
  diagonal fun i => (wordAmplitude c t (wordLabels k n i) : ℂ)

private theorem exact_labels {N j : ℕ} (e : Fin N ≃ Blocks (Fin j)) (d : Fin j → ℝ) (s : ℝ)
    (hmin : ∀ i, s^2 ≤ d i^2) :
    IsGreatest (scores (diagonal fun i => (amplitude d s (e i) : ℂ)))
      (2*Real.sqrt 2*(2*∑ i, d i^2) + 2*s^2) := by
  have h : N = 2*j+1 := by simpa [Blocks] using Fintype.card_congr e
  subst N
  exact paired_maximum e d s hmin

/-- Exact optimum over every local binary measurement on `n` copies, including
collective measurements across the copies within each laboratory. -/
theorem tensor_power_optimum {k : ℕ} (n : ℕ) (c : Fin k → ℝ) (t : ℝ)
    (hmin : ∀ i, t^2 ≤ c i^2) (hn : 2*(∑ i, c i^2)+t^2=1) :
    IsGreatest (scores (state n c t)) (2*Real.sqrt 2 - (2*Real.sqrt 2-2)*(t^2)^n) := by
  obtain ⟨j,e,d,hd⟩ := pair_words n c t
  have hfloor (i : Fin j) : (t^n)^2 ≤ d i^2 := by
    have hg := word_floor c t hmin (e.symm (.inl (0,i)))
    rwa [hd,e.apply_symm_apply] at hg
  let g := (wordLabels k n).trans e
  have h := exact_labels g d (t^n) hfloor
  have hmass : 2*(∑ i, d i^2)+(t^n)^2=1 := by
    rw [← amplitude_mass e d (t^n)]
    simpa only [← hd] using word_mass (n:=n) c t hn
  have hs : state n c t = diagonal (fun i => (amplitude d (t^n) (g i) : ℂ)) := by
    simp only [state, hd]; rfl
  rw [hs]
  convert h using 1
  rw [← pow_mul, Nat.mul_comm 2 n, pow_mul]
  linear_combination -(2*Real.sqrt 2)*hmass

#print axioms tensor_power_optimum

/-- In particular, the exact collective CHSH optimum on any number of maximally
entangled qutrit pairs has a deficit proportional to `(1/3)^n`. -/
theorem maximally_entangled_qutrits (n : ℕ) :
    IsGreatest (scores (state n (fun _ : Fin 1 => Real.sqrt (1/3)) (Real.sqrt (1/3))))
      (2*Real.sqrt 2 - (2*Real.sqrt 2-2)*(1/3)^n) := by
  have hsq : (Real.sqrt (1/3))^2 = (1/3:ℝ) := Real.sq_sqrt (by norm_num)
  have hn : 2*(∑ _ : Fin 1, (Real.sqrt (1/3))^2)+(Real.sqrt (1/3))^2 = 1 := by
    rw [hsq]; norm_num
  simpa only [hsq] using tensor_power_optimum n (fun _ : Fin 1 => Real.sqrt (1/3))
    (Real.sqrt (1/3)) (fun _ => le_rfl) hn

#print axioms maximally_entangled_qutrits

end
end CHSHOddCopies
