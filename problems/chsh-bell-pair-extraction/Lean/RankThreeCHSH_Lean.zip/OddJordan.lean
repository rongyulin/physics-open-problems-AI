import Mathlib.Analysis.Matrix.Spectrum
import Mathlib.LinearAlgebra.FiniteDimensional.Lemmas
import Mathlib.Tactic
import CHSHDefs

/-! In odd dimension a pair of involutions always has a common eigenvector.
For self-adjoint involutions the orthogonal complement also reduces both. -/
namespace CHSHOddJordan
open Matrix Module
open scoped Matrix BigOperators
noncomputable section
variable {d : ℕ}
local notation "M" => Matrix (Fin d) (Fin d) ℂ
local notation "V" => Fin d → ℂ

private theorem large_eigenspace (k : ℕ) (hdim : d=2*k+1) (A : M) (ha : A*A=1) :
    ∃ a : ℂ, (a=1 ∨ a= -1) ∧ k+1 ≤ finrank ℂ (Module.End.eigenspace A.mulVecLin a) := by
  let f : Module.End ℂ V := A.mulVecLin
  have invol (x : V) : f (f x) = x := by
    change A *ᵥ (A *ᵥ x) = x
    rw [mulVec_mulVec,ha,one_mulVec]
  have spanning : f.eigenspace 1 ⊔ f.eigenspace (-1) = ⊤ := by
    apply top_unique
    intro x _
    apply Submodule.mem_sup.mpr
    refine ⟨(2:ℂ)⁻¹ • (x + f x), ?_, (2:ℂ)⁻¹ • (x-f x), ?_, ?_⟩
    · rw [Module.End.mem_eigenspace_iff, map_smul, map_add, invol, one_smul, add_comm]
    · rw [Module.End.mem_eigenspace_iff, map_smul, map_sub, invol, neg_one_smul]
      rw [← smul_neg, neg_sub]
    · ext i
      change (2:ℂ)⁻¹ * (x i + f x i) + (2:ℂ)⁻¹ * (x i - f x i) = x i
      ring
  have h := Submodule.finrank_sup_add_finrank_inf_eq (f.eigenspace 1) (f.eigenspace (-1))
  rw [spanning] at h
  have hd : finrank ℂ (⊤ : Submodule ℂ V) = d := by simp
  rw [hd] at h
  by_cases hc : k+1 ≤ finrank ℂ (f.eigenspace 1)
  · exact ⟨1, Or.inl rfl, hc⟩
  · refine ⟨-1, Or.inr rfl, ?_⟩
    change k+1 ≤ finrank ℂ (f.eigenspace (-1))
    omega

/-- Hermiticity is unnecessary for the common eigenvector itself. -/
theorem common_eigenvector (k : ℕ) (hdim : d=2*k+1) (A B : Matrix (Fin d) (Fin d) ℂ)
    (ha : A*A=1) (hb : B*B=1) :
    ∃ v : Fin d → ℂ, v ≠ 0 ∧ ∃ a b : ℂ,
      (a=1 ∨ a= -1) ∧ (b=1 ∨ b= -1) ∧ A *ᵥ v = a • v ∧ B *ᵥ v = b • v := by
  obtain ⟨a, ha, hA⟩ := large_eigenspace k hdim A ha
  obtain ⟨b, hb, hB⟩ := large_eigenspace k hdim B hb
  let P := Module.End.eigenspace A.mulVecLin a
  let Q := Module.End.eigenspace B.mulVecLin b
  change k+1 ≤ finrank ℂ P at hA
  change k+1 ≤ finrank ℂ Q at hB
  have hne : P ⊓ Q ≠ ⊥ := by
    intro he
    have bound : finrank ℂ P + finrank ℂ Q ≤ d := calc
      _ ≤ finrank ℂ V := Submodule.finrank_add_finrank_le_of_disjoint
        (disjoint_iff.mpr he)
      _ = d := by simp
    omega
  obtain ⟨v,hv,hv0⟩ := Submodule.exists_mem_ne_zero_of_ne_bot hne
  exact ⟨v,hv0,a,b,ha,hb,Module.End.mem_eigenspace_iff.mp hv.1,
    Module.End.mem_eigenspace_iff.mp hv.2⟩

private theorem unitary_last_column (l : Fin d) {v : V} (hv : v ≠ 0) :
    ∃ (U : unitaryGroup (Fin d) ℂ) (c : ℂ),
      ((U : M) *ᵥ Pi.single l 1) = c • v := by
  classical
  let x : EuclideanSpace ℂ (Fin d) := WithLp.toLp 2 v
  have hx : x ≠ 0 := by
    intro h
    exact hv (congrArg WithLp.ofLp h)
  let w := (‖x‖⁻¹ : ℝ) • x
  have hw : ‖w‖ = 1 := by
    dsimp [w]
    rw [norm_smul, Real.norm_eq_abs, abs_of_nonneg (inv_nonneg.mpr (norm_nonneg _)),
      inv_mul_cancel₀ (norm_ne_zero_iff.mpr hx)]
  let s : Set (Fin d) := {l}
  let u : Fin d → EuclideanSpace ℂ (Fin d) := fun _ => w
  have hu : Orthonormal ℂ (s.restrict u) := by
    refine ⟨fun _ => hw, ?_⟩
    intro i j hij
    exact False.elim (hij (Subtype.ext (i.property.trans j.property.symm)))
  obtain ⟨b,hb⟩ := hu.exists_orthonormalBasis_extension_of_card_eq
    (by simp : finrank ℂ (EuclideanSpace ℂ (Fin d))=Fintype.card (Fin d))
  let e := EuclideanSpace.basisFun (Fin d) ℂ
  let U : unitaryGroup (Fin d) ℂ :=
    ⟨e.toBasis.toMatrix b.toBasis, e.toMatrix_orthonormalBasis_mem_unitary b⟩
  refine ⟨U, (‖x‖⁻¹:ℝ), ?_⟩
  rw [mulVec_single_one]
  have hcol : Matrix.col (U:M) l = WithLp.ofLp (b l) := rfl
  rw [hcol, hb l (by rfl)]
  rfl

/-- A shared unitary change of coordinates isolates one signed eigenvalue
of each observable in the last row and column. -/
def LastBlock (l : Fin d) (D : Matrix (Fin d) (Fin d) ℂ) (a : ℂ) : Prop :=
  (∀ i, D i l = if i=l then a else 0) ∧
  (∀ j, D l j = if j=l then a else 0)

private theorem lastBlock_of_eigenvector (l : Fin d) (A : M) (hA : A.IsHermitian)
    (U : unitaryGroup (Fin d) ℂ) (a : ℂ) (ha : a=1 ∨ a= -1)
    (he : A *ᵥ ((U : M) *ᵥ Pi.single l 1) =
      a • ((U : M) *ᵥ Pi.single l 1)) :
    LastBlock l ((U:M)ᴴ * A * (U:M)) a := by
  let D : M := (U:M)ᴴ * A * U
  have he' : D *ᵥ Pi.single l 1 = a • (Pi.single l (1:ℂ) : V) := by
    dsimp [D]
    rw [←mulVec_mulVec, ←mulVec_mulVec, he, mulVec_smul, mulVec_mulVec]
    have hi : (U:M)ᴴ * (U:M)=1 := Unitary.coe_star_mul_self U
    rw [hi, one_mulVec]
  have hcol (i : Fin d) : D i l = if i=l then a else 0 := by
    rw [mulVec_single_one] at he'
    have h := congrFun he' i
    by_cases hi : i = l <;> simp [hi, eq_comm] at h ⊢ <;> exact h
  refine ⟨hcol, ?_⟩
  have hHerm : D.IsHermitian := Matrix.isHermitian_conjTranspose_mul_mul _ hA
  intro i
  have h := congrFun (congrFun hHerm.eq l) i
  change star (D i l) = D l i at h
  change D l i = _
  rw [←h, hcol]
  rcases ha with rfl | rfl <;> split <;> simp

theorem simultaneous_blocks (k : ℕ) (hdim : d=2*k+1) (l : Fin d) (A B : Matrix (Fin d) (Fin d) ℂ)
    (hA : A.IsHermitian) (hB : B.IsHermitian) (ha : A*A=1) (hb : B*B=1) :
    ∃ (U : Matrix.unitaryGroup (Fin d) ℂ) (a b : ℂ),
      (a=1 ∨ a= -1) ∧ (b=1 ∨ b= -1) ∧
      LastBlock l ((U : M)ᴴ * A * (U:M)) a ∧ LastBlock l ((U:M)ᴴ * B * (U:M)) b := by
  obtain ⟨v,hv,a,b,ha,hb,hav,hbv⟩ := common_eigenvector k hdim A B ha hb
  obtain ⟨U,c,hc⟩ := unitary_last_column l hv
  refine ⟨U,a,b,ha,hb,lastBlock_of_eigenvector l A hA U a ha ?_,
    lastBlock_of_eigenvector l B hB U b hb ?_⟩
  · rw [hc,mulVec_smul,hav,smul_comm]
  · rw [hc,mulVec_smul,hbv,smul_comm]

#print axioms simultaneous_blocks

end
end CHSHOddJordan
