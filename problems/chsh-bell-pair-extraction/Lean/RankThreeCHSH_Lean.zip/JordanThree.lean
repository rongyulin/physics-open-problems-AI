import OddJordan

/-! An elementary three-dimensional form of Jordan's lemma for pairs of
binary observables. Each involution has an eigenspace of dimension at
least two, so the two large eigenspaces intersect nontrivially. -/
namespace CHSHJordan
open Matrix Module
open scoped Matrix BigOperators
noncomputable section
private abbrev M := Matrix (Fin 3) (Fin 3) ℂ

/-- Hermiticity is unnecessary for the common eigenvector itself. -/
theorem common_eigenvector (A B : Matrix (Fin 3) (Fin 3) ℂ)
    (ha : A*A=1) (hb : B*B=1) :
    ∃ v : Fin 3 → ℂ, v ≠ 0 ∧ ∃ a b : ℂ,
      (a=1 ∨ a= -1) ∧ (b=1 ∨ b= -1) ∧ A *ᵥ v = a • v ∧ B *ᵥ v = b • v := by
  exact CHSHOddJordan.common_eigenvector 1 rfl A B ha hb

/-- One-dimensional block in the last qutrit coordinate. -/
abbrev LastBlock (D : M) (a : ℂ) := CHSHOddJordan.LastBlock 2 D a

theorem simultaneous_blocks (A B : Matrix (Fin 3) (Fin 3) ℂ)
    (hA : A.IsHermitian) (hB : B.IsHermitian) (ha : A*A=1) (hb : B*B=1) :
    ∃ (U : Matrix.unitaryGroup (Fin 3) ℂ) (a b : ℂ),
      (a=1 ∨ a= -1) ∧ (b=1 ∨ b= -1) ∧
      LastBlock ((U : M)ᴴ * A * (U:M)) a ∧ LastBlock ((U:M)ᴴ * B * (U:M)) b := by
  exact CHSHOddJordan.simultaneous_blocks 1 rfl 2 A B hA hB ha hb

private theorem block_of_last {D : M} {a : ℂ} (ha : a=1 ∨ a= -1) (h : LastBlock D a) :
    D = CHSH.block (CHSH.top D) a.re := by
  have h02 := h.1 0
  have h12 := h.1 1
  have h20 := h.2 0
  have h21 := h.2 1
  have h22 := h.1 2
  have har : (a.re : ℂ)=a := by rcases ha with rfl|rfl <;> simp
  simp at h02 h12 h20 h21 h22
  ext i j
  fin_cases i <;> fin_cases j <;>
    first | rfl | exact h02 | exact h12 | exact h20 | exact h21 | exact h22.trans har.symm

private theorem conjugated_observable (D : M) (h : CHSH.Observable D)
    (U : unitaryGroup (Fin 3) ℂ) : CHSH.Observable ((U:M)ᴴ * D * (U:M)) := by
  refine ⟨Matrix.isHermitian_conjTranspose_mul_mul _ h.1, ?_⟩
  have hori : (U:M) * (U:M)ᴴ = 1 := Unitary.coe_mul_star_self U
  have hrev : (U:M)ᴴ * (U:M) = 1 := Unitary.coe_star_mul_self U
  calc
    ((U:M)ᴴ * D * (U:M)) * ((U:M)ᴴ * D * (U:M)) =
      (U:M)ᴴ * (D * ((U:M) * (U:M)ᴴ) * D) * U := by simp only [Matrix.mul_assoc]
    _ = 1 := by rw [hori,Matrix.mul_one,h.2,Matrix.mul_one,hrev]

private theorem top_observable {D : M} {a : ℝ} (h : CHSH.Observable D)
    (hb : D = CHSH.block (CHSH.top D) a) : CHSH.Observable (CHSH.top D) := by
  refine ⟨h.1.submatrix Fin.castSucc, ?_⟩
  have hsq := h.2
  rw [hb] at hsq
  ext i j
  have h := congrFun (congrFun hsq i.castSucc) j.castSucc
  fin_cases i <;> fin_cases j <;>
    simpa [CHSH.block,Matrix.mul_apply, Fin.sum_univ_succ] using h

/-- Simultaneous 2+1 decomposition in the observable model of the CHSH development. -/
theorem simultaneous_observable_blocks (A B : CHSH.Mat (Fin 3))
    (hA : CHSH.Observable A) (hB : CHSH.Observable B) :
    ∃ (U : Matrix.unitaryGroup (Fin 3) ℂ) (C D : CHSH.Mat (Fin 2)) (a b : ℝ),
      CHSH.Observable C ∧ CHSH.Observable D ∧ (a=1 ∨ a= -1) ∧ (b=1 ∨ b= -1) ∧
      (U:M)ᴴ * A * (U:M) = CHSH.block C a ∧ (U:M)ᴴ * B * (U:M) = CHSH.block D b := by
  obtain ⟨U,a,b,ha,hb,hC,hD⟩ := simultaneous_blocks A B hA.1 hB.1 hA.2 hB.2
  have hc := block_of_last ha hC
  have hd := block_of_last hb hD
  refine ⟨U,_,_,a.re,b.re,top_observable (conjugated_observable A hA U) hc,
    top_observable (conjugated_observable B hB U) hd, ?_, ?_,hc,hd⟩
  · rcases ha with rfl|rfl <;> simp
  · rcases hb with rfl|rfl <;> simp

#print axioms simultaneous_observable_blocks
end
end CHSHJordan
