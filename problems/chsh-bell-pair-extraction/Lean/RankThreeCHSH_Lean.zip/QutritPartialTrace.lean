import QutritPurification
namespace CHSHMixed
open CHSH Matrix
open scoped Matrix MatrixOrder ComplexOrder BigOperators Kronecker
noncomputable section
variable {n : Type*} [Fintype n] [DecidableEq n]

theorem marginal_left (A : Mat (Fin 3)) (R : Mat (Fin 3 × n)) :
    marginal ((A ⊗ₖ (1 : Mat n))*R) = A*marginal R := by
  ext i k
  simp [marginal,Matrix.mul_apply,Fintype.sum_prod_type,
    Matrix.one_apply, mul_ite,ite_mul,Finset.mul_sum]
  rw [Finset.sum_comm]

theorem marginal_right (R : Mat (Fin 3 × n)) (A : Mat (Fin 3)) :
    marginal (R*(A ⊗ₖ (1 : Mat n))) = marginal R*A := by
  ext i k
  simp [marginal,Matrix.mul_apply,Fintype.sum_prod_type,
    Matrix.one_apply, mul_ite,Finset.sum_mul]
  rw [Finset.sum_comm]

omit [DecidableEq n] in
theorem corr_trace (R : Mat (Fin 3 × n)) (A : Mat (Fin 3)) (B : Mat n) :
    mixedCorr R A B = ((A⊗ₖ B)*R).trace.re := by
  unfold mixedCorr Matrix.trace Matrix.diag
  simp only [Matrix.mul_apply, Fintype.sum_prod_type, Matrix.kronecker_apply]
  congr 1
  apply Finset.sum_congr rfl
  intro i _
  apply Finset.sum_congr rfl
  intro j _
  apply Finset.sum_congr rfl
  intro k _
  apply Finset.sum_congr rfl
  intro l _
  ring

theorem trace_unitary {v : Type*} [Fintype v] [DecidableEq v]
    (E : Mat v) (h : E*Eᴴ=1) (T : Mat v) : (Eᴴ*T*E).trace = T.trace := by
  rw [trace_mul_comm,← Matrix.mul_assoc,h,one_mul]

theorem corr_rotate (U : unitaryGroup (Fin 3) ℂ) (R : Mat (Fin 3 × n))
    (A : Mat (Fin 3)) (B : Mat n) :
    let E := U.val ⊗ₖ (1 : Mat n)
    mixedCorr (Eᴴ * R * E) (U.valᴴ * A * U.val) B = mixedCorr R A B := by
  let E := U.val ⊗ₖ (1 : Mat n)
  have huu : U.val*U.valᴴ=1 := U.property.2
  have he : E*Eᴴ=1 := by
    simp only [E,conjTranspose_kronecker,conjTranspose_one,← mul_kronecker_mul,
      huu, Matrix.one_mul,one_kronecker_one]
  have hm : (U.valᴴ*A*U.val) ⊗ₖ B = Eᴴ*(A⊗ₖ B)*E := by
    simp only [E,conjTranspose_kronecker,conjTranspose_one,← mul_kronecker_mul,
      Matrix.one_mul,Matrix.mul_one]
  dsimp only
  rw [corr_trace,corr_trace,hm]
  change ((Eᴴ*(A ⊗ₖ B)*E)*(Eᴴ*R*E)).trace.re = _
  have hx : (Eᴴ*(A ⊗ₖ B)*E)*(Eᴴ*R*E) = Eᴴ*((A ⊗ₖ B)*R)*E := by
    calc
      _ = Eᴴ*(A ⊗ₖ B)*(E*Eᴴ)*R*E := by simp only [Matrix.mul_assoc]
      _ = _ := by rw [he,Matrix.mul_one]; simp only [Matrix.mul_assoc]
  rw [hx,trace_unitary E he]

end
end CHSHMixed
