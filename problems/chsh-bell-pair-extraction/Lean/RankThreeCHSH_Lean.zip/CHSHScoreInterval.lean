import CHSHPOVM
import CHSHClassical

/-! Every score between zero and an achieved positive projective CHSH score
is exactly realized by ordinary positive binary effects. Alice attenuates
the two observables by the same scalar; Bob keeps his reflections. -/
namespace CHSHScoreInterval
open CHSH CHSHPOVM Matrix
open scoped Matrix BigOperators ComplexOrder
noncomputable section

structure Binary (n : Type*) [Fintype n] [DecidableEq n] where
  plus : Mat n
  minus : Mat n
  plus_pos : plus.PosSemidef
  minus_pos : minus.PosSemidef
  complete : plus+minus=1

def Binary.diff {n : Type*} [Fintype n] [DecidableEq n] (b : Binary n) := b.plus-b.minus

def effectScores {m n : Type*} [Fintype m] [Fintype n] [DecidableEq m] [DecidableEq n]
    (F : Matrix m n ℂ) : Set ℝ :=
  {s | ∃ (A₀ A₁ : Binary m) (B₀ B₁ : Binary n),
    chsh F A₀.diff A₁.diff B₀.diff B₁.diff = s}

private theorem scaled_plus {n : Type*} [Fintype n] [DecidableEq n] {A : Mat n}
    (hA : Observable A) (r : ℝ) (hr : 0 ≤ r) (h₁ : r ≤ 1) :
    (1+r • A).PosSemidef := by
  have hi := (Matrix.PosSemidef.one (n := n) (R := ℂ)).smul (sub_nonneg.mpr h₁)
  have ha := (CHSHClassical.plus_pos hA).smul hr
  have e : 1+r • A = (1-r) • (1 : Mat n) + r • (1+A) := by module
  rw [e]
  exact hi.add ha

def attenuated {n : Type*} [Fintype n] [DecidableEq n] {A : Mat n}
    (hA : Observable A) (r : ℝ) (hr : 0 ≤ r) (h₁ : r ≤ 1) : Binary n where
  plus := (1/2 : ℝ) • (1+r • A)
  minus := (1/2 : ℝ) • (1+r • (-A))
  plus_pos := (scaled_plus hA r hr h₁).smul (by norm_num : (0 : ℝ) ≤ 1/2)
  minus_pos := (scaled_plus (CHSHClassical.neg_observable hA) r hr h₁).smul
    (by norm_num : (0 : ℝ) ≤ 1/2)
  complete := by module

theorem attenuated_diff {n : Type*} [Fintype n] [DecidableEq n] {A : Mat n}
    (hA : Observable A) (r : ℝ) (hr : 0 ≤ r) (h₁ : r ≤ 1) :
    (attenuated hA r hr h₁).diff = r • A := by
  unfold attenuated Binary.diff
  module

theorem exact_score {m n : Type*} [Fintype m] [Fintype n] [DecidableEq m] [DecidableEq n]
    (F : Matrix m n ℂ) (A X : Mat m) (B Y : Mat n) (hA : Observable A) (hX : Observable X)
    (hB : Observable B) (hY : Observable Y) (s v : ℝ) (hv : chsh F A X B Y = v)
    (hs : 0 ≤ s) (hsv : s ≤ v) : s ∈ effectScores F := by
  let r := if v = 0 then 0 else s/v
  have h0 : 0 ≤ r := by
    dsimp [r]; split
    · exact le_rfl
    · exact div_nonneg hs (hs.trans hsv)
  have h1 : r ≤ 1 := by
    dsimp [r]; split
    · norm_num
    · rename_i h
      apply (div_le_iff₀ (lt_of_le_of_ne (hs.trans hsv) (Ne.symm h))).mpr
      linarith
  have hrv : r*v = s := by
    dsimp [r]; split
    · rename_i h; linarith
    · rename_i h; exact div_mul_cancel₀ _ h
  refine ⟨attenuated hA r h0 h1, attenuated hX r h0 h1,
    attenuated hB 1 (by norm_num) le_rfl, attenuated hY 1 (by norm_num) le_rfl, ?_⟩
  simp only [attenuated_diff, one_smul]
  have hc (P : Mat m) (Q : Mat n) : corr F (r • P) Q = r * corr F P Q :=
    (corrLeft F Q).map_smul r P
  simp only [chsh, hc]
  rw [← hrv, ← hv]
  unfold chsh
  ring

theorem effect_to_contractions {m n : Type*} [Fintype m] [Fintype n] [DecidableEq m] [DecidableEq n]
    {F : Matrix m n ℂ} {s : ℝ} (h : s ∈ effectScores F) :
    ∃ (A X : Mat m) (B Y : Mat n), Contraction A ∧ Contraction X ∧ Contraction B ∧ Contraction Y ∧
      chsh F A X B Y = s := by
  obtain ⟨A,X,B,Y,h⟩ := h
  exact ⟨A.diff,X.diff,B.diff,Y.diff,contraction_of_effects A.plus_pos A.minus_pos A.complete,
    contraction_of_effects X.plus_pos X.minus_pos X.complete,
    contraction_of_effects B.plus_pos B.minus_pos B.complete,
    contraction_of_effects Y.plus_pos Y.minus_pos Y.complete,h⟩

#print axioms exact_score
end
end CHSHScoreInterval
