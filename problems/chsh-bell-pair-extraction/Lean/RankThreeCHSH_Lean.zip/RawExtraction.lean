import MYFidelity
import QutritCHSH

/-! Operational singlet extraction for a raw two-qutrit amplitude matrix.
The two local isometries act on its actual input coordinates; the output
Bell-pair times ancillary-state amplitude matrix is diagonal and paired. -/
namespace RawExtraction
open CHSH MYFidelity QutritCHSH Matrix
open scoped Matrix BigOperators
noncomputable section

def overlap {n : ℕ} (F : M) (d : Fin (n+2) → ℝ) (L R : Embed n) : ℂ :=
  ∑ j, ∑ k : Fin 2, (d j : ℂ)*(L*F*Rᵀ) (j,k) (j,k)

def scores (F : M) : Set ℝ :=
  {r | ∃ (n : ℕ) (d : Fin (n+2) → ℝ) (L R : Embed n),
    Antitone d ∧ (∀ j, 0 ≤ d j) ∧ (2 * ∑ j, (d j)^2 = 1) ∧
      IsEmbedding L ∧ IsEmbedding R ∧ Complex.normSq (overlap F d L R) = r}

private theorem composed {n : ℕ} (L : Embed n) (U : U3) (hL : IsEmbedding L) :
    IsEmbedding (L*U.val) := by
  change (L*U.val)ᴴ*(L*U.val)=1
  rw [Matrix.conjTranspose_mul, Matrix.mul_assoc, ← Matrix.mul_assoc Lᴴ, hL, Matrix.one_mul]
  exact U.property.1

theorem overlap_basis {n : ℕ} (F : M) (U V : U3) (d : Fin (n+2) → ℝ) (L R : Embed n) :
    overlap (U.val*F*V.valᵀ) d L R = overlap F d (L*U.val) (R*V.val) := by
  simp only [overlap, Matrix.transpose_mul, Matrix.mul_assoc]

theorem scores_basis (F : M) (U V : U3) : scores (U.val*F*V.valᵀ)=scores F := by
  ext z
  constructor
  · rintro ⟨n,d,L,R,hd,hn,hnorm,hL,hR,hz⟩
    rw [overlap_basis] at hz
    exact ⟨n,d,_,_,hd,hn,hnorm,composed L U hL,composed R V hR,hz⟩
  · rintro ⟨n,d,L,R,hd,hn,hnorm,hL,hR,hz⟩
    refine ⟨n,d,L*(star U).val,R*(star V).val,hd,hn,hnorm,
      composed L (star U) hL,composed R (star V) hR,?_⟩
    rw [overlap_basis]
    have cancel (T : Embed n) (W : U3) : T*(star W).val*W.val = T := by
      rw [Matrix.mul_assoc]
      change T*(W.valᴴ*W.val)=T
      rw [show W.valᴴ*W.val=1 from W.property.1,Matrix.mul_one]
    rwa [cancel,cancel]

theorem overlap_diagonal {n : ℕ} (c : Fin 3 → ℝ) (d : Fin (n+2) → ℝ) (L R : Embed n) :
    overlap (state c) d L R = MYFidelity.overlap (c 0) (c 1) (c 2) d L R := by
  let t (i : Fin 3) (j : Fin (n+2)) (k : Fin 2) :=
    ((c i * d j : ℝ):ℂ) * L (j,k) i * R (j,k) i
  have hcoord : ![c 0,c 1,c 2]=c := by funext i; fin_cases i <;> rfl
  calc
    _ = ∑ j, ∑ k, ∑ i, t i j k := by
      unfold overlap
      refine Finset.sum_congr rfl fun j _ => Finset.sum_congr rfl fun k _ => ?_
      simp only [state, Matrix.mul_apply, Matrix.transpose_apply, Finset.mul_sum]
      refine Finset.sum_congr rfl fun i _ => ?_
      dsimp [t]
      simp [Matrix.diagonal_apply, mul_ite]
      ring
    _ = ∑ j, ∑ i, ∑ k, t i j k := by
      refine Finset.sum_congr rfl fun j _ => ?_
      rw [Finset.sum_comm]
    _ = ∑ i, ∑ j, ∑ k, t i j k := Finset.sum_comm
    _ = _ := by simp only [MYFidelity.overlap,hcoord,t]

theorem scores_diagonal (c : Fin 3 → ℝ) :
    scores (state c) = MYFidelity.scores (c 0) (c 1) (c 2) := by
  ext z
  simp only [scores, MYFidelity.scores, Set.mem_setOf_eq, overlap_diagonal]

#print axioms scores_basis
end
end RawExtraction
