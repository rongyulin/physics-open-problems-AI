import Mathlib.Data.Real.Sqrt
import Mathlib.Tactic

/-! The increase over the classical value for a two-dimensional Schmidt block. -/
namespace CHSHPair
noncomputable section
def gain (u v : ℝ) : ℝ := Real.sqrt ((u+v)^2 + 4*u*v) - (u+v)

lemma gain_nonneg {u v : ℝ} (hu : 0 ≤ u) (hv : 0 ≤ v) : 0 ≤ gain u v := by
  have hs := Real.sq_sqrt (show 0 ≤ (u+v)^2+4*u*v by positivity)
  have hp := Real.sqrt_nonneg ((u+v)^2+4*u*v)
  unfold gain
  nlinarith [mul_nonneg hu hv]

lemma gain_equation {u v : ℝ} (hu : 0 ≤ u) (hv : 0 ≤ v) :
    (gain u v)^2 + 2*(u+v)*gain u v = 4*u*v := by
  have h := Real.sq_sqrt (show 0 ≤ (u+v)^2+4*u*v by positivity)
  unfold gain
  nlinarith

lemma gain_le_two_right {u v : ℝ} (hu : 0 ≤ u) (hv : 0 ≤ v) :
    gain u v ≤ 2*v := by
  have hs := Real.sq_sqrt (show 0 ≤ (u+v)^2+4*u*v by positivity)
  have hp := Real.sqrt_nonneg ((u+v)^2+4*u*v)
  unfold gain
  nlinarith [sq_nonneg v]

lemma gain_comm (u v : ℝ) : gain u v = gain v u := by
  unfold gain
  rw [add_comm u v, show 4*u*v=4*v*u by ring]

lemma gain_mono_left {u U v : ℝ} (hu : 0 ≤ u) (hv : 0 ≤ v) (hle : u ≤ U) :
    gain u v ≤ gain U v := by
  have hU : 0 ≤ U := hu.trans hle
  have h1 := gain_equation hu hv
  have h2 := gain_equation hU hv
  have h3 := mul_nonneg (sub_nonneg.mpr hle) (sub_nonneg.mpr (gain_le_two_right hu hv))
  have h4 := gain_nonneg hU hv
  by_contra! hn
  have hs : (gain U v)^2 < (gain u v)^2 := by
    nlinarith [mul_pos (sub_pos.mpr hn) (show 0 < gain u v + gain U v by linarith)]
  have hm := mul_nonneg (show 0 ≤ 2*(U+v) by positivity) (sub_nonneg.mpr hn.le)
  nlinarith

theorem gain_mono {u v U V : ℝ} (hu : 0 ≤ u) (hv : 0 ≤ v) (huU : u ≤ U) (hvV : v ≤ V) :
    gain u v ≤ gain U V := by
  calc
    _ ≤ gain U v := gain_mono_left hu hv huU
    _ = gain v U := gain_comm _ _
    _ ≤ gain V U := gain_mono_left hv (hu.trans huU) hvV
    _ = _ := gain_comm _ _

/-- Combine compression and the two-dimensional CHSH bound. All variables
are unnormalized; the last Schmidt coefficient is the singleton weight. -/
theorem envelope {a b c x y W L : ℝ}
    (hx : 0 ≤ x) (hy : 0 ≤ y) (hxa : x ≤ a) (hyb : y ≤ b)
    (hW : W = a^2+b^2+c^2)
    (hL : L ≤ 2*Real.sqrt ((x^2+y^2)^2+4*(x*y)^2) + 2*(W-(x^2+y^2))) :
    L ≤ 2*c^2+2*Real.sqrt ((a^2+b^2)^2+4*a^2*b^2) := by
  have H := gain_mono (sq_nonneg x) (sq_nonneg y)
    (sq_le_sq' (by linarith : -a ≤ x) hxa)
    (sq_le_sq' (by linarith : -b ≤ y) hyb)
  unfold gain at H
  rw [mul_pow, ← mul_assoc (4:ℝ) (x^2) (y^2)] at hL
  linarith

#print axioms envelope
end
end CHSHPair
