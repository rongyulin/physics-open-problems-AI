import QutritCHSH
import CompressionMass
namespace CHSHRigidity
open CHSH QutritCHSH CHSHCompression Matrix
open scoped Matrix BigOperators
noncomputable section

def leak (U : U3) : ℝ := Complex.normSq (U.val 0 2) + Complex.normSq (U.val 1 2)

private theorem col_formula (L R : U3) (c : Fin 3 → ℝ) :
    mass (Matrix.col (L.val*state c*R.val) 2) =
      ∑ i, (c i)^2 * Complex.normSq (R.val i 2) := by
  have h : Matrix.col (L.val*state c*R.val) 2 =
      L.val *ᵥ (state c *ᵥ (Matrix.col R.val 2)) := by
    calc
      _ = (L.val*state c*R.val) *ᵥ (Pi.single (2:Fin 3) (1:ℂ)) := by rw [mulVec_single_one]
      _ = _ := by rw [←mulVec_mulVec, ←mulVec_mulVec, mulVec_single_one]
  rw [h,mass_unitary]
  simp [mass,state,Matrix.mulVec_diagonal,Complex.normSq_ofReal,pow_two]

private theorem col_norm (U : U3) : ∑ i, Complex.normSq (U.val i 2) = 1 := by
  have h := mass_unitary U (Pi.single (2:Fin 3) (1:ℂ))
  rw [mulVec_single_one] at h
  simpa [mass,Pi.single_apply,Fin.sum_univ_three] using h

private theorem col_estimate (U : U3) (c : Fin 3 → ℝ) (hc : Antitone c)
    (hn : ∀ i, 0 ≤ c i) : (c 2)^2+((c 1)^2-(c 2)^2)*leak U ≤
      ∑ i, (c i)^2 * Complex.normSq (U.val i 2) := by
  have hn' := col_norm U
  rw [Fin.sum_univ_three] at hn' ⊢
  have h10 : (c 1)^2 ≤ (c 0)^2 := by
    nlinarith [mul_nonneg (sub_nonneg.mpr (hc (show (0:Fin 3) ≤ 1 by decide)))
      (add_nonneg (hn 0) (hn 1))]
  dsimp [leak]
  nlinarith only [congrArg ((c 2)^2 * ·) hn',
    mul_nonneg (sub_nonneg.mpr h10) (Complex.normSq_nonneg (U.val 0 2))]

private theorem discarded_col (F : M) : weight (top F) + mass (F.col 2) ≤ weight F := by
  simp only [weight,top,mass,Matrix.submatrix_apply,Matrix.col_apply,Fin.sum_univ_two,Fin.sum_univ_three]
  simp only [show (Fin.castSucc (0:Fin 2))=(0:Fin 3) by rfl,
    show (Fin.castSucc (1:Fin 2))=(1:Fin 3) by rfl]
  linarith only [Complex.normSq_nonneg (F 2 0), Complex.normSq_nonneg (F 2 1)]

private theorem discarded_row (F : M) : weight (top F) + mass (Fᴴ.col 2) ≤ weight F := by
  simp only [weight,top,mass,Matrix.submatrix_apply,Matrix.col_apply,Matrix.conjTranspose_apply,
    Complex.star_def,Complex.normSq_conj,Fin.sum_univ_two,Fin.sum_univ_three]
  simp only [show (Fin.castSucc (0:Fin 2))=(0:Fin 3) by rfl,
    show (Fin.castSucc (1:Fin 2))=(1:Fin 3) by rfl]
  linarith only [Complex.normSq_nonneg (F 0 2), Complex.normSq_nonneg (F 1 2)]

theorem leak_bound (c : Fin 3 → ℝ) (hc : Antitone c) (hn : ∀ i, 0 ≤ c i) (U V : U3) :
    ((c 1)^2-(c 2)^2)*max (leak U) (leak V) ≤
      (c 0)^2+(c 1)^2-weight (top (U.valᴴ*state c*(conjugateU V).val)) := by
  let F := U.valᴴ*state c*(conjugateU V).val
  have hw : weight F = (c 0)^2+(c 1)^2+(c 2)^2 := by
    rw [← CHSHBasis.weight_basis F U V,restore,state_weight]
  have hf : Fᴴ = (star (conjugateU V) : U3).val * state c * U.val := by
    have hs : (state c)ᴴ = state c := by
      ext i j
      by_cases h : i=j
      · subst j; simp [state, Matrix.conjTranspose_apply]
      · simp [state, Matrix.conjTranspose_apply, Matrix.diagonal_apply, h, Ne.symm h]
    change (U.valᴴ * state c * (conjugateU V).val)ᴴ =
      (conjugateU V).valᴴ * state c * U.val
    simp only [Matrix.conjTranspose_mul, Matrix.conjTranspose_conjTranspose,hs, Matrix.mul_assoc]
  have col := col_formula (star U) (conjugateU V) c
  change mass (F.col 2) = _ at col
  have col' : mass (F.col 2) = ∑ i, (c i)^2*Complex.normSq (V.val i 2) := by
    simpa [conjugateU, Matrix.conjTranspose_apply,Complex.star_def] using col
  have row := col_formula (star (conjugateU V)) U c
  rw [← hf] at row
  have eu := col_estimate U c hc hn
  have ev := col_estimate V c hc hn
  change _ ≤ (c 0)^2+(c 1)^2-weight (top F)
  rcases le_total (leak U) (leak V) with huv|hvu
  · rw [max_eq_right huv]; linarith only [discarded_col F, col', ev, hw]
  · rw [max_eq_left hvu]; linarith only [discarded_row F, row, eu, hw]

#print axioms leak_bound
end
end CHSHRigidity
