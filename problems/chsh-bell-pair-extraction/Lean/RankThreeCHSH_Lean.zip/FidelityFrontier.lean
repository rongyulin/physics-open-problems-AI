import Mathlib.Data.Real.Sqrt
import Mathlib.Order.Bounds.Basic
import Mathlib.Tactic

/-! Sharp rank-three Schmidt-spectrum tradeoff. The normalized Schmidt
probabilities are a ≥ b ≥ p. The observed half-CHSH score is s, and
the Bell-pair fidelity of the state is (1+w)/2 for w=2√(ab). -/
namespace CHSHFrontier
noncomputable section

def switchA : ℝ := (1 + Real.sqrt 41) / 6
def switchB : ℝ := (1 + 2*Real.sqrt 2) / 3
def lowP (s : ℝ) := (s+1-Real.sqrt (-7*s^2+2*s+9))/8
def lowW (s : ℝ) := 2*Real.sqrt (lowP s*(1-2*lowP s))
def highW (s : ℝ) := (s-1)/(Real.sqrt 2-1)
def minimumW (s : ℝ) := if s ≤ switchA then lowW s else if s ≤ switchB then 2/3 else highW s

/-- Schmidt probabilities for states capable of the specified observed score. -/
structure Compatible (s w a b p : ℝ) : Prop where
  nonneg : 0 ≤ p
  order₁ : p ≤ b
  order₂ : b ≤ a
  normalized : a+b+p=1
  overlap : w = 2*Real.sqrt (a*b)
  score : s ≤ p + Real.sqrt ((1-p)^2+w^2)

def feasible (s w : ℝ) : Prop := ∃ a b p, Compatible s w a b p

private theorem score_iff {s p w : ℝ} (hsp : p ≤ s) :
    s ≤ p+Real.sqrt ((1-p)^2+w^2) ↔ (s-1)*(s+1-2*p) ≤ w^2 := by
  rw [← sub_le_iff_le_add', Real.le_sqrt (sub_nonneg.mpr hsp) (by positivity)]
  constructor <;> intro h <;> nlinarith only [h]

private theorem compatible_bounds {s w a b p : ℝ} (h : Compatible s w a b p) :
    0 ≤ w ∧ p ≤ 1/3 ∧ 4*p*(1-2*p) ≤ w^2 ∧ w ≤ 1-p := by
  obtain ⟨hp,hpb,hba,hn,hw,_⟩ := h
  have hb : 0 ≤ b := hp.trans hpb
  have ha : 0 ≤ a := hb.trans hba
  have hwp : 0 ≤ w := by rw [hw]; positivity
  have hw2 : w^2 = 4*(a*b) := by rw [hw, mul_pow, Real.sq_sqrt (mul_nonneg ha hb)]; ring
  refine ⟨hwp, by linarith, ?_, ?_⟩
  · nlinarith [mul_nonneg (sub_nonneg.mpr (hpb.trans hba)) (sub_nonneg.mpr hpb),
      congrArg (fun t : ℝ => t*p) hn]
  · apply (sq_le_sq₀ hwp (by linarith)).mp
    nlinarith [sq_nonneg (a-b), congrArg (fun t : ℝ => t^2) (show a+b=1-p by linarith)]

/-- The two equations characterizing the low-score minimizing branch. -/
private theorem low_data (s : ℝ) (hs : 1 ≤ s) (hupper : s ≤ switchA) :
    0 ≤ lowP s ∧ lowP s ≤ 1/6 ∧
    4*lowP s*(1-2*lowP s) = (s-1)*(s+1-2*lowP s) := by
  let D := -7*s^2+2*s+9
  have h41 : (Real.sqrt 41)^2 = 41 := Real.sq_sqrt (by norm_num)
  have hu : 6*s-1 ≤ Real.sqrt 41 := by dsimp [switchA] at hupper; linarith
  have hu2 := (sq_le_sq₀ (by linarith : 0 ≤ 6*s-1) (Real.sqrt_nonneg _)).mpr hu
  have hd : (s-1/3)^2 ≤ D := by dsimp [D]; nlinarith only [hu2, h41]
  have hd0 : 0 ≤ D := (sq_nonneg _).trans hd
  have hd2 := Real.sq_sqrt hd0
  have hr₁ : s-1/3 ≤ Real.sqrt D := Real.le_sqrt_of_sq_le hd
  have hr₂ : Real.sqrt D ≤ s+1 := by
    apply (sq_le_sq₀ (Real.sqrt_nonneg D) (by linarith)).mp
    rw [hd2]
    dsimp [D]
    nlinarith [mul_nonneg (sub_nonneg.mpr hs) (show 0 ≤ s+1 by linarith)]
  change 0 ≤ (s+1-Real.sqrt D)/8 ∧ (s+1-Real.sqrt D)/8 ≤ 1/6 ∧ _
  refine ⟨by linarith, by linarith, ?_⟩
  change 4*((s+1-Real.sqrt D)/8)*(1-2*((s+1-Real.sqrt D)/8)) =
    (s-1)*(s+1-2*((s+1-Real.sqrt D)/8))
  dsimp [D] at hd2 ⊢
  nlinarith only [hd2]

/-- For p₀≤1/6, either p≤p₀ and the observed score controls w, or
p≥p₀ and the ordering of the three Schmidt probabilities controls w. -/
private theorem branch_bound {s w a b p p₀ : ℝ} (h : Compatible s w a b p)
    (hs : 1 ≤ s) (h6 : p₀ ≤ 1/6)
    (he : 4*p₀*(1-2*p₀) = (s-1)*(s+1-2*p₀)) :
    4*p₀*(1-2*p₀) ≤ w^2 := by
  obtain ⟨_,hp3,hord,_⟩ := compatible_bounds h
  by_cases hpp : p ≤ p₀
  · have hscore := (score_iff (by linarith : p ≤ s)).mp h.score
    nlinarith [mul_nonneg (sub_nonneg.mpr hs) (sub_nonneg.mpr hpp)]
  · have hpos : 0 ≤ 1-2*p-2*p₀ := by linarith
    nlinarith [mul_nonneg (sub_nonneg.mpr (le_of_not_ge hpp)) hpos]

theorem low_le {s w a b p : ℝ} (h : Compatible s w a b p) (hs : 1 ≤ s)
    (hu : s ≤ switchA) : lowW s ≤ w := by
  obtain ⟨hp,h6,he⟩ := low_data s hs hu
  have hw := (compatible_bounds h).1
  apply (sq_le_sq₀ (by dsimp [lowW]; positivity) hw).mp
  have hn : 0 ≤ lowP s*(1-2*lowP s) := mul_nonneg hp (by linarith)
  simpa only [lowW, mul_pow, Real.sq_sqrt hn] using
    (show (2:ℝ)^2 *(lowP s*(1-2*lowP s)) ≤ w^2 by
      nlinarith only [branch_bound h hs h6 he])

theorem low_witness (s : ℝ) (hs : 1 ≤ s) (hu : s ≤ switchA) :
    Compatible s (lowW s) (1-2*lowP s) (lowP s) (lowP s) := by
  obtain ⟨hp,h6,he⟩ := low_data s hs hu
  have hn : 0 ≤ lowP s*(1-2*lowP s) := mul_nonneg hp (by linarith)
  refine ⟨hp, le_rfl, by linarith, by ring, by simp [lowW, mul_comm], ?_⟩
  apply (score_iff (by linarith : lowP s ≤ s)).mpr
  rw [lowW, mul_pow, Real.sq_sqrt hn]
  nlinarith only [he]

theorem middle_le {s w a b p : ℝ} (h : Compatible s w a b p)
    (hs : switchA ≤ s) : 2/3 ≤ w := by
  have h41 : (Real.sqrt 41)^2=41 := Real.sq_sqrt (by norm_num)
  have h1 : 1 ≤ switchA := by
    dsimp [switchA]
    nlinarith [Real.sqrt_nonneg 41]
  have h' : Compatible switchA w a b p := {h with score := hs.trans h.score}
  have hroot : 4*(1/6:ℝ)*(1-2*(1/6)) = (switchA-1)*(switchA+1-2*(1/6)) := by
    dsimp [switchA]; nlinarith only [h41]
  have hw := branch_bound h' h1 le_rfl hroot
  apply (sq_le_sq₀ (by norm_num : (0:ℝ) ≤ 2/3) (compatible_bounds h).1).mp
  nlinarith only [hw]

theorem middle_witness (s : ℝ) (hu : s ≤ switchB) :
    Compatible s (2/3) (1/3) (1/3) (1/3) := by
  have h2 : (Real.sqrt 2)^2=2 := Real.sq_sqrt (by norm_num)
  refine ⟨by norm_num, le_rfl, le_rfl, by norm_num, ?_, hu.trans ?_⟩
  · rw [Real.sqrt_mul_self (by norm_num : 0 ≤ (1/3:ℝ))]
    norm_num
  · apply (score_iff (by dsimp [switchB]; linarith [Real.sqrt_nonneg 2] : (1/3:ℝ) ≤ switchB)).mpr
    dsimp [switchB]
    nlinarith only [h2]

theorem high_le {s w a b p : ℝ} (h : Compatible s w a b p) (hs : 1 ≤ s) :
    highW s ≤ w := by
  obtain ⟨hw,hp,_,hwmax⟩ := compatible_bounds h
  have hscore := (score_iff (by linarith : p ≤ s)).mp h.score
  have h2 : (Real.sqrt 2)^2=2 := Real.sq_sqrt (by norm_num)
  have hrt : 1 < Real.sqrt 2 := Real.lt_sqrt_of_sq_lt (by norm_num)
  have hsm : (s-1+w)^2 ≤ 2*w^2 := by
    nlinarith [mul_nonneg (sub_nonneg.mpr hs) (show 0 ≤ 1-w-p by linarith)]
  have hlin : s-1+w ≤ Real.sqrt 2*w := by
    apply (sq_le_sq₀ (by linarith) (mul_nonneg (Real.sqrt_nonneg _) hw)).mp
    rwa [mul_pow, h2]
  apply (div_le_iff₀ (by linarith : 0 < Real.sqrt 2-1)).mpr
  nlinarith only [hlin]

theorem high_witness (s : ℝ) (hl : switchB ≤ s) (hu : s ≤ Real.sqrt 2) :
    Compatible s (highW s) (highW s/2) (highW s/2) (1-highW s) := by
  have hrt : 1 < Real.sqrt 2 := Real.lt_sqrt_of_sq_lt (by norm_num)
  have hd : 0 < Real.sqrt 2-1 := by linarith
  have hw : highW s*(Real.sqrt 2-1) = s-1 := by
    dsimp [highW]; exact div_mul_cancel₀ _ hd.ne'
  have hw1 : highW s ≤ 1 := by
    apply (div_le_iff₀ hd).mpr; linarith
  have hw2 : (2:ℝ)/3 ≤ highW s := by
    apply (le_div_iff₀ hd).mpr; dsimp [switchB] at hl; linarith
  have hw0 : 0 ≤ highW s := by linarith
  refine ⟨by linarith, by linarith, le_rfl, by ring, ?_, ?_⟩
  · rw [Real.sqrt_mul_self (show 0 ≤ highW s/2 by linarith)]
    ring
  · have h2 : (Real.sqrt 2)^2=2 := Real.sq_sqrt (by norm_num)
    have hr : Real.sqrt ((1-(1-highW s))^2+(highW s)^2) = Real.sqrt 2*highW s := by
      apply (sq_eq_sq₀ (Real.sqrt_nonneg _) (mul_nonneg (Real.sqrt_nonneg _) hw0)).mp
      rw [Real.sq_sqrt (by positivity), mul_pow, h2]; ring
    rw [hr]
    nlinarith only [hw]

theorem optimal_w (s : ℝ) (hs : 1 ≤ s) (hu : s ≤ Real.sqrt 2) :
    IsLeast {w : ℝ | feasible s w} (minimumW s) := by
  by_cases hlo : s ≤ switchA
  · rw [minimumW, if_pos hlo]
    exact ⟨⟨_,_,_,low_witness s hs hlo⟩, fun w ⟨_,_,_,hw⟩ => low_le hw hs hlo⟩
  · rw [minimumW, if_neg hlo]
    by_cases hmi : s ≤ switchB
    · rw [if_pos hmi]
      exact ⟨⟨_,_,_,middle_witness s hmi⟩, fun w ⟨_,_,_,hw⟩ => middle_le hw (le_of_not_ge hlo)⟩
    · rw [if_neg hmi]
      exact ⟨⟨_,_,_,high_witness s (le_of_not_ge hmi) hu⟩, fun w ⟨_,_,_,hw⟩ => high_le hw hs⟩

theorem optimal_fidelity (s : ℝ) (hs : 1 ≤ s) (hu : s ≤ Real.sqrt 2) :
    IsLeast {f : ℝ | ∃ w, feasible s w ∧ f = (1+w)/2} ((1+minimumW s)/2) := by
  obtain ⟨hmem,hlow⟩ := optimal_w s hs hu
  refine ⟨⟨_,hmem,rfl⟩, ?_⟩
  rintro _ ⟨w,hw,rfl⟩
  have := hlow hw
  linarith

#print axioms optimal_fidelity
end
end CHSHFrontier
