import Mathlib

/-! A cycle witness for the centered systematic CSS lift [−CDᵀ | C], [I | D].
Only the indicated nonpivot cycle and the extra site are needed to separate
the extra site's unit vector from the lifted X-row span. -/
namespace CanonicalCycle
open scoped BigOperators
noncomputable section

variable {R : Type*} [CommRing R] {L : ℕ} [NeZero L]

def alternating (R : Type*) [CommRing R] (j : ZMod L) : R := (-1:R)^j.val

private theorem step (even : Even L) (j : ZMod L) :
    alternating R (j+1) = -alternating R j := by
  have c : ((j.val+1 : ℕ):ZMod L)=j+1 := by simp
  have o : (-1:R)^L=1 := even.neg_one_pow
  by_cases h : j.val+1<L
  · have e : (j+1).val=j.val+1 := by rw [← c,ZMod.val_natCast_of_lt h]
    simp [alternating,e,pow_succ]
  · have wrap : j.val+1=L := by have := j.val_lt; omega
    have e : j+1=0 := by rw [← c,wrap,ZMod.natCast_self]
    rw [← wrap,pow_succ] at o
    simp only [e,alternating,ZMod.val_zero,pow_zero]
    linear_combination -o

def incident (i j : ZMod L) : Bool := decide (j=i-1 ∨ j=i)
def centered (R : Type*) [CommRing R] (t : Bool) : R := if t then -1 else 0
def mixed (j : ZMod L) : Bool := xor (incident 1 j) (incident 2 j)
def cyclePair (f : ZMod L → R) := ∑ j,f j*alternating R j

omit [NeZero L] in
private theorem neq_one_zero (hL : 4≤L) : (1:ZMod L)≠0 := by
  intro e
  have hv := congrArg ZMod.val e
  have hh := ZMod.val_natCast_of_lt (show 1<L by omega)
  simp only [Nat.cast_one] at hh
  rw [hh,ZMod.val_zero] at hv
  omega

omit [NeZero L] in
private theorem two_val (hL : 4≤L) : (2:ZMod L).val=2 := by
  exact_mod_cast ZMod.val_natCast_of_lt (show 2<L by omega)

/-- The restriction of an ordinary centered star pairs to zero on the even cycle. -/
theorem ordinary_pair (hL : 4≤L) (even : Even L) (i : ZMod L) :
    cyclePair (fun j => centered R (incident i j))=0 := by
  have ne : i-1≠i := by
    intro e
    apply neq_one_zero hL
    linear_combination -e
  have entry (j : ZMod L) : centered R (incident i j) =
      (if j=i-1 then (-1:R) else 0) + (if j=i then -1 else 0) := by
    by_cases a : j=i-1
    · subst j; simp [incident,centered,ne]
    · by_cases b : j=i
      · subst j; simp [incident,centered,Ne.symm ne]
      · simp [incident,centered,a,b]
  have s := step (R:=R) even (i-1)
  simp only [sub_add_cancel] at s
  simp only [cyclePair,entry,add_mul,Finset.sum_add_distrib,ite_mul,zero_mul,
    Finset.sum_ite_eq',Finset.mem_univ,if_true,neg_one_mul]
  linear_combination -s

/-- The common edge cancels before centering, leaving edges zero and two. -/
theorem mixed_pair (hL : 4≤L) :
    cyclePair (fun j : ZMod L => centered R (mixed j)) = -2 := by
  have one_ne : (1:ZMod L)≠0 := neq_one_zero hL
  have two_ne : (2:ZMod L)≠0 := by
    intro e; have h := congrArg ZMod.val e; rw [two_val hL,ZMod.val_zero] at h; omega
  have two_one : (2:ZMod L)≠1 := by
    intro e; apply one_ne; linear_combination e
  have two_sub : (2:ZMod L)-1=1 := by ring
  have entry (j : ZMod L) : centered R (mixed j) =
      (if j=0 then (-1:R) else 0) + (if j=2 then -1 else 0) := by
    simp only [mixed,incident,sub_self,two_sub]
    by_cases a : j=0 <;> by_cases b : j=1 <;> by_cases d : j=2 <;>
      simp_all [centered]
  simp only [cyclePair,entry,add_mul,Finset.sum_add_distrib,ite_mul,zero_mul,
    Finset.sum_ite_eq',Finset.mem_univ,if_true,neg_one_mul,alternating,ZMod.val_zero,
    pow_zero,two_val hL]
  ring

variable {Row Col : Type*}

def unitError (R : Type*) [CommRing R] [DecidableEq Col] (a : Col) : Col → R :=
  fun t => if t=a then 1 else 0

private def cert [DecidableEq Col] (γ : ZMod L → Col) (a : Col) : (Col → R) →ₗ[R] R where
  toFun v := cyclePair (fun j => v (γ j)) - 2*v a
  map_add' x y := by simp only [cyclePair,Pi.add_apply,add_mul,Finset.sum_add_distrib,mul_add]; ring
  map_smul' t x := by
    simp only [cyclePair,Pi.smul_apply,smul_eq_mul,RingHom.id_apply,mul_assoc,← Finset.mul_sum]
    ring

/-- Extra sites or rows are arbitrary. Restricted pairings and the one
private coefficient already separate the unit error from the full span. -/
theorem not_mem_xspan [DecidableEq Col] (h2 : (2:R)≠0) (γ : ZMod L → Col) (a : Col)
    (disjoint : ∀j,γ j≠a) (X : Row → Col → R) (r : Row)
    (target : cyclePair (fun j => X r (γ j)) = -2) (anc : X r a = -1)
    (other : ∀k,k≠r → cyclePair (fun j => X k (γ j))=0 ∧ X k a=0) :
    unitError R a ∉ Submodule.span R (Set.range X) := by
  let f := cert (R:=R) γ a
  have vanish (k : Row) : f (X k)=0 := by
    change cyclePair (fun j => X k (γ j)) - 2*X k a = 0
    by_cases eq : k=r
    · subst k; rw [target,anc]; ring
    · rw [(other k eq).1,(other k eq).2]; ring
  have hle : Submodule.span R (Set.range X) ≤ LinearMap.ker f :=
    Submodule.span_le.mpr (by rintro _ ⟨k,rfl⟩; exact vanish k)
  intro hin
  have e : f (unitError R a)=0 := hle hin
  change cyclePair (fun j => unitError R a (γ j)) - 2*unitError R a a=0 at e
  simp [cyclePair,unitError,disjoint] at e
  exact h2 e

variable {P T : Type*} [Fintype T] [DecidableEq T] [DecidableEq P]

/-- The centered binary CSS lift, including its recomputed systematic pivots. -/
def liftX (R : Type*) [CommRing R] (C : Row → T → Bool) (D : P → T → Bool)
    (r : Row) : P ⊕ T → R := Sum.elim
  (fun p => -(∑ t,centered R (C r t)*centered R (D p t))) (fun t => centered R (C r t))

def liftZ (R : Type*) [CommRing R] (D : P → T → Bool) (p : P) : P ⊕ T → R :=
  Sum.elim (fun q => if q=p then 1 else 0) (fun t => centered R (D p t))

omit [DecidableEq T] in
theorem lift_commutes [Fintype P] (C : Row → T → Bool) (D : P → T → Bool)
    (r : Row) (p : P) : ∑ t,liftX R C D r t * liftZ R D p t = 0 := by
  rw [Fintype.sum_sum_type]
  simp [liftX,liftZ,mul_ite]

/-- On an arbitrary systematic input whose nonpivot data include the cycle
pattern, the displayed lift has an undetectable single-site X outside the
row span. The other entries of both input matrices are unrestricted. -/
theorem systematic_logical [Fintype P] [DecidableEq R] (hL : 4≤L) (even : Even L) (h2 : (2:R)≠0)
    (C : Row → T → Bool) (D : P → T → Bool) (γ : ZMod L ↪ T) (a : T)
    (disjoint : ∀ j,γ j≠a) (r : Row) (mixed_row : ∀j,C r (γ j)=mixed j)
    (ordinary : ∀ k,k≠r → (∃ i,∀j,C k (γ j)=incident i j) ∨ (∀j,C k (γ j)=false))
    (a_mixed : C r a=true) (a_ordinary : ∀ k,k≠r → C k a=false) (a_z : ∀p,D p a=false) :
    unitError R (Sum.inr a) ∉ Submodule.span R (Set.range (liftX R C D)) ∧
    (∀p, ∑ t,unitError R (Sum.inr a) t * liftZ R D p t = 0) ∧
    ((Finset.univ : Finset (P ⊕ T)).filter (fun t => unitError R (Sum.inr a) t ≠ 0)).card=1 := by
  haveI : Nontrivial R := ⟨⟨2,0,h2⟩⟩
  refine ⟨?_,?_,?_⟩
  · apply not_mem_xspan h2 (fun j => Sum.inr (γ j)) (Sum.inr a)
      (fun j e => disjoint j (Sum.inr.inj e)) (liftX R C D) r
    · simpa only [liftX,Sum.elim_inr,mixed_row] using (mixed_pair (R:=R) hL)
    · simp [liftX,a_mixed,centered]
    · intro k hk
      refine ⟨?_,by simp [liftX,a_ordinary k hk,centered]⟩
      rcases ordinary k hk with ⟨i,hi⟩ | hz
      · simpa only [liftX,Sum.elim_inr,hi] using (ordinary_pair (R:=R) hL even i)
      · simp [liftX,hz,centered,cyclePair]
  · intro p; simp [liftZ,a_z p,centered,unitError]
  · have e : ((Finset.univ : Finset (P ⊕ T)).filter
        (fun t => unitError R (Sum.inr a) t ≠ 0)) = {Sum.inr a} := by
      ext t
      simp [unitError]
    rw [e,Finset.card_singleton]
#print axioms ordinary_pair
#print axioms mixed_pair
#print axioms systematic_logical
end
end CanonicalCycle
