"""Check the centered systematic CSS lift, Eq. (13) of arXiv:2610.15893, on even tori."""
from math import gcd
from twisted_audit import canonical, member
import sys


def systematic_binary(rows, pivots):
    matrix = [r.copy() for r in rows]
    for j, i in enumerate(pivots):
        k = next(k for k in range(j, len(matrix)) if matrix[k][i])
        matrix[j], matrix[k] = matrix[k], matrix[j]
        for k, row in enumerate(matrix):
            if k != j and row[i]:
                matrix[k] = [x ^ y for x, y in zip(row, matrix[j])]
    return matrix


def verify(L):
    assert L >= 4 and L % 2 == 0
    A, n = L*L, 2*L*L+1
    def h(i,j):
        return i % L + L*(j % L)
    def v(i,j):
        return A+h(i,j)
    def mark(s):
        return [int(i in s) for i in range(n)]
    stars = []
    faces = []
    for y in range(L):
        for x in range(L):
            if x or y:
                stars.append(mark([h(x,y),h(x-1,y),v(x,y),v(x,y-1)]))
                faces.append(mark([h(x,y),h(x,y+1),v(x,y),v(x+1,y)]))
    # The dual tree walks left inside each row, then down the first column:
    # cut the periodic seam y=0 to keep its horizontal data edges nonpivot.
    pivots = [v(x,y) for y in range(L) for x in range(1,L)] + [h(0,y) for y in range(1,L)]
    assert len(pivots)==A-1
    nonpivots = [j for j in range(n) if j not in pivots]
    order = pivots+nonpivots
    ix = {e:i for i,e in enumerate(order)}
    s = stars[0]
    t = stars[1]
    shared = [j for j in range(n) if s[j] and t[j]]
    assert shared == [h(1,0)] and shared[0] in nonpivots
    extra = [a^b^c for a,b,c in zip(s,t,mark([n-1]))]
    source_x = stars+[extra]
    source_z = systematic_binary(faces,pivots)
    # D and C below are precisely the centered (-1,0) nonpivot blocks.
    D = [[-r[j] for j in nonpivots] for r in source_z]
    C = [[-r[j] for j in nonpivots] for r in source_x]
    Z = [[int(j==i) for j in range(len(D))]+d for i,d in enumerate(D)]
    X = [[-sum(a*b for a,b in zip(c,d)) for d in D]+c for c in C]
    assert all(sum(a*b for a,b in zip(x,z))==0 for x in X for z in Z)
    assert all([a%2 for a in out] == [inp[j] for j in order] for inp,out in zip(source_x,X))
    assert all([a%2 for a in out] == [inp[j] for j in order] for inp,out in zip(source_z,Z))
    diag = [0]*n
    for j in range(L):
        diag[ix[h(j,0)]]=(-1)**j
    pairings = [sum(a*b for a,b in zip(row,diag)) for row in X]
    assert not any(pairings[:-1]) and abs(pairings[-1]) == 2
    anc = mark([ix[n-1]])
    assert all(sum(a*b for a,b in zip(anc,z)) == 0 for z in Z)
    assert all(x[ix[n-1]]==0 for x in X[:-1]) and X[-1][ix[n-1]]==-1
    for m in [2,3,4,5,6,7,8,9,12,101,65537]:
        bx,bz=canonical(X,m),canonical(Z,m)
        assert n-len(bx)-len(bz) == 2
        assert member(bx,anc,m) == (m==2)
    max_w=max(sum(bool(i) for i in row) for row in X+Z)
    max_v=max(sum(bool(row[j]) for row in X+Z) for j in range(n))
    max_a=max(abs(a) for row in X+Z for a in row)
    print(L,n,len(X),len(Z),pairings[-1],max_a,max_w,max_v)


if __name__ == '__main__':
    print("L n Xchecks Zchecks special_pairing B maxWeight maxDegree")
    for L in list(map(int,sys.argv[1:])) or [4,6,8,10]:
        verify(L)
