"""Independently audit sign-only toric-code lifts, using only Python's stdlib.

The seam form works for all L >= 3. The uniform, single-sided sign choice
works for odd L and agrees, up to face orientation, with the a=-1
Watanabe--Cheng--Fuji full-check model before dropping one star and face.
"""
from collections import deque
from math import gcd
import sys


def rows(length, uniform):
    """Return integer primal/dual checks, including the two rows to omit."""
    area = length ** 2
    def h(x, y):
        return (y % length) * length + x % length
    def v(x, y):
        return area + h(x, y)
    def sign(x):
        return -1 if x % length == length-1 else 1
    stars, faces = [], []
    for y in range(length):
        for x in range(length):
            star, face = [0] * (2*area), [0] * (2*area)
            # For a horizontal signed edge, the boundary is s(x)V(x+1,y)-V(x,y).
            star[h(x-1,y)] = 1 if uniform else sign(x-1)
            star[h(x,y)] = 1 if uniform else -1
            star[v(x,y-1)] = 1
            star[v(x,y)] = 1 if uniform else -1
            face[h(x,y)] = 1
            face[h(x,y+1)] = 1 if uniform else -1
            face[v(x+1,y)] = -1 if uniform else sign(x)
            face[v(x,y)] = -1
            stars.append(star)
            faces.append(face)
    return stars, faces


def canonical(rows, modulus):
    """Produce reduced pivots by units. Full independent unit pivots are required."""
    basis = [[a % modulus for a in v] for v in rows]
    pivots = []
    for i in range(len(rows[0])):
        r = len(pivots)
        candidate = next((j for j in range(r, len(rows)) if gcd(basis[j][i], modulus) == 1), None)
        if candidate is None:
            continue
        basis[r], basis[candidate] = basis[candidate], basis[r]
        inverse = pow(basis[r][i], -1, modulus)
        basis[r] = [(a * inverse) % modulus for a in basis[r]]
        for j in range(len(rows)):
            if j != r and basis[j][i]:
                coef = basis[j][i]
                basis[j] = [(a - coef*b) % modulus for a,b in zip(basis[j],basis[r])]
        pivots.append(i)
    assert len(pivots) == len(rows)
    return list(zip(pivots, basis))


def member(basis, test, m):
    v = test.copy()
    for c, row in basis:
        if v[c] % m:
            coef = v[c]
            v = [(a - coef*b) % m for a,b in zip(v,row)]
    return not any(a % m for a in v)


def support_graph_girth(full):
    # A word of smaller support is a forest. Since only one row was dropped,
    # it has a leaf with a remaining check and a unit-coefficient syndrome.
    adj = [[] for _ in full]
    for i in range(len(full[0])):
        ends = [j for j,row in enumerate(full) if row[i]]
        assert len(ends) == 2
        a,b = ends
        assert a != b and b not in adj[a]
        adj[a].append(b)
        adj[b].append(a)
    shortest = len(full)+1
    for initial in range(len(adj)):
        queue = deque([initial])
        depth = {initial: 0}
        parent = {initial: None}
        while queue:
            u = queue.popleft()
            for v in adj[u]:
                if v not in depth:
                    depth[v], parent[v] = depth[u]+1,u
                    queue.append(v)
                elif parent[u] != v and parent[v] != u:
                    shortest = min(shortest, depth[u]+depth[v]+1)
    return shortest


def run(length, uniform, mods):
    star, face = rows(length, uniform)
    size = 2*length**2
    assert all(sum(a*b for a,b in zip(x,z)) == 0 for x in star for z in face)
    for full in [star, face]:
        assert support_graph_girth(full) == min(length, 4)
        assert all(sum(abs(a) for a in row) == 4 for row in full)
    assert max(sum(bool(v[j]) for v in star[1:]+face[1:]) for j in range(size)) == 4
    for m in mods:
        bases = [canonical(terms[1:], m) for terms in (star, face)]
        assert size - sum(len(b) for b in bases) == 2
        for b,t in zip(bases,(star,face)):
            assert member(b,t[0],m) == (m == 2)
        # Pairwise commutation and omission give d_m <= 4; the girth proves
        # d_m >= min(L,4). At m=2 the checks have toric-code incidence.
    print(("uniform" if uniform else "seam"),length,size,','.join(map(str,mods)))


if __name__ == '__main__':
    print("form L physical-sites tested-moduli")
    for L in (list(map(int,sys.argv[1:])) or list(range(3,10))):
        assert L >= 3
        for variant in ([False,True] if L % 2 else [False]):
            run(L,variant,[2,3,4,5,6,7,8,9,12,101,65537])
