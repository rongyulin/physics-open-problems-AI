"""Recompute the finite witnesses using only Python's standard library."""
from itertools import combinations, product

def bracket(u, v, n):
    return sum(a*b-c*d for a, b, c, d in zip(u[:n], v[n:], u[n:], v[:n]))

def sum_rows(rows, coeffs, m):
    return tuple(sum(c*x for c,x in zip(coeffs,col)) % m for col in zip(*rows))

def finite_distance(rows, m, max_weight):
    n=len(rows[0])//2
    span={sum_rows(rows,c,m) for c in product(range(m),repeat=len(rows))}
    actions=[e for e in product(range(m),repeat=2) if any(e)]
    for w in range(1,max_weight+1):
        for sites in combinations(range(n),w):
            for local in product(actions,repeat=w):
                u=[0]*(2*n)
                for i,(x,z) in zip(sites,local):
                    u[i],u[i+n]=x,z
                if tuple(u) not in span and all(bracket(u,h,n)%m==0 for h in rows):
                    return w
    raise ValueError('no logical within the requested range')

def verify():
    # Five-site integer code.
    five=[
       [0]*5+[1,2,-2,0,0], [0,1,1,1,1]+[0]*5, [0]*5+[0,1,1,-1,-1]]
    assert all(bracket(a,b,5)==0 for a in five for b in five)
    assert [finite_distance(five,m,2) for m in (2,4)]==[2,1]
    print('Relative distances of the five-site code over F2 and Z/4: 2, 1.')

    # Seed is a genuinely binary canonical matrix. Apply the printed triangular rule.
    seven=[
       '1000001 0001010', '0100000 1010111', '0010000 0101100',
       '0001000 0010011','0000100 1110111','0000011 0000001']
    seed=[list(map(int,s.replace(' ',''))) for s in seven]
    H=[row.copy() for row in seed]
    for i in range(6):
        for j in range(i):
            H[i][7+j]+=bracket(seed[i],seed[j],7)
    assert all(bracket(a,b,7)==0 for a in H for b in H)
    assert finite_distance(seed,2,3)==3
    witness=[0,0,0,0,0,1,-1,0,0,0,0,0,-2,1]
    assert all(bracket(witness,row,7)==0 for row in H)
    assert witness[6]-H[-1][6]==-2
    for j in range(7):
        assert any(abs(a[j]*b[j+7]-b[j]*a[j+7])==1 for a,b in combinations(H,2))
    print('Triangular construction: binary distance 3; integral weight-two witness and unit site minors verified.')

    # Center the Eq. (13) tail blocks, then compute the pivot block over the integers.
    D=[[1,1,1,0,0],[1,1,0,1,0],[1,0,1,1,0]]
    C=D+[[0,0,1,1,1]]
    Z=[[int(i==j) for j in range(3)]+[-v for v in row] for i,row in enumerate(D)]
    X=[[-sum(t*u for t,u in zip(row,d)) for d in D]+[-v for v in row] for row in C]
    eight=[x+[0]*8 for x in X]+[[0]*8+z for z in Z]
    assert all(bracket(a,b,8)==0 for a in eight for b in eight)
    assert [finite_distance(eight,m,3) for m in (2,3,4)]==[3,1,1]
    print('Centered CSS construction: exact distances at dimensions 2, 3, 4 are 3, 1, 1.')

if __name__=='__main__':
    verify()
