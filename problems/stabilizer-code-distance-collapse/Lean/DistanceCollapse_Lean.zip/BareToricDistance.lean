import ToricDistance
import TwistedTorus

/-! On reduction mod two, even the model with sign holonomy has exactly the
usual square-torus distance on the physical edges, without any extra sites. -/
namespace BareToricDistance
open ToricDistance
open TwistedTorus (Edges)
variable {L : ℕ} [NeZero L]
abbrev E (L : ℕ) := Edges F L
def embed (x : E L) : C L := (x.1,x.2,0)
def weight (x z : E L) := pairOccupation x.1 z.1 + pairOccupation x.2 z.2

def Normal (x z : E L) : Prop :=
  (∀ u : G L, u 0 0=0 → TwistedTorus.dot (TwistedTorus.starCheck u) z=0) ∧
  ∀ b : G L, b 0 0=0 → TwistedTorus.dot x (TwistedTorus.faceCheck b)=0

def Stabilizer (x z : E L) : Prop :=
  (∃ u : G L, u 0 0=0 ∧ x=TwistedTorus.starCheck u) ∧
  ∃ b : G L, b 0 0=0 ∧ z=TwistedTorus.faceCheck b

private theorem two_zero : (2 : F)=0 := by decide
omit [NeZero L] in
private theorem sign_one (i : ZMod L) : TwistedTorus.sign F i = 1 := by
  simp [TwistedTorus.sign,show (-1:F)=1 by decide]

private theorem normal_iff (x z : E L) :
    Normal x z ↔ ToricDistance.Normal (embed x) (embed z) := by
  have star (u : G L) : TwistedTorus.dot (TwistedTorus.starCheck u) z =
      ToricLift.dot (ToricLift.xcheck u) (embed z) := by
    simp [TwistedTorus.dot,TwistedTorus.starCheck,ToricLift.dot,ToricLift.xcheck,embed,sign_one]
  have face (b : G L) (t : ZMod L → F) : TwistedTorus.dot x (TwistedTorus.faceCheck b) =
      ToricLift.dot (embed x) (ToricLift.zcheck b t) := by
    simp [TwistedTorus.dot,TwistedTorus.faceCheck,ToricLift.dot,ToricLift.zcheck,embed,sign_one,two_zero]
  constructor
  · intro h
    exact ⟨fun u hu => (star u).symm.trans (h.1 u hu),
           fun b t hb => (face b t).symm.trans (h.2 b hb)⟩
  · intro h
    exact ⟨fun u hu => (star u).trans (h.1 u hu),
           fun b hb => (face b 0).trans (h.2 b 0 hb)⟩

private theorem stabilizer_iff (x z : E L) :
    Stabilizer x z ↔ ToricDistance.Stabilizer (embed x) (embed z) := by
  have star (u : G L) : embed (TwistedTorus.starCheck u) = ToricLift.xcheck u := by
    simp [TwistedTorus.starCheck,ToricLift.xcheck,embed,sign_one,two_zero]
    rfl
  have face (b : G L) : embed (TwistedTorus.faceCheck b) = ToricLift.zcheck b 0 := by
    simp [TwistedTorus.faceCheck,ToricLift.zcheck,embed,sign_one,two_zero]
    rfl
  constructor
  · rintro ⟨⟨u,hu,rfl⟩,b,hb,rfl⟩
    exact ⟨⟨u,hu,star u⟩,b,0,hb,face b⟩
  · rintro ⟨⟨u,hu,he⟩,b,t,hb,hf⟩
    refine ⟨⟨u,hu,?_⟩,b,hb,?_⟩
    · rw [← star] at he
      exact congrArg (fun c : C L => (c.1,c.2.1)) he
    · have e := congrArg (fun c : C L => (c.1,c.2.1)) hf
      simpa only [embed,ToricLift.zcheck,TwistedTorus.faceCheck,sign_one,two_zero,zero_mul,
        ite_self,add_zero,one_mul,Prod.eta] using e

private theorem weight_eq (x z : E L) :
    ToricDistance.siteWeight (embed x) (embed z) = weight x z := by
  simp [ToricDistance.siteWeight,weight,embed]

theorem distance_lower (x z : E L) (hn : Normal x z) (hs : ¬ Stabilizer x z) :
    L ≤ weight x z := by
  rw [← weight_eq]
  exact ToricDistance.distance_lower _ _ ((normal_iff x z).mp hn) (hs ∘ (stabilizer_iff x z).mpr)

theorem distance_attained : ∃ x z : E L, Normal x z ∧ ¬ Stabilizer x z ∧ weight x z=L := by
  obtain ⟨h,v,hc,hn,hw⟩ := ToricBinary.sharp (L := L)
  let x : E L := (0,0)
  let z : E L := (h,v)
  refine ⟨x,z,(normal_iff x z).mpr <| ToricDistance.cycles_to_normal _ _ hc (by intro i j; simp [embed,x]) rfl,?_,?_⟩
  · rintro ⟨_,b,_,he⟩
    apply hn
    refine ⟨b,?_,?_⟩
    · intro i j
      exact congrArg (fun e : E L => e.1 i j) he
    · intro i j
      simpa [z,TwistedTorus.faceCheck,sign_one] using congrArg (fun e : E L => e.2 i j) he
  · simpa [weight,pairOccupation,x,z,ToricBinary.weight,ToricBinary.occupation] using hw

#print axioms distance_lower
#print axioms distance_attained
end BareToricDistance
