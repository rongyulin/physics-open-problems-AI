import TwistedTorus
import ToricDistance
import ShortCycles

/-! The binary reduction of the signed and pinned checks has the ordinary
closed and coclosed conditions, including the constraints at the omitted pin. -/
namespace TwistedBinary
open TwistedTorus
open scoped BigOperators
variable {L : ℕ} [NeZero L]
local notation "F" => ZMod 2

theorem sign_two (i : ZMod L) : sign F i = 1 := by
  unfold sign
  split
  · decide
  · rfl

def Normal (x z : Edges F L) : Prop :=
  (∀ u : ToricLift.Grid F L, u 0 0=0 → dot (starCheck u) z=0) ∧
  (∀ f : ToricLift.Grid F L, f 0 0=0 → dot x (faceCheck f)=0)

theorem normal_cycles (x z : Edges F L) (hn : Normal x z) :
    ToricBinary.Closed z.1 z.2 ∧ ToricBinary.Coclosed x.1 x.2 := by
  let X : ToricDistance.C L := (x.1,x.2,0)
  let Z : ToricDistance.C L := (z.1,z.2,0)
  have two : (2:F)=0 := by decide
  have normal : ToricDistance.Normal X Z := by
    constructor
    · intro u hu
      have h := hn.1 u hu
      simpa [ToricLift.dot,ToricLift.xcheck,X,Z,dot,starCheck,sign_two,two] using h
    · intro f t hf
      have h := hn.2 f hf
      simpa [ToricLift.dot,ToricLift.zcheck,X,Z,dot,faceCheck,sign_two,two] using h
  obtain ⟨h1,h2,_⟩ := ToricDistance.normal_to_cycles X Z normal
  exact ⟨h1,h2⟩

theorem small_none (hL : 4≤L) (x z : Edges F L) (hn : Normal x z)
    (sx : ToricBinary.weight x.1 x.2 < 4) (sz : ToricBinary.weight z.1 z.2 < 4) :
    x = 0 ∧ z=0 := by
  obtain ⟨zc,xc⟩ := normal_cycles x z hn
  have hz := mt (ToricBinary.closed_weight_four z.1 z.2 hL zc) (not_le.mpr sz)
  have hx := mt (ToricBinary.coclosed_weight_four x.1 x.2 hL xc) (not_le.mpr sx)
  push_neg at hx hz
  exact ⟨Prod.ext hx.1 hx.2,Prod.ext hz.1 hz.2⟩

#print axioms small_none
end TwistedBinary
