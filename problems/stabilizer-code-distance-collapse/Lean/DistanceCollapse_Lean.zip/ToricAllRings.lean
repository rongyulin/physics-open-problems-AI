import ToricIncidence
import SignedIncidence
import TwistedWitness

/-! Full site-weight lower bound on the square lattice for all cyclic dimensions. -/
namespace ToricAllRings
open ToricIncidence TwistedTorus TwistedCode
variable {L : ℕ} [NeZero L]

theorem normalizer_lower {R : Type*} [CommRing R] [DecidableEq R]
    (hL : 4≤L) (u : State R L) (hn : Normal u) (un : u≠0) : 4≤stateWeight u := by
  classical
  letI : Nontrivial (ZMod L) := ZMod.nontrivial_iff.2 (by omega)
  obtain ⟨f,nonzero⟩ : ∃ f,sample f u ≠ 0 := by
    by_contra! no
    apply un
    funext e
    exact Prod.ext (congrFun (no true) e) (congrFun (no false) e)
  obtain ⟨y,ny,sub,hy⟩ := SignedIncidence.kernel_transfer
    (incidence f) (coeff R f) (at_most_two f) (unit_entry f) (outside f)
    (sample f u) nonzero (point_orthogonal f u hn)
  have emb : embed f y ≠ 0 := by
    intro eq
    apply ny
    funext e
    have at_e := congrFun eq e
    cases f <;> simpa [embed] using at_e
  have le : stateWeight (embed f y) ≤ stateWeight u := by
    apply Finset.card_le_card
    intro e he
    refine Finset.mem_filter.mpr ⟨Finset.mem_univ _,?_⟩
    intro zero
    have cut := sub e (by cases f <;> simp [sample,zero])
    apply (Finset.mem_filter.mp he).2
    cases f <;> simp [embed,cut]
  by_contra! small
  exact emb (TwistedLower.binary_lower _ hL (binary_embed_normal f y hy) (le.trans_lt small))

#print axioms normalizer_lower
end ToricAllRings
