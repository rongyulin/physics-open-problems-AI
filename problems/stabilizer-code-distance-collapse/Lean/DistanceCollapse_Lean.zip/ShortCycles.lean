import ToricBinary

/-! A nonempty closed edge chain on the periodic square lattice has at least
four edges as soon as both periods are at least four. -/
namespace ToricBinary
open scoped BigOperators
variable {L : ℕ} [NeZero L]

private theorem shift_sum (f : ZMod L → ZMod 2) :
    (∑ j, f (j+1)) = ∑ j, f j :=
  Equiv.sum_comp (Equiv.addRight (1:ZMod L)) f

private theorem zero_of_single_support (h : Grid L) (small : occupation h ≤ 1)
    (ht : ∑ q : ZMod L × ZMod L, h q.1 q.2 = 0) : h = 0 := by
  classical
  funext i j
  change h i j = 0
  by_contra hne
  have ed (q : ZMod L × ZMod L) (hq : q≠(i,j)) : h q.1 q.2 = 0 := by
    by_contra hq'
    have hbound := Finset.card_le_one.mp small
    exact hq (hbound q (Finset.mem_filter.mpr ⟨Finset.mem_univ _,hq'⟩) (i,j)
      (Finset.mem_filter.mpr ⟨Finset.mem_univ _,hne⟩))
  have ee : (∑ q : ZMod L × ZMod L, h q.1 q.2) = h i j :=
    Finset.sum_eq_single (i,j) (fun q _ hq => ed q hq) (by simp)
  exact hne (ee.symm.trans ht)

private theorem eq_at_zero (f : ZMod L → ZMod 2) (step : ∀x,f (x+1)=f x) (x : ZMod L) :
    f x=f 0 := by
  have h (j : ℕ) : f (j:ZMod L)=f 0 := by
    induction j with
    | zero => simp
    | succ j ih => rw [Nat.cast_succ,step,ih]
  simpa using h x.val

private theorem occupied_line (g : Grid L) (inj : ZMod L → ZMod L × ZMod L)
    (hinj : Function.Injective inj) (full : ∀ t,g (inj t).1 (inj t).2≠0) :
    L ≤ occupation g := by
  have h := Finset.card_le_card_of_injOn (s := (Finset.univ : Finset (ZMod L)))
    (t := (Finset.univ : Finset (ZMod L × ZMod L)).filter (fun q=>g q.1 q.2≠0)) inj
    (fun t _ => Finset.mem_filter.mpr ⟨Finset.mem_univ _,full t⟩) hinj.injOn
  simpa [occupation] using h

/-- The binary centralizer contains no nonidentity error of weight below four,
including stabilizers. -/
theorem closed_weight_four (h v : Grid L) (hL : 4≤L) (hc : Closed h v) (hn : h≠0 ∨ v≠0) :
    4≤weight h v := by
  by_contra! small
  obtain ⟨f,hf,vf⟩ := low_weight_boundary h v hc (by omega)
  have hsum : ∑ q : ZMod L × ZMod L, h q.1 q.2=0 := by
    rw [Fintype.sum_prod_type]
    simp_rw [hf,Finset.sum_sub_distrib,shift_sum,sub_self]
  have vsum : ∑ q : ZMod L × ZMod L, v q.1 q.2=0 := by
    rw [Fintype.sum_prod_type,Finset.sum_comm]
    have shift (j : ZMod L) : (∑ i,f (i+1) j) = ∑ i,f i j := shift_sum (fun i=>f i j)
    simp only [vf,Finset.sum_sub_distrib,shift,sub_self,Finset.sum_const_zero]
  unfold weight at small
  have low : occupation h≤1 ∨ occupation v≤1 := by omega
  rcases low with lh|lv
  · have eh := zero_of_single_support h lh hsum
    have nv : v≠0 := hn.resolve_left (not_not.mpr eh)
    obtain ⟨i,j,ne⟩ : ∃ i j, v i j≠0 := by
      by_contra! e
      exact nv (funext fun i => funext fun j => e i j)
    have step (t : ZMod L) : v i (t+1)=v i t := by
      have e := hc i t
      rw [eh] at e
      simpa [sub_eq_zero] using e
    have line := occupied_line v (fun t=>(i,t)) (fun _ _ he=>congrArg Prod.snd he) (fun t => by
      change v i t ≠ 0
      rwa [(eq_at_zero (v i) step t).trans (eq_at_zero (v i) step j).symm])
    omega
  · have ev := zero_of_single_support v lv vsum
    have nh : h≠0 := hn.resolve_right (not_not.mpr ev)
    obtain ⟨i,j,ne⟩ : ∃ i j, h i j≠0 := by
      by_contra! e
      exact nh (funext fun i => funext fun j => e i j)
    have step (t : ZMod L) : h (t+1) j=h t j := by
      have e := hc t j
      rw [ev] at e
      simpa [sub_eq_zero] using e
    have line := occupied_line h (fun t=>(t,j)) (fun _ _ he=>congrArg Prod.fst he) (fun t => by
      change h t j ≠ 0
      rwa [(eq_at_zero (fun p=>h p j) step t).trans (eq_at_zero (fun p=>h p j) step i).symm])
    omega

/-- The dual square lattice has the same four-edge lower bound. -/
theorem coclosed_weight_four (h v : Grid L) (hL : 4≤L) (hc : Coclosed h v)
    (hn : h≠0 ∨ v≠0) : 4≤weight h v := by
  let h' : Grid L := fun i j => -v (-i) (-j)
  let v' : Grid L := fun i j => h (-i) (-j)
  have he (i : ZMod L) : -(i+1) = -i-1 := by abel
  have hc' : Closed h' v' := by
    intro i j
    dsimp [h',v']
    rw [he i,he j]
    linear_combination hc (-i) (-j)
  have hn' : h'≠0 ∨ v'≠0 := by
    contrapose! hn
    constructor <;> funext i j
    · have e := congrFun (congrFun hn.2 (-i)) (-j)
      simpa [v'] using e
    · have e := congrFun (congrFun hn.1 (-i)) (-j)
      simpa [h'] using e
  have oh : occupation h'=occupation v := by
    calc
      _ = occupation (fun i j => v (-i) (-j)) := by simp [occupation,h']
      _ = _ := occupation_reverse _
  have ov : occupation v'=occupation h := occupation_reverse _
  simpa [weight,oh,ov,Nat.add_comm] using closed_weight_four h' v' hL hc' hn'

#print axioms closed_weight_four
#print axioms coclosed_weight_four
end ToricBinary
