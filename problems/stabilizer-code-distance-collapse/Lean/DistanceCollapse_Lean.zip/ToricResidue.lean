import Mathlib

/-! A binary zero-weight exclusion transfers to any lifts of its check
generators on the same sites over Z/4. -/
namespace ToricResidue
open scoped BigOperators
noncomputable section
variable {J : Type*} [Fintype J] [DecidableEq J]
abbrev State (R : Type*) (J : Type*) := J → R × R
def form {R : Type*} [CommRing R] (x y : State R J) :=
  ∑ s, ((x s).1*(y s).2 - (x s).2*(y s).1)
def weight {R : Type*} [Zero R] [DecidableEq R] (x : State R J) : ℕ :=
  (Finset.univ.filter (fun s => x s≠0)).card

def red : ZMod 4 →+* ZMod 2 := ZMod.castHom (by decide) _
def reduce (x : State (ZMod 4) J) : State (ZMod 2) J := fun i => (red (x i).1,red (x i).2)
private def half (r : ZMod 4) : ZMod 4 := (r.val/2 : ℕ)
private def halves (x : State (ZMod 4) J) : State (ZMod 4) J :=
  fun s => (half (x s).1,half (x s).2)

theorem reduce_form (x y : State (ZMod 4) J) :
    red (form x y)=form (reduce x) (reduce y) := by
  simp only [form,reduce,map_sum,map_sub,map_mul]

private theorem form_twice (x y : State (ZMod 4) J) :
    form ((2:ZMod 4) • x) y=2*form x y := by
  simp only [form,Pi.smul_apply,Prod.smul_fst,Prod.smul_snd,smul_eq_mul,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro _ _
  ring

private theorem card_le_of_zero {R T : Type*} [Zero R] [Zero T] [DecidableEq R] [DecidableEq T]
    (x : State R J) (y : State T J) (hy : ∀ s,x s=0 → y s=0) : weight y≤weight x := by
  apply Finset.card_le_card
  intro s hs
  exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,mt (hy s) (Finset.mem_filter.mp hs).2⟩

/-- The hypotheses only require a lift of every binary check. They hold for
a set of generators or for the entire check module. -/
theorem lower_of_binary {A : Set (State (ZMod 4) J)} {B : Set (State (ZMod 2) J)} {k : ℕ}
    (checks : ∀ b∈B,∃ a∈A,reduce a=b)
    (binary : ∀ u : State (ZMod 2) J, (∀ b∈B,form u b=0) → weight u<k → u=0)
    (x : State (ZMod 4) J) (comm : ∀ a∈A,form x a=0) (sm : weight x<k) : x=0 := by
  have w₁ : weight (reduce x)≤weight x :=
    card_le_of_zero _ _ (fun s h => by simp [reduce,h])
  have rzero : reduce x=0 := by
    apply binary _ _ (w₁.trans_lt sm)
    intro b hb
    obtain ⟨a,ha,rfl⟩ := checks b hb
    rw [←reduce_form,comm a ha,map_zero]
  have halves_ok : ∀ s : ZMod 4, red s=0 → 2*half s=s := by decide
  have rebuild : (2:ZMod 4) • halves x = x := by
    funext j
    apply Prod.ext
    · exact halves_ok _ (congrArg (fun h : State (ZMod 2) J => (h j).1) rzero)
    · exact halves_ok _ (congrArg (fun h : State (ZMod 2) J => (h j).2) rzero)
  have w₂ : weight (reduce (halves x))≤weight x :=
    card_le_of_zero _ _ (fun s h => by simp [reduce,halves,half,h])
  have rz : reduce (halves x)=0 := by
    apply binary _ _ (w₂.trans_lt sm)
    intro b hb
    obtain ⟨a,ha,rfl⟩ := checks b hb
    rw [←reduce_form]
    have socle : ∀ s : ZMod 4, 2*s=0 → red s=0 := by decide
    apply socle
    rw [←form_twice,rebuild,comm a ha]
  have last : ∀ s : ZMod 4, red s=0 → red (half s)=0 → s=0 := by decide
  funext s
  apply Prod.ext
  · exact last _ (congrArg (fun z : State (ZMod 2) J => (z s).1) rzero)
      (congrArg (fun z : State (ZMod 2) J => (z s).1) rz)
  · exact last _ (congrArg (fun z : State (ZMod 2) J => (z s).2) rzero)
      (congrArg (fun z : State (ZMod 2) J => (z s).2) rz)
#print axioms lower_of_binary
end
end ToricResidue
