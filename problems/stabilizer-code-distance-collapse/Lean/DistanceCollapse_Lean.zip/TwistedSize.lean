import TwistedCode

namespace TwistedCode
variable {L : ℕ} [NeZero L]

theorem physical_sites : Fintype.card (Site L)=2*L^2 := by
  simp [Site,pow_two]

theorem punctures : Fintype.card (pinSet L)=L^2-1 := by
  simp [pinSet,Fintype.card_subtype_compl,pow_two]

theorem subgroup_size (R : Type*) [CommRing R] [Fintype R] :
    Nat.card (C R L)= (Fintype.card R)^(2*(L^2-1)) := by
  rw [← Nat.card_congr (freeBasis (R:=R) (L:=L)).toEquiv]
  simp [Inputs,Nat.card_eq_fintype_card,pow_mul]
  rw [← pow_mul,← pow_mul,pow_two L,Nat.mul_comm _ 2]
#print axioms subgroup_size
end TwistedCode
