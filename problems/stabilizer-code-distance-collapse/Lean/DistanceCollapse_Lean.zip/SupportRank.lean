import PauliBasic

/-! Exact erasure formula for the number of independent logical Pauli labels
that have a representative inside a prescribed site set, over any field. -/
namespace CyclicPauli.SupportRank
open Module Submodule
open scoped BigOperators
variable {K : Type*} [Field K] {n : ℕ}
abbrev Local (K : Type*) {n : ℕ} (S : Finset (Fin n)) := S → K × K

def restriction (S : Finset (Fin n)) : Labels K n →ₗ[K] Local K S where
  toFun x i := x i
  map_add' _ _ := rfl
  map_smul' _ _ := rfl

def extend (S : Finset (Fin n)) : Local K S →ₗ[K] Labels K n where
  toFun x i := if hi : i∈S then x ⟨i,hi⟩ else 0
  map_add' x y := by ext i <;> by_cases h : i∈S <;> simp [h]
  map_smul' r x := by ext i <;> by_cases h : i∈S <;> simp [h]

@[simp] theorem restrict_extend (S : Finset (Fin n)) (x : Local K S) :
    restriction S (extend S x)=x := by
  ext i <;> simp [restriction,extend,i.property]

theorem extend_supported (S : Finset (Fin n)) (x : Local K S) : supported S (extend S x) := by
  intro i hi
  simp [extend,hi]

theorem restore_supported (S : Finset (Fin n)) (x : Labels K n) (hx : supported S x) :
    extend S (restriction S x)=x := by
  funext i
  by_cases h : i∈S
  · simp [extend,restriction,h]
  · simp [extend,h,hx i h]

def restrictedChecks (S : Finset (Fin n)) (D : Submodule K (Labels K n)) :
    D →ₗ[K] Local K S := (restriction S).comp D.subtype

noncomputable def rankOn (S : Finset (Fin n)) (D : Submodule K (Labels K n)) : ℕ :=
  finrank K (restrictedChecks S D).range

def localPair (S : Finset (Fin n)) : LinearMap.BilinForm K (Local K S) :=
  LinearMap.mk₂ K (fun x y => ∑ i, ((x i).1*(y i).2-(x i).2*(y i).1))
    (by intro x y z; simp only [Pi.add_apply,Prod.fst_add,Prod.snd_add,←Finset.sum_add_distrib]
        apply Finset.sum_congr rfl; intro i _; ring)
    (by intro a x z; simp only [Pi.smul_apply,Prod.smul_fst,Prod.smul_snd,smul_eq_mul,Finset.mul_sum]
        apply Finset.sum_congr rfl; intro i _; ring)
    (by intro x y z; simp only [Pi.add_apply,Prod.fst_add,Prod.snd_add,←Finset.sum_add_distrib]
        apply Finset.sum_congr rfl; intro i _; ring)
    (by intro a x z; simp only [Pi.smul_apply,Prod.smul_fst,Prod.smul_snd,smul_eq_mul,Finset.mul_sum]
        apply Finset.sum_congr rfl; intro i _; ring)

private theorem local_alt (S : Finset (Fin n)) : (localPair (K:=K) S).IsAlt := by
  intro x
  change (∑ i, ((x i).1*(x i).2-(x i).2*(x i).1))=0
  exact Finset.sum_eq_zero fun i _ => by ring

private theorem local_nondegenerate (S : Finset (Fin n)) :
    (localPair (K:=K) S).Nondegenerate := by
  apply LinearMap.BilinForm.Nondegenerate.ofSeparatingLeft
  intro x hx
  have atom (i : S) (a : K×K) :
      localPair S x (Pi.single i a) = (x i).1*a.2-(x i).2*a.1 := by
    change (∑ j, ((x j).1*((Pi.single i a : Local K S) j).2-(x j).2*((Pi.single i a : Local K S) j).1))=_
    rw [Finset.sum_eq_single i]
    · simp
    · intro j _ hji
      simp [Pi.single_eq_of_ne hji]
    · simp
  funext i
  apply Prod.ext
  · simpa only [atom, mul_one, mul_zero, sub_zero] using hx (Pi.single i (0,1))
  · simpa only [atom, mul_zero, mul_one, zero_sub,neg_eq_zero] using hx (Pi.single i (1,0))

/-- Independent check labels supported entirely on S, as local Pauli coordinates. -/
def localStabilizer (S : Finset (Fin n)) (D : Submodule K (Labels K n)) :
    Submodule K (Local K S) := D.comap (extend S)

/-- Local labels whose extension commutes with all checks. -/
def localNormalizer (S : Finset (Fin n)) (D : Submodule K (Labels K n)) :
    Submodule K (Local K S) := (localPair S).orthogonal (restrictedChecks S D).range

theorem bracket_extend (S : Finset (Fin n)) (x : Labels K n) (y : Local K S) :
    bracket x (extend S y) = localPair S (restriction S x) y := by
  let f := fun i => (x i).1*(extend S y i).2-(x i).2*(extend S y i).1
  change (∑ i, f i) = ∑ i : S, ((x i).1*(y i).2-(x i).2*(y i).1)
  calc
    _ = ∑ i ∈ S, f i := (Finset.sum_subset (Finset.subset_univ S)
      (fun i _ hi => by simp [f,extend,hi])).symm
    _ = _ := by
      rw [←Finset.sum_attach S]
      apply Finset.sum_congr rfl
      intro i _
      simp [f,extend,i.property]

theorem mem_localNormalizer_iff (S : Finset (Fin n)) (D : Submodule K (Labels K n))
    (x : Local K S) : x∈localNormalizer S D ↔ ∀ y∈D, bracket y (extend S x)=0 := by
  constructor
  · intro h y hy
    rw [bracket_extend]
    exact h _ ⟨⟨y,hy⟩,rfl⟩
  · intro h y hy
    obtain ⟨v,rfl⟩ := hy
    exact (bracket_extend S v x).symm.trans (h v v.property)

theorem stabilizer_le_normalizer (S : Finset (Fin n)) (D : Submodule K (Labels K n))
    (hi : Isotropic D) : localStabilizer S D ≤ localNormalizer S D := by
  intro x hx
  exact (mem_localNormalizer_iff S D x).mpr (fun y hy => hi _ hy _ hx)

/-- Quotient by local stabilizers identifies representatives with the same logical action. -/
abbrev Logical (S : Finset (Fin n)) (D : Submodule K (Labels K n)) :=
  (localNormalizer S D) ⧸ ((localStabilizer S D).comap (localNormalizer S D).subtype)

noncomputable def supportedKernelEquiv (S : Finset (Fin n)) (D : Submodule K (Labels K n)) :
    localStabilizer S D ≃ₗ[K] (restrictedChecks Sᶜ D).ker where
  toFun x := ⟨⟨extend S x,x.property⟩,by
    ext i <;> simp [restrictedChecks,restriction,extend,
      Finset.mem_compl.mp i.property]⟩
  invFun x := ⟨restriction S x.1.1,by
    have z : supported S x.1.1 := by
      intro i hi
      exact congrFun x.property ⟨i,Finset.mem_compl.mpr hi⟩
    change extend S (restriction S x.1.1)∈D
    rw [restore_supported _ _ z]
    exact x.1.2⟩
  left_inv x := Subtype.ext (restrict_extend S (x : Local K S))
  right_inv x := by
    apply Subtype.ext
    apply Subtype.ext
    apply restore_supported
    intro i hi
    exact congrFun x.property ⟨i,Finset.mem_compl.mpr hi⟩
  map_add' _ _ := Subtype.ext <| Subtype.ext <| (extend S).map_add _ _
  map_smul' _ _ := Subtype.ext <| Subtype.ext <| (extend S).map_smul _ _

/-- Exact support rank formula, stated additively to avoid natural subtraction.
The rank of the complementary restriction is required in the degenerate case. -/
theorem support_rank (S : Finset (Fin n)) (D : Submodule K (Labels K n)) (hi : Isotropic D) :
    finrank K (Logical S D) + rankOn S D + finrank K D = 2*S.card + rankOn Sᶜ D := by
  have ort := LinearMap.BilinForm.finrank_add_finrank_orthogonal (local_alt (K:=K) S).isRefl
    (restrictedChecks S D).range
  rw [(localPair (K:=K) S).orthogonal_top_eq_bot (local_nondegenerate (K:=K) S) (local_alt (K:=K) S).isRefl,
    inf_bot_eq,finrank_bot,add_zero] at ort
  have dimlocal : finrank K (Local K S) = 2*S.card := by
    simp [Local,Module.finrank_pi_fintype,Module.finrank_prod,Nat.mul_comm]
  rw [dimlocal] at ort
  change rankOn S D + finrank K (localNormalizer S D) = 2*S.card at ort
  have nu := (restrictedChecks Sᶜ D).finrank_range_add_finrank_ker
  rw [←(supportedKernelEquiv S D).finrank_eq] at nu
  change rankOn Sᶜ D + finrank K (localStabilizer S D)=finrank K D at nu
  have q := ((localStabilizer S D).comap (localNormalizer S D).subtype).finrank_quotient_add_finrank
  rw [(Submodule.comapSubtypeEquivOfLe (stabilizer_le_normalizer S D hi)).finrank_eq] at q
  change finrank K (Logical S D)+finrank K (localStabilizer S D)=finrank K (localNormalizer S D) at q
  omega

/-- Positive quotient dimension is equivalent to a physical logical Pauli supported on S. -/
theorem logical_exists_iff (S : Finset (Fin n)) (D : Submodule K (Labels K n)) :
    0 < finrank K (Logical S D) ↔
      ∃ x : Labels K n, supported S x ∧ (∀ y∈D, bracket y x=0) ∧ x∉D := by
  let W := (localStabilizer S D).comap (localNormalizer S D).subtype
  rw [Module.finrank_pos_iff_exists_ne_zero]
  constructor
  · rintro ⟨z,hz⟩
    obtain ⟨u, rfl⟩ := W.mkQ_surjective z
    refine ⟨extend S u,extend_supported S _,(mem_localNormalizer_iff S D u).mp u.property,?_⟩
    intro hu
    exact hz ((Submodule.Quotient.mk_eq_zero W).mpr hu)
  · rintro ⟨x,hx,hcomm,hnot⟩
    have e := restore_supported S x hx
    have hm : restriction S x∈localNormalizer S D := by
      rw [mem_localNormalizer_iff]
      simpa only [e] using hcomm
    let u : localNormalizer S D := ⟨restriction S x,hm⟩
    refine ⟨W.mkQ u,?_⟩
    intro hzero
    have hmem := (Submodule.Quotient.mk_eq_zero W).mp hzero
    change extend S (restriction S x)∈D at hmem
    exact hnot (e ▸ hmem)

#print axioms support_rank
#print axioms logical_exists_iff
end CyclicPauli.SupportRank
