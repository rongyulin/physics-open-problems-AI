import PrescribedDefs

namespace PrescribedLDI
open CyclicPauli FrobeniusCounterexample
set_option maxHeartbeats 0

theorem enc_cast (R : Type*) [CommRing R] (c : Row→ℤ) (i : Site) :
    enc (fun a => (c a:R)) i = (((enc c i).1:R),((enc c i).2:R)) := by
  fin_cases i <;> simp [enc]

/-- The checks used over every target ring are the coefficientwise images
of exactly the integers produced by the prescribed binary lift. -/
theorem change_ring (R : Type*) [CommRing R] (g : Row) (i : Site) :
    rowR (R:=R) g i = (((recipe raw g i).1:R),((recipe raw g i).2:R)) := by
  rw [prescribed.2.2 g i]
  rw [← integer_matrix g i]
  have single_cast : (Pi.single g 1 : Row→R) = fun a : Row => (((Pi.single g 1 : Row→ℤ) a):R) := by
    funext a
    by_cases h : a=g <;> simp [Pi.single_apply,h]
  unfold rowR
  rw [single_cast]
  exact enc_cast R _ i

noncomputable def freeBasis (R : Type*) [CommRing R] : (Row→R) ≃ₗ[R] code R :=
  LinearEquiv.ofInjective (encoder R) independent

theorem free (R : Type*) [CommRing R] : Module.Free R (code R) :=
  Module.Free.of_equiv (freeBasis R)

theorem binary_degenerate : short (ZMod 2)∈code (ZMod 2) ∧ wt (short (ZMod 2))=2 := by
  refine ⟨⟨Pi.single (5:Row) 1,?_⟩,short_weight _⟩
  decide +kernel

#print axioms change_ring
#print axioms binary_degenerate
end PrescribedLDI
