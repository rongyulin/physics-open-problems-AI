import TwistedLower

/-! The signed CSS layers have at most two unit entries per site. A binary
kernel on any one layer embeds into the physical binary toric normalizer. -/
namespace ToricIncidence
open TwistedTorus TwistedCode
open scoped BigOperators
variable {L : ℕ} [NeZero L] {R : Type*} [CommRing R]

def fromV (face : Bool) : Site L → ZMod L × ZMod L
  | (false,i,j) => if face then (i,j+1) else (i-1,j)
  | (true,i,j) => if face then (i,j) else (i,j-1)

def toV (face : Bool) : Site L → ZMod L × ZMod L
  | (false,i,j) => (i,j)
  | (true,i,j) => if face then (i+1,j) else (i,j)

def g₁ (R : Type*) [CommRing R] (face : Bool) : Site L → R
  | (false,i,_) => if face then 1 else sign R (i-1)
  | (true,_,_) => 1

def g₂ (R : Type*) [CommRing R] (face : Bool) : Site L → R
  | (false,_,_) => -1
  | (true,i,_) => if face then -sign R i else -1

def incidence (f : Bool) (e : Site L) : Finset (pinSet L) :=
  Finset.univ.filter fun v => v.val = fromV f e ∨ v.val = toV f e

def coeff (R : Type*) [CommRing R] (f : Bool) (v : pinSet L) (e : Site L) : R :=
  (if v.val = fromV f e then g₁ R f e else 0) + (if v.val = toV f e then g₂ R f e else 0)

theorem at_most_two (f : Bool) (e : Site L) : (incidence f e).card ≤ 2 := by
  let t : Finset (ZMod L × ZMod L) := {fromV f e, toV f e}
  have inj := Finset.card_le_card_of_injOn (s:=incidence f e) (t:=t)
    (fun v : pinSet L => v.val) (fun v hv => by simpa [incidence,t] using hv)
    (fun _ _ _ _ h => Subtype.ext h)
  exact inj.trans (Finset.card_le_two)

theorem outside (f : Bool) (v : pinSet L) (e : Site L) (h : v∉incidence f e) : coeff R f v e=0 := by
  simp [incidence] at h
  simp [coeff,h.1,h.2]

omit [NeZero L] in
theorem distinct_ends [Nontrivial (ZMod L)] (f : Bool) (e : Site L) : fromV f e ≠ toV f e := by
  rcases e with ⟨s,i,j⟩
  cases f <;> cases s <;> simp [fromV,toV,sub_eq_self]

theorem unit_entry [Nontrivial (ZMod L)] (f : Bool) (v : pinSet L) (e : Site L)
    (h : v∈incidence f e) : IsUnit (coeff R f v e) := by
  have d := distinct_ends f e
  have u₁ : IsUnit (g₁ R f e) := by
    rcases e with ⟨s,i,j⟩
    cases f <;> cases s <;> simp [g₁,sign]
    split <;> simp
  have u₂ : IsUnit (g₂ R f e) := by
    rcases e with ⟨s,i,j⟩
    cases f <;> cases s <;> simp [g₂,sign]
    split <;> simp
  rcases (Finset.mem_filter.mp h).2 with h|h
  · simpa [coeff,h,d] using u₁
  · simpa [coeff,h,Ne.symm d] using u₂

def elem (p : pinSet L) : pinSet L → R := fun q => if q=p then 1 else 0

def read (f : Bool) (a : pinSet L → R) : Site L → R
  | (false,i,j) => if f then (faceCheck (pin a)).1 i j else (starCheck (pin a)).1 i j
  | (true,i,j) => if f then (faceCheck (pin a)).2 i j else (starCheck (pin a)).2 i j

def sample (f : Bool) (u : State R L) (e : Site L) : R :=
  if f then (u e).1 else (u e).2

private theorem pdelta (p : pinSet L) (i j : ZMod L) :
    pin (elem (R:=R) p) i j = if p.val=(i,j) then 1 else 0 := by
  by_cases h : (i,j)=(0,0)
  · rw [pin,dif_pos h,if_neg (fun eq => p.property (eq.trans h))]
  · by_cases hp : p.val=(i,j)
    · have eq : (⟨(i,j),h⟩ : pinSet L) = p := Subtype.ext hp.symm
      simp [pin,h,elem,eq,hp]
    · have ne : (⟨(i,j),h⟩ : pinSet L) ≠ p := fun e => hp (congrArg Subtype.val e).symm
      simp [pin,h,elem,ne,hp]

theorem incidence_row (f : Bool) (p : pinSet L) (e : Site L) :
    read f (elem (R:=R) p) e = coeff R f p e := by
  rcases e with ⟨s,i,j⟩
  cases f <;> cases s <;> simp only [read,faceCheck,starCheck,pdelta,coeff,fromV,toV,g₁,g₂,
    Bool.false_eq_true,if_false,if_true]
  all_goals split_ifs <;> ring

theorem point_orthogonal (f : Bool) (u : State R L) (hn : Normal u) (p : pinSet L) :
    ∑ e, coeff R f p e * sample f u e = 0 := by
  simp_rw [←incidence_row]
  cases f
  · have e := hn (check (elem p) 0) (show check (elem p) 0∈C R L from ⟨![elem p,0],rfl⟩)
    have equal : pairing u (check (elem p) 0) = -(∑ e,read false (elem p) e * sample false u e) := by
      unfold pairing
      rw [←Finset.sum_neg_distrib]
      apply Finset.sum_congr rfl
      rintro ⟨s,i,j⟩ _
      have z0 (i j : ZMod L) : pin (0 : pinSet L → R) i j=0 := by
        by_cases h : (i,j)=(0,0) <;> simp [pin,h]
      cases s <;> simp [check,pack,read,sample,faceCheck,z0,mul_comm]
    simpa [equal] using e
  · have e := hn (check 0 (elem p)) (show check 0 (elem p)∈C R L from ⟨![0,elem p],rfl⟩)
    have equal : pairing u (check 0 (elem p)) = ∑ e,read true (elem p) e * sample true u e := by
      unfold pairing
      apply Finset.sum_congr rfl
      rintro ⟨s,i,j⟩ _
      have z0 (i j : ZMod L) : pin (0 : pinSet L → R) i j=0 := by
        by_cases h : (i,j)=(0,0) <;> simp [pin,h]
      cases s <;> simp [check,pack,read,sample,starCheck,z0,mul_comm]
    simpa [equal] using e

private theorem expand_pin (a : pinSet L → R) (i j : ZMod L) :
    (∑ p : pinSet L, (if p.val=(i,j) then a p else 0))=pin a i j := by
  by_cases h : (i,j)=(0,0)
  · have no (p : pinSet L) : p.val≠(0,0) := p.property
    simp [pin,h,no]
  · have same (p : pinSet L) : p.val=(i,j) ↔ p=⟨(i,j),h⟩ := ⟨fun eq => Subtype.ext eq, fun eq => congrArg Subtype.val eq⟩
    simp [same,pin,h]

theorem linear_row (f : Bool) (a : pinSet L → R) (e : Site L) :
    read f a e = ∑ p, coeff R f p e * a p := by
  have factor (p : pinSet L) (q : ZMod L × ZMod L) (w : R) :
      (if p.val=q then w else 0)*a p = w*(if p.val=q then a p else 0) := by split_ifs <;> simp_all
  rcases e with ⟨s,i,j⟩
  cases f <;> cases s <;>
    simp only [read,starCheck,faceCheck,coeff,fromV,toV,g₁,g₂,Bool.false_eq_true,if_false,if_true,
      add_mul,Finset.sum_add_distrib,factor,←Finset.mul_sum,expand_pin] <;> ring

theorem binary_coeff [Nontrivial (ZMod L)] (f : Bool) (v : pinSet L) (e : Site L) :
    coeff (ZMod 2) f v e = if v ∈ incidence f e then 1 else 0 := by
  by_cases h : v∈incidence f e
  · simp only [h,if_true]
    have unit := unit_entry (R:=ZMod 2) f v e h
    have v01 : ∀ t : ZMod 2, IsUnit t → t=1 := by decide +kernel
    exact v01 _ unit
  · simp [h,outside f v e h]

def embed (f : Bool) (y : Site L → R) : State R L :=
  fun e => if f then (y e,0) else (0,y e)

theorem binary_embed_normal [Nontrivial (ZMod L)] (f : Bool) (y : Site L → ZMod 2)
    (ker : ∀v, ∑ e, (if v∈incidence f e then y e else 0)=0) : Normal (embed f y) := by
  have hsum (a : pinSet L → ZMod 2) : (∑ e, y e * read f a e)=0 := by
    simp_rw [linear_row,Finset.mul_sum]
    rw [Finset.sum_comm]
    apply Finset.sum_eq_zero
    intro p _
    have sw (e : Site L) : y e*(coeff (ZMod 2) f p e*a p) =
          (if p∈incidence f e then y e else 0)*a p := by
      rw [binary_coeff]
      split_ifs <;> simp_all
    simp_rw [sw]
    rw [←Finset.sum_mul,ker,zero_mul]
  rintro _ ⟨a,rfl⟩
  change pairing (embed f y) (check (a 0) (a 1))=0
  cases f
  · have equal : pairing (embed false y) (check (a 0) (a 1)) = -(∑ e,y e*read false (a 0) e) := by
      unfold pairing
      rw [←Finset.sum_neg_distrib]
      apply Finset.sum_congr rfl
      rintro ⟨s,i,j⟩ _
      cases s <;> simp [embed,check,pack,read]
    rw [equal,hsum,neg_zero]
  · have equal : pairing (embed true y) (check (a 0) (a 1)) = ∑ e,y e*read true (a 1) e := by
      unfold pairing
      apply Finset.sum_congr rfl
      rintro ⟨s,i,j⟩ _
      cases s <;> simp [embed,check,pack,read]
    rw [equal,hsum]
end ToricIncidence
