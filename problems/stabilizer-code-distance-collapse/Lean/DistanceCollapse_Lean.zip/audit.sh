#!/usr/bin/env bash
# Compile the shipped sources, then replay their declarations in a new kernel process.
set -euo pipefail
cd "$(dirname "$0")"
project_root=$PWD
toolchain_bin="$(lean --print-prefix)/bin"
export PATH="$toolchain_bin:$PATH"
proof_work=$(mktemp -d)
trap 'rm -rf -- "$proof_work"' EXIT
dependency_path=$(lake env printenv LEAN_PATH)
mapfile -t modules < <(python3 - <<'PY'
import tomllib
with open("lakefile.toml", "rb") as f:
    print(*tomllib.load(f)["defaultTargets"],sep="\n")
PY
)
export LEAN_PATH="$proof_work:$dependency_path"
for name in "${modules[@]}"; do
    cp "$project_root/$name.lean" "$proof_work/$name.lean"
done
cd "$proof_work"
for name in "${modules[@]}"; do
    echo "compiling $name"
    "$toolchain_bin/lean" -j 1 -o "$name.olean" "$name.lean"
done
for name in "${modules[@]}"; do
    "$toolchain_bin/leanchecker" --verbose "$name"
done
echo "All ${#modules[@]} modules compiled from source and passed kernel replay."
