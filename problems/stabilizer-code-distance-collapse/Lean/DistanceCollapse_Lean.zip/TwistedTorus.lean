import ToricLift

/-! Square torus with sign holonomy in the first direction. No extra qudits. -/
namespace TwistedTorus
open scoped BigOperators
open ToricLift (Grid cyclic_constant shiftPair)
variable {L : ℕ} [NeZero L] {R : Type*} [CommRing R]

abbrev Edges (R : Type*) (L : ℕ) := Grid R L × Grid R L

def sign (R : Type*) [CommRing R] (i : ZMod L) : R := if i+1=0 then -1 else 1

def starCheck (u : Grid R L) : Edges R L :=
  (fun i j => sign R (i-1)*u (i-1) j-u i j, fun i j => u i (j-1)-u i j)

def faceCheck (f : Grid R L) : Edges R L :=
  (fun i j => f i (j+1)-f i j, fun i j => f i j-sign R i*f (i+1) j)

def dot (a b : Edges R L) : R :=
  (∑ i,∑ j,a.1 i j*b.1 i j)+(∑ i,∑ j,a.2 i j*b.2 i j)

theorem parts (u h v : Grid R L) : dot (starCheck u) (h,v) =
    ∑ i,∑ j,u i j*(sign R i*h (i+1) j-h i j+v i (j+1)-v i j) := by
  have ex : (∑ i, ∑ j, (sign R (i-1)*u (i-1) j)*h i j) =
      ∑ i, ∑ j, (sign R i*u i j)*h (i+1) j := by
    rw [Finset.sum_comm, Finset.sum_comm (f := fun i j => (sign R i*u i j)*h (i+1) j)]
    exact Finset.sum_congr rfl fun j _ => shiftPair (fun i => sign R i*u i j) (fun i => h i j)
  have ey : (∑ i,∑ j,u i (j-1)*v i j) = ∑ i,∑ j,u i j*v i (j+1) :=
    Finset.sum_congr rfl fun i _ => shiftPair (u i) (v i)
  unfold dot starCheck
  dsimp only
  simp only [sub_mul, mul_sub, mul_add, Finset.sum_sub_distrib, Finset.sum_add_distrib]
  rw [ex,ey]
  have scale (i j : ZMod L) : u i j*(sign R i*h (i+1) j)=(sign R i*u i j)*h (i+1) j := by ring
  simp_rw [scale]; ring

/-- Flatness of the sign transport makes the two CSS layers commute. -/
theorem commute (u f : Grid R L) : dot (starCheck u) (faceCheck f)=0 := by
  rw [show faceCheck f = ((faceCheck f).1,(faceCheck f).2) from rfl,parts]
  have flat (i j : ZMod L) : sign R i*(faceCheck f).1 (i+1) j-(faceCheck f).1 i j+
      (faceCheck f).2 i (j+1)-(faceCheck f).2 i j=0 := by simp only [faceCheck]; ring
  simp [flat]

/-- Walking forward without crossing the seam reaches each representative 0,...,L-1. -/
private theorem open_interval_constant {α : Type*} (g : ZMod L → α)
    (h : ∀ i, i+1≠0 → g (i+1)=g i) (i : ZMod L) : g i=g 0 := by
  have step (m : ℕ) (hm : m<L) : g (m:ZMod L)=g 0 := by
    induction m with
    | zero => simp
    | succ m ih =>
      have ne : ((m+1:ℕ):ZMod L)≠0 := by
        rw [Ne,ZMod.natCast_eq_zero_iff]
        exact Nat.not_dvd_of_pos_of_lt (Nat.succ_pos _) hm
      have e := h (m:ZMod L) (by simpa only [Nat.cast_succ] using ne)
      rw [Nat.cast_succ,e,ih (by omega)]
  simpa using step i.val i.val_lt

theorem holonomy (g : ZMod L → R) (h : ∀ i,g i=sign R i*g (i+1)) : g 0= -g 0 := by
  have allc := open_interval_constant g (fun i hi => by simpa [sign,hi] using (h i).symm)
  have e := h (-1)
  simpa [sign,allc (-1)] using e

theorem star_pinned_injective (u t : Grid R L) (hu : u 0 0=t 0 0)
    (h : starCheck u=starCheck t) : u=t := by
  have ex (i j : ZMod L) := congrArg (fun z : Edges R L => z.1 (i+1) j) h
  have ey (i j : ZMod L) := congrArg (fun z : Edges R L => z.2 i (j+1)) h
  simp only [starCheck,add_sub_cancel_right] at ex ey
  funext i j
  have a := open_interval_constant (fun i => u i j-t i j) (fun i hi => by
    have e := ex i j
    simp only [sign,if_neg hi,one_mul] at e
    linear_combination -e) i
  have b := cyclic_constant (R:=R) (fun j => u 0 j-t 0 j) (fun j => by
    linear_combination -(ey 0 j)) j
  linear_combination a+b+hu

theorem face_pinned_injective (u t : Grid R L) (hu : u 0 0=t 0 0)
    (h : faceCheck u=faceCheck t) : u=t := by
  have ex (i j : ZMod L) := congrArg (fun z : Edges R L => z.2 i j) h
  have ey (i j : ZMod L) := congrArg (fun z : Edges R L => z.1 i j) h
  simp only [faceCheck] at ex ey
  funext i j
  have a := open_interval_constant (fun i => u i j-t i j) (fun i hi => by
    have e := ex i j
    simp only [sign,if_neg hi,one_mul] at e
    linear_combination -e) i
  have b := cyclic_constant (R:=R) (fun j => u 0 j-t 0 j) (fun j => by
    linear_combination ey 0 j) j
  linear_combination a+b+hu

def point (R : Type*) [CommRing R] (i j : ZMod L) : R := if i=0 ∧ j=0 then 1 else 0

def omitted : Edges (ZMod 4) L := faceCheck (point (L:=L) (ZMod 4))

theorem omitted_commutes (u : Grid (ZMod 4) L) : dot (starCheck u) omitted=0 := commute u _

/-- Any attempted pinned face filling has transport holonomy -1 but starts with
coefficient minus one. This contradicts 1 ≠ -1 in the four-element ring. -/
theorem excluded_face (htwo : (2:R)≠0) (b : Grid R L) (h0 : b 0 0=0) :
    faceCheck b≠faceCheck (point (L:=L) R) := by
  intro eq
  let g (i : ZMod L) := b i 0-point R i 0
  have hg (i : ZMod L) : g i=sign R i * g (i+1) := by
    have e := congrArg (fun z : Edges R L => z.2 i 0) eq
    change b i 0-sign R i*b (i+1) 0 = point R i 0 - sign R i * point R (i+1) 0 at e
    dsimp [g]; linear_combination e
  have bad := holonomy g hg
  have g0 : g 0 = -1 := by simp [g,h0,point]
  rw [g0,neg_neg] at bad
  exact htwo (by linear_combination -bad)

theorem omitted_not_generated (b : Grid (ZMod 4) L) (h0 : b 0 0=0) : faceCheck b≠omitted :=
  excluded_face (by decide) b h0

#print axioms excluded_face
#print axioms omitted_not_generated
#print axioms commute
end TwistedTorus
