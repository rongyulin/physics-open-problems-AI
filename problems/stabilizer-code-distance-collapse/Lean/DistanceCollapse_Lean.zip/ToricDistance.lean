import ToricBinary
import ToricLift

/-! Pauli weight counts each occupied site once, even when both Pauli exponents are nonzero.
The normalizer is defined by the actual check pairings; the stabilizer is their image. -/
namespace ToricDistance
open ToricLift
variable {L : ℕ} [NeZero L]
abbrev F := ZMod 2
abbrev G (L : ℕ) := Grid F L
abbrev C (L : ℕ) := Chains F L

private theorem two_zero : (2 : F) = 0 := by decide

def Normal (x z : C L) : Prop :=
  (∀ u : G L, u 0 0 = 0 → dot (xcheck u) z = 0) ∧
  (∀ (b : G L) (t : ZMod L → F), b 0 0 = 0 → dot x (zcheck b t) = 0)

def Stabilizer (x z : C L) : Prop :=
  (∃ u : G L, u 0 0 = 0 ∧ x = xcheck u) ∧
  ∃ (b : G L) (t : ZMod L → F), b 0 0 = 0 ∧ z = zcheck b t

def pairOccupation (g h : G L) : ℕ :=
  ((Finset.univ : Finset (ZMod L × ZMod L)).filter
    (fun ij => g ij.1 ij.2 ≠ 0 ∨ h ij.1 ij.2 ≠ 0)).card

def siteWeight (x z : C L) : ℕ :=
  pairOccupation x.1 z.1 + pairOccupation x.2.1 z.2.1 +
  ((Finset.univ : Finset (ZMod L)).filter (fun i => x.2.2 i ≠ 0 ∨ z.2.2 i ≠ 0)).card

private theorem occupation_le_left (g h : G L) :
    ToricBinary.occupation g ≤ pairOccupation g h := by
  apply Finset.card_le_card
  intro i hi
  exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,Or.inl (Finset.mem_filter.mp hi).2⟩

private theorem occupation_le_right (g h : G L) :
    ToricBinary.occupation h ≤ pairOccupation g h := by
  apply Finset.card_le_card
  intro i hi
  exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,Or.inr (Finset.mem_filter.mp hi).2⟩

private theorem weight_le (x z : C L) :
    ToricBinary.weight x.1 x.2.1 ≤ siteWeight x z ∧
    ToricBinary.weight z.1 z.2.1 ≤ siteWeight x z := by
  unfold ToricBinary.weight siteWeight
  have := occupation_le_left x.1 z.1
  have := occupation_le_left x.2.1 z.2.1
  have := occupation_le_right x.1 z.1
  have := occupation_le_right x.2.1 z.2.1
  omega

private def pin (u : G L) : G L := fun i j => u i j - u 0 0
omit [NeZero L] in
private theorem pin_zero (u : G L) : pin u 0 0=0 := by simp [pin]
omit [NeZero L] in
private theorem xcheck_pin (u : G L) : xcheck (pin u) = xcheck u := by
  apply Prod.ext
  · funext i j; simp [xcheck,pin]
  · apply Prod.ext
    · funext i j; simp [xcheck,pin]
    · funext i; simp [xcheck,pin,two_zero]

omit [NeZero L] in
private theorem zcheck_pin (b : G L) (t : ZMod L → F) : zcheck (pin b) t = zcheck b t := by
  apply Prod.ext
  · funext i j; simp [zcheck,pin]
  · apply Prod.ext
    · funext i j; simp [zcheck,pin]
    · rfl

private def stitch (t : ZMod L → F) : ZMod L → F := fun i =>
  t i - (if i=0 then 0 else t (i-1))

private theorem stitch_onto : Function.Surjective (stitch (L := L)) := by
  apply Finite.surjective_of_injective
  intro s t h
  have hh : s-t=0 := stitch_kernel (s-t) (by
    intro i
    have e := congrFun h i
    by_cases hi : i=0
    · simpa [stitch,hi,sub_eq_zero] using e
    · simp [stitch,hi] at e ⊢
      linear_combination e)
  exact sub_eq_zero.mp hh

private theorem partsZ (b h v : G L) :
    (∑ i, ∑ j, h i j * (b i (j+1) - b i j)) +
    (∑ i, ∑ j, v i j * (b i j - b (i+1) j)) =
    ∑ i, ∑ j, b i j * (h i (j-1) - h i j + v i j - v (i-1) j) := by
  have hx : (∑ i, ∑ j, h i j * b i (j+1)) = ∑ i, ∑ j, h i (j-1) * b i j :=
    Finset.sum_congr rfl fun i _ => (shiftPair (h i) (b i)).symm
  have hv : (∑ i, ∑ j, v i j * b (i+1) j) = ∑ i, ∑ j, v (i-1) j * b i j := by
    rw [Finset.sum_comm, Finset.sum_comm (f := fun i j => v (i-1) j * b i j)]
    exact Finset.sum_congr rfl fun j _ => (shiftPair (fun i => v i j) (fun i => b i j)).symm
  simp only [mul_sub,mul_add,Finset.sum_sub_distrib,Finset.sum_add_distrib]
  rw [hx,hv]
  simp_rw [mul_comm (b _ _) (h _ _), mul_comm (b _ _) (v _ _)]
  abel

private def point (i j : ZMod L) : G L := fun k l => if i=k then (if j=l then 1 else 0) else 0

private theorem test_point (i j : ZMod L) (f : G L) :
    (∑ k, ∑ l, point i j k l * f k l) = f i j := by
  simp [point,ite_mul]

theorem normal_to_cycles (x z : C L) (hn : Normal x z) :
    ToricBinary.Closed z.1 z.2.1 ∧ ToricBinary.Coclosed x.1 x.2.1 ∧ x.2.2 = 0 := by
  have hu (u : G L) : dot (xcheck u) z = 0 := by
    simpa only [xcheck_pin] using hn.1 (pin u) (pin_zero u)
  have hb (b : G L) (t : ZMod L → F) : dot x (zcheck b t) = 0 := by
    simpa only [zcheck_pin] using hn.2 (pin b) t (pin_zero b)
  refine ⟨?_,?_,?_⟩
  · intro i j
    have e := hu (point i j)
    simp only [dot,xcheck,two_zero,neg_zero,zero_mul,Finset.sum_const_zero,add_zero] at e
    rw [summationByParts,test_point] at e
    exact e
  · intro i j
    have e := hb (point i j) 0
    simp only [dot,zcheck,two_zero,ite_self,add_zero,Pi.zero_apply,sub_zero,
      mul_zero,Finset.sum_const_zero] at e
    rw [partsZ,test_point] at e
    exact e
  · funext i
    obtain ⟨t,ht⟩ := stitch_onto (fun j : ZMod L => if i=j then 1 else 0)
    have e := hb 0 t
    simp only [dot,zcheck,two_zero,zero_mul,ite_self,add_zero,Pi.zero_apply,sub_zero,
      mul_zero,Finset.sum_const_zero,zero_add] at e
    change (∑ j, x.2.2 j * stitch t j) = 0 at e
    simpa [ht,mul_ite] using e

theorem cycles_to_normal (x z : C L) (hz : ToricBinary.Closed z.1 z.2.1)
    (hx : ToricBinary.Coclosed x.1 x.2.1) (ha : x.2.2 = 0) : Normal x z := by
  constructor
  · intro u _
    simp only [dot,xcheck,two_zero,neg_zero,zero_mul,Finset.sum_const_zero,add_zero]
    rw [summationByParts]
    unfold ToricBinary.Closed at hz
    simp [hz]
  · intro b t _
    simp only [dot,zcheck,two_zero,zero_mul,ite_self,add_zero,ha,Pi.zero_apply,
      Finset.sum_const_zero]
    rw [partsZ]
    unfold ToricBinary.Coclosed at hx
    simp [hx]

/-- Every normalizer element supported on fewer than L physical qubits belongs to the
binary stabilizer, including arbitrary Pauli operators on the auxiliary chain. -/
theorem low_weight_stabilizer (x z : C L) (hn : Normal x z) (sm : siteWeight x z<L) :
    Stabilizer x z := by
  obtain ⟨zc,xc,xa⟩ := normal_to_cycles x z hn
  obtain ⟨xl,zl⟩ := weight_le x z
  obtain ⟨u, uh, uv⟩ := ToricBinary.low_weight_coboundary x.1 x.2.1 xc (lt_of_le_of_lt xl sm)
  obtain ⟨b, bh, bv⟩ := ToricBinary.low_weight_boundary z.1 z.2.1 zc (lt_of_le_of_lt zl sm)
  obtain ⟨t,ht⟩ := stitch_onto z.2.2
  constructor
  · refine ⟨pin u,pin_zero _,?_⟩
    rw [xcheck_pin]
    apply Prod.ext
    · exact funext fun i => funext fun j => uh i j
    · apply Prod.ext
      · exact funext fun i => funext fun j => uv i j
      · simpa [xcheck,two_zero] using xa
  · refine ⟨pin b,t,pin_zero _,?_⟩
    rw [zcheck_pin]
    apply Prod.ext
    · funext i j; simpa [zcheck,two_zero] using bh i j
    · exact Prod.ext (funext fun i => funext fun j => bv i j) ht.symm

theorem distance_lower (x z : C L) (hn : Normal x z) (hs : ¬ Stabilizer x z) :
    L ≤ siteWeight x z := le_of_not_gt fun h => hs (low_weight_stabilizer x z hn h)

/-- A straight winding loop realizes the lower bound. -/
theorem distance_attained : ∃ x z : C L, Normal x z ∧ ¬ Stabilizer x z ∧ siteWeight x z = L := by
  obtain ⟨h,v,hc,hn,hw⟩ := ToricBinary.sharp (L := L)
  refine ⟨(0,0,0), (h,v,0), cycles_to_normal _ _ hc (by intro i j; simp) rfl, ?_,?_⟩
  · rintro ⟨_,b,t,_,he⟩
    apply hn
    refine ⟨b,?_,?_⟩
    · intro i j
      simpa [zcheck,two_zero] using congrArg (fun c : C L => c.1 i j) he
    · intro i j
      exact congrArg (fun c : C L => c.2.1 i j) he
  · simpa [siteWeight, pairOccupation, ToricBinary.weight, ToricBinary.occupation] using hw

#print axioms distance_lower
#print axioms distance_attained
end ToricDistance
