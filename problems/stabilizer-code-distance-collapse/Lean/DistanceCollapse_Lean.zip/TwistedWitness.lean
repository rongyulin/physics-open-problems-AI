import TwistedCode

/-! Support and cardinality of the omitted plaquette in the physical edge labels. -/
namespace TwistedCode
open TwistedTorus
open scoped BigOperators
variable {R : Type*} [CommRing R] [DecidableEq R] {L : ℕ} [NeZero L]

private def corners (L : ℕ) : Finset (Site L) := {(false,0,0),(false,0,-1),(true,0,0),(true,-1,0)}

private theorem next_zero (i : ZMod L) : i+1=0 ↔ i= -1 := by
  constructor
  · intro h; calc i = (i+1)-1 := by abel
                  _ = -1 := by rw [h,zero_sub]
  · intro h; rw [h,neg_add_cancel]

private theorem omitted_supported (s : Site L) (h : omitted R L s≠0) : s∈corners L := by
  obtain ⟨d,i,j⟩ := s
  cases d
  · by_cases hi:i=0
    · subst i
      by_cases hj:j=0
      · subst j; simp [corners]
      · by_cases hj':j= -1
        · subst j; simp [corners]
        · exfalso; apply h
          simp [omitted,pack,faceCheck,point,hj,(next_zero j).not.mpr hj']
    · exfalso; apply h; simp [omitted,pack,faceCheck,point,hi]
  · by_cases hj:j=0
    · subst j
      by_cases hi:i=0
      · subst i; simp [corners]
      · by_cases hi':i= -1
        · subst i; simp [corners]
        · exfalso; apply h
          simp [omitted,pack,faceCheck,point,hi,(next_zero i).not.mpr hi']
    · exfalso; apply h; simp [omitted,pack,faceCheck,point,hj]

theorem omitted_weight_le : stateWeight (omitted R L) ≤ 4 := by
  have le : stateWeight (omitted R L) ≤ (corners L).card :=
    Finset.card_le_card (fun s hs => omitted_supported s (Finset.mem_filter.mp hs).2)
  exact le.trans (by
    unfold corners
    let A : Site L := (false,0,0)
    let B : Site L := (false,0,-1)
    let C : Site L := (true,0,0)
    let D : Site L := (true,-1,0)
    have h1 := Finset.card_insert_le A ({B,C,D} : Finset (Site L))
    have h2 := Finset.card_insert_le B ({C,D} : Finset (Site L))
    have h3 := Finset.card_insert_le C ({D} : Finset (Site L))
    change (insert A {B,C,D} : Finset (Site L)).card ≤ 4
    rw [Finset.card_singleton] at h3
    omega)

theorem short_logical (h : (2:R)≠0) : ∃ x : State R L, Normal x ∧ x∉C R L ∧ stateWeight x≤4 :=
  ⟨omitted R L,omitted_normal,omitted_not_mem h,omitted_weight_le⟩

#print axioms short_logical
end TwistedCode
