import BareToricDistance
import TwistedLower

/-! Binary distance for the same linear stabilizer module, physical support function and
symplectic normalizer as the signed ququart code. -/
namespace TwistedFieldDistance
open TwistedCode TwistedTorus
variable {L : ℕ} [NeZero L]
local notation "F" => ZMod 2

private theorem weight_pack (x z : Edges F L) : stateWeight (pack x z)=BareToricDistance.weight x z := by
  have en (a b : F) : (a,b) ≠ 0 ↔ a≠0 ∨ b≠0 := by revert a b; decide
  simp only [stateWeight,BareToricDistance.weight,ToricDistance.pairOccupation,
    Finset.card_filter,Fintype.sum_prod_type,Fintype.sum_bool,pack,en]
  omega

private theorem normal_pack (x z : Edges F L) : Normal (pack x z) ↔ BareToricDistance.Normal x z := by
  constructor
  · intro hn
    exact TwistedLower.binary_grid_commutation (pack x z) hn
  · intro hn y hy
    obtain ⟨a,rfl⟩ := hy
    change pairing (pack x z) (pack (starCheck (pin (a 0))) (faceCheck (pin (a 1)))) = 0
    rw [pairing_pack,hn.1 _ (by simp [pin]),hn.2 _ (by simp [pin]),sub_zero]

omit [NeZero L] in
private lemma restore (u : ToricLift.Grid F L) (hu : u 0 0=0) :
    pin (fun r : pinSet L => u r.1.1 r.1.2) = u := by
  funext i j
  by_cases ij : (i,j)=(0,0)
  · obtain ⟨rfl,rfl⟩ := Prod.mk.inj ij
    simp [pin,hu]
  · simp [pin,ij]

private theorem mem_pack (x z : Edges F L) : pack x z∈C F L ↔ BareToricDistance.Stabilizer x z := by
  constructor
  · rintro ⟨a,he⟩
    refine ⟨⟨pin (a 0),by simp [pin],?_⟩,pin (a 1),by simp [pin],?_⟩
    · exact (congrArg TwistedLower.xedges he).symm
    · exact (congrArg TwistedLower.zedges he).symm
  · rintro ⟨⟨u,hu,rfl⟩,f,hf,rfl⟩
    let a : pinSet L → F := fun r => u r.1.1 r.1.2
    let b : pinSet L → F := fun r => f r.1.1 r.1.2
    refine ⟨![a,b],?_⟩
    change pack (starCheck (pin a)) (faceCheck (pin b))=_
    rw [show pin a=u from restore u hu,show pin b=f from restore f hf]

theorem binary_logical_lower (u : State F L) (hn : Normal u) (hm : u ∉ C F L) :
    L ≤ stateWeight u := by
  rw [←TwistedLower.repack u] at hn hm ⊢
  rw [weight_pack]
  exact BareToricDistance.distance_lower _ _ ((normal_pack _ _).mp hn) (hm ∘ (mem_pack _ _).mpr)

theorem binary_logical_attained :
    ∃ u : State F L, Normal u ∧ u ∉ C F L ∧ stateWeight u=L := by
  obtain ⟨x,z,hn,hs,hw⟩ := BareToricDistance.distance_attained (L:=L)
  exact ⟨pack x z,(normal_pack x z).mpr hn, hs ∘ (mem_pack x z).mp, (weight_pack x z).trans hw⟩

#print axioms binary_logical_lower
#print axioms binary_logical_attained
end TwistedFieldDistance
