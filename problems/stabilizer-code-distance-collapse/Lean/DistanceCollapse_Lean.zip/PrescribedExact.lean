import PrescribedLDI
import PrescribedCoefficients

/-! An integral pair of checks with local entries (1,0) and (0,1) exists
at every site. This rules out single-site centralizer elements over every
commutative ring, including composite cyclic alphabets. -/
namespace PrescribedLDI
open CyclicPauli FrobeniusCounterexample
open scoped BigOperators
variable {R : Type*} [CommRing R]
private def localX (i : Site) : Row→ℤ := ![![1,0,0,0,0,0],![0,1,0,0,0,0],![0,0,1,0,0,0],![0,0,0,1,0,0],![0,-1,0,0,1,0],![0,0,0,0,0,1],![1,0,0,0,0,0]] i
private def localZ (i : Site) : Row→ℤ := ![![0,-1,0,0,0,0],![0,0,1,0,0,0],![0,1,0,0,0,0],![1,0,0,0,0,0],![0,1,0,0,0,0],![1,0,0,0,0,0],![0,1,0,0,0,0]] i

private theorem local_tests (i : Site) :
    enc (fun a => (localX i a:R)) i=(1,0) ∧ enc (fun a => (localZ i a:R)) i=(0,1) := by
  have cert : ∀ k : Site, enc (localX k) k=(1,0) ∧ enc (localZ k) k=(0,1) := by decide +kernel
  rw [enc_cast,enc_cast,(cert i).1,(cert i).2]
  simp

private theorem local_bracket (x y : Labels R 7) (i : Site)
    (off : ∀ j, j≠i → x j=0) :
    bracket x y=(x i).1*(y i).2-(x i).2*(y i).1 := by
  unfold bracket
  apply Finset.sum_eq_single i
  · intro j _ hj; simp [off j hj]
  · simp

/-- A commuting Pauli label supported on at most one site vanishes. -/
theorem one_site_zero [DecidableEq R] (x : Labels R 7)
    (h : ∀ y∈code R, bracket x y=0) (small : wt x≤1) : x=0 := by
  let s := (Finset.univ : Finset Site).filter (fun i => x i≠0)
  obtain ⟨t,st,_,ht⟩ := Finset.exists_subsuperset_card_eq (Finset.subset_univ s) small
    (show 1≤ (Finset.univ : Finset Site).card by decide)
  obtain ⟨i,rfl⟩ := Finset.card_eq_one.mp ht
  have off (j : Site) (ji : j≠i) : x j=0 := by
    by_contra hn
    exact ji (Finset.mem_singleton.mp (st (Finset.mem_filter.mpr ⟨Finset.mem_univ _,hn⟩)))
  have hx := h (enc (fun a => (localX i a:R))) ⟨fun a => (localX i a:R),rfl⟩
  have hz := h (enc (fun a => (localZ i a:R))) ⟨fun a => (localZ i a:R),rfl⟩
  rw [local_bracket _ _ i off, (local_tests i).1] at hx
  rw [local_bracket _ _ i off, (local_tests i).2] at hz
  simp at hx hz
  funext j
  by_cases ji:j=i
  · subst j; exact Prod.ext hz hx
  · exact off j ji

/-- The exact distance in arbitrary characteristic not dividing 2, including nonfields. -/
theorem lifted_distance (R : Type*) [CommRing R] [DecidableEq R] [Nontrivial R]
    (h2 : (2:R)≠0) : relativeDistance (code R)=2 := by
  let s : Set ℕ := {w | ∃ x : Labels R 7, logical (code R) x ∧ wt x=w}
  have h2s : 2∈s := ⟨short R,short_logical R h2,short_weight R⟩
  change sInf s=2
  apply le_antisymm (Nat.sInf_le h2s)
  apply le_csInf ⟨2,h2s⟩
  rintro _ ⟨x,h,rfl⟩
  by_contra! small
  have e := one_site_zero x h.1 (by omega)
  exact h.2 (e ▸ (code R).zero_mem)

theorem large_distance (m : ℕ) (hm : 2 < m) :
    relativeDistance (code (ZMod m))=2 := by
  letI : Fact (1 < m) := ⟨by omega⟩
  have h2 : (2:ZMod m)≠0 := by
    intro z
    have e := congrArg ZMod.val z
    simp [ZMod.val_ofNat,Nat.mod_eq_of_lt hm] at e
  exact lifted_distance (ZMod m) h2

theorem no_prime_cutoff (bound : ℕ) : ∃ p > bound, Nat.Prime p ∧
    relativeDistance (code (ZMod p)) < relativeDistance (code (ZMod 2)) := by
  obtain ⟨p,hp,prime⟩ := Nat.exists_infinite_primes (bound+3)
  exact ⟨p,by omega,prime,by rw [large_distance p (by omega),binary_distance]; decide⟩

#print axioms no_prime_cutoff
#print axioms one_site_zero
#print axioms large_distance
end PrescribedLDI
