import TwistedBinary
import TwistedCode
import ToricResidue

/-! Exact lower bound for the genuine site weight of any nonidentity Pauli
commuting with the pinned sign-twisted toric checks over the four-level alphabet. -/
namespace TwistedLower
open TwistedTorus TwistedCode
open scoped BigOperators
variable {L : ℕ} [NeZero L]
local notation "F" => ZMod 2

def xedges {R : Type*} (u : State R L) : Edges R L :=
  (fun i j => (u (false,i,j)).1,fun i j => (u (true,i,j)).1)
def zedges {R : Type*} (u : State R L) : Edges R L :=
  (fun i j => (u (false,i,j)).2,fun i j => (u (true,i,j)).2)

theorem repack {R : Type*} [CommRing R] (u : State R L) :
    pack (xedges u) (zedges u)=u := by
  funext ⟨t,i,j⟩
  cases t <;> rfl

private theorem pin_repr (g : ToricLift.Grid F L) (hg : g 0 0=0) :
    pin (fun q : pinSet L => g q.val.1 q.val.2) = g := by
  funext i j
  by_cases h : (i,j)=(0,0)
  · obtain ⟨rfl,rfl⟩ := Prod.mk.inj h
    simp [pin,hg]
  · simp [pin,h]

theorem binary_grid_commutation (u : State F L) (hn : Normal u) :
    TwistedBinary.Normal (xedges u) (zedges u) := by
  have h (a b : pinSet L → F) := hn (check a b) (show check a b∈C F L from ⟨![a,b],rfl⟩)
  have h' (a b : pinSet L → F) : dot (xedges u) (faceCheck (pin b)) -
      dot (starCheck (pin a)) (zedges u) = 0 := by
    rw [←pairing_pack,repack]
    exact h a b
  have pz : pin (0:pinSet L → F)=0 := by
    funext i j
    by_cases q:(i,j)=(0,0) <;> simp [pin,q]
  constructor
  · intro g hg
    have e := h' (fun q => g q.val.1 q.val.2) 0
    rw [pin_repr g hg,pz] at e
    simpa [dot,faceCheck,add_comm] using e
  · intro g hg
    have e := h' 0 (fun q => g q.val.1 q.val.2)
    rw [pin_repr g hg,pz] at e
    simpa [dot,starCheck] using e

private theorem weight_layer (u : State F L) (val : F × F → F) (v0 : val 0=0) :
    ToricBinary.weight (fun i j => val (u (false,i,j))) (fun i j => val (u (true,i,j))) ≤ stateWeight u := by
  let occ (t : Bool) := (Finset.univ.filter (fun q : ZMod L × ZMod L => u (t,q)≠0)).card
  have h (t) : ToricBinary.occupation (fun i j => val (u (t,i,j))) ≤ occ t := by
    apply Finset.card_le_card
    intro q hq
    refine Finset.mem_filter.mpr ⟨Finset.mem_univ _,?_⟩
    intro e
    apply (Finset.mem_filter.mp hq).2
    change val (u (t,q))=0
    rw [e,v0]
  have total : stateWeight u = occ true + occ false := by
    simp only [stateWeight,occ,Finset.card_filter,Fintype.sum_prod_type,Fintype.sum_bool]
  unfold ToricBinary.weight
  rw [total,add_comm]
  exact Nat.add_le_add (h true) (h false)

theorem binary_lower (u : State F L) (hL : 4≤L) (hn : Normal u) (sm : stateWeight u<4) : u=0 := by
  have hx := weight_layer u Prod.fst (by rfl)
  have hz := weight_layer u Prod.snd (by rfl)
  obtain ⟨zx,zz⟩ := TwistedBinary.small_none hL (xedges u) (zedges u) (binary_grid_commutation u hn)
    (hx.trans_lt sm) (hz.trans_lt sm)
  rw [←repack u,zx,zz]
  funext ⟨t,i,j⟩
  cases t <;> rfl

/-- This bound includes the commuting stabilizers themselves, and permits both
nonzero Pauli components on the same physical site. -/
theorem ring_lower (hL : 4≤L) (u : State (ZMod 4) L) (hn : Normal u) (un : u≠0) :
    4 ≤ stateWeight u := by
  by_contra! h
  apply un
  apply ToricResidue.lower_of_binary (A := (C (ZMod 4) L : Set (State (ZMod 4) L)))
    (B := (C F L : Set (State F L))) (k:=4) _ _ u hn h
  · intro b hb
    rw [←code_reduce] at hb
    exact hb
  · exact fun v hnorm hweight => binary_lower v hL hnorm hweight

#print axioms binary_grid_commutation
#print axioms ring_lower
end TwistedLower
