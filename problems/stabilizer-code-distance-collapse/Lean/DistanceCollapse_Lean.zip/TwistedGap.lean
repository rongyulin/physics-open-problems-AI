import TwistedWitness
import TwistedFieldDistance
import TwistedSize

/-! Relative symplectic distances of the physical modules, including
attainment by logical operators, for the same square torus and same checks. -/
namespace TwistedGap
open TwistedCode
variable {L : ℕ} [NeZero L]

noncomputable def distance (R : Type*) [CommRing R] [DecidableEq R] (L : ℕ) [NeZero L] : ℕ :=
  sInf {w | ∃ x : State R L, Normal x ∧ x∉C R L ∧ stateWeight x=w}

private theorem dist_eq {R : Type*} [CommRing R] [DecidableEq R] (d : ℕ)
    (witness : ∃ x : State R L, Normal x ∧ x∉C R L ∧ stateWeight x≤d)
    (lower : ∀ x : State R L, Normal x → x∉C R L → d≤stateWeight x) :
    distance R L=d := by
  obtain ⟨u,hn,hm,hw⟩ := witness
  have hw' := le_antisymm hw (lower u hn hm)
  have mem : d ∈ {w | ∃ x : State R L, Normal x ∧ x∉C R L ∧ stateWeight x=w} :=
    ⟨u,hn,hm,hw'⟩
  apply le_antisymm (Nat.sInf_le mem)
  apply le_csInf ⟨d,mem⟩
  rintro _ ⟨x,hx,hxm,rfl⟩
  exact lower x hx hxm

theorem ring_distance (hl : 4≤L) : distance (ZMod 4) L=4 := by
  apply dist_eq 4 (short_logical (by decide))
  intro x hn hm
  apply TwistedLower.ring_lower hl x hn
  exact fun e => hm (e ▸ (C (ZMod 4) L).zero_mem)

theorem field_distance : distance (ZMod 2) L=L := by
  obtain ⟨x,hn,hm,hw⟩ := TwistedFieldDistance.binary_logical_attained (L:=L)
  exact dist_eq L ⟨x,hn,hm,hw.le⟩ TwistedFieldDistance.binary_logical_lower

/-- A family on the exact edges of a square torus: the free signed Z/4
stabilizer has distance four, its coordinatewise field reduction distance L. -/
theorem unbounded_gap (hl : 4≤L) :
    Module.Free (ZMod 4) (C (ZMod 4) L) ∧
    (∀ x∈C (ZMod 4) L,∀ y∈C (ZMod 4) L, pairing x y=0) ∧
    red '' (C (ZMod 4) L : Set (State (ZMod 4) L)) = (C (ZMod 2) L : Set (State (ZMod 2) L)) ∧
    Fintype.card (Site L)=2*L^2 ∧ Nat.card (C (ZMod 4) L)=4^(2*(L^2-1)) ∧
    distance (ZMod 4) L=4 ∧ distance (ZMod 2) L=L := by
  refine ⟨free,fun _ a _ b => isotropy a b,code_reduce,physical_sites,?_,ring_distance hl,field_distance⟩
  simpa [ZMod.card] using subgroup_size (L:=L) (ZMod 4)
#print axioms unbounded_gap
end TwistedGap
