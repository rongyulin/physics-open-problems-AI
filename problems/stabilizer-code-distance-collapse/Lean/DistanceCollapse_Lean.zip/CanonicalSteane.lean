import Mathlib

/-! A eight-site counterexample for the centered systematic CSS lift in Eq. (13)
of Islam, Reza and Gunderman (2026). Vectors and stabilizer spans below are
over the same ring as the Pauli labels. -/
namespace CanonicalSteane
open scoped BigOperators
set_option maxRecDepth 8000
set_option maxHeartbeats 0
abbrev Vec (R : Type*) := Fin 8 → R
def xInteger : Fin 4 → Vec ℤ :=
  ![![-3,-2,-2,-1,-1,-1,0,0],![-2,-3,-2,-1,-1,0,-1,0],
    ![-2,-2,-3,-1,0,-1,-1,0],![-1,-1,-2,0,0,-1,-1,-1]]
def zInteger : Fin 3 → Vec ℤ :=
  ![![1,0,0,-1,-1,-1,0,0],![0,1,0,-1,-1,0,-1,0],![0,0,1,-1,0,-1,-1,0]]
def xs (R : Type*) [CommRing R] (j : Fin 4) (i : Fin 8) : R := (xInteger j i : R)
def zs (R : Type*) [CommRing R] (j : Fin 3) (i : Fin 8) : R := (zInteger j i : R)
def anc (R : Type*) [CommRing R] : Vec R := ![0,0,0,0,0,0,0,1]
def xspan {R : Type*} [CommRing R] (v : Vec R) := ∃ a b c d : R,
    ∀ i,v i=a*xs R 0 i+b*xs R 1 i+c*xs R 2 i+d*xs R 3 i
def zspan {R : Type*} [CommRing R] (v : Vec R) := ∃ a b c : R,
    ∀ i,v i=a*zs R 0 i+b*zs R 1 i+c*zs R 2 i
def xnormal {R : Type*} [CommRing R] (v : Vec R) :=
  ∀ j : Fin 3, (∑ i,v i*zs R j i)=0
def znormal {R : Type*} [CommRing R] (v : Vec R) :=
  ∀ j : Fin 4,(∑ i,v i*xs R j i)=0
def wt {R : Type*} [Zero R] [DecidableEq R] (x z : Vec R) : ℕ :=
    (Finset.univ.filter fun i => x i ≠ 0 ∨ z i ≠ 0).card

/-- The Z pivot block is the identity. Both tails use exactly the centered
binary representatives, and each X pivot is the prescribed entry of -C D^T. -/
theorem centered_systematic_recipe :
    (∀ i j : Fin 3,zInteger i (Fin.castAdd 5 j) = if i=j then 1 else 0) ∧
    (∀ j (k : Fin 5),zInteger j (Fin.natAdd 3 k)=0 ∨ zInteger j (Fin.natAdd 3 k)= -1) ∧
    (∀ j (k : Fin 5),xInteger j (Fin.natAdd 3 k)=0 ∨ xInteger j (Fin.natAdd 3 k)= -1) ∧
    (∀ i j,xInteger i (Fin.castAdd 5 j) =
        -(∑ k : Fin 5,xInteger i (Fin.natAdd 3 k)*zInteger j (Fin.natAdd 3 k))) := by
  decide +kernel

theorem commutes {R : Type*} [CommRing R] (j : Fin 4) : xnormal (xs R j) := by
  intro h
  fin_cases j <;> fin_cases h <;> norm_num [xs,zs,xInteger,zInteger,Fin.sum_univ_succ]

/-- In all moduli greater than two there is a nontrivial single-site X error. -/
theorem target_weight_one (m : ℕ) (hm : 2 < m) :
    xnormal (anc (ZMod m)) ∧ ¬xspan (anc (ZMod m)) ∧ wt (anc (ZMod m)) 0=1 := by
  letI : NeZero m := ⟨by omega⟩
  haveI : Nontrivial (ZMod m) := ZMod.nontrivial_iff.2 (by omega)
  refine ⟨?_,?_,?_⟩
  · intro j
    fin_cases j <;> norm_num [anc,zs,zInteger,Fin.sum_univ_succ]
  · rintro ⟨a,b,c,d,h⟩
    have e3 := h 3
    change 0 = a*((-1 : ℤ) : ZMod m) + b*((-1 : ℤ) : ZMod m) + c*((-1 : ℤ) : ZMod m) + d*((0 : ℤ) : ZMod m) at e3
    have e4 := h 4
    change 0 = a*((-1 : ℤ) : ZMod m) + b*((-1 : ℤ) : ZMod m) + c*((0 : ℤ) : ZMod m) + d*((0 : ℤ) : ZMod m) at e4
    have e5 := h 5
    change 0 = a*((-1 : ℤ) : ZMod m) + b*((0 : ℤ) : ZMod m) + c*((-1 : ℤ) : ZMod m) + d*((-1 : ℤ) : ZMod m) at e5
    have e6 := h 6
    change 0 = a*((0 : ℤ) : ZMod m) + b*((-1 : ℤ) : ZMod m) + c*((-1 : ℤ) : ZMod m) + d*((-1 : ℤ) : ZMod m) at e6
    have e7 := h 7
    change 1 = a*((0 : ℤ) : ZMod m) + b*((0 : ℤ) : ZMod m) + c*((0 : ℤ) : ZMod m) + d*((-1 : ℤ) : ZMod m) at e7
    norm_num at e3 e4 e5 e6 e7
    have bad : (2 : ZMod m)=0 := by linear_combination 2*e3-e4-e5-e6+2*e7
    exact Nat.not_dvd_of_pos_of_lt (by decide) hm ((ZMod.natCast_eq_zero_iff 2 m).mp bad)
  · have sf : (Finset.univ.filter fun i => (anc (ZMod m)) i≠0 ∨ (0 : Vec (ZMod m)) i≠0) = {7} := by
      ext i
      fin_cases i <;> simp [anc]
    simp only [wt,sf,Finset.card_singleton]

theorem x_injective {R : Type*} [CommRing R] (a b c d : R)
    (h : ∀ i,a*xs R 0 i+b*xs R 1 i+c*xs R 2 i+d*xs R 3 i=0) :
    a=0 ∧ b=0 ∧ c=0 ∧ d=0 := by
  have e3 := h 3
  change a*((-1 : ℤ) : R) + b*((-1 : ℤ) : R) + c*((-1 : ℤ) : R) + d*((0 : ℤ) : R) = 0 at e3
  have e4 := h 4
  change a*((-1 : ℤ) : R) + b*((-1 : ℤ) : R) + c*((0 : ℤ) : R) + d*((0 : ℤ) : R) = 0 at e4
  have e5 := h 5
  change a*((-1 : ℤ) : R) + b*((0 : ℤ) : R) + c*((-1 : ℤ) : R) + d*((-1 : ℤ) : R) = 0 at e5
  have e6 := h 6
  change a*((0 : ℤ) : R) + b*((-1 : ℤ) : R) + c*((-1 : ℤ) : R) + d*((-1 : ℤ) : R) = 0 at e6
  have e7 := h 7
  change a*((0 : ℤ) : R) + b*((0 : ℤ) : R) + c*((0 : ℤ) : R) + d*((-1 : ℤ) : R) = 0 at e7
  norm_num at e3 e4 e5 e6 e7
  exact ⟨by linear_combination e3-e4-e5-e7, by linear_combination -e3+e5+e7,
         by linear_combination -e3+e4,e7⟩

theorem z_injective {R : Type*} [CommRing R] (a b c : R)
    (h : ∀ i,a*zs R 0 i+b*zs R 1 i+c*zs R 2 i=0) : a=0 ∧ b=0 ∧ c=0 := by
  have h0 := h 0; have h1 := h 1; have h2 := h 2
  change a*((1:ℤ):R)+b*((0:ℤ):R)+c*((0:ℤ):R)=0 at h0
  change a*((0:ℤ):R)+b*((1:ℤ):R)+c*((0:ℤ):R)=0 at h1
  change a*((0:ℤ):R)+b*((0:ℤ):R)+c*((1:ℤ):R)=0 at h2
  norm_num at h0 h1 h2
  exact ⟨h0,h1,h2⟩

abbrev F := ZMod 2

/-- Separate component bounds avoid enumerating pairs of error vectors. -/
private theorem x_lower : ∀ v : Vec F, xnormal v → wt v 0 ≤ 2 → xspan v := by
  unfold xnormal wt xspan xs zs xInteger zInteger
  decide +kernel
private theorem z_lower : ∀ v : Vec F, znormal v → wt 0 v ≤ 2 → zspan v := by
  unfold znormal wt zspan xs zs xInteger zInteger
  decide +kernel

theorem binary_lower (x z : Vec F) (hx : xnormal x) (hz : znormal z) (w : wt x z ≤ 2) :
    xspan x ∧ zspan z := by
  constructor
  · apply x_lower x hx
    apply le_trans _ w
    apply Finset.card_le_card
    intro i hi
    simp at hi ⊢
    exact Or.inl hi
  · apply z_lower z hz
    apply le_trans _ w
    apply Finset.card_le_card
    intro i hi
    simp at hi ⊢
    exact Or.inr hi

theorem binary_upper :
    ∃ v : Vec F,xnormal v ∧ ¬xspan v ∧ wt v 0=3 := by
  refine ⟨![1,1,0,0,1,0,0,0],?_⟩
  unfold xnormal wt xspan xs zs xInteger zInteger
  decide +kernel

#print axioms centered_systematic_recipe
#print axioms target_weight_one
#print axioms binary_lower
#print axioms binary_upper
end CanonicalSteane
