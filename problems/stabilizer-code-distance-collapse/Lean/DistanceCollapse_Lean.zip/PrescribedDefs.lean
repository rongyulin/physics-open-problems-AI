import Counterexample
/-! A direct check of the lower triangular local-dimension-invariant lift
specified in Gunderman's Theorem 8. -/
namespace PrescribedLDI
open CyclicPauli FrobeniusCounterexample
open scoped BigOperators
set_option maxHeartbeats 0
set_option maxRecDepth 1000000
abbrev Site := Fin 7
abbrev Row := Fin 6

def raw : Row → Labels ℤ 7 := ![![(1,0),(0,0),(0,0),(0,1),(0,0),(0,1),(1,0)],![(0,1),(1,0),(0,1),(0,0),(0,1),(0,1),(0,1)],![(0,0),(0,1),(1,0),(0,1),(0,1),(0,0),(0,0)],![(0,0),(0,0),(0,1),(1,0),(0,0),(0,1),(0,1)],![(0,1),(0,1),(0,1),(0,0),(1,1),(0,1),(0,1)],![(0,0),(0,0),(0,0),(0,0),(0,0),(1,0),(1,1)]]
def lifted : Row → Labels ℤ 7 := ![![(1,0),(0,0),(0,0),(0,1),(0,0),(0,1),(1,0)],![(0,-1),(1,0),(0,1),(0,0),(0,1),(0,1),(0,1)],![(0,0),(0,1),(1,0),(0,1),(0,1),(0,0),(0,0)],![(0,0),(0,0),(0,1),(1,0),(0,0),(0,1),(0,1)],![(0,-1),(0,1),(0,1),(0,0),(1,1),(0,1),(0,1)],![(0,0),(0,2),(0,0),(0,2),(0,2),(1,0),(1,1)]]

/-- Only the strictly lower triangular part of the leading phase block changes. -/
def recipe (q : Row → Labels ℤ 7) (g : Row) (i : Site) : ℤ × ℤ :=
  ((q g i).1, (q g i).2 + if h : i.val<g.val then
    bracket (q g) (q ⟨i.val,by omega⟩) else 0)

theorem prescribed : (∀ g i, (raw g i).1∈({0,1}:Finset ℤ) ∧ (raw g i).2∈({0,1}:Finset ℤ)) ∧
    (∀ g i : Row, (raw g i.castSucc).1 = if g=i then 1 else 0) ∧
    ∀ (g : Row) (i : Site), recipe raw g i = lifted g i := by decide +kernel

variable {R : Type*} [CommRing R]
def enc (c : Row → R) : Labels R 7 := ![(c 0,-c 1-c 4),(c 1,c 2+c 4+2*c 5),(c 2,c 1+c 3+c 4),(c 3,c 0+c 2+2*c 5),(c 4,c 1+c 2+c 4+2*c 5),(c 5,c 0+c 1+c 3+c 4),(c 0+c 5,c 1+c 3+c 4+c 5)]

def encoder (R : Type*) [CommRing R] : (Row→R) →ₗ[R] Labels R 7 where
  toFun := enc
  map_add' a b := by funext i; fin_cases i <;> apply Prod.ext <;> dsimp [enc] <;> ring
  map_smul' c a := by funext i; fin_cases i <;> apply Prod.ext <;> dsimp [enc] <;> ring

def code (R : Type*) [CommRing R] := LinearMap.range (encoder R)
def rowR (g : Row) : Labels R 7 := enc (Pi.single g 1)

theorem integer_matrix : ∀ (g : Row) (i : Site), rowR (R:=ℤ) g i=lifted g i := by decide +kernel
theorem binary_matrix : ∀ (g : Row) (i : Site), rowR (R:=ZMod 2) g i=
    (((raw g i).1:ZMod 2),((raw g i).2:ZMod 2)) := by decide +kernel

theorem pivot (c : Row→R) (i : Row) : (enc c i.castSucc).1=c i := by fin_cases i <;> rfl

theorem independent : Function.Injective (enc (R:=R)) := by
  intro a b e
  funext i
  simpa only [pivot] using congrArg (fun x: Labels R 7 => (x i.castSucc).1) e

theorem isotropic (R : Type*) [CommRing R] : Isotropic (code R) := by
  rintro _ ⟨a,rfl⟩ _ ⟨b,rfl⟩
  change bracket (enc a) (enc b)=0
  simp [enc,bracket,Fin.sum_univ_succ] <;> ring

def short (R : Type*) [CommRing R] : Labels R 7 :=
  ![0,0,0,0,0,(1,-2),(-1,1)]

theorem short_normal (R : Type*) [CommRing R] (y) (hy:y∈code R) :
    bracket (short R) y=0 := by
  obtain ⟨c,rfl⟩ := hy
  change bracket (short R) (enc c)=0
  simp [short,enc,bracket,Fin.sum_univ_succ] <;> ring

theorem short_logical (R : Type*) [CommRing R] (h2 : (2:R)≠0) :
    logical (code R) (short R) := by
  refine ⟨short_normal R,?_⟩
  rintro ⟨c,e⟩
  change enc c = short R at e
  have ce (i : Row) : c i = (short R i.castSucc).1 := by
    rw [←e,pivot]
  have t := congrArg (fun x:Labels R 7 => (x 6).1) e
  change c 0 + c 5 = -1 at t
  simp only [ce] at t
  change (0:R)+1 = -1 at t
  exact h2 (by linear_combination t)

theorem short_weight (R : Type*) [CommRing R] [DecidableEq R] [Nontrivial R] :
    wt (short R)=2 := by
  have s : (Finset.univ.filter fun i:Site=>short R i≠0) = {5,6} := by
    ext i; fin_cases i <;> simp [short,Prod.mk.injEq]
  simp [wt,s]

end PrescribedLDI
