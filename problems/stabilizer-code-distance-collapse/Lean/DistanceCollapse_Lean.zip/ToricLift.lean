import Mathlib

/-! A local modification of the square toric CSS checks.  Coordinates `h i j`
and `v i j` label the horizontal and vertical edges entering vertex `(i,j)`. -/
namespace ToricLift

abbrev Grid (R : Type*) (L : ℕ) := ZMod L → ZMod L → R
abbrev Chains (R : Type*) (L : ℕ) := Grid R L × Grid R L × (ZMod L → R)

variable {L : ℕ} [NeZero L] {R : Type*} [CommRing R]

def xcheck (u : Grid R L) : Chains R L :=
  (fun i j => u (i-1) j - u i j, fun i j => u i (j-1) - u i j, fun i => -2 * u i 0)

def zcheck (b : Grid R L) (t : ZMod L → R) : Chains R L :=
  (fun i j => b i (j+1) - b i j + (if j=0 then 2*t (i-1) else 0),
   fun i j => b i j - b (i+1) j,
   fun i => t i - (if i=0 then 0 else t (i-1)))

def dot (x z : Chains R L) : R :=
  (∑ i, ∑ j, x.1 i j * z.1 i j) +
  (∑ i, ∑ j, x.2.1 i j * z.2.1 i j) + ∑ i, x.2.2 i * z.2.2 i

def anchor : Chains R L :=
  (0, 0, fun i => if i=0 then 1 else 0)

lemma shiftSum (f : ZMod L → R) (s : ZMod L) :
    (∑ i, f (i+s)) = ∑ i, f i := Equiv.sum_comp (Equiv.addRight s) f

lemma shiftPair (f g : ZMod L → R) :
    (∑ i, f (i-1) * g i) = ∑ i, f i * g (i+1) := by
  simpa [sub_eq_add_neg, add_assoc] using
    (shiftSum (fun i => f i * g (i+1)) (-1))

lemma summationByParts (u h v : Grid R L) :
    (∑ i, ∑ j, (u (i-1) j - u i j) * h i j) +
      (∑ i, ∑ j, (u i (j-1) - u i j) * v i j) =
    ∑ i, ∑ j, u i j * (h (i+1) j - h i j + v i (j+1) - v i j) := by
  have hx : (∑ i, ∑ j, u (i-1) j * h i j) = ∑ i, ∑ j, u i j * h (i+1) j := by
    rw [Finset.sum_comm, Finset.sum_comm (f := fun i j => u i j * h (i+1) j)]
    exact Finset.sum_congr rfl fun j _ => shiftPair (fun i => u i j) (fun i => h i j)
  have hy : (∑ i, ∑ j, u i (j-1) * v i j) = ∑ i, ∑ j, u i j * v i (j+1) := by
    exact Finset.sum_congr rfl fun i _ => shiftPair (u i) (v i)
  simp only [sub_mul, mul_sub, mul_add, Finset.sum_sub_distrib, Finset.sum_add_distrib]
  rw [hx, hy]
  ring

theorem local_checks_commute (u b : Grid R L) (t : ZMod L → R) (hu : u 0 0 = 0) :
    dot (xcheck u) (zcheck b t) = 0 := by
  unfold dot xcheck zcheck
  dsimp only
  rw [summationByParts]
  have hc (i j : ZMod L) :
      b (i+1) (j+1) - b (i+1) j + (if j=0 then 2*t (i+1-1) else 0)
        - (b i (j+1) - b i j + (if j=0 then 2*t (i-1) else 0)) +
        (b i (j+1)-b (i+1) (j+1)) - (b i j - b (i+1) j) =
      (if j=0 then 2*(t i - t (i-1)) else 0) := by
    split_ifs <;> simp <;> ring
  simp_rw [hc, mul_ite, mul_zero]
  simp only [Finset.sum_ite_eq', Finset.mem_univ, if_true]
  rw [← Finset.sum_add_distrib]
  apply Finset.sum_eq_zero
  intro i _
  by_cases hi : i=0
  · subst i; simp [hu]
  · simp [hi]; ring

theorem anchor_commutes (u : Grid R L) (hu : u 0 0 = 0) :
    dot (xcheck u) (anchor : Chains R L) = 0 := by
  simp [dot,xcheck,anchor,mul_ite,hu]

/-- Flux through the vertical cut at class 1 detects twice the stitch at class 0. -/
theorem anchor_not_boundary (b : Grid (ZMod 4) L) (t : ZMod L → ZMod 4) :
    zcheck b t ≠ anchor := by
  intro eq
  have ht := congrArg (fun x : Chains (ZMod 4) L => x.2.2 0) eq
  change t 0 - (if (0 : ZMod L) = 0 then 0 else t (0-1)) = (if (0 : ZMod L) = 0 then 1 else 0) at ht
  simp at ht
  have cut := congrArg (fun x : Chains (ZMod 4) L => ∑ j, x.1 1 j) eq
  simp [zcheck, anchor, Finset.sum_add_distrib, Finset.sum_sub_distrib, shiftSum, ht] at cut
  exact (by decide : (2 : ZMod 4) ≠ 0) cut

omit [CommRing R] in
lemma cyclic_constant (f : ZMod L → R) (h : ∀ i, f (i+1) = f i) (i : ZMod L) : f i = f 0 := by
  have H (m : ℕ) : f m = f 0 := by
    induction m with
    | zero => simp
    | succ m ih => simpa only [Nat.cast_succ] using (h (m : ZMod L)).trans ih
  simpa using H i.val

lemma stitch_kernel (t : ZMod L → R)
    (h : ∀ i, t i - (if i=0 then 0 else t (i-1)) = 0) : t = 0 := by
  have h0 : t 0 = 0 := by simpa using h 0
  have H (m : ℕ) (hm : m < L) : t m = 0 := by
    induction m with
    | zero => simpa using h0
    | succ m ih =>
      have ne : ((m+1 : ℕ) : ZMod L) ≠ 0 := by
        rw [Ne, ZMod.natCast_eq_zero_iff]
        exact Nat.not_dvd_of_pos_of_lt (Nat.succ_pos _) hm
      simpa [ne, Nat.cast_succ, ih (by omega)] using h ((m+1 : ℕ) : ZMod L)
  funext i
  simpa using H i.val i.val_lt

theorem xcheck_kernel (u : Grid R L) (hu : u 0 0=0) (h : xcheck u = 0) : u = 0 := by
  have a (i j : ZMod L) := congrArg (fun x : Chains R L => x.1 (i+1) j) h
  have b (i j : ZMod L) := congrArg (fun x : Chains R L => x.2.1 i (j+1)) h
  simp [xcheck, sub_eq_zero] at a b
  funext i j
  calc u i j = u 0 j := cyclic_constant (fun z => u z j) (fun z => (a z j).symm) _
       _ = u 0 0 := cyclic_constant (u 0) (fun z => (b 0 z).symm) _
       _ = _ := hu

theorem zcheck_kernel (b : Grid R L) (t : ZMod L → R) (hb : b 0 0=0)
    (h : zcheck b t = 0) : b = 0 ∧ t = 0 := by
  have c (i : ZMod L) := congrArg (fun x : Chains R L => x.2.2 i) h
  have ht : t = 0 := stitch_kernel t c
  subst t
  have a (i j : ZMod L) := congrArg (fun x : Chains R L => x.1 i j) h
  have v (i j : ZMod L) := congrArg (fun x : Chains R L => x.2.1 i j) h
  simp [zcheck, sub_eq_zero] at a v
  refine ⟨?_,rfl⟩
  funext i j
  calc b i j = b 0 j := cyclic_constant (fun z => b z j) (fun z => (v z j).symm) _
       _ = b 0 0 := cyclic_constant (b 0) (fun z => a 0 z) _
       _ = _ := hb

end ToricLift
