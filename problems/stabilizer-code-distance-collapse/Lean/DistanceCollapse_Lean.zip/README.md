# Reproducing the distance comparisons

The Lean sources use Lean 4.28.0 and mathlib commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365`. The project checks cyclic Pauli labels on the physical sites. A logical operator commutes with every check and is outside the generated stabilizer. The weight counts a site once even if its two coordinates are both nonzero.

With the pinned Lean toolchain available through elan, from the directory containing `lakefile.toml` run

```sh
lake exe cache get
bash audit.sh
```

The manifest pins the dependency revisions. The audit script builds the project modules one at a time in a fresh temporary directory. It then runs the Lean distribution's `leanchecker` in a separate process for each module. This shares Lean's kernel implementation and the pinned imported mathlib. It checks every project module's declarations from their imports and emits the names of the modules replayed. Python 3.11 or newer is used to read the Lake configuration. The proofs need neither an external solver nor the Python numerical checks. Source files are included without precompiled project objects.

## Results

- `Counterexample.lean` gives the five-site free-module counterexample, with both distances attained, and equality of the full reduction image with the given binary code. `Characteristic.lean` extends the distance-one conclusion to all moduli above two.
- `PrescribedDefs.lean` compares the original binary check matrix, its prescribed triangular integer lift, and the row-space encoder. `PrescribedLDI.lean`, `PrescribedExact.lean` and `PrescribedCoefficients.lean` give the seven-site distances, exact matrix and coefficient checks.
- `CanonicalSteane.lean` verifies the centered CSS construction, the free rows, and distance loss from three to one on eight sites.
- `TwistedGap.lean` proves the square-torus gap for every size at least four using the actual check modules, their reduction and the joint physical site weight.
- `UniversalTorus.lean` combines a witness and a lower bound for the same torus over every cyclic local dimension above two. `ToricAllRings.lean` proves the lower bound on the physical support from a signed incidence kernel.
- `CanonicalCycle.lean` treats the alternating functional for the centered CSS algorithm on even cycles. Its theorem takes the restriction of the binary rows to the cycle and ancillary column as hypotheses. The paper supplies the spanning-tree construction that realizes these hypotheses on a torus.
- `SupportRank.lean` formalizes the field dimension identity for support-restricted logical classes and the equivalence with existence of a nontrivial logical Pauli. The cyclic Smith counting formula is proved on paper.
- The single-file `standalone/DistanceCollapse.lean` presents the five-, seven- and eight-site distance comparisons in one theorem, `distance_collapse_examples`. Run it with `lake env lean standalone/DistanceCollapse.lean` in the pinned mathlib environment.

## Independent calculations

The three scripts use only the Python standard library. Run them from the extracted project directory.

```sh
python3 checks/check_small_codes.py
python3 checks/twisted_audit.py
python3 checks/canonical_torus.py 4 6 8 10
```

The numerical calculations accompany the symbolic proofs. `twisted_audit.py` also tests a uniform sign convention for odd periods, a variant of the full-check model discussed by Watanabe, Cheng and Fuji. Source checksums, build and replay transcripts are in `evidence/`.
