import Counterexample

namespace FrobeniusCounterexample
open CyclicPauli

/-- The same integral generators give distance one for every coefficient ring
in which two is nonzero.  The field family therefore has no large-prime cutoff. -/
theorem distance_eq_one_of_two_ne_zero (R : Type*) [CommRing R] [DecidableEq R]
    (two_ne : (2 : R) ≠ 0) : relativeDistance (code R) = 1 := by
  let z : Labels R 5 := ![(0,1),0,0,0,0]
  have one_ne : (1 : R) ≠ 0 := fun h => two_ne (by rw [show (2:R)=1+1 by ring,h,add_zero])
  have hz : logical (code R) z := by
    constructor
    · rintro _ ⟨a,rfl⟩
      change bracket z (enc a)=0
      simp [bracket,z,enc,Fin.sum_univ_succ]
    · rintro ⟨a,h⟩
      have h0 := congrArg (fun x : Labels R 5 => (x 0).2) h
      have h1 := congrArg (fun x : Labels R 5 => (x 1).2) h
      have h3 := congrArg (fun x : Labels R 5 => (x 3).2) h
      change a 0=1 at h0
      change 2*a 0+a 2=0 at h1
      change -a 2=0 at h3
      exact two_ne (by simpa [h0,neg_eq_zero.mp h3] using h1)
  have hw : wt z = 1 := by
    have he : Finset.univ.filter (fun i => z i ≠ 0) = {0} := by
      ext j
      fin_cases j <;> simp [z,one_ne]
    simp [wt, he]
  unfold relativeDistance
  apply le_antisymm
  · exact Nat.sInf_le ⟨z,hz,hw⟩
  · apply le_csInf (s := {w | ∃ x : Labels R 5, logical (code R) x ∧ wt x = w}) ⟨1,z,hz,hw⟩
    rintro _ ⟨x,h,rfl⟩
    obtain ⟨i,hi⟩ : ∃ i, x i ≠ 0 := by
      by_contra! e
      exact h.2 (funext e ▸ (code R).zero_mem)
    exact Finset.card_pos.mpr ⟨i,Finset.mem_filter.mpr ⟨Finset.mem_univ i, hi⟩⟩

theorem distance_all_moduli {m : ℕ} (hm : 2 < m) : relativeDistance (code (ZMod m)) = 1 := by
  have h : ¬m ∣ 2 := Nat.not_dvd_of_pos_of_lt (by decide) hm
  exact distance_eq_one_of_two_ne_zero _ (by simpa using (ZMod.natCast_eq_zero_iff 2 m).not.mpr h)

#print axioms distance_all_moduli
end FrobeniusCounterexample
