import ToricAllRings
import TwistedGap

/-! The same four-edge logical operator is optimal over any commutative ring
where the two sign transports are distinct, including every cyclic alphabet
with more than two levels. -/
namespace UniversalTorus
open TwistedCode TwistedGap
variable {L : ℕ} [NeZero L]

theorem exact_distance {R : Type*} [CommRing R] [DecidableEq R] (hL : 4≤L) (h₂ : (2:R)≠0) :
    Normal (omitted R L) ∧ omitted R L∉C R L ∧ stateWeight (omitted R L)=4 ∧ distance R L=4 := by
  have notmem : omitted R L∉C R L := omitted_not_mem h₂
  have lower (u : State R L) (hn : Normal u) (hm : u∉C R L) : 4≤stateWeight u :=
    ToricAllRings.normalizer_lower hL u hn (fun eq => hm (eq ▸ (C R L).zero_mem))
  have eqw : stateWeight (omitted R L)=4 :=
    le_antisymm omitted_weight_le (lower _ omitted_normal notmem)
  have mem : 4∈ {w | ∃ u : State R L, Normal u ∧ u∉C R L ∧ stateWeight u=w} :=
    ⟨omitted R L,omitted_normal,notmem,eqw⟩
  refine ⟨omitted_normal,notmem,eqw,le_antisymm (Nat.sInf_le mem) (le_csInf ⟨4,mem⟩ ?_)⟩
  rintro _ ⟨u,hn,hm,rfl⟩
  exact lower u hn hm

theorem cyclic_distance (m : ℕ) (hm : 2 < m) (hL : 4≤L) : distance (ZMod m) L=4 := by
  have h₂ : (2 : ZMod m)≠0 := by
    exact_mod_cast (show ((2:ℕ):ZMod m) ≠ 0 from
      fun e => Nat.not_dvd_of_pos_of_lt (by decide : 0 < 2) hm ((ZMod.natCast_eq_zero_iff _ _).mp e))
  exact (exact_distance hL h₂).2.2.2

/-- A single family, with the binary distance and every larger cyclic alphabet
evaluated for the same period, physical sites and sign convention. -/
theorem universal_gap (m : ℕ) (hm : 2 < m) (hL : 4≤L) :
    distance (ZMod 2) L=L ∧ distance (ZMod m) L=4 :=
  ⟨TwistedGap.field_distance,cyclic_distance m hm hL⟩

#print axioms universal_gap
#print axioms cyclic_distance
end UniversalTorus
