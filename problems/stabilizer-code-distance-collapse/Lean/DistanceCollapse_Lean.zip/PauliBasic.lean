import Mathlib

/-! Canonical cyclic Pauli labels with one position and one phase coordinate per site. -/
namespace CyclicPauli

abbrev Labels (R : Type*) (n : ℕ) := Fin n → R × R

def bracket {R : Type*} [CommRing R] {n : ℕ} (x y : Labels R n) : R :=
  ∑ i, ((x i).1 * (y i).2 - (x i).2 * (y i).1)

def supported {R : Type*} [Zero R] {n : ℕ} (S : Finset (Fin n))
    (x : Labels R n) : Prop := ∀ i, i ∉ S → x i = 0

def Far {R : Type*} [CommRing R] {n : ℕ}
    (L : Submodule R (Labels R n)) (δ : ℕ) : Prop :=
  ∀ x, (∀ y ∈ L, bracket x y = 0) →
    ∀ S : Finset (Fin n), S.card < δ → supported S x → x = 0

def Isotropic {R : Type*} [CommRing R] {n : ℕ}
    (L : Submodule R (Labels R n)) : Prop :=
  ∀ x ∈ L, ∀ y ∈ L, bracket x y = 0

end CyclicPauli
