import Mathlib

/-! A signed incidence kernel over any commutative ring cannot have a smaller
support than the corresponding binary kernel. A column has at most two
incident rows, with a unit coefficient at each of them. -/
namespace SignedIncidence
open scoped BigOperators
noncomputable section
variable {E V R : Type*} [Fintype E] [Fintype V] [DecidableEq E] [DecidableEq V]
  [CommRing R] [DecidableEq R]
local notation "F" => ZMod 2

private theorem truncated_sum {M : Type*} [AddCommMonoid M] (S : Finset E) (f : E → M)
    (hz : ∀ e,e∉S → f e=0) : ∑ e,f e = ∑ e : S,f e.val := by
  calc
    _ = ∑ e∈S,f e := (Finset.sum_subset (Finset.subset_univ _) (fun e _ h => hz e h)).symm
    _ = _ := (Finset.sum_attach S f).symm

theorem kernel_transfer (inc : E → Finset V) (cf : V → E → R)
    (two : ∀ e,(inc e).card≤2) (units : ∀ v e,v∈inc e → IsUnit (cf v e))
    (missing : ∀ v e,v∉inc e → cf v e=0) (x : E→R) (xn : x≠0)
    (kernel : ∀ v,∑e,cf v e*x e=0) :
    ∃ y:E→F, y≠0 ∧ (∀e,x e=0 → y e=0) ∧ ∀v,∑e, (if v∈inc e then y e else 0)=0 := by
  classical
  let S := Finset.univ.filter (fun e => x e≠0)
  let U := S.biUnion inc
  let N (v : V) := S.filter (fun e => v∈inc e)
  have supp (e) : e∈S ↔ x e≠0 := by simp [S]
  have snon : S.Nonempty := by
    by_contra! empty
    apply xn
    funext e
    have : e∉S := by simp [empty]
    simpa [supp] using this
  have count (v) (hv : v∈U) : 2 ≤ (N v).card := by
    obtain ⟨e,he,hit⟩ := Finset.mem_biUnion.mp hv
    have pos : 0 < (N v).card := Finset.card_pos.mpr ⟨e,Finset.mem_filter.mpr ⟨he,hit⟩⟩
    by_contra! small
    obtain ⟨q,only⟩ := Finset.card_eq_one.mp (show (N v).card=1 by omega)
    have hq : q∈N v := by rw [only]; simp
    obtain ⟨qs,qhit⟩ := Finset.mem_filter.mp hq
    have van : cf v q * x q=0 := by
      have hk := kernel v
      rwa [Finset.sum_eq_single q] at hk
      · intro i _ ne
        by_cases hi : x i=0
        · rw [hi,mul_zero]
        · have no : v∉inc i := by
            intro yes
            have : i∈N v := Finset.mem_filter.mpr ⟨(supp i).mpr hi,yes⟩
            rw [only,Finset.mem_singleton] at this
            exact ne this
          rw [missing v i no,zero_mul]
      · simp
    exact ((supp q).mp qs) ((units v q qhit).mul_right_eq_zero.mp van)
  have total : (∑ v∈U,(N v).card) ≤ S.card*2 := by
    calc
      _ = ∑ e∈S,(U.filter (fun v => v∈inc e)).card := by
        simp only [N,Finset.card_filter]
        rw [Finset.sum_comm]
      _ ≤ ∑ e∈S,2 := Finset.sum_le_sum (fun e _ =>
        (Finset.card_le_card (show U.filter (fun v => v∈inc e) ⊆ inc e from
          fun v h => (Finset.mem_filter.mp h).2)).trans (two e))
      _ = _ := by simp
  by_cases few : U.card<S.card
  · let M : Matrix U S F := fun v e => if v.val∈inc e.val then 1 else 0
    have kr : LinearMap.ker M.toLin' ≠ ⊥ := LinearMap.ker_ne_bot_of_finrank_lt (by simpa using few)
    obtain ⟨b,hb,bn⟩ := Submodule.exists_mem_ne_zero_of_ne_bot kr
    let y (e : E) := if he:e∈S then b ⟨e,he⟩ else 0
    have yesc (e:S) : y e.val = b e := by simp [y,e.property]
    have nob (e) (he:e∉S) : y e=0 := by simp [y,he]
    refine ⟨y,?_,fun e he => nob e (fun hy => (supp e).mp hy he),?_⟩
    · intro yz
      apply bn
      funext e
      rw [←yesc]
      exact congrFun yz e.val
    · intro v
      rw [truncated_sum S _ (fun e he => by rw [nob e he]; simp)]
      by_cases hv : v∈U
      · have z := congrFun (LinearMap.mem_ker.mp hb) ⟨v,hv⟩
        change (∑ e:S,M ⟨v,hv⟩ e * b e)=0 at z
        simpa [M,yesc,ite_mul] using z
      · have off (i : S) : v∉inc i.val := fun hh => hv (Finset.mem_biUnion.mpr ⟨i.val,i.property,hh⟩)
        simp [off]
  · have exactCount (v) (hv : v∈U) : (N v).card=2 := by
      have eq := count v hv
      by_contra ne
      have lt : (∑ _v∈U,2) < ∑ j∈U,(N j).card :=
        Finset.sum_lt_sum count ⟨v,hv,by omega⟩
      have bad : U.card*2 < ∑ j∈U,(N j).card := by simpa using lt
      omega
    let y (e:E) : F := if e∈S then 1 else 0
    refine ⟨y,?_,fun e he => if_neg (fun h => (supp e).mp h he),?_⟩
    · obtain ⟨i,hi⟩ := snon
      intro hz
      have one := congrFun hz i
      simpa [y,hi] using one
    · intro v
      have enc : (∑ e,if v∈inc e then y e else 0) = ((N v).card:F) := by
        have trunc : (∑ e,if v∈inc e then y e else 0) =
            ∑ e∈S,if v∈inc e then y e else 0 :=
          (Finset.sum_subset (Finset.subset_univ _) (fun e _ he => by simp [y,he])).symm
        rw [trunc]
        simp only [N,Finset.card_filter,Nat.cast_sum,Nat.cast_ite,Nat.cast_one,Nat.cast_zero,y]
        apply Finset.sum_congr rfl
        intro i hi
        simp [hi]
      rw [enc]
      by_cases hv:v∈U
      · rw [exactCount v hv]; decide
      · have emp : N v=∅ := Finset.eq_empty_iff_forall_notMem.mpr (fun i hi =>
          hv (Finset.mem_biUnion.mpr ⟨i,(Finset.mem_filter.mp hi).1,(Finset.mem_filter.mp hi).2⟩))
        simp [emp]

#print axioms kernel_transfer
end
end SignedIncidence
