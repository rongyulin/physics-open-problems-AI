import Mathlib

/-! The square binary toric code. Edges are indexed by the vertex they enter.
A closed chain of fewer than L edges has an empty cut in each direction, so
it has zero winding and is the boundary of a sum of plaquettes. -/
namespace ToricBinary
open scoped BigOperators
variable {L : ℕ} [NeZero L]
abbrev Grid (L : ℕ) := ZMod L → ZMod L → ZMod 2

def Closed (h v : Grid L) : Prop :=
  ∀ i j, h (i+1) j - h i j + v i (j+1) - v i j = 0

def Boundary (h v : Grid L) : Prop :=
  ∃ f : Grid L, (∀ i j, h i j = f i (j+1)-f i j) ∧
    ∀ i j, v i j = f i j - f (i+1) j

def occupation (h : Grid L) : ℕ :=
  ((Finset.univ : Finset (ZMod L × ZMod L)).filter (fun ij => h ij.1 ij.2 ≠ 0)).card

def weight (h v : Grid L) : ℕ := occupation h + occupation v

theorem constant_of_step (g : ZMod L → ZMod 2) (hg : ∀ i,g (i+1)=g i)
    (i : ZMod L) : g i = g 0 := by
  have h (k : ℕ) : g (k:ZMod L)=g 0 := by
    induction k with
    | zero => simp
    | succ k ih => rw [Nat.cast_succ,hg,ih]
  simpa using h i.val

private def period (g : ZMod L → ZMod 2) := ∑ j ∈ Finset.range L, g (j:ZMod L)

omit [NeZero L] in
private theorem period_delta (g : ZMod L → ZMod 2) :
    period (fun j => g (j+1)-g j) = 0 := by
  have e (m : ℕ) : (∑ j ∈ Finset.range m, (g ((j:ZMod L)+1)-g j)) =
      g (m:ZMod L)-g 0 := by
    induction m with
    | zero => simp
    | succ m ih => rw [Finset.sum_range_succ,ih,Nat.cast_succ]; abel
  simpa [period] using e L

private theorem exists_primitive (g : ZMod L → ZMod 2) (hg : period g = 0) :
    ∃ f : ZMod L → ZMod 2, ∀ j, f (j+1)-f j = g j := by
  let f (j : ZMod L) := ∑ k ∈ Finset.range j.val, g (k:ZMod L)
  refine ⟨f,fun j => ?_⟩
  have c : ((j.val+1 : ℕ):ZMod L) = j+1 := by simp
  by_cases lt : j.val+1<L
  · have e : (j+1).val=j.val+1 := by rw [← c,ZMod.val_natCast_of_lt lt]
    simp [f,e,Finset.sum_range_succ]
  · have eL : j.val+1=L := by have := j.val_lt; omega
    have e : j+1=0 := by rw [← c,eL,ZMod.natCast_self]
    have full : (∑ k ∈ Finset.range j.val,g (k:ZMod L)) + g j=0 := by
      calc
        _ = ∑ k ∈ Finset.range (j.val+1),g (k:ZMod L) := by
          rw [Finset.sum_range_succ,ZMod.natCast_zmod_val]
        _ = ∑ k ∈ Finset.range L,g (k:ZMod L) :=
          congrArg (fun m : ℕ => ∑ k ∈ Finset.range m,g (k:ZMod L)) eL
        _ = 0 := hg
    rw [e]
    simp only [f,ZMod.val_zero,Finset.range_zero,Finset.sum_empty,zero_sub]
    linear_combination -full

/-- Construct the filling potential. The missing cuts need not be adjacent to
the coordinate origin. -/
theorem boundary_of_empty_cuts (h v : Grid L) (hc : Closed h v)
    (i₀ j₀ : ZMod L) (hh : ∀ j,h i₀ j=0) (hv : ∀ i,v i j₀=0) : Boundary h v := by
  have hpstep (i : ZMod L) : period (h (i+1))=period (h i) := by
    have es := period_delta (v i)
    have pt (j : ℕ) : h (i+1) (j:ZMod L) - h i j = -(v i ((j:ZMod L)+1)-v i j) := by
      linear_combination hc i (j:ZMod L)
    have he := Finset.sum_congr (s₁ := Finset.range L) rfl (fun j _ => pt j)
    rw [Finset.sum_sub_distrib,Finset.sum_neg_distrib] at he
    change period (h (i+1)) - period (h i) = -period (fun j => v i (j+1)-v i j) at he
    rw [es,neg_zero] at he
    exact sub_eq_zero.mp he
  have hp (i : ZMod L) : period (h i)=0 := by
    rw [(constant_of_step (fun a => period (h a)) hpstep i).trans (constant_of_step (fun a => period (h a)) hpstep i₀).symm]
    simp [period,hh]
  choose p hp using fun i => exists_primitive (h i) (hp i)
  let f (i j : ZMod L) := p i j - p i j₀
  have d (i j : ZMod L) : f i (j+1) - f i j = h i j := by
    dsimp [f]; linear_combination hp i j
  let w (i j : ZMod L) := f (i+1) j - f i j + v i j
  have ws (i j : ZMod L) : w i (j+1)=w i j := by
    dsimp [w]
    linear_combination d (i+1) j - d i j + hc i j
  refine ⟨f,fun i j => (d i j).symm, fun i j => ?_⟩
  have hw := (constant_of_step (w i) (ws i) j).trans (constant_of_step (w i) (ws i) j₀).symm
  have woh : w i j₀=0 := by simp [w,f,hv]
  rw [woh] at hw
  dsimp [w] at hw
  linear_combination hw

theorem empty_horizontal (h : Grid L) (small : occupation h < L) :
    ∃ i, ∀ j,h i j=0 := by
  classical
  by_contra! hn
  choose j hj using hn
  let s := (Finset.univ : Finset (ZMod L × ZMod L)).filter (fun ij => h ij.1 ij.2≠0)
  have le : (Finset.univ : Finset (ZMod L)).card ≤ s.card :=
    Finset.card_le_card_of_injOn (fun i => (i,j i)) (by intro i _; simpa [s] using hj i)
      (by intro a _ b _ he; exact congrArg Prod.fst he)
  have := (by simpa [s,occupation] using le : L ≤ occupation h)
  omega

theorem empty_vertical (v : Grid L) (small : occupation v < L) :
    ∃ j, ∀ i,v i j=0 := by
  classical
  by_contra! hn
  choose i hi using hn
  let s := (Finset.univ : Finset (ZMod L × ZMod L)).filter (fun ij => v ij.1 ij.2≠0)
  have le : (Finset.univ : Finset (ZMod L)).card ≤ s.card :=
    Finset.card_le_card_of_injOn (fun j => (i j,j)) (by intro j _; simpa [s] using hi j)
      (by intro a _ b _ he; exact congrArg Prod.snd he)
  have := (by simpa [s,occupation] using le : L ≤ occupation v)
  omega

theorem low_weight_boundary (h v : Grid L) (hc : Closed h v) (small : weight h v < L) :
    Boundary h v := by
  unfold weight at small
  obtain ⟨i,hi⟩ := empty_horizontal h (by omega)
  obtain ⟨j,hj⟩ := empty_vertical v (by omega)
  exact boundary_of_empty_cuts h v hc i j hi hj

theorem distance (h v : Grid L) (hc : Closed h v) (hb : ¬Boundary h v) :
    L ≤ weight h v := le_of_not_gt fun lt => hb (low_weight_boundary h v hc lt)

def Coclosed (h v : Grid L) : Prop :=
  ∀ i j, h i (j-1) - h i j + v i j - v (i-1) j = 0

def Coboundary (h v : Grid L) : Prop :=
  ∃ u : Grid L, (∀ i j, h i j = u (i-1) j - u i j) ∧
    ∀ i j, v i j = u i (j-1) - u i j

theorem occupation_reverse (h : Grid L) :
    occupation (fun i j => h (-i) (-j)) = occupation h := by
  classical
  let s := (Finset.univ : Finset (ZMod L × ZMod L)).filter (fun ij => h (-ij.1) (-ij.2) ≠ 0)
  let t := (Finset.univ : Finset (ZMod L × ZMod L)).filter (fun ij => h ij.1 ij.2 ≠ 0)
  let e : ↥s ≃ ↥t := {
    toFun := fun q => ⟨(-q.val.1,-q.val.2),Finset.mem_filter.mpr
      ⟨Finset.mem_univ _,(Finset.mem_filter.mp q.property).2⟩⟩
    invFun := fun q => ⟨(-q.val.1,-q.val.2),Finset.mem_filter.mpr
      ⟨Finset.mem_univ _,by simpa only [neg_neg] using (Finset.mem_filter.mp q.property).2⟩⟩
    left_inv := fun q => by ext <;> simp
    right_inv := fun q => by ext <;> simp }
  change s.card=t.card
  simpa only [Fintype.card_coe] using Fintype.card_congr e

/-- The corresponding filling theorem on the dual square lattice. -/
theorem low_weight_coboundary (h v : Grid L) (hc : Coclosed h v) (small : weight h v<L) :
    Coboundary h v := by
  let h' : Grid L := fun i j => -v (-i) (-j)
  let v' : Grid L := fun i j => h (-i) (-j)
  have he (i : ZMod L) : -(i+1) = -i-1 := by abel
  have closed : Closed h' v' := by
    intro i j
    dsimp [h',v']
    rw [he i,he j]
    linear_combination hc (-i) (-j)
  have oh : occupation h'=occupation v := by
    calc
      _ = occupation (fun i j => v (-i) (-j)) := by simp [occupation,h']
      _ = _ := occupation_reverse _
  have ov : occupation v'=occupation h := occupation_reverse _
  have small' : weight h' v'<L := by
    simpa [weight,oh,ov,Nat.add_comm] using small
  obtain ⟨f,hh,hv⟩ := low_weight_boundary h' v' closed small'
  refine ⟨fun i j => -f (-i) (-j),?_,?_⟩
  · intro i j
    have e := hv (-i) (-j)
    dsimp [v'] at e
    rw [neg_neg,neg_neg] at e
    change h i j = -f (-(i-1)) (-j) - -f (-i) (-j)
    rw [show -(i-1) = -i+1 by abel]
    linear_combination e
  · intro i j
    have e := hh (-i) (-j)
    dsimp [h'] at e
    rw [neg_neg,neg_neg] at e
    change v i j = -f (-i) (-(j-1)) - -f (-i) (-j)
    rw [show -(j-1) = -j+1 by abel]
    linear_combination -e

/-- A horizontal winding loop has exactly L edges and cannot be a boundary. -/
theorem sharp : ∃ h v : Grid L, Closed h v ∧ ¬Boundary h v ∧ weight h v=L := by
  classical
  let h : Grid L := fun _ j => if j=0 then 1 else 0
  let v : Grid L := fun _ _ => 0
  refine ⟨h,v,?_,?_,?_⟩
  · intro i j; simp [h,v]
  · rintro ⟨f,hf,_⟩
    have he := Finset.sum_congr (s₁ := (Finset.univ : Finset (ZMod L))) rfl (fun j _ => hf 0 j)
    have shift := Equiv.sum_comp (Equiv.addRight (1:ZMod L)) (f 0)
    change (∑ j, f 0 (j+1)) = ∑ j, f 0 j at shift
    simp [h,Finset.sum_sub_distrib,shift] at he
  · have support : ((Finset.univ : Finset (ZMod L × ZMod L)).filter (fun ij => h ij.1 ij.2 ≠ 0))
        = Finset.univ ×ˢ {0} := by
      ext ⟨i,j⟩
      simp [h,eq_comm]
    simp [weight,occupation,support,v,ZMod.card]

#print axioms low_weight_coboundary
#print axioms sharp
#print axioms distance
end ToricBinary
