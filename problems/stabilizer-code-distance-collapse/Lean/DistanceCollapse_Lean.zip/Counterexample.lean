import PauliBasic

/-! A free cyclic stabilizer over Z/4 whose relative symplectic distance
is one, whereas its reduction over F₂ has relative symplectic distance two. -/
namespace FrobeniusCounterexample
open CyclicPauli
open scoped BigOperators
variable {R : Type*} [CommRing R]

/-- The three coefficients are for the marked ancilla Z, data X check, and data Z check. -/
def enc (c : Fin 3 → R) : Labels R 5 :=
  ![(0,c 0),(c 1,2*c 0+c 2),(c 1,-2*c 0+c 2),(c 1,-c 2),(c 1,-c 2)]

def encoder (R : Type*) [CommRing R] : (Fin 3 → R) →ₗ[R] Labels R 5 where
  toFun := enc
  map_add' a b := by
    funext i; fin_cases i <;> apply Prod.ext <;> dsimp [enc] <;> ring
  map_smul' c a := by
    funext i; fin_cases i <;> apply Prod.ext <;> dsimp [enc] <;> ring

def code (R : Type*) [CommRing R] := LinearMap.range (encoder R)

theorem enc_injective : Function.Injective (enc (R:=R)) := by
  intro a b h
  have h0 := congrArg (fun x : Labels R 5 => (x 0).2) h
  have h1 := congrArg (fun x : Labels R 5 => (x 1).1) h
  have h2 := congrArg (fun x : Labels R 5 => (x 3).2) h
  funext i; fin_cases i
  · exact h0
  · exact h1
  · exact neg_injective h2

noncomputable def freeBasis (R : Type*) [CommRing R] : (Fin 3 → R) ≃ₗ[R] code R :=
  LinearEquiv.ofInjective (encoder R) enc_injective

theorem free (R : Type*) [CommRing R] : Module.Free R (code R) :=
  Module.Free.of_equiv (freeBasis R)

theorem isotropic (R : Type*) [CommRing R] : Isotropic (code R) := by
  rintro _ ⟨a,rfl⟩ _ ⟨b,rfl⟩
  change bracket (enc a) (enc b)=0
  simp [bracket,Fin.sum_univ_succ,enc] <;> ring

abbrev res : ZMod 4 →+* ZMod 2 := ZMod.castHom (by decide) (ZMod 2)

def reduce (v : Labels (ZMod 4) 5) : Labels (ZMod 2) 5 := fun i => (res (v i).1,res (v i).2)

theorem reduce_enc (a : Fin 3 → ZMod 4) : reduce (enc a)=enc (fun i => res (a i)) := by
  revert a
  decide +kernel

theorem reduction_exact : reduce '' (code (ZMod 4) : Set _) = (code (ZMod 2) : Set _) := by
  ext x
  constructor
  · rintro ⟨_,⟨a,rfl⟩,rfl⟩
    exact ⟨fun i => res (a i),(reduce_enc a).symm⟩
  · rintro ⟨a,rfl⟩
    let b : Fin 3 → ZMod 4 := fun i => ((a i).val:ZMod 4)
    refine ⟨enc b,⟨b,rfl⟩,?_⟩
    rw [reduce_enc]
    apply congrArg enc
    funext i
    change res ((a i).val:ZMod 4)=a i
    rw [map_natCast,ZMod.natCast_zmod_val]

def wt {n : ℕ} [DecidableEq R] (x : Labels R n) := (Finset.univ.filter (fun i => x i≠0)).card

def logical {n : ℕ} (C : Submodule R (Labels R n)) (x : Labels R n) : Prop :=
  (∀ y∈C,bracket x y=0) ∧ x∉C

noncomputable def relativeDistance {n : ℕ} [DecidableEq R] (C : Submodule R (Labels R n)) : ℕ :=
  sInf {w | ∃ x : Labels R n, logical C x ∧ wt x=w}

private theorem realize_distance {n : ℕ} [DecidableEq R] {C : Submodule R (Labels R n)} {d : ℕ}
    (witness : ∃ x, logical C x ∧ wt x=d) (lower : ∀ x, logical C x → d≤wt x) :
    relativeDistance C=d := by
  apply le_antisymm
  · exact Nat.sInf_le witness
  · apply le_csInf ⟨d,witness⟩
    rintro _ ⟨x,h,rfl⟩; exact lower x h

private def e0 : Labels (ZMod 4) 5 := ![(0,1),0,0,0,0]

theorem ring_distance : relativeDistance (code (ZMod 4)) = 1 := by
  apply realize_distance
  · refine ⟨e0,⟨?_,?_⟩,by decide⟩
    · rintro _ ⟨a,rfl⟩
      change bracket e0 (enc a)=0
      simp [e0,bracket,enc,Fin.sum_univ_succ]
    · rintro ⟨a,h⟩
      have h0 := congrArg (fun x : Labels (ZMod 4) 5 => (x 0).2) h
      have h1 := congrArg (fun x : Labels (ZMod 4) 5 => (x 1).2) h
      have h3 := congrArg (fun x : Labels (ZMod 4) 5 => (x 3).2) h
      change a 0=1 at h0
      change 2*a 0+a 2=0 at h1
      change -a 2=0 at h3
      rw [h0,neg_eq_zero.mp h3] at h1
      exact (by decide : (2:ZMod 4)≠0) (by simpa using h1)
  · intro x h
    by_contra! hz
    have e : (Finset.univ.filter (fun i => x i≠0))=∅ := Finset.card_eq_zero.mp (by change wt x=0; omega)
    have hx : x=0 := by
      funext i
      by_contra hi
      have hm : i∈Finset.univ.filter (fun j => x j≠0) := Finset.mem_filter.mpr ⟨Finset.mem_univ _,hi⟩
      rw [e] at hm; exact Finset.notMem_empty _ hm
    exact h.2 (hx ▸ (code (ZMod 4)).zero_mem)

private def e12 : Labels (ZMod 2) 5 := ![0,(0,1),(0,1),0,0]

private theorem binary_small : ∀ (x : Labels (ZMod 2) 5), wt x < 2 →
    bracket x (enc ![1,0,0])=0 → bracket x (enc ![0,1,0])=0 →
    bracket x (enc ![0,0,1])=0 → x=enc ![(x 0).2,0,0] := by decide +kernel

theorem field_distance : relativeDistance (code (ZMod 2)) = 2 := by
  apply realize_distance
  · refine ⟨e12,⟨?_,?_⟩,by decide⟩
    · rintro _ ⟨a,rfl⟩
      change bracket e12 (enc a)=0
      simp [e12,bracket,enc,Fin.sum_univ_succ]
      ring_nf
      rw [show (2:ZMod 2)=0 by decide,mul_zero]
    · rintro ⟨a,h⟩
      have h0 := congrArg (fun x : Labels (ZMod 2) 5 => (x 0).2) h
      have h1 := congrArg (fun x : Labels (ZMod 2) 5 => (x 1).2) h
      have h3 := congrArg (fun x : Labels (ZMod 2) 5 => (x 3).2) h
      change a 0=0 at h0
      change 2*a 0+a 2=1 at h1
      change -a 2=0 at h3
      rw [h0,neg_eq_zero.mp h3] at h1
      norm_num at h1
  · intro x h
    by_contra! hz
    have c (a : Fin 3 → ZMod 2) := h.1 (enc a) ⟨a,rfl⟩
    have e := binary_small x hz (c _) (c _) (c _)
    exact h.2 ⟨_,e.symm⟩

/-- Counterexample to Gluesing-Luerssen and Pllaha, Conjecture 5.5. -/
theorem counterexample : Module.Free (ZMod 4) (code (ZMod 4)) ∧
    Isotropic (code (ZMod 4)) ∧ reduce '' (code (ZMod 4) : Set _) = (code (ZMod 2) : Set _) ∧
    relativeDistance (code (ZMod 4)) = 1 ∧ relativeDistance (code (ZMod 2)) = 2 :=
  ⟨free _,isotropic _,reduction_exact,ring_distance,field_distance⟩
#print axioms counterexample
end FrobeniusCounterexample
