import PrescribedDefs

namespace PrescribedLDI
open CyclicPauli FrobeniusCounterexample
open scoped BigOperators
set_option maxHeartbeats 0
set_option maxRecDepth 1000000

abbrev F := ZMod 2
def twoSites (i j : Site) (u v : F×F) : Labels F 7 :=
  fun k => if k=i then u else if k=j then v else 0

private theorem binary_test : ∀ (i j : Site) (u v : F×F),
    (∀ g:Row, bracket (twoSites i j u v) (rowR g)=0) →
    ∀ k:Site, twoSites i j u v k = enc (fun a:Row => (twoSites i j u v a.castSucc).1) k := by
  decide +kernel

private theorem tiny_supported {R : Type*} [CommRing R] [DecidableEq R]
    (b : Labels R 7) (small : wt b≤2) : ∃ i j : Site,
      ∀ k : Site, k≠i → k≠j → b k=0 := by
  let s := (Finset.univ : Finset Site).filter (fun i=> b i≠0)
  obtain ⟨t,st,_,ht⟩ := Finset.exists_subsuperset_card_eq (Finset.subset_univ s) small
    (show 2≤ (Finset.univ : Finset Site).card by decide)
  obtain ⟨i,j,_,h⟩ := Finset.card_eq_two.mp ht
  refine ⟨i,j,fun k ki kj => ?_⟩
  by_contra h'
  have hm : k∈t := st (Finset.mem_filter.mpr ⟨Finset.mem_univ _,h'⟩)
  simpa [h,ki,kj] using hm

private theorem binary_lower (e : Labels F 7) (h : logical (code F) e) : 3≤wt e := by
  by_contra! small
  obtain ⟨i,j,off⟩ := tiny_supported e (by omega)
  have ee : e=twoSites i j (e i) (e j) := by
    funext k
    by_cases ki:k=i
    · simp [twoSites,ki]
    · by_cases kj:k=j
      · subst k; simp [twoSites,ki]
      · simp [twoSites,ki,kj,off k ki kj]
  have norm (g:Row) : bracket (twoSites i j (e i) (e j)) (rowR g)=0 := by
    rw [← ee]
    exact h.1 (rowR g) ⟨Pi.single g 1,rfl⟩
  have recon :=  funext (binary_test i j (e i) (e j) norm)
  rw [← ee] at recon
  exact h.2 ⟨fun a:Row=>(e a.castSucc).1,recon.symm⟩

def three : Labels F 7 := ![(1,0),(1,1),(0,1),0,0,0,0]

private theorem three_logical : logical (code F) three := by
  constructor
  · rintro _ ⟨c,rfl⟩
    change bracket three (enc c)=0
    revert c
    decide +kernel
  · rintro ⟨c,e⟩
    change enc c=three at e
    have h (i:Row) : c i=(three i.castSucc).1 := by rw [←e,pivot]
    have he : c=fun i:Row=>(three i.castSucc).1 := funext h
    rw [he] at e
    exact (by decide : enc (fun i:Row=>(three i.castSucc).1)≠three) e

theorem binary_distance : relativeDistance (code F)=3 := by
  let s : Set ℕ := {w | ∃ x : Labels F 7, logical (code F) x ∧ wt x=w}
  have h3 : 3∈s := ⟨three,three_logical,by decide⟩
  change sInf s=3
  apply le_antisymm (Nat.sInf_le h3)
  · apply le_csInf ⟨3,h3⟩
    rintro _ ⟨x,h,rfl⟩
    exact binary_lower x h

theorem large_distance_le_two (p : ℕ) [Fact p.Prime] (hp : 2<p) :
    relativeDistance (code (ZMod p))≤2 := by
  have h2 : (2:ZMod p) ≠ 0 := by
    intro z
    have e := congrArg ZMod.val z
    simp [ZMod.val_ofNat,Nat.mod_eq_of_lt hp] at e
  exact Nat.sInf_le ⟨short _,short_logical _ h2,short_weight _⟩

#print axioms binary_distance
#print axioms large_distance_le_two
end PrescribedLDI
