import TwistedTorus

/-! Physical labels on the 2L² edges and the free stabilizer module of the
square torus with flat sign transport and one check deleted in each layer. -/
namespace TwistedCode
open TwistedTorus
open ToricLift (Grid)
open scoped BigOperators
variable {L : ℕ} [NeZero L] {R : Type*} [CommRing R]

abbrev Site (L : ℕ) := Bool × ZMod L × ZMod L
abbrev State (R : Type*) (L : ℕ) := Site L → R×R
abbrev pinSet (L : ℕ) := {p : ZMod L × ZMod L // p≠(0,0)}
abbrev Inputs (R : Type*) (L : ℕ) := Fin 2 → pinSet L → R

def pin (a : pinSet L → R) (i j : ZMod L) : R := if h:(i,j)=(0,0) then 0 else a ⟨(i,j),h⟩

def pack (x z : Edges R L) : State R L
  | (false,i,j) => (x.1 i j,z.1 i j)
  | (true,i,j) => (x.2 i j,z.2 i j)

def check (a b : pinSet L → R) : State R L := pack (starCheck (pin a)) (faceCheck (pin b))

def pairing (x y : State R L) : R := ∑ s, ((x s).1*(y s).2-(x s).2*(y s).1)

theorem pairing_pack (x z u v : Edges R L) : pairing (pack x z) (pack u v) = dot x v-dot u z := by
  simp only [pairing,Fintype.sum_prod_type,Fintype.sum_bool,pack,dot,Finset.sum_sub_distrib]
  simp only [mul_comm (z.1 _ _) (u.1 _ _),mul_comm (z.2 _ _) (u.2 _ _)]
  ring

private theorem pin_add (a b : pinSet L → R) (i j) : pin (a+b) i j=pin a i j+pin b i j := by
  by_cases e:(i,j)=(0,0) <;> simp [pin,e]
private theorem pin_smul (t : R) (a : pinSet L → R) (i j) : pin (t • a) i j=t*pin a i j := by
  by_cases e:(i,j)=(0,0) <;> simp [pin,e]

def encoder (R : Type*) [CommRing R] (L : ℕ) [NeZero L] :
    Inputs R L →ₗ[R] State R L where
  toFun t := check (t 0) (t 1)
  map_add' a b := by
    funext ⟨d,i,j⟩
    cases d <;> apply Prod.ext <;> simp [check,pack,starCheck,faceCheck,Pi.add_apply,pin_add] <;> ring
  map_smul' t a := by
    funext ⟨d,i,j⟩
    cases d <;> apply Prod.ext <;> simp [check,pack,starCheck,faceCheck,Pi.smul_apply,pin_smul] <;> ring

def C (R : Type*) [CommRing R] (L : ℕ) [NeZero L] := (encoder R L).range

theorem pin_injective : Function.Injective (pin (R:=R) (L:=L)) := by
  intro a b h
  funext ⟨p,hp⟩
  have e := congrFun (congrFun h p.1) p.2
  simpa only [pin,dif_neg hp] using e

theorem encoder_injective : Function.Injective (encoder R L) := by
  intro a b h
  have px : starCheck (pin (a 0))=starCheck (pin (b 0)) := by
    apply Prod.ext
    · funext i j; exact congrArg (fun z : State R L => (z (false,i,j)).1) h
    · funext i j; exact congrArg (fun z : State R L => (z (true,i,j)).1) h
  have pz : faceCheck (pin (a 1))=faceCheck (pin (b 1)) := by
    apply Prod.ext
    · funext i j; exact congrArg (fun z : State R L => (z (false,i,j)).2) h
    · funext i j; exact congrArg (fun z : State R L => (z (true,i,j)).2) h
  funext i
  fin_cases i
  · exact pin_injective (star_pinned_injective _ _ (by simp [pin]) px)
  · exact pin_injective (face_pinned_injective _ _ (by simp [pin]) pz)

noncomputable def freeBasis : Inputs R L ≃ₗ[R] C R L :=
  LinearEquiv.ofInjective (encoder R L) encoder_injective

theorem free : Module.Free R (C R L) := Module.Free.of_equiv freeBasis

theorem isotropy {x y : State R L} (hx : x∈C R L) (hy : y∈C R L) : pairing x y=0 := by
  obtain ⟨a,rfl⟩ := hx
  obtain ⟨b,rfl⟩ := hy
  change pairing (pack (starCheck (pin (a 0))) (faceCheck (pin (a 1))))
    (pack (starCheck (pin (b 0))) (faceCheck (pin (b 1))))=0
  rw [pairing_pack,commute,commute,sub_self]

abbrev res : ZMod 4 →+* ZMod 2 := ZMod.castHom (by decide) (ZMod 2)
def red (x : State (ZMod 4) L) : State (ZMod 2) L := fun s => (res (x s).1,res (x s).2)

private theorem respin (a : pinSet L → ZMod 4) (i j) : res (pin a i j)=pin (res ∘ a) i j := by
  by_cases e:(i,j)=(0,0) <;> simp [pin,e]
private theorem ressign (i : ZMod L) : res (sign (ZMod 4) i)=sign (ZMod 2) i := by
  by_cases e:i+1=0 <;> simp [sign,e]

theorem red_check (a b : pinSet L → ZMod 4) : red (check a b)=check (res ∘ a) (res ∘ b) := by
  funext ⟨d,i,j⟩
  cases d <;> apply Prod.ext <;> simp only [red,check,pack,starCheck,faceCheck,map_sub,map_mul,respin,ressign]

theorem code_reduce : red '' (C (ZMod 4) L : Set (State (ZMod 4) L)) = (C (ZMod 2) L : Set (State (ZMod 2) L)) := by
  ext x
  constructor
  · rintro ⟨_,⟨a,rfl⟩,rfl⟩
    exact ⟨fun k => res ∘ a k,(red_check (a 0) (a 1)).symm⟩
  · rintro ⟨a,rfl⟩
    let b : Inputs (ZMod 4) L := fun k i => ((a k i).val:ZMod 4)
    refine ⟨encoder _ _ b,⟨b,rfl⟩,?_⟩
    change red (check (b 0) (b 1))=check (a 0) (a 1)
    rw [red_check]
    have eq (k) : res ∘ b k = a k := by
      funext i
      change res ((a k i).val:ZMod 4)=a k i
      rw [map_natCast,ZMod.natCast_zmod_val]
    rw [eq,eq]

def stateWeight [DecidableEq R] (x : State R L) := (Finset.univ.filter (fun s => x s≠0)).card
def Normal (x : State R L) : Prop := ∀ y∈C R L,pairing x y=0

def omitted (R : Type*) [CommRing R] (L : ℕ) [NeZero L] : State R L := pack 0 (faceCheck (point R))

theorem omitted_normal : Normal (omitted R L) := by
  rintro _ ⟨a,rfl⟩
  change pairing (pack 0 (faceCheck (point R)))
    (pack (starCheck (pin (a 0))) (faceCheck (pin (a 1))))=0
  rw [pairing_pack,commute]; simp [dot]

theorem omitted_not_mem (htwo : (2:R)≠0) : omitted R L∉C R L := by
  rintro ⟨a,e⟩
  apply excluded_face htwo (pin (a 1)) (by simp [pin])
  apply Prod.ext
  · funext i j; exact congrArg (fun x : State R L => (x (false,i,j)).2) e
  · funext i j; exact congrArg (fun x : State R L => (x (true,i,j)).2) e

#print axioms code_reduce
#print axioms omitted_not_mem
end TwistedCode
